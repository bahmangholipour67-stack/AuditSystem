# Phase 66 – Startup dependency fix

- The Word-export package `python-docx` is now loaded only when a Word export is requested.
- A missing Word package no longer blocks AuditSystem startup.
- Run `INSTALL_DEPENDENCIES.bat` once to install packages listed in `requirements.txt` and verify `python-docx`.
- Then run `run_demo.bat` as before.
- If package installation fails, check internet/proxy access; the app can still start, but Word export requires `python-docx`.
