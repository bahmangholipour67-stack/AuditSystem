# Phase 46 — Evidence Management Engine (Foundation)

This phase adds a reusable, UI/database-independent evidence-management service foundation.


## Included
- Metadata validation for title, source, recipient, and received date.
- Evidence status vocabulary and guarded transitions.
- Link validation for engagements, risks, accounts, assertions, procedures, tests, samples, workpapers, and findings.
- Duplicate-link removal while preserving order.
- SHA-256 file fingerprinting for integrity/duplicate-check workflows.
- Duplicate fingerprint lookup across supplied metadata records.

## Status transitions
- Received → In Review or Archived
- In Review → Approved, Rejected, Received, or Archived
- Approved → Archived
- Rejected → Received or Archived
- Archived → no further transition

The service is not yet wired into the GUI or persistent evidence repository. No file storage, database migration, permissions screen, or reviewer workflow is claimed in this phase. This package adds tested foundations only.


## Tests
Run from the project directory:

```bash
python -m pytest -q
```

