# Phase 42 — Risk Heatmap & Interactive Risk Center (service foundation)

Adds a read-only service foundation for 5x5 risk heatmap analytics.

- Validates likelihood and impact ratings from 1 to 5.
- Builds 25 matrix cells and counts valid supplied risk records by likelihood/impact.
- Computes inherent and residual scores only when both rating pairs are explicitly supplied; does not infer control effectiveness or residual values.
- Provides cell filtering for callers/UI.
- Invalid records are skipped in aggregation; direct rating/score validation raises `ValueError`.
- Does not write to the database and is not yet wired to the graphical UI.


## Validation

Run from the project folder:

`python -m pytest -q`

Latest environment run: **243 passed, 131 subtests passed**.
