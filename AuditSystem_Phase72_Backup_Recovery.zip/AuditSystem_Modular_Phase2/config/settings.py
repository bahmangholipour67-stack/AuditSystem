from pathlib import Path
import os
BASE_DIR = Path(__file__).resolve().parents[1]
LEGACY_DIR = BASE_DIR / "legacy"
DATABASE_PATH = Path(os.environ.get("AUDITSYSTEM_DB_PATH", LEGACY_DIR / "audit_system.db")).expanduser()
if not DATABASE_PATH.is_absolute():
    DATABASE_PATH = BASE_DIR / DATABASE_PATH
APP_TITLE = "سامانه مدیریت و تحلیل حسابرسی"
