# -*- coding: utf-8 -*-
"""Install Phase 15 safe-delete controls. Run from project root: py install_phase15_safe_delete.py"""
import ast, datetime, shutil, sqlite3, sys, tempfile, types
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'legacy' / 'audit_system.db'
FILES = {
    'project_view': ROOT / 'ui/views/project_view.py',
    'project_repo': ROOT / 'repositories/project_repository.py',
    'risk_repo': ROOT / 'repositories/risk_repository.py',
    'workpaper_repo': ROOT / 'repositories/workpaper_repository.py',
    'finding_repo': ROOT / 'repositories/finding_repository.py',
}

PROJECT_DELETE = '''
    def delete(self, project_id):
        """Delete an empty project only; any project-scoped row blocks deletion."""
        with connect() as conn:
            if not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                return False
            dependencies = []
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
            for (table_name,) in tables:
                if table_name == 'projects':
                    continue
                escaped = table_name.replace('"', '""')
                columns = {r[1] for r in conn.execute(f'PRAGMA table_info("{escaped}")').fetchall()}
                if 'project_id' not in columns:
                    continue
                count = conn.execute(f'SELECT COUNT(*) FROM "{escaped}" WHERE project_id=?', (project_id,)).fetchone()[0]
                if count:
                    dependencies.append(f'{table_name}: {count}')
            if dependencies:
                raise ValueError('این پرونده دارای اطلاعات وابسته است و حذف آن مجاز نیست:\\n' + '\\n'.join(dependencies))
            return conn.execute('DELETE FROM projects WHERE id=?', (project_id,)).rowcount > 0
'''

RISK_DELETE = '''
    def delete(self, project_id, risk_id):
        """Delete a risk only when no project-scoped row refers to it."""
        with connect() as conn:
            if not conn.execute('SELECT 1 FROM risks WHERE id=? AND project_id=?', (risk_id, project_id)).fetchone():
                return False
            dependencies = []
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
            for (table_name,) in tables:
                if table_name == 'risks':
                    continue
                escaped = table_name.replace('"', '""')
                columns = {r[1] for r in conn.execute(f'PRAGMA table_info("{escaped}")').fetchall()}
                if not {'project_id', 'risk_id'}.issubset(columns):
                    continue
                count = conn.execute(f'SELECT COUNT(*) FROM "{escaped}" WHERE project_id=? AND risk_id=?', (project_id, risk_id)).fetchone()[0]
                if count:
                    dependencies.append(f'{table_name}: {count}')
            if dependencies:
                raise ValueError('این ریسک به اطلاعات دیگری متصل است و حذف آن مجاز نیست:\\n' + '\\n'.join(dependencies))
            return conn.execute('DELETE FROM risks WHERE id=? AND project_id=?', (risk_id, project_id)).rowcount > 0
'''

WORKPAPER_DELETE = '''
    def delete(self, project_id, workpaper_id):
        """Only an unreferenced draft workpaper can be physically deleted."""
        with connect() as conn:
            row = conn.execute('SELECT status FROM workpapers WHERE id=? AND project_id=?', (workpaper_id, project_id)).fetchone()
            if not row:
                return False
            if row[0] != 'پیش‌نویس':
                raise ValueError('فقط کاربرگِ در وضعیت «پیش‌نویس» قابل حذف است. کاربرگ ارسال‌شده، بررسی‌شده یا تأییدشده باید در سوابق باقی بماند.')
            dependencies = []
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
            for (table_name,) in tables:
                if table_name == 'workpapers':
                    continue
                escaped = table_name.replace('"', '""')
                columns = {r[1] for r in conn.execute(f'PRAGMA table_info("{escaped}")').fetchall()}
                if not {'project_id', 'workpaper_id'}.issubset(columns):
                    continue
                count = conn.execute(f'SELECT COUNT(*) FROM "{escaped}" WHERE project_id=? AND workpaper_id=?', (project_id, workpaper_id)).fetchone()[0]
                if count:
                    dependencies.append(f'{table_name}: {count}')
            if dependencies:
                raise ValueError('این کاربرگ دارای سابقه یا اطلاعات وابسته است و حذف آن مجاز نیست:\\n' + '\\n'.join(dependencies))
            return conn.execute('DELETE FROM workpapers WHERE id=? AND project_id=?', (workpaper_id, project_id)).rowcount > 0
'''

FINDING_DELETE = '''
    def delete(self, project_id, finding_id):
        """Only an open finding without evidence or linked records can be deleted."""
        with connect() as conn:
            row = conn.execute('SELECT status FROM findings WHERE id=? AND project_id=?', (finding_id, project_id)).fetchone()
            if not row:
                return False
            if row[0] != 'باز':
                raise ValueError('فقط یافته با وضعیت «باز» قابل حذف است. یافته رفع‌شده یا بسته‌شده باید در سوابق حسابرسی باقی بماند.')
            dependencies = []
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
            for (table_name,) in tables:
                if table_name == 'findings':
                    continue
                escaped = table_name.replace('"', '""')
                columns = {r[1] for r in conn.execute(f'PRAGMA table_info("{escaped}")').fetchall()}
                if not {'project_id', 'finding_id'}.issubset(columns):
                    continue
                count = conn.execute(f'SELECT COUNT(*) FROM "{escaped}" WHERE project_id=? AND finding_id=?', (project_id, finding_id)).fetchone()[0]
                if count:
                    dependencies.append(f'{table_name}: {count}')
            if dependencies:
                raise ValueError('این یافته دارای مستندات، سابقه یا ارتباط با آزمون حسابرسی است و حذف آن مجاز نیست:\\n' + '\\n'.join(dependencies))
            return conn.execute('DELETE FROM findings WHERE id=? AND project_id=?', (finding_id, project_id)).rowcount > 0
'''

PROJECT_UI_METHOD = '''
    def delete_selected_project(self):
        selected = self.tree_projects.selection()
        if not selected:
            messagebox.showinfo('انتخاب پرونده', 'ابتدا پرونده موردنظر را انتخاب کنید.', parent=self.root)
            return
        values = self.tree_projects.item(selected[0], 'values')
        project_id, project_name = int(values[0]), str(values[1])
        if not messagebox.askyesno(
            'تأیید حذف پرونده',
            f'آیا از درخواست حذف پرونده «{project_name}» مطمئن هستید؟\\n\\n'
            'حذف فقط زمانی انجام می‌شود که هیچ اطلاعات وابسته‌ای در پرونده وجود نداشته باشد.\\n'
            'در صورت وجود اطلاعات، برنامه حذف را متوقف و جدول‌های دارای رکورد را اعلام می‌کند.\\n\\n'
            'این عملیات قابل بازگشت نیست.', parent=self.root
        ):
            return
        try:
            deleted = self.services.projects.delete(project_id)
            if not deleted:
                messagebox.showwarning('حذف انجام نشد', 'پرونده پیدا نشد یا قبلاً حذف شده است.', parent=self.root)
                self.load_projects()
                return
            self.load_projects()
            messagebox.showinfo('حذف موفق', f'پرونده «{project_name}» حذف شد.', parent=self.root)
        except Exception as exc:
            messagebox.showwarning('امکان حذف وجود ندارد', str(exc), parent=self.root)
'''


def parse(src, label):
    try: return ast.parse(src, filename=label)
    except SyntaxError as e: raise RuntimeError(f'خطای نحوی در {label}: {e}')


def add_import(src, label):
    tree = parse(src, label)
    if any(isinstance(n, ast.ImportFrom) and n.module == 'database.connection' and any(a.name == 'connect' for a in n.names) for n in tree.body):
        return src
    lines = src.splitlines(keepends=True)
    line = 0
    if tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(tree.body[0].value, ast.Constant) and isinstance(tree.body[0].value.value, str):
        line = tree.body[0].end_lineno
    for n in tree.body:
        if isinstance(n, ast.ImportFrom) and n.module == '__future__': line = max(line, n.end_lineno)
    offset = sum(len(x) for x in lines[:line])
    return src[:offset] + 'from database.connection import connect\n' + src[offset:]


def method_node(tree, cls_name, method_name):
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls_name), None)
    if cls is None: raise RuntimeError(f'کلاس {cls_name} پیدا نشد.')
    node = next((n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method_name), None)
    if node is None: raise RuntimeError(f'متد {cls_name}.{method_name} پیدا نشد.')
    return cls, node


def replace_method(src, cls_name, method_name, replacement, label):
    tree = parse(src, label); _, node = method_node(tree, cls_name, method_name)
    lines = src.splitlines(keepends=True)
    start, end = sum(map(len, lines[:node.lineno-1])), sum(map(len, lines[:node.end_lineno]))
    return src[:start] + replacement.strip('\n') + '\n\n' + src[end:].lstrip('\n')


def append_method(src, cls_name, method, label):
    tree = parse(src, label); cls, _ = method_node(tree, cls_name, '__init__') if False else (None, None)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls_name), None)
    if cls is None: raise RuntimeError(f'کلاس {cls_name} پیدا نشد.')
    if any(isinstance(n, ast.FunctionDef) and n.name == 'delete' for n in cls.body):
        raise RuntimeError(f'متد delete از قبل در {cls_name} وجود دارد؛ نصب متوقف شد.')
    return src.rstrip() + '\n\n' + method.strip('\n') + '\n'


def make_sources():
    result = {}
    p = FILES['project_view']; src = p.read_text(encoding='utf-8-sig'); parse(src, str(p))
    # Add visible delete button after the edit button, preserving all other UI code.
    anchor = '''        ttk.Button(\n            buttons,\n            text="ویرایش پرونده",\n            command=self.edit_selected_project\n        ).pack(side="right", padx=4)'''
    button = anchor + '''\n\n        ttk.Button(\n            buttons,\n            text="حذف پرونده",\n            command=self.delete_selected_project\n        ).pack(side="right", padx=4)'''
    if 'text="حذف پرونده"' not in src:
        if anchor not in src: raise RuntimeError('محل درج دکمه حذف در project_view.py پیدا نشد.')
        src = src.replace(anchor, button, 1)
    old_nav = 'self.add_record_navigation(tab, self.tree_projects, on_edit=self.edit_selected_project, label="پرونده")'
    new_nav = 'self.add_record_navigation(tab, self.tree_projects, on_edit=self.edit_selected_project, on_delete=self.delete_selected_project, label="پرونده")'
    if old_nav in src: src = src.replace(old_nav, new_nav, 1)
    elif new_nav not in src: raise RuntimeError('فراخوانی ناوبری پرونده در project_view.py پیدا نشد.')
    if 'def delete_selected_project(self):' not in src: src = src.rstrip() + '\n\n' + PROJECT_UI_METHOD.strip() + '\n'
    result[p] = src

    p = FILES['project_repo']; src = add_import(p.read_text(encoding='utf-8-sig'), str(p))
    result[p] = append_method(src, 'ProjectRepository', PROJECT_DELETE, str(p))
    for key, cls, body in [('risk_repo','RiskRepository',RISK_DELETE), ('workpaper_repo','WorkpaperRepository',WORKPAPER_DELETE), ('finding_repo','FindingRepository',FINDING_DELETE)]:
        p = FILES[key]; src = add_import(p.read_text(encoding='utf-8-sig'), str(p))
        result[p] = replace_method(src, cls, 'delete', body, str(p))
    for p, src in result.items(): compile(src, str(p), 'exec')
    return result


def test_on_copy(sources):
    with tempfile.TemporaryDirectory(prefix='phase15_safe_delete_') as td:
        test_db = Path(td) / 'audit_test.db'; shutil.copy2(DB, test_db)
        def tx():
            conn = sqlite3.connect(str(test_db))
            class Ctx:
                def __enter__(self): return conn
                def __exit__(self, typ, val, tb):
                    conn.commit() if typ is None else conn.rollback(); conn.close()
            return Ctx()
        repos = {}
        for key, cls in [('project_repo','ProjectRepository'),('risk_repo','RiskRepository'),('workpaper_repo','WorkpaperRepository'),('finding_repo','FindingRepository')]:
            p = FILES[key]; module = types.ModuleType('_safe_test_'+key); module.__file__ = str(p)
            exec(compile(sources[p], str(p), 'exec'), module.__dict__); module.connect = tx
            repos[key] = getattr(module, cls)()
        def sql(q, args=()):
            with tx() as c: return c.execute(q,args).lastrowid
        def must_block(fn, label):
            try: fn()
            except ValueError: return
            raise RuntimeError('آزمون جلوگیری از حذف ناموفق: '+label)
        p=sql("INSERT INTO projects(name,period) VALUES('P0','T')"); assert repos['project_repo'].delete(p)
        p=sql("INSERT INTO projects(name,period) VALUES('P1','T')"); sql("INSERT INTO team_members(project_id,full_name) VALUES(?,'M')",(p,)); must_block(lambda:repos['project_repo'].delete(p),'project dependency')
        p=sql("INSERT INTO projects(name,period) VALUES('P2','T')"); r=sql("INSERT INTO risks(project_id,title,score) VALUES(?,'R',1)",(p,)); assert repos['risk_repo'].delete(p,r)
        r=sql("INSERT INTO risks(project_id,title,score) VALUES(?,'R2',1)",(p,)); sql("INSERT INTO workpapers(project_id,risk_id,title,status) VALUES(?,?,?,'پیش‌نویس')",(p,r,'W')); must_block(lambda:repos['risk_repo'].delete(p,r),'risk dependency')
        p=sql("INSERT INTO projects(name,period) VALUES('P3','T')"); w=sql("INSERT INTO workpapers(project_id,title,status) VALUES(?,'D','پیش‌نویس')",(p,)); assert repos['workpaper_repo'].delete(p,w)
        w=sql("INSERT INTO workpapers(project_id,title,status) VALUES(?,'A','نهایی و تأیید')",(p,)); must_block(lambda:repos['workpaper_repo'].delete(p,w),'approved workpaper')
        w=sql("INSERT INTO workpapers(project_id,title,status) VALUES(?,'H','پیش‌نویس')",(p,)); sql("INSERT INTO workpaper_history(project_id,workpaper_id,action) VALUES(?,?,?)",(p,w,'test')); must_block(lambda:repos['workpaper_repo'].delete(p,w),'workpaper history')
        p=sql("INSERT INTO projects(name,period) VALUES('P4','T')"); f=sql("INSERT INTO findings(project_id,title,status) VALUES(?,'O','باز')",(p,)); assert repos['finding_repo'].delete(p,f)
        f=sql("INSERT INTO findings(project_id,title,status) VALUES(?,'C','رفع‌شده')",(p,)); must_block(lambda:repos['finding_repo'].delete(p,f),'closed finding')
        f=sql("INSERT INTO findings(project_id,title,status) VALUES(?,'E','باز')",(p,)); sql("INSERT INTO finding_evidence(project_id,finding_id,file_path) VALUES(?,?,?)",(p,f,'evidence.pdf')); must_block(lambda:repos['finding_repo'].delete(p,f),'finding evidence')
    return ['پرونده خالی / پرونده دارای وابستگی','ریسک مستقل / ریسک دارای کاربرگ','کاربرگ پیش‌نویس / تأییدشده / دارای تاریخچه','یافته باز / رفع‌شده / دارای مستند']


def main():
    if sys.version_info < (3,10): raise RuntimeError('Python 3.10 یا بالاتر لازم است.')
    missing=[str(p) for p in FILES.values() if not p.is_file()]
    if missing: raise RuntimeError('فایل‌های لازم پیدا نشدند:\n'+'\n'.join(missing))
    if not DB.is_file(): raise RuntimeError(f'پایگاه داده پیدا نشد: {DB}')
    sources=make_sources()
    tests=test_on_copy(sources)  # All checks run on a temporary DB copy before source files change.
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); backup=ROOT/'backups'/f'safe_delete_{stamp}'; backup.mkdir(parents=True,exist_ok=False)
    for p in sources:
        dest=backup/p.relative_to(ROOT); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
    for p,src in sources.items():
        tmp=p.with_suffix(p.suffix+'.safe_delete_tmp'); tmp.write_text(src,encoding='utf-8'); tmp.replace(p)
    for p in sources: compile(p.read_text(encoding='utf-8'),str(p),'exec')
    report=['اصلاحات حذف ایمن فاز ۱۵ با موفقیت نصب شد.',f'پوشه پشتیبان: {backup}','تعداد فایل‌های اصلاح‌شده: ۵','آزمون‌ها روی کپی موقت پایگاه داده:']+[f'- {x}: موفق' for x in tests]+['پایگاه داده اصلی تغییر داده نشد.']
    (ROOT/'phase15_safe_delete_install_report.txt').write_text('\n'.join(report),encoding='utf-8')
    print('\n'.join(report))

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('نصب متوقف شد؛ در صورت توقف پیش از مرحله جایگزینی، فایل‌های اصلی تغییر نکرده‌اند.'); print('علت:',e); sys.exit(1)
