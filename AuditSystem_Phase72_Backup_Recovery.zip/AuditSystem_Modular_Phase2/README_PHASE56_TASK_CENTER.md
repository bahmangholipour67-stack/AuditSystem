# Phase 56 – Audit Task & Follow-up Center

## Scope
Adds a unified, read-only task center to the management dashboard. It aggregates existing records from corrective actions, document requests, pending approval requests, and workpapers awaiting review. It supports current-project scope (or all projects when no project is selected), overdue identification, and a simple overdue-only view.

## Data safety
- No database tables, columns, or migrations are added.
- The service only reads existing records.
- No task status, approval decision, workpaper, finding, or evidence is modified.
- Missing optional tables/columns are tolerated through schema inspection.

## Validation
- Python compileall: passed.
- Full test suite: 276 passed, 131 subtests passed.
- ZIP integrity: verified after packaging.
- Windows GUI visual verification: not performed in this environment; please verify on the target Windows machine.

## Files added/changed
- `services/task_center_service.py` (new)
- `ui/views/dashboard_view.py` (task center integration)
- `tests/test_phase56_task_center.py` (new regression tests)
