# Phase 6 – Specialized Audit Test Engine

## Delivered in this increment

### Sample selection
- Simple random selection with a reproducible seed.
- Systematic selection with a reproducible random start and recorded interval/positions in the engine result.
- Proportional stratified allocation using the largest-remainder method, exposed through the application service for callers that provide the stratum membership.
- The audit-test screen now offers simple-random and systematic selection. Existing duplicate-sample protection remains active.

### Specialized evaluations
- Control tests: observed deviation rate compared with an auditor-defined tolerable deviation rate.
- Substantive tests: sum of identified misstatements compared with performance materiality.
- Analytical procedures: actual-versus-expected variance compared with one explicit amount or percentage threshold.
- Unresolved items are reported and can block the assessment by default.
- The application service exposes all specialized engine operations.

## Audit safeguards and limitations
- The calculations are descriptive and deterministic; they do not replace professional judgment.
- No upper deviation limit, statistical confidence, or sampling-risk measure is calculated in this increment.
- Sample misstatements are not projected to the population.
- Analytical results depend on the reliability of the expectation and require investigation of significant differences.
- Stratified selection is available in the service layer; the current Tkinter screen only exposes simple-random and systematic methods because the existing form does not capture stratum identifiers.

## Verification
- Unit tests cover selection reproducibility, systematic selection, proportional allocation, control testing, substantive testing, analytical procedures, incomplete results, and invalid inputs.
- Full verification results are recorded in `TEST_REPORT_PHASE6_ENGINE.md`.

### Traceability
- The selected sampling method and random seed are saved on the audit-test record when samples are generated, so the selection can be reproduced and reviewed later.
- Seeds are restricted to the nonnegative signed 64-bit integer range supported by SQLite.
