"""Guarded interactive restore from a verified AuditSystem SQLite backup."""
import argparse
from database.backup import restore_backup
from config.settings import DATABASE_PATH


def main():
    parser = argparse.ArgumentParser(description="بازیابی کنترل‌شده پایگاه داده AuditSystem")
    parser.add_argument("backup_file", help="مسیر فایل .db پشتیبان")
    parser.add_argument("--database", default=str(DATABASE_PATH))
    args = parser.parse_args()
    print("هشدار: پیش از جایگزینی، از پایگاه داده فعلی نیز نسخه پشتیبان تهیه می‌شود.")
    print("لطفاً مطمئن شوید AuditSystem و تمام پنجره‌های مرتبط بسته هستند.")
    confirmation = input("برای تأیید بازیابی، عبارت بازیابی را دقیقاً وارد کنید: ").strip()
    if confirmation != "بازیابی":
        print("عملیات لغو شد؛ هیچ تغییری انجام نشد.")
        return 2
    result = restore_backup(args.backup_file, args.database)
    print("بازیابی انجام شد و سلامت پایگاه داده تأیید شد.")
    print(f"پایگاه داده: {result['target_path']}")
    if result["pre_restore_backup"]:
        print(f"نسخه پشتیبان قبل از بازیابی: {result['pre_restore_backup']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
