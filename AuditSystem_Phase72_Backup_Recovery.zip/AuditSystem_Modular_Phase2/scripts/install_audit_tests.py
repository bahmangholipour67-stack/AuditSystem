import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import sqlite3
from config.settings import DATABASE_PATH
import sqlite3
from config.settings import DATABASE_PATH


def install():
    conn = sqlite3.connect(str(DATABASE_PATH))

    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_programs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                audit_area TEXT NOT NULL DEFAULT '',
                objective TEXT NOT NULL DEFAULT '',
                risk_id INTEGER,
                workpaper_id INTEGER,
                assigned_member_id INTEGER,
                start_date TEXT NOT NULL DEFAULT '',
                due_date TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'برنامه‌ریزی‌شده',
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_tests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                program_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                test_type TEXT NOT NULL DEFAULT 'ماهوی',
                procedure TEXT NOT NULL DEFAULT '',
                population_description TEXT NOT NULL DEFAULT '',
                population_size INTEGER NOT NULL DEFAULT 0,
                sample_size INTEGER NOT NULL DEFAULT 0,
                sampling_method TEXT NOT NULL DEFAULT 'تصادفی ساده',
                random_seed INTEGER,
                assigned_member_id INTEGER,
                status TEXT NOT NULL DEFAULT 'برنامه‌ریزی‌شده',
                conclusion TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_test_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                test_id INTEGER NOT NULL,
                sample_no INTEGER NOT NULL,
                population_row INTEGER,
                document_ref TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                amount REAL,
                result TEXT NOT NULL DEFAULT 'رسیدگی‌نشده',
                exception_description TEXT NOT NULL DEFAULT '',
                evidence_path TEXT NOT NULL DEFAULT '',
                tested_by_member_id INTEGER,
                tested_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(test_id, sample_no)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_test_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                test_id INTEGER NOT NULL,
                sample_id INTEGER,
                action TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                actor_member_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_programs_project
            ON audit_programs(project_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_tests_program
            ON audit_tests(program_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_samples_test
            ON audit_test_samples(test_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_audit_history_test
            ON audit_test_history(test_id)
        """)

        conn.commit()
        print("AUDIT TEST TABLES INSTALLED SUCCESSFULLY")

    except Exception:
        conn.rollback()
        raise

    finally:
        conn.close()


if __name__ == "__main__":
    install()
