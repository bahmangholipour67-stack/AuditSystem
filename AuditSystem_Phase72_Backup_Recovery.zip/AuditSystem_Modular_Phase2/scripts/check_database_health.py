"""Run read-only SQLite health checks for the configured AuditSystem DB."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from config.settings import DATABASE_PATH
from database.health import inspect_database


def main():
    print("AuditSystem - Database Health Check")
    print(f"Database: {DATABASE_PATH}")
    try:
        result = inspect_database(DATABASE_PATH)
    except FileNotFoundError:
        print("نتیجه: فایل پایگاه داده در مسیر تنظیم‌شده پیدا نشد.")
        print("اگر از نسخه آزمایشی استفاده می‌کنید، run_demo.bat را اجرا کنید.")
        return 2
    print(f"Integrity check: {', '.join(result['integrity_check'])}")
    print(f"Foreign-key issues: {len(result['foreign_key_issues'])}")
    print(f"Journal mode: {result['journal_mode']}")
    print(f"Database size: {result['database_size_bytes']:,} bytes")
    print("نتیجه: سالم" if result["ok"] else "نتیجه: نیازمند بررسی")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
