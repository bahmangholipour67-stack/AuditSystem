from pathlib import Path
import shutil

PROJECT = Path(__file__).resolve().parent.parent
TARGET = PROJECT / "legacy" / "audit_app.py"
BACKUP = PROJECT / "legacy" / "audit_app_before_audit_test_ui.py"

source = TARGET.read_text(encoding="utf-8")

changes = [
    (
        "from ui.views.team_view import TeamViewMixin\n",
        "from ui.views.team_view import TeamViewMixin\n"
        "from ui.views.audit_test_view import AuditTestViewMixin\n",
        "Import"
    ),
    (
        "    TeamViewMixin\n):",
        "    TeamViewMixin,\n"
        "    AuditTestViewMixin\n):",
        "Class"
    ),
    (
        "        self.tab_team = ttk.Frame(self.notebook)\n",
        "        self.tab_team = ttk.Frame(self.notebook)\n"
        "        self.tab_audit_tests = ttk.Frame(self.notebook)\n",
        "Tab"
    ),
    (
        '            (self.tab_team, "۸. اعضای تیم"),\n',
        '            (self.tab_team, "۸. اعضای تیم"),\n'
        '            (self.tab_audit_tests, "۹. آزمون‌های حسابرسی"),\n',
        "Tab list"
    ),
    (
        "        self.setup_team_tab()\n",
        "        self.setup_team_tab()\n"
        "        self.setup_audit_test_tab()\n",
        "Setup"
    ),
    (
        "        self.refresh_team()\n",
        "        self.refresh_team()\n"
        "        self.refresh_audit_tests()\n",
        "Refresh"
    ),
]

for old, new, name in changes:
    count = source.count(old)
    if count != 1:
        print("STOP:", name, "matches:", count)
        print("No changes were made.")
        raise SystemExit(1)

if not BACKUP.exists():
    shutil.copy2(TARGET, BACKUP)

updated = source

for old, new, name in changes:
    updated = updated.replace(old, new, 1)
    print("OK:", name)

TARGET.write_text(updated, encoding="utf-8")

print("AUDIT TEST UI INTEGRATION COMPLETED")