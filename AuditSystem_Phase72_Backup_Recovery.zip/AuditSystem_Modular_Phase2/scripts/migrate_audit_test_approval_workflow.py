
import sys
import sqlite3
from pathlib import Path

# Add project root to Python import path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import DATABASE_PATH


def migrate():
    conn = sqlite3.connect(str(DATABASE_PATH))

    required_tables = {
        "audit_tests",
        "audit_test_history",
        "team_members",
    }

    new_columns = {
        "submitted_by_member_id": "INTEGER",
        "submitted_at": "TEXT",
        "supervisor_decision": "TEXT",
        "supervisor_member_id": "INTEGER",
        "supervisor_reviewed_at": "TEXT",
        "supervisor_comment": "TEXT",
        "manager_member_id": "INTEGER",
        "manager_approved_at": "TEXT",
        "manager_comment": "TEXT",
    }

    try:
        existing_tables = {
            row[0]
            for row in conn.execute("""
                SELECT name
                FROM sqlite_master
                WHERE type = 'table'
            """)
        }

        missing_tables = required_tables - existing_tables

        if missing_tables:
            raise RuntimeError(
                f"Required tables are missing: {sorted(missing_tables)}"
            )

        existing_columns = {
            row[1]
            for row in conn.execute(
                "PRAGMA table_info(audit_tests)"
            )
        }

        added = []

        with conn:
            for column_name, column_type in new_columns.items():
                if column_name not in existing_columns:
                    conn.execute(
                        f"""
                        ALTER TABLE audit_tests
                        ADD COLUMN {column_name} {column_type}
                        """
                    )
                    added.append(column_name)

        print("MIGRATION: SUCCESS")

        if added:
            print("ADDED COLUMNS:")
            for column in added:
                print("-", column)
        else:
            print("No changes needed. Columns already exist.")

        print("\nFINAL SCHEMA:")
        for row in conn.execute(
            "PRAGMA table_info(audit_tests)"
        ):
            print(row[1], row[2])

        print(
            "\nINTEGRITY:",
            conn.execute(
                "PRAGMA integrity_check"
            ).fetchone()[0]
        )

    except Exception:
        conn.rollback()
        raise

    finally:
        conn.close()


if __name__ == "__main__":
    migrate()
