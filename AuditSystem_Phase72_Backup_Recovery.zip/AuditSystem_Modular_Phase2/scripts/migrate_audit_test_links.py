
"""Non-destructive migration for audit test links."""

import sqlite3
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config.settings import DATABASE_PATH


def columns(conn, table_name):
    return {
        row[1]
        for row in conn.execute(
            f"PRAGMA table_info({table_name})"
        ).fetchall()
    }


def migrate():
    conn = sqlite3.connect(str(DATABASE_PATH))

    try:
        conn.execute("PRAGMA foreign_keys = ON")

        required_tables = (
            "audit_tests",
            "audit_test_samples",
            "workpapers",
            "findings",
        )

        existing_tables = {
            row[0]
            for row in conn.execute("""
                SELECT name
                FROM sqlite_master
                WHERE type = 'table'
            """).fetchall()
        }

        missing = [
            name for name in required_tables
            if name not in existing_tables
        ]

        if missing:
            raise RuntimeError(
                "Missing required tables: " + ", ".join(missing)
            )

        test_columns = columns(conn, "audit_tests")

        if "workpaper_id" not in test_columns:
            conn.execute("""
                ALTER TABLE audit_tests
                ADD COLUMN workpaper_id INTEGER
            """)
            print("ADDED: audit_tests.workpaper_id")
        else:
            print("EXISTS: audit_tests.workpaper_id")

        if "finding_id" not in test_columns:
            conn.execute("""
                ALTER TABLE audit_tests
                ADD COLUMN finding_id INTEGER
            """)
            print("ADDED: audit_tests.finding_id")
        else:
            print("EXISTS: audit_tests.finding_id")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_sample_findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                test_id INTEGER NOT NULL,
                sample_id INTEGER NOT NULL,
                finding_id INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(sample_id, finding_id)
            )
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_audit_tests_workpaper
            ON audit_tests(workpaper_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_audit_tests_finding
            ON audit_tests(finding_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_audit_sample_findings_test
            ON audit_sample_findings(test_id)
        """)

        conn.execute("""
            CREATE INDEX IF NOT EXISTS
            idx_audit_sample_findings_finding
            ON audit_sample_findings(finding_id)
        """)

        conn.commit()

        print()
        print("AUDIT TEST LINKS MIGRATION SUCCESSFUL")
        print("DATABASE:", DATABASE_PATH)

        print(
            "AUDIT_TESTS COLUMNS:",
            sorted(columns(conn, "audit_tests"))
        )

        print(
            "LINK TABLE EXISTS:",
            "audit_sample_findings" in {
                row[0]
                for row in conn.execute("""
                    SELECT name
                    FROM sqlite_master
                    WHERE type = 'table'
                """).fetchall()
            }
        )

    except Exception:
        conn.rollback()
        raise

    finally:
        conn.close()


if __name__ == "__main__":
    migrate()
