"""Create and verify a timestamped AuditSystem database backup."""
import argparse
from database.backup import create_backup
from config.settings import DATABASE_PATH


def main():
    parser = argparse.ArgumentParser(description="تهیه نسخه پشتیبان سالم از پایگاه داده AuditSystem")
    parser.add_argument("--database", default=str(DATABASE_PATH))
    parser.add_argument("--backup-dir", default=None)
    parser.add_argument("--keep", type=int, default=10)
    args = parser.parse_args()
    result = create_backup(args.database, args.backup_dir, args.keep)
    print("نسخه پشتیبان با موفقیت ایجاد و بررسی شد.")
    print(f"فایل: {result['backup_path']}")
    print(f"حجم: {result['size_bytes']:,} bytes")
    print(f"SHA-256: {result['sha256']}")
    if result["rotated_files"]:
        print(f"نسخه‌های قدیمی حذف‌شده طبق سیاست نگهداری: {len(result['rotated_files'])}")


if __name__ == "__main__":
    main()
