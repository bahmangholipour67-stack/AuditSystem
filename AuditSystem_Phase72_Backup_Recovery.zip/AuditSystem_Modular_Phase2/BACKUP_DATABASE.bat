@echo off
setlocal
cd /d "%~dp0"
echo Creating a verified AuditSystem database backup...
py -3.12 scripts\backup_database.py
if errorlevel 1 (
  echo.
  echo Backup failed. Review the message above.
) else (
  echo.
  echo Backup completed successfully.
)
echo.
pause
endlocal
