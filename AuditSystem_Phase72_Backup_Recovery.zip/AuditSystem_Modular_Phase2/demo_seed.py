"""Create an isolated, clearly labeled AuditSystem demonstration database."""
import argparse
import os
import sqlite3
from pathlib import Path

from database.migrations import ensure_schema

DEMO_NAME = "[DEMO] شرکت تولیدی پارس‌صنعت"
DEFAULT_DB = Path(__file__).resolve().parent / "demo_audit_system.db"


def seed(db_path: Path, reset: bool = False):
    db_path = Path(db_path).resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    ensure_schema(db_path)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        existing = conn.execute("SELECT id FROM projects WHERE name=?", (DEMO_NAME,)).fetchone()
        if existing and not reset:
            return existing["id"], False
        if existing:
            pid = existing["id"]
            # Only remove records belonging to this explicitly labeled demo project.
            for table in ("audit_sample_findings", "audit_test_history", "audit_test_samples", "audit_tests", "audit_programs", "audit_misstatements", "misstatement_history", "approval_requests", "approval_history", "document_links", "engagement_documents", "document_requests", "document_request_history", "team_communications", "workpaper_history", "finding_evidence", "audit_template_history", "audit_project_template_overrides", "project_materiality_history", "project_materiality", "coso_control_mappings", "coso_principle_assessments", "coso_checklist_responses", "coso_checklist_history", "internal_controls", "control_tests", "corrective_actions", "trial_balance", "findings", "workpapers", "risks", "team_members"):
                if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                    conn.execute(f"DELETE FROM {table} WHERE project_id=?", (pid,))
            conn.execute("DELETE FROM projects WHERE id=?", (pid,))

        conn.execute("INSERT INTO projects(name,period,audit_type,manager,start_date,end_date,status,description) VALUES(?,?,?,?,?,?,?,?)",
                     (DEMO_NAME, "سال مالی منتهی به ۱۴۰۴/۱۲/۲۹", "حسابرسی صورت‌های مالی", "مدیر حسابرسی نمونه", "1404/01/01", "1404/12/29", "در جریان", "پرونده آزمایشی؛ تمام اطلاعات ساختگی و فقط برای نمایش قابلیت‌ها."))
        pid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        members = [
            ("مدیر حسابرسی نمونه", "مدیر حسابرسی", "demo.manager@example.test"),
            ("سرپرست حسابرسی نمونه", "سرپرست", "demo.supervisor@example.test"),
            ("حسابرس ارشد نمونه", "حسابرس ارشد", "demo.senior@example.test"),
            ("حسابرس نمونه", "حسابرس", "demo.staff@example.test"),
        ]
        for name, role, email in members:
            conn.execute("INSERT INTO team_members(project_id,full_name,role,email) VALUES(?,?,?,?)", (pid,name,role,email))
        member_ids = [r[0] for r in conn.execute("SELECT id FROM team_members WHERE project_id=? ORDER BY id", (pid,)).fetchall()]
        risks = [
            ("ریسک بیش‌نمایی فروش و شناسایی زودهنگام درآمد", 20, "تطبیق فاکتور، حواله خروج و اسناد حمل؛ آزمون cut-off"),
            ("ریسک عدم کفایت ذخیره مطالبات مشکوک‌الوصول", 16, "تحلیل سنی مطالبات و بررسی وصول‌های بعد از تاریخ گزارش"),
            ("ریسک شمارش نادرست موجودی و افت ارزش", 20, "حضور در شمارش، آزمون شمارش و بررسی خالص ارزش فروش"),
            ("ریسک ثبت ناقص بدهی‌ها در پایان سال", 15, "جستجوی بدهی‌های ثبت‌نشده با پرداخت‌های بعدی و فاکتورهای دریافت‌شده"),
            ("ریسک محاسبه نادرست استهلاک دارایی ثابت", 12, "بازمحاسبه استهلاک و بررسی عمر مفید و تاریخ آماده بهره‌برداری"),
        ]
        risk_ids=[]
        for title, score, control in risks:
            conn.execute("INSERT INTO risks(project_id,title,score,control_desc) VALUES(?,?,?,?)",(pid,title,score,control))
            risk_ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        workpapers = [
            (risk_ids[0],"رسیدگی به فروش و cut-off","نمونه فاکتور فروش، حواله و اسناد حمل را تطبیق دهید.","۲ مورد اختلاف تاریخ شناسایی؛ نیازمند بررسی تکمیلی","در حال بازبینی"),
            (risk_ids[0],"تحلیل روند فروش ماهانه","مقایسه ماهانه و بررسی معاملات غیرعادی پایان سال.","افزایش فروش اسفند نسبت به میانگین؛ توضیح مدیریت دریافت شد","پیش‌نویس"),
            (risk_ids[1],"تأییدیه و وصول مطالبات","تطبیق تأییدیه‌ها و وصول بعد از تاریخ گزارش.","۳ مانده با پاسخ تأییدیه دریافت نشده؛ جایگزین در حال اجرا","در حال اجرا"),
            (risk_ids[2],"مشاهده شمارش موجودی","مشاهده شمارش و اجرای آزمون شمارش نمونه‌ای.","اختلاف شمارش در یک قلم؛ صورت مغایرت تهیه شد","در حال بازبینی"),
            (risk_ids[2],"بررسی افت ارزش موجودی","بررسی اقلام کم‌گردش و قیمت فروش بعدی.","دو قلم کم‌گردش برای محاسبه ذخیره علامت‌گذاری شد","پیش‌نویس"),
            (risk_ids[3],"جستجوی بدهی ثبت‌نشده","بررسی پرداخت‌های بعدی و اسناد خرید دریافت‌شده.","یک فاکتور خدمات مربوط به دوره در فهرست بررسی قرار گرفت","در حال اجرا"),
            (risk_ids[4],"بازمحاسبه استهلاک","بازمحاسبه استهلاک نمونه دارایی‌ها.","محاسبات نمونه با دفتر دارایی تطبیق شد","تکمیل‌شده"),
            (risk_ids[4],"بررسی اضافه‌شدن دارایی‌ها","بررسی فاکتور، تأییدیه و آماده بهره‌برداری.","مدارک ۴ خرید سرمایه‌ای دریافت شد","پیش‌نویس"),
        ]
        wp_ids=[]
        for rid,title,proc,result,status in workpapers:
            conn.execute("INSERT INTO workpapers(project_id,risk_id,title,procedure,result,status) VALUES(?,?,?,?,?,?)",(pid,rid,title,proc,result,status))
            wp_ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        findings = [
            (wp_ids[0],risk_ids[0],"عدم تطابق تاریخ شناسایی دو فروش با اسناد حمل","متوسط","بررسی تاریخ انتقال کنترل و اصلاح ثبت در صورت لزوم","مدیر مالی","باز"),
            (wp_ids[3],risk_ids[2],"مغایرت شمارش در یک قلم موجودی","زیاد","بررسی علت مغایرت، اصلاح کارت انبار و ارزیابی اثر مالی","مدیر انبار","باز"),
            (wp_ids[5],risk_ids[3],"فاکتور خدمات دریافت‌شده پس از پایان سال در فهرست بدهی‌های احتمالی","متوسط","تعیین دوره تعلق و ثبت تعدیل لازم","مدیر مالی","در حال پیگیری"),
            (wp_ids[4],risk_ids[2],"نیاز به ارزیابی ذخیره افت ارزش اقلام کم‌گردش","کم","تکمیل تحلیل قیمت فروش و هزینه تکمیل","مدیر تولید","باز"),
        ]
        finding_ids=[]
        for wpid,rid,title,severity,action,owner,status in findings:
            conn.execute("INSERT INTO findings(project_id,workpaper_id,risk_id,title,severity,action_text,owner,status) VALUES(?,?,?,?,?,?,?,?)",(pid,wpid,rid,title,severity,action,owner,status))
            finding_ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        accounts = [
            (1001,"صندوق و بانک",18500000000,0),(1101,"حساب‌های دریافتنی تجاری",32800000000,0),(1102,"ذخیره مطالبات مشکوک‌الوصول",0,2100000000),
            (1201,"موجودی مواد اولیه",24600000000,0),(1202,"موجودی کالای ساخته‌شده",21600000000,0),(1301,"دارایی ثابت مشهود",71500000000,0),
            (1302,"استهلاک انباشته",0,12500000000),(2001,"حساب‌های پرداختنی",0,28400000000),(2101,"تسهیلات مالی",0,35000000000),
            (3001,"سرمایه",0,50000000000),(3101,"سود انباشته",0,17300000000),(4001,"فروش",0,126000000000),
            (5001,"بهای تمام‌شده فروش",88000000000,0),(6001,"هزینه‌های اداری و فروش",14300000000,0),
        ]
        for code,name,debit,credit in accounts:
            net=debit-credit
            conn.execute("INSERT INTO trial_balance(project_id,account_code,account_name,debit,credit,net,flags) VALUES(?,?,?,?,?,?,?)",(pid,str(code),name,debit,credit,net,"DEMO"))
        conn.execute("INSERT INTO project_materiality(project_id,overall_materiality,performance_materiality,clearly_trivial,basis) VALUES(?,?,?,?,?)",(pid,2500000000,1800000000,125000000,"درصدی از سود قبل از مالیات؛ مقادیر نمونه برای Demo"))
        programs=[("برنامه حسابرسی فروش و درآمد","فروش و درآمد","کسب اطمینان از وقوع، صحت و cut-off درآمد"),("برنامه حسابرسی مطالبات","حساب‌های دریافتنی","ارزیابی وجود، ارزش‌گذاری و قابلیت وصول مطالبات"),("برنامه حسابرسی موجودی","موجودی کالا","وجود، کامل بودن، مالکیت و ارزش‌گذاری موجودی"),("برنامه حسابرسی بدهی‌ها","حساب‌های پرداختنی","کامل بودن بدهی‌ها و cut-off خرید"),]
        program_ids=[]
        for title,area,obj in programs:
            conn.execute("INSERT INTO audit_programs(project_id,title,audit_area,objective,risk_id,workpaper_id,assigned_member_id,status,notes) VALUES(?,?,?,?,?,?,?,?,?)",(pid,title,area,obj,risk_ids[len(program_ids)],wp_ids[len(program_ids)],member_ids[3],"در جریان","برنامه آزمایشی DEMO"))
            program_ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        tests=[("آزمون cut-off فروش","ماهوی","تطبیق فاکتور و اسناد حمل","فروش ۲۰ روز قبل و بعد از پایان سال",30,8),("آزمون وصول مطالبات","ماهوی","بررسی وصول‌های بعد از تاریخ گزارش","مانده‌های مشتریان منتخب",40,10),("آزمون شمارش موجودی","ماهوی","تطبیق شمارش فیزیکی با لیست انبار","اقلام منتخب انبار",80,12),("جستجوی بدهی ثبت‌نشده","ماهوی","بررسی پرداخت‌های بعدی و فاکتورهای دریافت‌شده","پرداخت‌های ۳۰ روز پس از پایان سال",50,10)]
        test_ids=[]
        for i,(title,ttype,procedure,pop,n,s) in enumerate(tests):
            conn.execute("INSERT INTO audit_tests(project_id,program_id,title,test_type,procedure,population_description,population_size,sample_size,sampling_method,assigned_member_id,status,conclusion,workpaper_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(pid,program_ids[i],title,ttype,procedure,pop,n,s,"نمونه‌گیری قضاوتی",member_ids[3],"در حال اجرا","نتایج نمونه در محیط Demo؛ برای نتیجه‌گیری واقعی کافی نیست.",wp_ids[i]))
            test_ids.append(conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        sample_groups = [
            [(1,"INV-1404-0981","فاکتور فروش نمونه",1450000000,"تطبیق‌شده"),(2,"INV-1404-1012","فاکتور پایان دوره",980000000,"نیازمند بررسی")],
            [(1,"CUS-031","مشتری نمونه A",3200000000,"وصول‌شده"),(2,"CUS-044","مشتری نمونه B",1850000000,"تأییدیه دریافت نشده")],
            [(1,"INV-COUNT-008","موجودی قطعه A",760000000,"مغایرت"),(2,"INV-COUNT-017","موجودی قطعه B",410000000,"تطبیق‌شده")],
            [(1,"PAY-1405-001","پرداخت بعد از سال",530000000,"نیازمند بررسی")],
        ]
        for test_id, sample_rows in zip(test_ids, sample_groups):
            for sno,ref,desc,amt,res in sample_rows:
                conn.execute("INSERT INTO audit_test_samples(project_id,test_id,sample_no,document_ref,description,amount,result,exception_description) VALUES(?,?,?,?,?,?,?,?)",(pid,test_id,sno,ref,desc,amt,res,"مورد استثنا برای نمایش گردش رسیدگی" if res in ("مغایرت","نیازمند بررسی","تأییدیه دریافت نشده") else ""))
        conn.commit()
        return pid, True
    finally:
        conn.close()


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description="Seed an isolated demo database for AuditSystem")
    parser.add_argument("--db", default=str(DEFAULT_DB), help="Target demo database file")
    parser.add_argument("--reset-demo", action="store_true", help="Rebuild only the [DEMO] project in the selected database")
    args=parser.parse_args()
    project_id, created=seed(Path(args.db), args.reset_demo)
    print(f"Demo project id={project_id}; {'created' if created else 'already exists'}; database={Path(args.db).resolve()}")
