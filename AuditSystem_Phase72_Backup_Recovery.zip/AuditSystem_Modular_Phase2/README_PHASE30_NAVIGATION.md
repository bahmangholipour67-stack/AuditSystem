# Phase 30 — Professional Navigation & Workspace Redesign

## Scope
- Replaced the crowded visible notebook tab strip with a modern, minimal right-side module navigator.
- Kept the existing notebook child frames as internal workspaces. Existing view mixins, setup routines, callbacks, services, repositories, migrations, and database files are retained.
- Preserved the top-level active engagement selector, active team member selector, new-engagement action, and integrated report action.
- Added module search in the right navigation panel and grouped modules by workflow.
- Default workspace is the dashboard.

## Navigation groups
- Overview: dashboard
- Engagement & team: engagement management, archive, team
- Planning & execution: risks, workpapers, audit programs/tests, sampling, trial balance, unified execution
- Risk & controls: internal controls, COSO framework/checklists
- Results & reporting: findings/corrective actions, misstatements/materiality, final engagement assessment
- Governance & quality: approvals, documents/requests, file quality, traceability
- Analytical tools: Benford and M-Score

## Data preservation
No database schema, migration, repository, service, or business-rule code was changed in this phase. Existing database backup files are included in the distribution. The redesign changes presentation/navigation only.

## Verification
- `python -m compileall -q .` — passed
- `python -m pytest -q` — 216 passed, 131 subtests passed (baseline suite)
- Dedicated Phase 30 navigation tests are included in `tests/test_phase30_navigation.py`.
- GUI smoke test on the user's Windows desktop remains to be performed after extraction.

## Run
From the project folder:

```bash
python main.py
```

If a project copy already exists, make a separate backup before replacing it. Do not overwrite the user's live database with an empty or sample database.
