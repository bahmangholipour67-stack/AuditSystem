from pathlib import Path

from database.connection import connect
from repositories.base_repository import BaseRepository


class FindingRepository(BaseRepository):
    """Findings linked to the workpaper and risk within one project."""

    def for_project(self, project_id):
        return self.fetch_all(
            """SELECT f.id, f.title, f.severity, f.action_text, f.owner,
                      f.status, f.workpaper_id, w.title AS workpaper_title,
                      f.risk_id, r.title AS risk_title
               FROM findings f
               LEFT JOIN workpapers w
                 ON w.id=f.workpaper_id AND w.project_id=f.project_id
               LEFT JOIN risks r
                 ON r.id=f.risk_id AND r.project_id=f.project_id
               WHERE f.project_id=?
               ORDER BY f.id DESC""",
            (project_id,),
        )

    def create(
        self, project_id, title, severity="", action_text="", owner="",
        workpaper_id=None
    ):
        title = str(title or "").strip()
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")
        if not title:
            raise ValueError("شرح یافته الزامی است.")

        risk_id = None
        with connect() as conn:
            if workpaper_id is not None:
                workpaper = conn.execute(
                    """SELECT id, risk_id FROM workpapers
                       WHERE id=? AND project_id=?""",
                    (workpaper_id, project_id),
                ).fetchone()
                if not workpaper:
                    raise ValueError("کاربرگ انتخاب‌شده متعلق به این پرونده نیست.")
                risk_id = workpaper[1]

            cur = conn.execute(
                """INSERT INTO findings(
                       project_id, workpaper_id, risk_id, title, severity,
                       action_text, owner, status
                   ) VALUES(?,?,?,?,?,?,?,'باز')""",
                (
                    project_id, workpaper_id, risk_id, title,
                    str(severity or "").strip(),
                    str(action_text or "").strip(),
                    str(owner or "").strip(),
                ),
            )
            return cur.lastrowid


    def update(self, project_id, finding_id, title, severity="", action_text="", owner=""):
        title = str(title or "").strip()
        if not title:
            raise ValueError("شرح یافته الزامی است.")
        with connect() as conn:
            row = conn.execute(
                "SELECT status FROM findings WHERE id=? AND project_id=?",
                (finding_id, project_id),
            ).fetchone()
            if not row:
                raise ValueError("یافته در این پرونده پیدا نشد.")
            if row[0] != "باز":
                raise ValueError("ویرایش فقط برای یافته‌های باز مجاز است.")
            conn.execute(
                "UPDATE findings SET title=?, severity=?, action_text=?, owner=? WHERE id=? AND project_id=?",
                (title, str(severity or "").strip(), str(action_text or "").strip(),
                 str(owner or "").strip(), finding_id, project_id),
            )
        return True

    def link_workpaper(self, project_id, finding_id, workpaper_id):
        with connect() as conn:
            finding = conn.execute(
                "SELECT id, status FROM findings WHERE id=? AND project_id=?",
                (finding_id, project_id),
            ).fetchone()
            if not finding:
                raise ValueError("یافته در این پرونده پیدا نشد.")
            if finding[1] != "باز":
                raise ValueError("فقط یافته باز قابل اتصال یا تغییر کاربرگ است.")

            linked_tests = conn.execute(
                "SELECT workpaper_id FROM audit_tests "
                "WHERE project_id=? AND finding_id=? AND workpaper_id IS NOT NULL",
                (project_id, finding_id),
            ).fetchall()
            if any(row[0] != workpaper_id for row in linked_tests):
                raise ValueError(
                    "کاربرگ انتخابی با کاربرگ متصل به یکی از آزمون‌های این یافته یکسان نیست."
                )

            linked_sample_tests = conn.execute(
                """SELECT DISTINCT t.workpaper_id
                   FROM audit_sample_findings sf
                   JOIN audit_tests t ON t.id=sf.test_id AND t.project_id=sf.project_id
                   WHERE sf.project_id=? AND sf.finding_id=?
                     AND t.workpaper_id IS NOT NULL""",
                (project_id, finding_id),
            ).fetchall()
            if any(row[0] != workpaper_id for row in linked_sample_tests):
                raise ValueError(
                    "کاربرگ انتخابی با کاربرگ آزمونی که نمونه آن به این یافته متصل است یکسان نیست."
                )

            risk_id = None
            if workpaper_id is not None:
                workpaper = conn.execute(
                    "SELECT id, risk_id FROM workpapers WHERE id=? AND project_id=?",
                    (workpaper_id, project_id),
                ).fetchone()
                if not workpaper:
                    raise ValueError("کاربرگ انتخاب‌شده متعلق به این پرونده نیست.")
                risk_id = workpaper[1]

            conn.execute(
                "UPDATE findings SET workpaper_id=?, risk_id=? "
                "WHERE id=? AND project_id=?",
                (workpaper_id, risk_id, finding_id, project_id),
            )
        return True

    def close(self, project_id, finding_id):
        return self.execute(
            "UPDATE findings SET status='رفع‌شده' "
            "WHERE id=? AND project_id=? AND status='باز'",
            (finding_id, project_id),
        )

    def add_evidence(
        self, project_id, finding_id, file_path, description="",
        added_by_member_id=None
    ):
        file_path = str(file_path or "").strip()
        if not file_path:
            raise ValueError("مسیر مستند الزامی است.")
        path = Path(file_path).expanduser()
        if not path.is_file():
            raise ValueError("فایل مستند در مسیر انتخاب‌شده پیدا نشد.")

        with connect() as conn:
            finding = conn.execute(
                "SELECT id FROM findings WHERE id=? AND project_id=?",
                (finding_id, project_id),
            ).fetchone()
            if not finding:
                raise ValueError("یافته در این پرونده پیدا نشد.")

            if added_by_member_id is not None:
                member = conn.execute(
                    """SELECT id FROM team_members
                       WHERE id=? AND project_id=? AND is_active=1""",
                    (added_by_member_id, project_id),
                ).fetchone()
                if not member:
                    raise ValueError("عضو ثبت‌کننده فعال نیست یا به این پرونده تعلق ندارد.")

            cur = conn.execute(
                """INSERT INTO finding_evidence(
                       project_id, finding_id, file_path, description,
                       added_by_member_id
                   ) VALUES(?,?,?,?,?)""",
                (
                    project_id, finding_id, str(path.resolve()),
                    str(description or "").strip(), added_by_member_id,
                ),
            )
            return cur.lastrowid

    def evidence_for_finding(self, project_id, finding_id):
        return self.fetch_all(
            """SELECT e.id, e.file_path, e.description,
                      m.full_name, e.created_at
               FROM finding_evidence e
               LEFT JOIN team_members m
                 ON m.id=e.added_by_member_id AND m.project_id=e.project_id
               WHERE e.project_id=? AND e.finding_id=?
               ORDER BY e.id DESC""",
            (project_id, finding_id),
        )

    def linkage_summary(self, project_id):
        with connect() as conn:
            return {
                "total": conn.execute(
                    "SELECT COUNT(*) FROM findings WHERE project_id=?", (project_id,)
                ).fetchone()[0],
                "linked_workpaper": conn.execute(
                    "SELECT COUNT(*) FROM findings WHERE project_id=? AND workpaper_id IS NOT NULL",
                    (project_id,),
                ).fetchone()[0],
                "linked_risk": conn.execute(
                    "SELECT COUNT(*) FROM findings WHERE project_id=? AND risk_id IS NOT NULL",
                    (project_id,),
                ).fetchone()[0],
            }

    def delete(self, project_id, finding_id):
        if not project_id or not finding_id:
            raise ValueError("پرونده و شناسه یافته باید مشخص باشند.")
        with connect() as conn:
            row = conn.execute("SELECT status FROM findings WHERE id=? AND project_id=?", (finding_id, project_id)).fetchone()
            if not row:
                raise ValueError("یافته موردنظر در این پرونده پیدا نشد.")
            if row[0] != "باز":
                raise ValueError("فقط یافته باز قابل حذف است؛ یافته رفع‌شده باید در سوابق باقی بماند.")
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            deps = []
            for (name,) in tables:
                if name == "findings":
                    continue
                q = '"' + str(name).replace('"', '""') + '"'
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
                if {"project_id", "finding_id"}.issubset(cols):
                    n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND finding_id=?", (project_id, finding_id)).fetchone()[0]
                    if n:
                        deps.append(f"{name}: {n}")
            if deps:
                raise ValueError("این یافته دارای مستند یا ارجاع وابسته است و حذف نمی‌شود: " + "، ".join(deps))
            conn.execute("DELETE FROM findings WHERE id=? AND project_id=?", (finding_id, project_id))
        return True
