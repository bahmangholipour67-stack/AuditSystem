"""Persistence for editable reusable audit templates and engagement overrides."""
import json
from database.connection import connect


class AuditTemplateRepository:
    def __init__(self, db_path=None):
        self.db_path = db_path

    def _connect(self):
        return connect(self.db_path) if self.db_path else connect()

    @staticmethod
    def _decode(value):
        return json.loads(value) if value else None

    def get_library_override(self, template_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT content_json FROM audit_template_library WHERE template_id=?",
                (template_id,),
            ).fetchone()
        return self._decode(row[0]) if row else None

    def get_project_override(self, project_id, template_id):
        if not project_id:
            return None
        with self._connect() as conn:
            row = conn.execute(
                "SELECT content_json FROM audit_project_template_overrides WHERE project_id=? AND template_id=?",
                (project_id, template_id),
            ).fetchone()
        return self._decode(row[0]) if row else None

    def _save(self, table, template_id, content, project_id=None, actor_member_id=None):
        payload = json.dumps(content, ensure_ascii=False, sort_keys=True)
        with self._connect() as conn:
            if table == "audit_template_library":
                conn.execute(
                    """INSERT INTO audit_template_library(template_id,content_json,updated_at)
                       VALUES(?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(template_id) DO UPDATE SET
                       content_json=excluded.content_json, updated_at=CURRENT_TIMESTAMP""",
                    (template_id, payload),
                )
                scope = "library"
            else:
                conn.execute(
                    """INSERT INTO audit_project_template_overrides(project_id,template_id,content_json,updated_at)
                       VALUES(?,?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(project_id,template_id) DO UPDATE SET
                       content_json=excluded.content_json, updated_at=CURRENT_TIMESTAMP""",
                    (project_id, template_id, payload),
                )
                scope = "project"
            conn.execute(
                """INSERT INTO audit_template_history
                   (scope,project_id,template_id,content_json,action,actor_member_id)
                   VALUES(?,?,?,?,?,?)""",
                (scope, project_id, template_id, payload, "ویرایش الگو", actor_member_id),
            )
        return True

    def save_library_override(self, template_id, content, actor_member_id=None):
        return self._save("audit_template_library", template_id, content, actor_member_id=actor_member_id)

    def save_project_override(self, project_id, template_id, content, actor_member_id=None):
        if not project_id:
            raise ValueError("برای ذخیره الگو در پرونده جاری، ابتدا پرونده حسابرسی را انتخاب کنید.")
        return self._save("audit_project_template_overrides", template_id, content, project_id, actor_member_id)


    def get_history_entry(self, history_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id,scope,project_id,template_id,content_json,actor_member_id,created_at "
                "FROM audit_template_history WHERE id=?", (history_id,)
            ).fetchone()
        if not row:
            return None
        if hasattr(row, "keys"):
            data = dict(row)
        else:
            data = dict(zip(("id", "scope", "project_id", "template_id", "content_json", "actor_member_id", "created_at"), row))
        data["content"] = self._decode(data.pop("content_json"))
        return data

    def restore_history(self, history_id, actor_member_id=None):
        entry = self.get_history_entry(history_id)
        if not entry:
            raise ValueError("نسخه انتخاب‌شده در سوابق پیدا نشد.")
        if entry["scope"] == "library":
            return self.save_library_override(entry["template_id"], entry["content"], actor_member_id)
        return self.save_project_override(entry["project_id"], entry["template_id"], entry["content"], actor_member_id)

    def list_history(self, template_id, project_id=None):
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT id,scope,project_id,action,actor_member_id,created_at
                   FROM audit_template_history WHERE template_id=?
                   AND (scope='library' OR project_id=?) ORDER BY id DESC""",
                (template_id, project_id),
            ).fetchall()
        return [dict(row) if hasattr(row, "keys") else {
            "id": row[0], "scope": row[1], "project_id": row[2],
            "action": row[3], "actor_member_id": row[4], "created_at": row[5]
        } for row in rows]
