from database.connection import connect

from repositories.base_repository import BaseRepository


class ProjectRepository(BaseRepository):

    def all(self):
        return self.fetch_all("""
            SELECT
                id, name, period, created_at,
                audit_type, manager, start_date,
                end_date, status, description, updated_at
            FROM projects
            ORDER BY id DESC
        """)

    def active(self):
        return self.fetch_all("""
            SELECT id, name, period, created_at, audit_type, manager,
                   start_date, end_date, status, description, updated_at
            FROM projects
            WHERE archived_at IS NULL AND COALESCE(status, '') <> 'بایگانی'
            ORDER BY id DESC
        """)

    def search_active(self, keyword=""):
        keyword = f"%{keyword.strip()}%"
        return self.fetch_all("""
            SELECT id, name, period, created_at, audit_type, manager,
                   start_date, end_date, status, description, updated_at
            FROM projects
            WHERE archived_at IS NULL AND COALESCE(status, '') <> 'بایگانی'
              AND (name LIKE ? OR period LIKE ? OR manager LIKE ?)
            ORDER BY id DESC
        """, (keyword, keyword, keyword))

    def archived(self, keyword=""):
        keyword = f"%{keyword.strip()}%"
        return self.fetch_all("""
            SELECT id, name, period, created_at, audit_type, manager,
                   start_date, end_date, status, description, updated_at,
                   archived_at, archive_reason, archived_by_member_id,
                   archived_previous_status
            FROM projects
            WHERE (archived_at IS NOT NULL OR status = 'بایگانی')
              AND (name LIKE ? OR period LIKE ? OR manager LIKE ?)
            ORDER BY archived_at DESC, id DESC
        """, (keyword, keyword, keyword))

    def archive(self, project_id, reason="", actor_member_id=None):
        if not project_id:
            raise ValueError("شناسه پرونده معتبر نیست.")
        reason = (reason or "").strip()
        if not reason:
            raise ValueError("ثبت علت بایگانی الزامی است.")
        with connect() as conn:
            row = conn.execute("""
                SELECT status, archived_at FROM projects WHERE id = ?
            """, (project_id,)).fetchone()
            if not row:
                raise ValueError("پرونده موردنظر پیدا نشد.")
            if row[1] is not None or row[0] == "بایگانی":
                raise ValueError("این پرونده قبلاً بایگانی شده است.")
            conn.execute("""
                UPDATE projects
                SET archived_previous_status = COALESCE(status, 'جدید'),
                    status = 'بایگانی', archived_at = CURRENT_TIMESTAMP,
                    archive_reason = ?, archived_by_member_id = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (reason, actor_member_id, project_id))
            conn.execute("""
                INSERT INTO project_archive_history
                    (project_id, event_type, reason, actor_member_id)
                VALUES (?, 'ARCHIVE', ?, ?)
            """, (project_id, reason, actor_member_id))
        return True

    def restore(self, project_id, actor_member_id=None):
        if not project_id:
            raise ValueError("شناسه پرونده معتبر نیست.")
        with connect() as conn:
            row = conn.execute("""
                SELECT archived_at, archived_previous_status
                FROM projects WHERE id = ?
            """, (project_id,)).fetchone()
            if not row:
                raise ValueError("پرونده موردنظر پیدا نشد.")
            if row[0] is None:
                raise ValueError("پرونده در وضعیت بایگانی قرار ندارد.")
            previous_status = row[1] or "تکمیل‌شده"
            if previous_status == "بایگانی":
                previous_status = "تکمیل‌شده"
            conn.execute("""
                UPDATE projects
                SET status = ?, archived_at = NULL, archive_reason = '',
                    archived_by_member_id = NULL, archived_previous_status = '',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (previous_status, project_id))
            conn.execute("""
                INSERT INTO project_archive_history
                    (project_id, event_type, reason, actor_member_id)
                VALUES (?, 'RESTORE', 'بازیابی پرونده از بایگانی', ?)
            """, (project_id, actor_member_id))
        return True

    def archive_history(self, project_id):
        return self.fetch_all("""
            SELECT id, event_type, reason, actor_member_id, created_at
            FROM project_archive_history
            WHERE project_id = ? ORDER BY id DESC
        """, (project_id,))

    def get(self, project_id):
        rows = self.fetch_all("""
            SELECT
                id, name, period, created_at,
                audit_type, manager, start_date,
                end_date, status, description, updated_at
            FROM projects
            WHERE id = ?
        """, (project_id,))

        return rows[0] if rows else None

    def search(self, keyword=""):
        keyword = f"%{keyword.strip()}%"

        return self.fetch_all("""
            SELECT
                id, name, period, created_at,
                audit_type, manager, start_date,
                end_date, status, description, updated_at
            FROM projects
            WHERE name LIKE ?
               OR period LIKE ?
               OR manager LIKE ?
            ORDER BY id DESC
        """, (keyword, keyword, keyword))

    def create(
        self,
        name,
        period,
        audit_type="مستقل",
        manager="",
        start_date="",
        end_date="",
        status="جدید",
        description=""
    ):
        return self.execute("""
            INSERT INTO projects (
                name, period, audit_type, manager,
                start_date, end_date, status,
                description, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        """, (
            name, period, audit_type, manager,
            start_date, end_date, status, description
        ))

    def update(
        self,
        project_id,
        name,
        period,
        audit_type,
        manager,
        start_date,
        end_date,
        status,
        description
    ):
        return self.execute("""
            UPDATE projects
            SET
                name = ?,
                period = ?,
                audit_type = ?,
                manager = ?,
                start_date = ?,
                end_date = ?,
                status = ?,
                description = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (
            name, period, audit_type, manager,
            start_date, end_date, status,
            description, project_id
        ))

    def update_status(self, project_id, status):
        return self.execute("""
            UPDATE projects
            SET status = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (status, project_id))

    def delete(self, project_id):
        if not project_id:
            raise ValueError("شناسه پرونده معتبر نیست.")
        with connect() as conn:
            if not conn.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone():
                raise ValueError("پرونده موردنظر پیدا نشد.")
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            deps = []
            for (name,) in tables:
                if name == "projects":
                    continue
                q = '"' + str(name).replace('"', '""') + '"'
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
                if "project_id" in cols:
                    n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=?", (project_id,)).fetchone()[0]
                    if n:
                        deps.append(f"{name}: {n}")
            if deps:
                raise ValueError("پرونده دارای اطلاعات وابسته است و حذف نمی‌شود: " + "، ".join(deps))
            conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
        return True
