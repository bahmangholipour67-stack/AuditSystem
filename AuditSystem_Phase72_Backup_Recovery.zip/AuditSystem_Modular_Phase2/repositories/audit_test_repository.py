﻿
from database.connection import connect
from math import isfinite


class AuditTestRepository:
    """Database operations for audit programs, tests, samples and approvals."""

    # ---------------------------------------------------------
    # Common helpers
    # ---------------------------------------------------------

    @staticmethod
    def _rows(cursor):
        columns = [item[0] for item in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    @staticmethod
    def _row(cursor):
        columns = [item[0] for item in cursor.description]
        row = cursor.fetchone()
        return dict(zip(columns, row)) if row else None

    @staticmethod
    def _add_history(
        conn,
        project_id,
        test_id,
        action,
        details="",
        actor_member_id=None,
        sample_id=None
    ):
        conn.execute(
            """
            INSERT INTO audit_test_history (
                project_id, test_id, sample_id,
                action, details, actor_member_id, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                project_id,
                test_id,
                sample_id,
                action,
                details,
                actor_member_id
            )
        )

    @staticmethod
    def _get_member(conn, member_id, project_id):
        if not member_id:
            return None

        cur = conn.execute(
            """
            SELECT id, project_id, full_name, role, is_active
            FROM team_members
            WHERE id = ?
              AND project_id = ?
              AND is_active = 1
            """,
            (member_id, project_id)
        )

        return AuditTestRepository._row(cur)

    @staticmethod
    def _get_test(conn, test_id, project_id=None):
        sql = "SELECT * FROM audit_tests WHERE id = ?"
        params = [test_id]

        if project_id is not None:
            sql += " AND project_id = ?"
            params.append(project_id)

        cur = conn.execute(sql, tuple(params))
        return AuditTestRepository._row(cur)

    @staticmethod
    def _ensure_editable(test):
        if not test:
            raise ValueError("آزمون موردنظر پیدا نشد.")

        if test["status"] not in (
            "جدید",
            "در حال اجرا",
            "نیازمند اصلاح"
        ):
            raise ValueError(
                "این آزمون در وضعیت فعلی قابل ویرایش نیست."
            )

    @staticmethod
    def _require_role(member, allowed_roles):
        if not member:
            raise ValueError(
                "عضو انتخاب‌شده فعال نیست یا به این پروژه تعلق ندارد."
            )

        if member["role"] not in allowed_roles:
            raise ValueError(
                "نقش عضو انتخاب‌شده اجازه انجام این عملیات را ندارد."
            )

    # ---------------------------------------------------------
    # Audit programs
    # ---------------------------------------------------------

    def for_project(self, project_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT p.*, r.title AS risk_title
                FROM audit_programs p
                LEFT JOIN risks r
                  ON r.id = p.risk_id AND r.project_id = p.project_id
                WHERE p.project_id = ?
                ORDER BY p.id DESC
                """,
                (project_id,)
            )
            return self._rows(cur)

    def get_program(self, program_id):
        with connect() as conn:
            cur = conn.execute(
                "SELECT * FROM audit_programs WHERE id = ?",
                (program_id,)
            )
            return self._row(cur)

    def create_program(
        self,
        project_id,
        title,
        audit_area="",
        objective="",
        risk_id=None,
        workpaper_id=None,
        assigned_member_id=None,
        start_date="",
        due_date="",
        status="جدید",
        notes=""
    ):
        title = str(title or "").strip()
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")
        if not title:
            raise ValueError("عنوان برنامه حسابرسی الزامی است.")

        with connect() as conn:
            if risk_id is not None:
                risk = conn.execute(
                    "SELECT id FROM risks WHERE id=? AND project_id=?",
                    (risk_id, project_id),
                ).fetchone()
                if not risk:
                    raise ValueError("ریسک انتخاب‌شده متعلق به این پرونده نیست.")

            if workpaper_id is not None:
                workpaper = conn.execute(
                    "SELECT id, risk_id FROM workpapers WHERE id=? AND project_id=?",
                    (workpaper_id, project_id),
                ).fetchone()
                if not workpaper:
                    raise ValueError("کاربرگ انتخاب‌شده متعلق به این پرونده نیست.")
                if risk_id is not None and workpaper[1] is not None and workpaper[1] != risk_id:
                    raise ValueError("ریسک برنامه با ریسک کاربرگ مرتبط یکسان نیست.")
                if risk_id is None:
                    risk_id = workpaper[1]

            cur = conn.execute(
                """
                INSERT INTO audit_programs (
                    project_id, title, audit_area, objective,
                    risk_id, workpaper_id, assigned_member_id,
                    start_date, due_date, status, notes,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """,
                (
                    project_id, title, audit_area, objective,
                    risk_id, workpaper_id, assigned_member_id,
                    start_date, due_date, status, notes
                )
            )
            return cur.lastrowid

    # ---------------------------------------------------------
    # Audit tests
    # ---------------------------------------------------------

    def tests_for_program(self, program_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_tests
                WHERE program_id = ?
                ORDER BY id DESC
                """,
                (program_id,)
            )
            return self._rows(cur)

    def get_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                "SELECT * FROM audit_tests WHERE id = ?",
                (test_id,)
            )
            return self._row(cur)

    def create_test(
        self,
        project_id,
        program_id,
        title,
        test_type="ماهوی",
        procedure="",
        population_description="",
        population_size=0,
        sample_size=0,
        sampling_method="تصادفی",
        random_seed=None,
        assigned_member_id=None,
        status="جدید",
        conclusion="",
        template_id="",
        template_objective="",
        template_assertions="[]",
        expected_evidence="",
    ):
        with connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO audit_tests (
                    project_id, program_id, title, test_type,
                    procedure, population_description,
                    population_size, sample_size, sampling_method,
                    random_seed, assigned_member_id, status,
                    conclusion, template_id, template_objective,
                    template_assertions, expected_evidence, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """,
                (
                    project_id, program_id, title, test_type,
                    procedure, population_description,
                    population_size, sample_size, sampling_method,
                    random_seed, assigned_member_id, status,
                    conclusion, template_id, template_objective,
                    template_assertions, expected_evidence
                )
            )
            return cur.lastrowid

    def save_conclusion(self, project_id, test_id, actor_member_id, conclusion):
        conclusion = str(conclusion or "").strip()
        if not conclusion:
            raise ValueError("نتیجه‌گیری حسابرسی الزامی است.")

        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)
            self._ensure_editable(test)
            actor = self._get_member(conn, actor_member_id, project_id)
            self._require_role(actor, {"حسابرس", "حسابرس ارشد"})
            conn.execute(
                """UPDATE audit_tests
                   SET conclusion = ?, updated_at = CURRENT_TIMESTAMP
                   WHERE id = ? AND project_id = ?""",
                (conclusion, test_id, project_id)
            )
            self._add_history(
                conn, project_id, test_id,
                "ثبت نتیجه‌گیری حسابرسی", conclusion, actor_member_id
            )
        return True

    # ---------------------------------------------------------
    # Samples
    # ---------------------------------------------------------

    def samples_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_test_samples
                WHERE test_id = ?
                ORDER BY sample_no
                """,
                (test_id,)
            )
            return self._rows(cur)

    def create_samples(
        self, project_id, test_id, selected_rows,
        sampling_method=None, random_seed=None
    ):
        selected_rows = list(selected_rows)

        if not selected_rows:
            raise ValueError("فهرست نمونه‌ها خالی است.")

        if len(set(selected_rows)) != len(selected_rows):
            raise ValueError("شماره نمونه تکراری است.")

        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون موردنظر پیدا نشد.")

            self._ensure_editable(test)

            population_size = test["population_size"]
            sample_size = test["sample_size"]

            if len(selected_rows) != sample_size:
                raise ValueError(
                    "تعداد نمونه‌ها با حجم نمونه آزمون برابر نیست."
                )

            if any(
                not isinstance(x, int)
                or x < 1
                or x > population_size
                for x in selected_rows
            ):
                raise ValueError(
                    "شماره یکی از نمونه‌ها خارج از محدوده جامعه است."
                )

            existing = conn.execute(
                """
                SELECT COUNT(*)
                FROM audit_test_samples
                WHERE test_id = ?
                """,
                (test_id,)
            ).fetchone()[0]

            if existing:
                raise ValueError(
                    "برای این آزمون قبلاً نمونه ثبت شده است؛ "
                    "نمونه‌های قبلی حذف یا جایگزین نمی‌شوند."
                )

            for number, population_row in enumerate(
                sorted(selected_rows), start=1
            ):
                conn.execute(
                    """
                    INSERT INTO audit_test_samples (
                        project_id, test_id, sample_no,
                        population_row, result, created_at
                    )
                    VALUES (?, ?, ?, ?, 'رسیدگی‌نشده',
                            CURRENT_TIMESTAMP)
                    """,
                    (project_id, test_id, number, population_row)
                )

            conn.execute(
                """
                UPDATE audit_tests
                SET status = 'در حال اجرا',
                    sampling_method = COALESCE(?, sampling_method),
                    random_seed = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (sampling_method, random_seed, test_id, project_id)
            )

            return len(selected_rows)

    def update_sample_result(
        self,
        sample_id,
        result,
        exception_description="",
        document_ref="",
        description="",
        amount=None,
        misstatement_amount=None,
        evidence_path="",
        tested_by_member_id=None,
        actor_member_id=None
    ):
        allowed_results = {
            "رسیدگی‌نشده",
            "تأیید",
            "مغایرت",
            "عدم انطباق",
            "نیازمند بررسی"
        }

        if result not in allowed_results:
            raise ValueError("نتیجه رسیدگی معتبر نیست.")
        if misstatement_amount not in (None, ""):
            try:
                misstatement_amount = float(misstatement_amount)
            except (TypeError, ValueError):
                raise ValueError("مبلغ مغایرت باید عددی باشد.")
            if not isfinite(misstatement_amount) or misstatement_amount < 0:
                raise ValueError("مبلغ مغایرت باید عددی معتبر و غیرمنفی باشد.")

        with connect() as conn:
            cur = conn.execute(
                """
                SELECT test_id, project_id
                FROM audit_test_samples
                WHERE id = ?
                """,
                (sample_id,)
            )

            sample = cur.fetchone()

            if not sample:
                raise ValueError("نمونه موردنظر پیدا نشد.")

            test_id, project_id = sample

            test = self._get_test(conn, test_id, project_id)
            self._ensure_editable(test)

            if not actor_member_id:
                raise ValueError(
                    "شناسه حسابرس ثبت‌کننده نتیجه الزامی است."
                )

            actor = self._get_member(
                conn, actor_member_id, project_id
            )
            self._require_role(
                actor,
                {"حسابرس", "حسابرس ارشد"}
            )

            if tested_by_member_id is None:
                tested_by_member_id = actor_member_id

            tester = self._get_member(
                conn, tested_by_member_id, project_id
            )
            self._require_role(
                tester,
                {"حسابرس", "حسابرس ارشد"}
            )

            conn.execute(
                """
                UPDATE audit_test_samples
                SET result = ?,
                    exception_description = ?,
                    document_ref = ?,
                    description = ?,
                    amount = ?,
                    misstatement_amount = ?,
                    evidence_path = ?,
                    tested_by_member_id = ?,
                    tested_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (
                    result,
                    exception_description,
                    document_ref,
                    description,
                    amount,
                    misstatement_amount,
                    evidence_path,
                    tested_by_member_id,
                    sample_id
                )
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "ثبت نتیجه نمونه",
                f"نتیجه: {result} | مبلغ مغایرت: {misstatement_amount if misstatement_amount is not None else 'ثبت‌نشده'} | توضیحات: {exception_description}",
                actor_member_id,
                sample_id
            )

    # ---------------------------------------------------------
    # Approval workflow
    # ---------------------------------------------------------

    def submit_test(
        self,
        project_id,
        test_id,
        actor_member_id,
        supervisor_member_id
    ):
        """Submit a completed test to an explicitly selected supervisor."""

        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون در این پروژه پیدا نشد.")

            self._ensure_editable(test)

            actor = self._get_member(
                conn, actor_member_id, project_id
            )
            self._require_role(
                actor,
                {"حسابرس", "حسابرس ارشد"}
            )

            supervisor = self._get_member(
                conn, supervisor_member_id, project_id
            )
            self._require_role(
                supervisor,
                {"سرپرست حسابرسی"}
            )

            if not str(test.get("conclusion") or "").strip():
                raise ValueError(
                    "قبل از ارسال آزمون، نتیجه‌گیری حسابرسی الزامی است."
                )

            sample_count = conn.execute(
                """
                SELECT COUNT(*)
                FROM audit_test_samples
                WHERE test_id = ?
                """,
                (test_id,)
            ).fetchone()[0]

            if sample_count == 0:
                raise ValueError(
                    "برای آزمون هیچ نمونه‌ای ثبت نشده است."
                )

            untested_count = conn.execute(
                """
                SELECT COUNT(*)
                FROM audit_test_samples
                WHERE test_id = ?
                  AND result = 'رسیدگی‌نشده'
                """,
                (test_id,)
            ).fetchone()[0]

            if untested_count:
                raise ValueError(
                    "تا زمانی که نتیجه تمام نمونه‌ها ثبت نشده باشد، "
                    "امکان ارسال آزمون وجود ندارد."
                )

            conn.execute(
                """
                UPDATE audit_tests
                SET status = 'آماده بررسی سرپرست',
                    submitted_by_member_id = ?,
                    submitted_at = CURRENT_TIMESTAMP,
                    supervisor_decision = NULL,
                    supervisor_member_id = ?,
                    supervisor_reviewed_at = NULL,
                    supervisor_comment = NULL,
                    manager_member_id = NULL,
                    manager_approved_at = NULL,
                    manager_comment = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (
                    actor_member_id,
                    supervisor_member_id,
                    test_id,
                    project_id
                )
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "ارسال برای بررسی سرپرست",
                (
                    f"ارسال‌کننده: {actor['full_name']} | "
                    f"سرپرست انتخاب‌شده: {supervisor['full_name']}"
                ),
                actor_member_id
            )

        return True

    def supervisor_review(
        self,
        project_id,
        test_id,
        supervisor_member_id,
        decision,
        comment=""
    ):
        """Supervisor approves the test or returns it for correction."""

        decision_map = {
            "approve": ("تأیید", "تأیید سرپرست"),
            "return": ("برگشت برای اصلاح", "نیازمند اصلاح")
        }

        if decision not in decision_map:
            raise ValueError(
                "تصمیم سرپرست باید approve یا return باشد."
            )

        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون موردنظر پیدا نشد.")

            if test["status"] != "آماده بررسی سرپرست":
                raise ValueError(
                    "آزمون در وضعیت آماده بررسی سرپرست نیست."
                )

            if test["supervisor_member_id"] != supervisor_member_id:
                raise ValueError(
                    "این آزمون برای بررسی به سرپرست دیگری ارجاع شده است."
                )

            supervisor = self._get_member(
                conn, supervisor_member_id, project_id
            )
            self._require_role(
                supervisor,
                {"سرپرست حسابرسی"}
            )

            if decision == "return" and not str(comment).strip():
                raise ValueError(
                    "برای برگشت آزمون، درج توضیح اصلاحات الزامی است."
                )

            decision_text, new_status = decision_map[decision]

            conn.execute(
                """
                UPDATE audit_tests
                SET status = ?,
                    supervisor_decision = ?,
                    supervisor_reviewed_at = CURRENT_TIMESTAMP,
                    supervisor_comment = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (
                    new_status,
                    decision_text,
                    comment,
                    test_id,
                    project_id
                )
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "تصمیم سرپرست",
                f"تصمیم: {decision_text} | توضیحات: {comment}",
                supervisor_member_id
            )

        return True

    def manager_approve(
        self,
        project_id,
        test_id,
        manager_member_id,
        comment=""
    ):
        """Final approval by an explicitly identified audit manager."""

        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون موردنظر پیدا نشد.")

            if test["status"] != "تأیید سرپرست":
                raise ValueError(
                    "ابتدا باید آزمون توسط سرپرست تأیید شود."
                )

            manager = self._get_member(
                conn, manager_member_id, project_id
            )
            self._require_role(
                manager,
                {"مدیر حسابرسی"}
            )

            conn.execute(
                """
                UPDATE audit_tests
                SET status = 'تأیید نهایی مدیر',
                    manager_member_id = ?,
                    manager_approved_at = CURRENT_TIMESTAMP,
                    manager_comment = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (
                    manager_member_id,
                    comment,
                    test_id,
                    project_id
                )
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "تأیید نهایی مدیر حسابرسی",
                (
                    f"مدیر تأییدکننده: {manager['full_name']} | "
                    f"توضیحات: {comment}"
                ),
                manager_member_id
            )

        return True

    # ---------------------------------------------------------
    # Progress and exceptions
    # ---------------------------------------------------------

    def test_progress(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_samples,
                    SUM(
                        CASE
                            WHEN result <> 'رسیدگی‌نشده'
                            THEN 1 ELSE 0
                        END
                    ) AS tested_samples,
                    SUM(
                        CASE
                            WHEN result = 'رسیدگی‌نشده'
                            THEN 1 ELSE 0
                        END
                    ) AS untested_samples,
                    SUM(
                        CASE
                            WHEN result IN ('مغایرت', 'عدم انطباق')
                            THEN 1 ELSE 0
                        END
                    ) AS exception_samples
                FROM audit_test_samples
                WHERE test_id = ?
                """,
                (test_id,)
            )

            row = self._row(cur)
            total = row["total_samples"] or 0
            tested = row["tested_samples"] or 0

            row["completion_percent"] = (
                round(tested * 100 / total, 2) if total else 0
            )

            return row

    def exceptions_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_test_samples
                WHERE test_id = ?
                  AND result IN ('مغایرت', 'عدم انطباق')
                ORDER BY sample_no
                """,
                (test_id,)
            )
            return self._rows(cur)

    def history_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT h.*, m.full_name AS actor_name, m.role AS actor_role
                FROM audit_test_history AS h
                LEFT JOIN team_members AS m
                    ON m.id = h.actor_member_id
                   AND m.project_id = h.project_id
                WHERE h.test_id = ?
                ORDER BY h.id DESC
                """,
                (test_id,)
            )
            return self._rows(cur)

    # ---------------------------------------------------------
    # Links: tests, workpapers and findings
    # ---------------------------------------------------------

    def link_test_workpaper(self, project_id, test_id, workpaper_id):
        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون در این پروژه پیدا نشد.")

            self._ensure_editable(test)

            if workpaper_id is not None:
                workpaper = conn.execute(
                    """
                    SELECT id
                    FROM workpapers
                    WHERE id = ? AND project_id = ?
                    """,
                    (workpaper_id, project_id)
                ).fetchone()

                if not workpaper:
                    raise ValueError(
                        "کاربرگ در این پروژه پیدا نشد."
                    )

            if test.get("finding_id"):
                finding = conn.execute(
                    "SELECT workpaper_id FROM findings WHERE id=? AND project_id=?",
                    (test["finding_id"], project_id),
                ).fetchone()
                if finding and finding[0] is not None and finding[0] != workpaper_id:
                    raise ValueError(
                        "کاربرگ آزمون با کاربرگ مرتبط با یافته یکسان نیست."
                    )

            conn.execute(
                """
                UPDATE audit_tests
                SET workpaper_id = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (workpaper_id, test_id, project_id)
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "اتصال کاربرگ",
                f"شناسه کاربرگ: {workpaper_id}"
            )

        return True

    def link_test_finding(self, project_id, test_id, finding_id):
        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون در این پروژه پیدا نشد.")

            self._ensure_editable(test)

            if finding_id is not None:
                finding = conn.execute(
                    """
                    SELECT id, workpaper_id
                    FROM findings
                    WHERE id = ? AND project_id = ?
                    """,
                    (finding_id, project_id)
                ).fetchone()

                if not finding:
                    raise ValueError(
                        "یافته در این پروژه پیدا نشد."
                    )
                if (
                    test.get("workpaper_id") is not None
                    and finding[1] is not None
                    and test["workpaper_id"] != finding[1]
                ):
                    raise ValueError(
                        "یافته به کاربرگی متفاوت از کاربرگ متصل به آزمون مرتبط است."
                    )

            conn.execute(
                """
                UPDATE audit_tests
                SET finding_id = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND project_id = ?
                """,
                (finding_id, test_id, project_id)
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "اتصال یافته",
                f"شناسه یافته: {finding_id}"
            )

        return True

    def link_sample_finding(
        self, project_id, test_id, sample_id, finding_id
    ):
        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون در این پروژه پیدا نشد.")

            self._ensure_editable(test)

            sample = conn.execute(
                """
                SELECT id
                FROM audit_test_samples
                WHERE id = ?
                  AND test_id = ?
                  AND project_id = ?
                """,
                (sample_id, test_id, project_id)
            ).fetchone()

            if not sample:
                raise ValueError(
                    "نمونه متعلق به این آزمون یا پروژه نیست."
                )

            finding = conn.execute(
                """
                SELECT id, workpaper_id
                FROM findings
                WHERE id = ? AND project_id = ?
                """,
                (finding_id, project_id)
            ).fetchone()

            if not finding:
                raise ValueError(
                    "یافته در این پروژه پیدا نشد."
                )
            if (
                test.get("workpaper_id") is not None
                and finding[1] is not None
                and test["workpaper_id"] != finding[1]
            ):
                raise ValueError(
                    "یافته نمونه به کاربرگی متفاوت از کاربرگ آزمون مرتبط است."
                )

            conn.execute(
                """
                INSERT OR IGNORE INTO audit_sample_findings (
                    project_id, test_id, sample_id, finding_id
                )
                VALUES (?, ?, ?, ?)
                """,
                (project_id, test_id, sample_id, finding_id)
            )

            self._add_history(
                conn,
                project_id,
                test_id,
                "اتصال یافته به نمونه",
                f"شناسه یافته: {finding_id}",
                sample_id=sample_id
            )

        return True

    def unlink_sample_finding(
        self, project_id, test_id, sample_id, finding_id
    ):
        with connect() as conn:
            test = self._get_test(conn, test_id, project_id)

            if not test:
                raise ValueError("آزمون در این پروژه پیدا نشد.")

            self._ensure_editable(test)

            cur = conn.execute(
                """
                DELETE FROM audit_sample_findings
                WHERE project_id = ?
                  AND test_id = ?
                  AND sample_id = ?
                  AND finding_id = ?
                """,
                (project_id, test_id, sample_id, finding_id)
            )

            if cur.rowcount:
                self._add_history(
                    conn,
                    project_id,
                    test_id,
                    "قطع ارتباط یافته از نمونه",
                    f"شناسه یافته: {finding_id}",
                    sample_id=sample_id
                )

            return cur.rowcount > 0

    def test_links(self, project_id, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT
                    t.id,
                    t.title,
                    t.workpaper_id,
                    w.title AS workpaper_title,
                    t.finding_id,
                    f.title AS finding_title
                FROM audit_tests t
                LEFT JOIN workpapers w
                    ON w.id = t.workpaper_id
                   AND w.project_id = t.project_id
                LEFT JOIN findings f
                    ON f.id = t.finding_id
                   AND f.project_id = t.project_id
                WHERE t.id = ? AND t.project_id = ?
                """,
                (test_id, project_id)
            )

            return self._row(cur)

    def findings_for_sample(self, project_id, sample_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT
                    f.id,
                    f.title,
                    f.severity,
                    f.status,
                    sf.created_at
                FROM audit_sample_findings sf
                JOIN findings f
                    ON f.id = sf.finding_id
                   AND f.project_id = sf.project_id
                WHERE sf.project_id = ?
                  AND sf.sample_id = ?
                ORDER BY f.id DESC
                """,
                (project_id, sample_id)
            )

            return self._rows(cur)

    def available_workpapers(self, project_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT id, title, status
                FROM workpapers
                WHERE project_id = ?
                ORDER BY id DESC
                """,
                (project_id,)
            )
            return self._rows(cur)

    def available_findings(self, project_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT id, title, severity, status
                FROM findings
                WHERE project_id = ?
                ORDER BY id DESC
                """,
                (project_id,)
            )
            return self._rows(cur)
