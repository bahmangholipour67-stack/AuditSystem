from database.connection import connect
from repositories.base_repository import BaseRepository


class WorkpaperRepository(BaseRepository):
    STATUS_DRAFT = "پیش‌نویس"
    STATUS_PENDING_REVIEW = "در انتظار بررسی مدیر"
    STATUS_NEEDS_CORRECTION = "نیازمند اصلاح"
    STATUS_SUPERVISOR_APPROVED = "تأیید سرپرست"
    STATUS_FINAL_APPROVED = "نهایی و تأیید"

    AUDITOR_ROLES = {"حسابرس", "حسابرس ارشد"}
    SUPERVISOR_ROLES = {"سرپرست حسابرسی"}
    MANAGER_ROLES = {"مدیر حسابرسی"}

    def for_project(self, project_id):
        return self.fetch_all("""
            SELECT id, title, procedure, result, status
            FROM workpapers
            WHERE project_id = ?
            ORDER BY id DESC
        """, (project_id,))

    def for_project_detailed(self, project_id):
        return self.fetch_all("""
            SELECT
                w.id, w.title, w.procedure, w.result, w.status,
                w.assigned_member_id, a.full_name,
                w.reviewer_member_id, r.full_name,
                w.approved_by_member_id, w.reviewed_at, w.approved_at,
                w.risk_id, risks.title AS risk_title
            FROM workpapers w
            LEFT JOIN team_members a ON a.id = w.assigned_member_id
            LEFT JOIN team_members r ON r.id = w.reviewer_member_id
            LEFT JOIN risks ON risks.id = w.risk_id AND risks.project_id = w.project_id
            WHERE w.project_id = ?
            ORDER BY w.id DESC
        """, (project_id,))

    def create(
        self, project_id, title, procedure="", result="",
        status="پیش‌نویس", risk_id=None, assigned_member_id=None,
        reviewer_member_id=None
    ):
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")
        if not str(title or "").strip():
            raise ValueError("عنوان کاربرگ الزامی است.")
        if status != self.STATUS_DRAFT:
            raise ValueError("کاربرگ جدید باید با وضعیت پیش‌نویس ثبت شود.")
        with connect() as conn:
            if risk_id is not None:
                risk = conn.execute(
                    "SELECT id FROM risks WHERE id=? AND project_id=?",
                    (risk_id, project_id),
                ).fetchone()
                if not risk:
                    raise ValueError("ریسک انتخاب‌شده متعلق به این پرونده نیست.")
            cur = conn.execute("""
                INSERT INTO workpapers (
                    project_id, risk_id, title, procedure, result, status,
                    assigned_member_id, reviewer_member_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                project_id, risk_id, str(title).strip(), procedure, result,
                status, assigned_member_id, reviewer_member_id
            ))
            return cur.lastrowid


    def update_content(self, project_id, workpaper_id, title, procedure="", result=""):
        title = str(title or "").strip()
        if not title:
            raise ValueError("عنوان کاربرگ الزامی است.")
        with connect() as conn:
            row = conn.execute(
                "SELECT status FROM workpapers WHERE id=? AND project_id=?",
                (workpaper_id, project_id),
            ).fetchone()
            if not row:
                raise ValueError("کاربرگ موردنظر پیدا نشد.")
            if row[0] not in (self.STATUS_DRAFT, self.STATUS_NEEDS_CORRECTION):
                raise ValueError("ویرایش محتوای کاربرگ پس از ارسال برای بررسی مجاز نیست.")
            conn.execute(
                "UPDATE workpapers SET title=?, procedure=?, result=? WHERE id=? AND project_id=?",
                (title, str(procedure or "").strip(), str(result or "").strip(),
                 workpaper_id, project_id),
            )
        return True

    @staticmethod
    def _row(cursor):
        row = cursor.fetchone()
        if row is None:
            return None
        return dict(zip([item[0] for item in cursor.description], row))

    @staticmethod
    def _get_member(conn, member_id, project_id):
        if not member_id:
            return None
        cur = conn.execute("""
            SELECT id, project_id, full_name, role, is_active
            FROM team_members
            WHERE id = ? AND project_id = ? AND is_active = 1
        """, (member_id, project_id))
        return WorkpaperRepository._row(cur)

    @staticmethod
    def _require_role(member, roles):
        if not member:
            raise ValueError("عضو انتخاب‌شده فعال نیست یا به این پرونده تعلق ندارد.")
        if member["role"] not in roles:
            raise ValueError("نقش عضو انتخاب‌شده اجازه انجام این عملیات را ندارد.")

    def link_risk(self, project_id, workpaper_id, risk_id):
        with connect() as conn:
            workpaper = conn.execute(
                "SELECT status FROM workpapers WHERE id=? AND project_id=?",
                (workpaper_id, project_id),
            ).fetchone()
            if not workpaper:
                raise ValueError("کاربرگ موردنظر در این پرونده پیدا نشد.")
            if workpaper[0] not in (self.STATUS_DRAFT, self.STATUS_NEEDS_CORRECTION):
                raise ValueError("ارتباط ریسک پس از ارسال کاربرگ برای بررسی قابل تغییر نیست.")
            if risk_id is not None:
                risk = conn.execute(
                    "SELECT id FROM risks WHERE id=? AND project_id=?",
                    (risk_id, project_id),
                ).fetchone()
                if not risk:
                    raise ValueError("ریسک انتخاب‌شده متعلق به این پرونده نیست.")
            conn.execute(
                "UPDATE workpapers SET risk_id=? WHERE id=? AND project_id=?",
                (risk_id, workpaper_id, project_id),
            )
            conn.execute(
                "UPDATE findings SET risk_id=? WHERE workpaper_id=? AND project_id=?",
                (risk_id, workpaper_id, project_id),
            )
            conn.execute(
                "UPDATE audit_programs SET risk_id=?, updated_at=CURRENT_TIMESTAMP "
                "WHERE workpaper_id=? AND project_id=?",
                (risk_id, workpaper_id, project_id),
            )
        return True

    def update_assignment(
        self, project_id, workpaper_id, assigned_member_id, reviewer_member_id
    ):
        with connect() as conn:
            cur = conn.execute("""
                SELECT status FROM workpapers
                WHERE id = ? AND project_id = ?
            """, (workpaper_id, project_id))
            workpaper = cur.fetchone()
            if not workpaper:
                raise ValueError("کاربرگ موردنظر پیدا نشد.")
            if workpaper[0] not in (self.STATUS_DRAFT, self.STATUS_NEEDS_CORRECTION):
                raise ValueError("تخصیص کاربرگ پس از ارسال برای بررسی قابل تغییر نیست.")

            assignee = self._get_member(conn, assigned_member_id, project_id)
            reviewer = self._get_member(conn, reviewer_member_id, project_id)
            self._require_role(assignee, self.AUDITOR_ROLES)
            self._require_role(reviewer, self.SUPERVISOR_ROLES)
            if assignee["id"] == reviewer["id"]:
                raise ValueError("حسابرس مسئول و سرپرست بررسی‌کننده باید متفاوت باشند.")

            conn.execute("""
                UPDATE workpapers
                SET assigned_member_id = ?, reviewer_member_id = ?
                WHERE id = ? AND project_id = ?
            """, (assigned_member_id, reviewer_member_id, workpaper_id, project_id))
        return True

    def update_workflow(
        self, project_id, workpaper_id, new_status,
        actor_member_id=None, notes=""
    ):
        if not project_id or not workpaper_id or not actor_member_id:
            raise ValueError("پرونده، کاربرگ و عضو انجام‌دهنده عملیات باید مشخص باشند.")

        allowed_transitions = {
            self.STATUS_PENDING_REVIEW,
            self.STATUS_NEEDS_CORRECTION,
            self.STATUS_SUPERVISOR_APPROVED,
            self.STATUS_FINAL_APPROVED,
        }
        if new_status not in allowed_transitions:
            raise ValueError("وضعیت درخواستی معتبر نیست.")

        with connect() as conn:
            cur = conn.execute("""
                SELECT id, project_id, status, assigned_member_id,
                       reviewer_member_id
                FROM workpapers
                WHERE id = ? AND project_id = ?
            """, (workpaper_id, project_id))
            workpaper = self._row(cur)
            if not workpaper:
                raise ValueError("کاربرگ موردنظر پیدا نشد.")

            actor = self._get_member(conn, actor_member_id, project_id)
            if not actor:
                raise ValueError("عضو انجام‌دهنده فعال نیست یا به این پرونده تعلق ندارد.")

            previous = workpaper["status"]
            assigned_id = workpaper["assigned_member_id"]
            reviewer_id = workpaper["reviewer_member_id"]
            notes = str(notes or "").strip()

            if new_status == self.STATUS_PENDING_REVIEW:
                if previous not in (self.STATUS_DRAFT, self.STATUS_NEEDS_CORRECTION):
                    raise ValueError("فقط کاربرگ پیش‌نویس یا نیازمند اصلاح قابل ارسال است.")
                self._require_role(actor, self.AUDITOR_ROLES)
                if actor_member_id != assigned_id:
                    raise ValueError("فقط حسابرس مسئول تعیین‌شده می‌تواند کاربرگ را ارسال کند.")
                if not reviewer_id:
                    raise ValueError("ابتدا سرپرست بررسی‌کننده را تعیین کنید.")
                action = "ارسال برای بررسی سرپرست"

            elif new_status in (self.STATUS_SUPERVISOR_APPROVED, self.STATUS_NEEDS_CORRECTION) and previous == self.STATUS_PENDING_REVIEW:
                self._require_role(actor, self.SUPERVISOR_ROLES)
                if actor_member_id != reviewer_id:
                    raise ValueError("فقط سرپرست تعیین‌شده برای این کاربرگ می‌تواند آن را بررسی کند.")
                if new_status == self.STATUS_NEEDS_CORRECTION and not notes:
                    raise ValueError("برای برگشت کاربرگ جهت اصلاح، درج توضیحات الزامی است.")
                action = "تأیید سرپرست" if new_status == self.STATUS_SUPERVISOR_APPROVED else "ارجاع برای اصلاح"

            elif new_status == self.STATUS_FINAL_APPROVED:
                if previous != self.STATUS_SUPERVISOR_APPROVED:
                    raise ValueError("تأیید نهایی فقط پس از تأیید سرپرست امکان‌پذیر است.")
                self._require_role(actor, self.MANAGER_ROLES)
                action = "تأیید نهایی مدیر حسابرسی"

            else:
                raise ValueError("تغییر وضعیت در این مرحله از گردش کار مجاز نیست.")

            conn.execute("""
                UPDATE workpapers
                SET status = ?,
                    reviewed_at = CASE WHEN ? IN (?, ?, ?) THEN CURRENT_TIMESTAMP ELSE reviewed_at END,
                    approved_at = CASE WHEN ? = ? THEN CURRENT_TIMESTAMP ELSE approved_at END,
                    approved_by_member_id = CASE WHEN ? = ? THEN ? ELSE approved_by_member_id END
                WHERE id = ? AND project_id = ?
            """, (
                new_status,
                new_status, self.STATUS_PENDING_REVIEW, self.STATUS_SUPERVISOR_APPROVED,
                self.STATUS_NEEDS_CORRECTION,
                new_status, self.STATUS_FINAL_APPROVED,
                new_status, self.STATUS_FINAL_APPROVED, actor_member_id,
                workpaper_id, project_id
            ))

            conn.execute("""
                INSERT INTO workpaper_history (
                    project_id, workpaper_id, action, previous_status,
                    new_status, actor_member_id, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                project_id, workpaper_id, action, previous,
                new_status, actor_member_id, notes
            ))
        return True

    def history(self, workpaper_id):
        return self.fetch_all("""
            SELECT h.id, h.action, h.previous_status, h.new_status,
                   m.full_name, h.notes, h.created_at
            FROM workpaper_history h
            LEFT JOIN team_members m ON m.id = h.actor_member_id
            WHERE h.workpaper_id = ?
            ORDER BY h.id DESC
        """, (workpaper_id,))

    def delete(self, project_id, workpaper_id):
        if not project_id or not workpaper_id:
            raise ValueError("پرونده و شناسه کاربرگ باید مشخص باشند.")
        with connect() as conn:
            row = conn.execute("SELECT status FROM workpapers WHERE id=? AND project_id=?", (workpaper_id, project_id)).fetchone()
            if not row:
                raise ValueError("کاربرگ موردنظر در این پرونده پیدا نشد.")
            if row[0] != self.STATUS_DRAFT:
                raise ValueError("فقط کاربرگ پیش‌نویس قابل حذف است؛ سایر وضعیت‌ها باید در سوابق باقی بمانند.")
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            deps = []
            for (name,) in tables:
                if name == "workpapers":
                    continue
                q = '"' + str(name).replace('"', '""') + '"'
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
                if {"project_id", "workpaper_id"}.issubset(cols):
                    n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND workpaper_id=?", (project_id, workpaper_id)).fetchone()[0]
                    if n:
                        deps.append(f"{name}: {n}")
            if deps:
                raise ValueError("این کاربرگ دارای ارتباط یا سابقه ثبت‌شده است و حذف نمی‌شود: " + "، ".join(deps))
            conn.execute("DELETE FROM workpapers WHERE id=? AND project_id=?", (workpaper_id, project_id))
        return True
