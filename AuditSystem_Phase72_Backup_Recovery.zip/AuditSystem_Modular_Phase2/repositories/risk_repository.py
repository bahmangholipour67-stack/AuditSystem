from database.connection import connect
from repositories.base_repository import BaseRepository


class RiskRepository(BaseRepository):
    """Project-scoped risk access and linkage queries."""

    def for_project(self, project_id):
        return self.fetch_all(
            """SELECT id, title, score, control_desc
               FROM risks WHERE project_id=?
               ORDER BY score DESC, id DESC""",
            (project_id,),
        )

    def for_project_detailed(self, project_id):
        return self.fetch_all(
            """SELECT r.id, r.title, r.score, r.control_desc,
                      COUNT(DISTINCT w.id) AS workpaper_count,
                      COUNT(DISTINCT f.id) AS finding_count
               FROM risks r
               LEFT JOIN workpapers w
                 ON w.risk_id = r.id AND w.project_id = r.project_id
               LEFT JOIN findings f
                 ON f.risk_id = r.id AND f.project_id = r.project_id
               WHERE r.project_id=?
               GROUP BY r.id, r.title, r.score, r.control_desc
               ORDER BY r.score DESC, r.id DESC""",
            (project_id,),
        )

    def create(self, project_id, title, score, control_desc=""):
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")
        title = str(title or "").strip()
        if not title:
            raise ValueError("عنوان ریسک الزامی است.")
        try:
            score = int(score)
        except (TypeError, ValueError):
            raise ValueError("امتیاز ریسک باید عدد صحیح باشد.")
        if not 1 <= score <= 25:
            raise ValueError("امتیاز ریسک باید بین ۱ تا ۲۵ باشد.")
        return self.execute(
            "INSERT INTO risks(project_id,title,score,control_desc) VALUES(?,?,?,?)",
            (project_id, title, score, str(control_desc or "").strip()),
        )

    def get(self, project_id, risk_id):
        rows = self.fetch_all(
            "SELECT id, project_id, title, score, control_desc "
            "FROM risks WHERE id=? AND project_id=?",
            (risk_id, project_id),
        )
        return rows[0] if rows else None

    def update(self, project_id, risk_id, title, score, control_desc=""):
        title = str(title or "").strip()
        if not title:
            raise ValueError("عنوان ریسک الزامی است.")
        try:
            score = int(score)
        except (TypeError, ValueError):
            raise ValueError("امتیاز ریسک باید عدد صحیح باشد.")
        if not 1 <= score <= 25:
            raise ValueError("امتیاز ریسک باید بین ۱ تا ۲۵ باشد.")
        return self.execute(
            "UPDATE risks SET title=?, score=?, control_desc=? WHERE id=? AND project_id=?",
            (title, score, str(control_desc or "").strip(), risk_id, project_id),
        )

    def delete(self, risk_id):
        if not risk_id:
            raise ValueError("شناسه ریسک معتبر نیست.")
        with connect() as conn:
            row = conn.execute("SELECT id, project_id FROM risks WHERE id=?", (risk_id,)).fetchone()
            if not row:
                raise ValueError("ریسک موردنظر پیدا نشد.")
            pid = row[1]
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            deps = []
            dependency_labels = {
                "workpapers": "کاربرگ",
                "findings": "یافته",
                "audit_programs": "برنامه آزمون",
                "audit_tests": "آزمون حسابرسی",
                "audit_test_evidence": "مدرک آزمون",
            }
            for (name,) in tables:
                if name == "risks":
                    continue
                q = '"' + str(name).replace('"', '""') + '"'
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
                if {"project_id", "risk_id"}.issubset(cols):
                    n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND risk_id=?", (pid, risk_id)).fetchone()[0]
                    if n:
                        label = dependency_labels.get(name, name)
                        deps.append(f"{label}: {n}")
            if deps:
                raise ValueError("این ریسک دارای ارجاع وابسته است و حذف نمی‌شود: " + "، ".join(deps))
            conn.execute("DELETE FROM risks WHERE id=? AND project_id=?", (risk_id, pid))
        return True
