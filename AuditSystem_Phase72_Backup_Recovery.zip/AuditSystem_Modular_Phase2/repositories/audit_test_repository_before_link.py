
from database.connection import connect


class AuditTestRepository:
    """Database operations for audit programs, tests and samples."""

    # ---------------------------------------------------------
    # Common helpers
    # ---------------------------------------------------------

    @staticmethod
    def _rows(cursor):
        columns = [item[0] for item in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

    @staticmethod
    def _row(cursor):
        columns = [item[0] for item in cursor.description]
        row = cursor.fetchone()
        return dict(zip(columns, row)) if row else None

    # ---------------------------------------------------------
    # Audit programs
    # ---------------------------------------------------------

    def for_project(self, project_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_programs
                WHERE project_id = ?
                ORDER BY id DESC
                """,
                (project_id,)
            )
            return self._rows(cur)

    def get_program(self, program_id):
        with connect() as conn:
            cur = conn.execute(
                "SELECT * FROM audit_programs WHERE id = ?",
                (program_id,)
            )
            return self._row(cur)

    def create_program(
        self,
        project_id,
        title,
        audit_area="",
        objective="",
        risk_id=None,
        workpaper_id=None,
        assigned_member_id=None,
        start_date="",
        due_date="",
        status="جدید",
        notes=""
    ):
        with connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO audit_programs (
                    project_id, title, audit_area, objective,
                    risk_id, workpaper_id, assigned_member_id,
                    start_date, due_date, status, notes,
                    created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """,
                (
                    project_id, title, audit_area, objective,
                    risk_id, workpaper_id, assigned_member_id,
                    start_date, due_date, status, notes
                )
            )
            return cur.lastrowid

    # ---------------------------------------------------------
    # Audit tests
    # ---------------------------------------------------------

    def tests_for_program(self, program_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_tests
                WHERE program_id = ?
                ORDER BY id DESC
                """,
                (program_id,)
            )
            return self._rows(cur)

    def get_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                "SELECT * FROM audit_tests WHERE id = ?",
                (test_id,)
            )
            return self._row(cur)

    def create_test(
        self,
        project_id,
        program_id,
        title,
        test_type="ماهوی",
        procedure="",
        population_description="",
        population_size=0,
        sample_size=0,
        sampling_method="تصادفی",
        random_seed=None,
        assigned_member_id=None,
        status="جدید",
        conclusion=""
    ):
        with connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO audit_tests (
                    project_id, program_id, title, test_type,
                    procedure, population_description,
                    population_size, sample_size, sampling_method,
                    random_seed, assigned_member_id, status,
                    conclusion, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """,
                (
                    project_id, program_id, title, test_type,
                    procedure, population_description,
                    population_size, sample_size, sampling_method,
                    random_seed, assigned_member_id, status,
                    conclusion
                )
            )
            return cur.lastrowid

    # ---------------------------------------------------------
    # Samples
    # ---------------------------------------------------------

    def samples_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_test_samples
                WHERE test_id = ?
                ORDER BY sample_no
                """,
                (test_id,)
            )
            return self._rows(cur)

    def create_samples(self, project_id, test_id, selected_rows):
        """
        Create selected samples once.
        Existing samples are not silently replaced.
        selected_rows: iterable of population row numbers.
        """
        selected_rows = list(selected_rows)

        if not selected_rows:
            raise ValueError("فهرست نمونه‌ها خالی است.")

        if len(set(selected_rows)) != len(selected_rows):
            raise ValueError("شماره نمونه تکراری است.")

        with connect() as conn:
            test = conn.execute(
                """
                SELECT population_size, sample_size
                FROM audit_tests
                WHERE id = ? AND project_id = ?
                """,
                (test_id, project_id)
            ).fetchone()

            if not test:
                raise ValueError("آزمون موردنظر پیدا نشد.")

            population_size, sample_size = test

            if len(selected_rows) != sample_size:
                raise ValueError("تعداد نمونه‌ها با حجم نمونه آزمون برابر نیست.")

            if any(
                not isinstance(x, int) or x < 1 or x > population_size
                for x in selected_rows
            ):
                raise ValueError("شماره یکی از نمونه‌ها خارج از محدوده جامعه است.")

            existing = conn.execute(
                "SELECT COUNT(*) FROM audit_test_samples WHERE test_id = ?",
                (test_id,)
            ).fetchone()[0]

            if existing:
                raise ValueError(
                    "برای این آزمون قبلاً نمونه ثبت شده است؛ "
                    "نمونه‌های قبلی حذف یا جایگزین نمی‌شوند."
                )

            for number, population_row in enumerate(
                sorted(selected_rows), start=1
            ):
                conn.execute(
                    """
                    INSERT INTO audit_test_samples (
                        project_id, test_id, sample_no,
                        population_row, result, created_at
                    )
                    VALUES (?, ?, ?, ?, 'رسیدگی‌نشده', CURRENT_TIMESTAMP)
                    """,
                    (project_id, test_id, number, population_row)
                )

            conn.execute(
                """
                UPDATE audit_tests
                SET status = 'در حال اجرا',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (test_id,)
            )

            return len(selected_rows)

    def update_sample_result(
        self,
        sample_id,
        result,
        exception_description="",
        document_ref="",
        description="",
        amount=None,
        evidence_path="",
        tested_by_member_id=None,
        actor_member_id=None
    ):
        allowed_results = {
            "رسیدگی‌نشده",
            "تأیید",
            "مغایرت",
            "عدم انطباق",
            "نیازمند بررسی"
        }

        if result not in allowed_results:
            raise ValueError("نتیجه رسیدگی معتبر نیست.")

        with connect() as conn:
            sample = conn.execute(
                """
                SELECT test_id, project_id
                FROM audit_test_samples
                WHERE id = ?
                """,
                (sample_id,)
            ).fetchone()

            if not sample:
                raise ValueError("نمونه موردنظر پیدا نشد.")

            test_id, project_id = sample

            conn.execute(
                """
                UPDATE audit_test_samples
                SET result = ?,
                    exception_description = ?,
                    document_ref = ?,
                    description = ?,
                    amount = ?,
                    evidence_path = ?,
                    tested_by_member_id = ?,
                    tested_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (
                    result, exception_description, document_ref,
                    description, amount, evidence_path,
                    tested_by_member_id, sample_id
                )
            )

            conn.execute(
                """
                INSERT INTO audit_test_history (
                    project_id, test_id, sample_id,
                    action, details, actor_member_id, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (
                    project_id, test_id, sample_id,
                    "ثبت نتیجه نمونه",
                    f"نتیجه: {result} | توضیحات: {exception_description}",
                    actor_member_id
                )
            )

    # ---------------------------------------------------------
    # Progress and exceptions
    # ---------------------------------------------------------

    def test_progress(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_samples,
                    SUM(CASE WHEN result <> 'رسیدگی‌نشده'
                        THEN 1 ELSE 0 END) AS tested_samples,
                    SUM(CASE WHEN result = 'رسیدگی‌نشده'
                        THEN 1 ELSE 0 END) AS untested_samples,
                    SUM(CASE WHEN result IN ('مغایرت', 'عدم انطباق')
                        THEN 1 ELSE 0 END) AS exception_samples
                FROM audit_test_samples
                WHERE test_id = ?
                """,
                (test_id,)
            )

            row = self._row(cur)
            total = row["total_samples"] or 0
            tested = row["tested_samples"] or 0

            row["completion_percent"] = (
                round(tested * 100 / total, 2) if total else 0
            )
            return row

    def exceptions_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_test_samples
                WHERE test_id = ?
                  AND result IN ('مغایرت', 'عدم انطباق')
                ORDER BY sample_no
                """,
                (test_id,)
            )
            return self._rows(cur)

    def history_for_test(self, test_id):
        with connect() as conn:
            cur = conn.execute(
                """
                SELECT *
                FROM audit_test_history
                WHERE test_id = ?
                ORDER BY id DESC
                """,
                (test_id,)
            )
            return self._rows(cur)
