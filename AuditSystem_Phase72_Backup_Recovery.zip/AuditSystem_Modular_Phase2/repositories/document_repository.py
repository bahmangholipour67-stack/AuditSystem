"""Project-scoped document repository with immutable audit history."""
from pathlib import Path
from contextlib import contextmanager
import hashlib
from database.connection import connect


class DocumentRepository:
    LINK_TABLES = {
        "risk": ("risks", "id"),
        "workpaper": ("workpapers", "id"),
        "finding": ("findings", "id"),
        "audit_test": ("audit_tests", "id"),
        "audit_program": ("audit_programs", "id"),
    }

    def __init__(self, db_path=None):
        self.db_path = db_path

    @contextmanager
    def _connect(self):
        manager = connect(self.db_path) if self.db_path else connect()
        with manager as conn:
            conn.row_factory = __import__("sqlite3").Row
            yield conn

    @staticmethod
    def _file_metadata(file_path):
        path = Path(file_path).expanduser()
        if not path.is_file():
            raise ValueError("فایل انتخاب‌شده وجود ندارد یا قابل دسترسی نیست.")
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return path.resolve(), path.name, path.stat().st_size, digest.hexdigest()

    def register(self, project_id, title, file_path, category="عمومی", description="", uploaded_by_member_id=None):
        title = str(title or "").strip()
        if not title or not project_id:
            raise ValueError("پرونده و عنوان سند الزامی است.")
        path, name, size, checksum = self._file_metadata(file_path)
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                raise ValueError("پرونده انتخاب‌شده وجود ندارد.")
            if uploaded_by_member_id is not None and not conn.execute(
                "SELECT 1 FROM team_members WHERE id=? AND project_id=? AND is_active=1",
                (uploaded_by_member_id, project_id),
            ).fetchone():
                raise ValueError("عضو ثبت‌کننده فعال نیست یا به این پرونده تعلق ندارد.")
            cur = conn.execute("""INSERT INTO engagement_documents
                (project_id,title,category,file_path,file_name,size_bytes,sha256,description,uploaded_by_member_id)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (project_id,title,str(category or "عمومی").strip(),str(path),name,size,checksum,
                 str(description or "").strip(),uploaded_by_member_id))
            return cur.lastrowid

    def link(self, project_id, document_id, relation_type, relation_id):
        if relation_type not in self.LINK_TABLES:
            raise ValueError("نوع ارتباط سند معتبر نیست.")
        table, key = self.LINK_TABLES[relation_type]
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM engagement_documents WHERE id=? AND project_id=? AND archived_at IS NULL", (document_id, project_id)).fetchone():
                raise ValueError("سند فعال در این پرونده پیدا نشد.")
            if not conn.execute(f"SELECT 1 FROM {table} WHERE {key}=? AND project_id=?", (relation_id, project_id)).fetchone():
                raise ValueError("رکورد مقصد متعلق به این پرونده نیست.")
            cur = conn.execute("""INSERT OR IGNORE INTO document_links
                (project_id,document_id,relation_type,relation_id) VALUES(?,?,?,?)""",
                (project_id,document_id,relation_type,relation_id))
            return cur.rowcount > 0

    def list_for_project(self, project_id, include_archived=False):
        sql = "SELECT * FROM engagement_documents WHERE project_id=?"
        if not include_archived:
            sql += " AND archived_at IS NULL"
        sql += " ORDER BY id DESC"
        with self._connect() as conn:
            return [dict(row) for row in conn.execute(sql, (project_id,)).fetchall()]

    def archive(self, project_id, document_id, reason, actor_member_id=None):
        if not str(reason or "").strip():
            raise ValueError("علت بایگانی سند الزامی است.")
        with self._connect() as conn:
            cur = conn.execute("""UPDATE engagement_documents SET archived_at=CURRENT_TIMESTAMP,
                archive_reason=?, archived_by_member_id=?
                WHERE id=? AND project_id=? AND archived_at IS NULL""",
                (str(reason).strip(),actor_member_id,document_id,project_id))
            if not cur.rowcount:
                raise ValueError("سند فعال برای بایگانی پیدا نشد.")
            conn.execute("INSERT INTO document_history(project_id,document_id,event_type,details,actor_member_id) VALUES(?,?,'ARCHIVE',?,?)",
                         (project_id,document_id,str(reason).strip(),actor_member_id))
        return True

    def restore(self, project_id, document_id, actor_member_id=None):
        with self._connect() as conn:
            cur = conn.execute("UPDATE engagement_documents SET archived_at=NULL, archive_reason='', archived_by_member_id=NULL WHERE id=? AND project_id=? AND archived_at IS NOT NULL", (document_id,project_id))
            if not cur.rowcount:
                raise ValueError("سند بایگانی‌شده پیدا نشد.")
            conn.execute("INSERT INTO document_history(project_id,document_id,event_type,actor_member_id) VALUES(?,?,'RESTORE',?)", (project_id,document_id,actor_member_id))
        return True
