"""Document request workflow; status changes are recorded, never erased."""
from database.connection import connect
from contextlib import contextmanager


class DocumentRequestRepository:
    STATUSES = {"جدید", "ارسال‌شده", "دریافت‌شده", "در حال بررسی", "تکمیل‌شده", "لغوشده"}
    PRIORITIES = {"عادی", "مهم", "فوری"}

    def __init__(self, db_path=None):
        self.db_path = db_path

    @contextmanager
    def _connect(self):
        manager = connect(self.db_path) if self.db_path else connect()
        with manager as conn:
            conn.row_factory = __import__("sqlite3").Row
            yield conn

    def create(self, project_id, title, description="", requested_from="", assigned_member_id=None,
               due_date="", priority="عادی", created_by_member_id=None):
        title = str(title or "").strip()
        if not project_id or not title:
            raise ValueError("پرونده و عنوان درخواست الزامی است.")
        if priority not in self.PRIORITIES:
            raise ValueError("اولویت درخواست معتبر نیست.")
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                raise ValueError("پرونده انتخاب‌شده وجود ندارد.")
            for member_id in (assigned_member_id, created_by_member_id):
                if member_id is not None and not conn.execute(
                    "SELECT 1 FROM team_members WHERE id=? AND project_id=? AND is_active=1", (member_id,project_id)
                ).fetchone():
                    raise ValueError("عضو انتخاب‌شده فعال نیست یا به این پرونده تعلق ندارد.")
            cur = conn.execute("""INSERT INTO document_requests
                (project_id,title,description,requested_from,assigned_member_id,due_date,priority,created_by_member_id)
                VALUES(?,?,?,?,?,?,?,?)""",
                (project_id,title,str(description or "").strip(),str(requested_from or "").strip(),
                 assigned_member_id,str(due_date or "").strip(),priority,created_by_member_id))
            conn.execute("INSERT INTO document_request_history(project_id,request_id,event_type,new_status,actor_member_id,details) VALUES(?,?,'CREATED','جدید',?,?)",
                         (project_id,cur.lastrowid,created_by_member_id,title))
            return cur.lastrowid

    def update_status(self, project_id, request_id, new_status, actor_member_id=None, note=""):
        if new_status not in self.STATUSES:
            raise ValueError("وضعیت جدید معتبر نیست.")
        with self._connect() as conn:
            row = conn.execute("SELECT status FROM document_requests WHERE id=? AND project_id=? AND archived_at IS NULL", (request_id,project_id)).fetchone()
            if not row:
                raise ValueError("درخواست فعال در این پرونده پیدا نشد.")
            old_status = row[0]
            if old_status == new_status:
                return False
            completed = "CURRENT_TIMESTAMP" if new_status in ("تکمیل‌شده", "لغوشده") else "NULL"
            conn.execute(f"UPDATE document_requests SET status=?, updated_at=CURRENT_TIMESTAMP, completed_at={completed} WHERE id=? AND project_id=?",
                         (new_status,request_id,project_id))
            conn.execute("""INSERT INTO document_request_history
                (project_id,request_id,event_type,old_status,new_status,actor_member_id,details)
                VALUES(?,?,'STATUS_CHANGED',?,?,?,?)""",
                (project_id,request_id,old_status,new_status,actor_member_id,str(note or "").strip()))
        return True

    def list_for_project(self, project_id, include_archived=False):
        sql = "SELECT * FROM document_requests WHERE project_id=?"
        if not include_archived:
            sql += " AND archived_at IS NULL"
        sql += " ORDER BY CASE priority WHEN 'فوری' THEN 0 WHEN 'مهم' THEN 1 ELSE 2 END, due_date, id DESC"
        with self._connect() as conn:
            return [dict(row) for row in conn.execute(sql,(project_id,)).fetchall()]

    def history(self, project_id, request_id):
        with self._connect() as conn:
            return [dict(row) for row in conn.execute("SELECT * FROM document_request_history WHERE project_id=? AND request_id=? ORDER BY id",(project_id,request_id)).fetchall()]

    def archive(self, project_id, request_id, reason, actor_member_id=None):
        if not str(reason or "").strip():
            raise ValueError("علت بایگانی درخواست الزامی است.")
        with self._connect() as conn:
            cur = conn.execute("UPDATE document_requests SET archived_at=CURRENT_TIMESTAMP, archive_reason=?, archived_by_member_id=? WHERE id=? AND project_id=? AND archived_at IS NULL",(str(reason).strip(),actor_member_id,request_id,project_id))
            if not cur.rowcount:
                raise ValueError("درخواست فعال برای بایگانی پیدا نشد.")
            conn.execute("INSERT INTO document_request_history(project_id,request_id,event_type,details,actor_member_id) VALUES(?,?,'ARCHIVE',?,?)",(project_id,request_id,str(reason).strip(),actor_member_id))
        return True
