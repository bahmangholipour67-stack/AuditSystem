from database.connection import connect
class BaseRepository:
    def fetch_all(self, sql, params=()):
        with connect() as conn: return conn.execute(sql, params).fetchall()
    def execute(self, sql, params=()):
        with connect() as conn:
            cur=conn.execute(sql, params)
            return cur.lastrowid
