"""Read-only project-scoped data loader for audit traceability reporting."""

from database.connection import connect


class AuditTraceabilityRepository:
    """Collect existing risk/program/test/evidence/finding links without schema changes."""

    @staticmethod
    def _rows(cursor):
        names = [column[0] for column in cursor.description]
        return [dict(zip(names, row)) for row in cursor.fetchall()]

    def for_project(self, project_id):
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")

        with connect() as conn:
            risks = self._rows(conn.execute(
                "SELECT id, title, score, control_desc FROM risks WHERE project_id=? ORDER BY score DESC, id",
                (project_id,),
            ))
            programs = self._rows(conn.execute(
                "SELECT id, title, audit_area, objective, risk_id, workpaper_id, status "
                "FROM audit_programs WHERE project_id=? ORDER BY id",
                (project_id,),
            ))
            tests = self._rows(conn.execute(
                """SELECT t.id, t.program_id, t.title, t.test_type, t.status,
                          t.workpaper_id, t.finding_id, t.template_id,
                          t.template_objective, t.template_assertions,
                          t.expected_evidence, t.conclusion,
                          p.risk_id AS program_risk_id,
                          w.risk_id AS workpaper_risk_id,
                          w.title AS workpaper_title,
                          f.title AS finding_title
                   FROM audit_tests t
                   LEFT JOIN audit_programs p
                     ON p.id=t.program_id AND p.project_id=t.project_id
                   LEFT JOIN workpapers w
                     ON w.id=t.workpaper_id AND w.project_id=t.project_id
                   LEFT JOIN findings f
                     ON f.id=t.finding_id AND f.project_id=t.project_id
                   WHERE t.project_id=? ORDER BY t.id""",
                (project_id,),
            ))
            samples = self._rows(conn.execute(
                """SELECT s.id, s.test_id, s.sample_no, s.result, s.evidence_path,
                          s.exception_description, s.misstatement_amount,
                          sf.finding_id
                   FROM audit_test_samples s
                   LEFT JOIN audit_sample_findings sf
                     ON sf.sample_id=s.id AND sf.test_id=s.test_id AND sf.project_id=s.project_id
                   WHERE s.project_id=? ORDER BY s.test_id, s.sample_no""",
                (project_id,),
            ))
            findings = self._rows(conn.execute(
                """SELECT f.id, f.title, f.severity, f.status, f.risk_id,
                          f.workpaper_id, w.risk_id AS workpaper_risk_id,
                          w.title AS workpaper_title
                   FROM findings f
                   LEFT JOIN workpapers w
                     ON w.id=f.workpaper_id AND w.project_id=f.project_id
                   WHERE f.project_id=? ORDER BY f.id""",
                (project_id,),
            ))
            finding_evidence = self._rows(conn.execute(
                "SELECT id, finding_id, file_path, description FROM finding_evidence "
                "WHERE project_id=? ORDER BY id",
                (project_id,),
            ))

        return {
            "project_id": project_id,
            "risks": risks,
            "programs": programs,
            "tests": tests,
            "samples": samples,
            "findings": findings,
            "finding_evidence": finding_evidence,
        }
