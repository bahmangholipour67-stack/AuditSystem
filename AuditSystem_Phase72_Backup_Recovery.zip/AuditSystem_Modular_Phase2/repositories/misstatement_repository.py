"""Project-scoped misstatement register and materiality evaluation."""
from contextlib import contextmanager
import sqlite3
import json
from database.connection import connect


class MisstatementRepository:
    TYPES = ("واقعی", "قضاوتی", "برآوردی")
    STATUSES = ("اصلاح‌نشده", "اصلاح‌شده", "مورد اختلاف", "مسترد")
    LINK_TABLES = {"finding": "findings", "workpaper": "workpapers", "audit_test": "audit_tests"}

    def __init__(self, db_path=None):
        self.db_path = db_path

    @contextmanager
    def _connect(self):
        with connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            yield conn

    def set_materiality(self, project_id, overall, performance, clearly_trivial, basis="", actor_member_id=None):
        values = [float(overall), float(performance), float(clearly_trivial)]
        if not project_id or any(v < 0 for v in values):
            raise ValueError("پرونده و مبالغ اهمیت باید معتبر و نامنفی باشند.")
        if values[0] <= 0:
            raise ValueError("اهمیت کلی باید بزرگ‌تر از صفر باشد.")
        if values[1] > values[0]:
            raise ValueError("اهمیت عملکردی نمی‌تواند از اهمیت کلی بیشتر باشد.")
        if values[2] > values[1]:
            raise ValueError("حد آستانه ناچیز نمی‌تواند از اهمیت عملکردی بیشتر باشد.")
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                raise ValueError("پرونده حسابرسی پیدا نشد.")
            previous = conn.execute("SELECT overall_materiality,performance_materiality,clearly_trivial,basis FROM project_materiality WHERE project_id=?", (project_id,)).fetchone()
            if actor_member_id is not None and not conn.execute("SELECT 1 FROM team_members WHERE id=? AND project_id=? AND is_active=1", (actor_member_id,project_id)).fetchone():
                raise ValueError("عضو ثبت‌کننده فعال نیست یا متعلق به این پرونده نیست.")
            new_values = {"overall_materiality": values[0], "performance_materiality": values[1], "clearly_trivial": values[2], "basis": str(basis or "").strip()}
            conn.execute("""INSERT INTO project_materiality
                (project_id,overall_materiality,performance_materiality,clearly_trivial,basis,updated_at)
                VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(project_id) DO UPDATE SET
                overall_materiality=excluded.overall_materiality,
                performance_materiality=excluded.performance_materiality,
                clearly_trivial=excluded.clearly_trivial,basis=excluded.basis,
                updated_at=CURRENT_TIMESTAMP""", (project_id, *values, str(basis or "").strip()))
            conn.execute("INSERT INTO project_materiality_history(project_id,event_type,previous_values,new_values,actor_member_id) VALUES(?,?,?,?,?)",
                         (project_id, "UPDATED" if previous else "CREATED",
                          json.dumps(dict(previous) if previous else {}, ensure_ascii=False),
                          json.dumps(new_values, ensure_ascii=False), actor_member_id))
        return self.get_materiality(project_id)

    def get_materiality(self, project_id):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM project_materiality WHERE project_id=?", (project_id,)).fetchone()
            return dict(row) if row else None

    def create(self, project_id, title, misstatement_type, amount, account_name="", description="",
               source="", status="اصلاح‌نشده", finding_id=None, workpaper_id=None, audit_test_id=None,
               actor_member_id=None, tax_effect=None):
        title = str(title or "").strip()
        if not project_id or not title:
            raise ValueError("پرونده و عنوان تحریف الزامی است.")
        if misstatement_type not in self.TYPES:
            raise ValueError("نوع تحریف باید واقعی، قضاوتی یا برآوردی باشد.")
        if status not in self.STATUSES:
            raise ValueError("وضعیت تحریف معتبر نیست.")
        amount = float(amount)
        if amount < 0:
            raise ValueError("مبلغ تحریف باید نامنفی باشد؛ جهت اثر را در شرح ثبت کنید.")
        tax_effect = None if tax_effect in (None, "") else float(tax_effect)
        links = (("finding", finding_id), ("workpaper", workpaper_id), ("audit_test", audit_test_id))
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
                raise ValueError("پرونده حسابرسی پیدا نشد.")
            for kind, record_id in links:
                if record_id is not None and not conn.execute(
                    f"SELECT 1 FROM {self.LINK_TABLES[kind]} WHERE id=? AND project_id=?", (record_id, project_id)
                ).fetchone():
                    raise ValueError(f"رکورد مرتبط ({kind}) به این پرونده تعلق ندارد.")
            if actor_member_id is not None and not conn.execute(
                "SELECT 1 FROM team_members WHERE id=? AND project_id=? AND is_active=1", (actor_member_id, project_id)
            ).fetchone():
                raise ValueError("عضو ثبت‌کننده فعال نیست یا متعلق به این پرونده نیست.")
            cur = conn.execute("""INSERT INTO audit_misstatements
                (project_id,title,misstatement_type,account_name,description,source,amount,status,
                 finding_id,workpaper_id,audit_test_id,tax_effect,created_by_member_id)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (project_id,title,misstatement_type,str(account_name or "").strip(),str(description or "").strip(),
                 str(source or "").strip(),amount,status,finding_id,workpaper_id,audit_test_id,tax_effect,actor_member_id))
            item_id = cur.lastrowid
            conn.execute("INSERT INTO misstatement_history(project_id,misstatement_id,event_type,new_status,details,actor_member_id) VALUES(?,?,'CREATED',?,?,?)",
                         (project_id,item_id,status,str(description or "").strip(),actor_member_id))
            return item_id

    def update_status(self, project_id, misstatement_id, status, actor_member_id=None, note=""):
        if status not in self.STATUSES:
            raise ValueError("وضعیت تحریف معتبر نیست.")
        with self._connect() as conn:
            row = conn.execute("SELECT status FROM audit_misstatements WHERE id=? AND project_id=? AND archived_at IS NULL", (misstatement_id,project_id)).fetchone()
            if not row:
                raise ValueError("تحریف فعال پیدا نشد.")
            if row["status"] == status:
                return False
            conn.execute("UPDATE audit_misstatements SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND project_id=?", (status,misstatement_id,project_id))
            conn.execute("INSERT INTO misstatement_history(project_id,misstatement_id,event_type,old_status,new_status,details,actor_member_id) VALUES(?,?,'STATUS_CHANGED',?,?,?,?)",
                         (project_id,misstatement_id,row["status"],status,str(note or ""),actor_member_id))
        return True

    def list_for_project(self, project_id, include_archived=False):
        sql = "SELECT * FROM audit_misstatements WHERE project_id=?"
        if not include_archived:
            sql += " AND archived_at IS NULL"
        sql += " ORDER BY id DESC"
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(sql,(project_id,)).fetchall()]

    def archive(self, project_id, misstatement_id, reason, actor_member_id=None):
        if not str(reason or "").strip():
            raise ValueError("علت بایگانی الزامی است.")
        with self._connect() as conn:
            cur = conn.execute("UPDATE audit_misstatements SET archived_at=CURRENT_TIMESTAMP,archive_reason=?,archived_by_member_id=? WHERE id=? AND project_id=? AND archived_at IS NULL",
                               (str(reason).strip(),actor_member_id,misstatement_id,project_id))
            if not cur.rowcount:
                raise ValueError("تحریف فعال پیدا نشد.")
            conn.execute("INSERT INTO misstatement_history(project_id,misstatement_id,event_type,details,actor_member_id) VALUES(?,?,'ARCHIVED',?,?)",
                         (project_id,misstatement_id,str(reason).strip(),actor_member_id))
        return True

    def evaluate(self, project_id):
        materiality = self.get_materiality(project_id)
        rows = self.list_for_project(project_id)
        uncorrected = [r for r in rows if r["status"] in ("اصلاح‌نشده", "مورد اختلاف")]
        corrected = [r for r in rows if r["status"] == "اصلاح‌شده"]
        total = round(sum(float(r["amount"] or 0) for r in uncorrected), 2)
        by_type = {kind: round(sum(float(r["amount"] or 0) for r in uncorrected if r["misstatement_type"] == kind), 2) for kind in self.TYPES}
        individually_significant = []
        if materiality:
            individually_significant = [r["id"] for r in uncorrected if float(r["amount"] or 0) >= materiality["overall_materiality"]]
        threshold = materiality["overall_materiality"] if materiality else None
        return {
            "materiality": materiality, "items": rows, "uncorrected_count": len(uncorrected),
            "corrected_count": len(corrected), "uncorrected_total": total,
            "uncorrected_by_type": by_type, "clearly_trivial_exceeded_count": sum(
                1 for r in uncorrected if materiality and float(r["amount"] or 0) >= materiality["clearly_trivial"]
            ),
            "overall_materiality_exceeded": bool(materiality and total >= threshold),
            "individually_significant_ids": individually_significant,
            "evaluation_note": "جمع مبالغ به‌صورت ناخالص و بدون تهاتر بین حساب‌ها محاسبه شده است. نتیجه صرفاً ابزار ارزیابی است و تعیین اثر بر اظهارنظر نیازمند قضاوت حرفه‌ای، ماهیت و شرایط تحریف و الزامات استانداردهای مربوط است."
        }
