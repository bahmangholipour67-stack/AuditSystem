
from repositories.base_repository import BaseRepository


class TeamRepository(BaseRepository):

    def for_project(self, project_id, active_only=False):
        sql = """
            SELECT
                id, full_name, role, phone,
                email, is_active, created_at
            FROM team_members
            WHERE project_id = ?
        """

        params = [project_id]

        if active_only:
            sql += " AND is_active = 1"

        sql += " ORDER BY is_active DESC, full_name"

        return self.fetch_all(sql, tuple(params))

    def get(self, member_id):
        rows = self.fetch_all("""
            SELECT
                id, project_id, full_name, role,
                phone, email, is_active, created_at
            FROM team_members
            WHERE id = ?
        """, (member_id,))

        return rows[0] if rows else None

    def create(
        self,
        project_id,
        full_name,
        role="حسابرس",
        phone="",
        email=""
    ):
        return self.execute("""
            INSERT INTO team_members (
                project_id, full_name, role, phone, email
            )
            VALUES (?, ?, ?, ?, ?)
        """, (
            project_id, full_name, role, phone, email
        ))

    def update(
        self,
        member_id,
        full_name,
        role,
        phone="",
        email=""
    ):
        return self.execute("""
            UPDATE team_members
            SET
                full_name = ?,
                role = ?,
                phone = ?,
                email = ?
            WHERE id = ?
        """, (
            full_name, role, phone, email, member_id
        ))

    def deactivate(self, member_id):
        return self.execute("""
            UPDATE team_members
            SET is_active = 0
            WHERE id = ?
        """, (member_id,))

    def activate(self, member_id):
        return self.execute("""
            UPDATE team_members
            SET is_active = 1
            WHERE id = ?
        """, (member_id,))
