from database.connection import connect
from repositories.base_repository import BaseRepository
class TrialBalanceRepository(BaseRepository):
    def for_project(self, project_id): return self.fetch_all("SELECT id,account_code,account_name,debit,credit,net,flags,imported_at FROM trial_balance WHERE project_id=? ORDER BY account_code,account_name",(project_id,))
    def replace_for_project(self, project_id, records):
        with connect() as conn:
            conn.execute("DELETE FROM trial_balance WHERE project_id=?",(project_id,))
            conn.executemany("INSERT INTO trial_balance(project_id,account_code,account_name,debit,credit,net,flags) VALUES(?,?,?,?,?,?,?)",[(project_id,r['code'],r['name'],r['debit'],r['credit'],r['net'],r['flags']) for r in records])
