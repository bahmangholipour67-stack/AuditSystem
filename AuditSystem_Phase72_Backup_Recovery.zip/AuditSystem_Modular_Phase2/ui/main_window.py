"""Tkinter application composition root."""
from legacy.audit_app import AuditApp

def launch():
    import tkinter as tk
    root = tk.Tk()
    AuditApp(root)
    root.mainloop()
