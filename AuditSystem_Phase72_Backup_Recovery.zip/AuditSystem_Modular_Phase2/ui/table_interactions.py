"""Keyboard and sorting enhancements shared by Treeview-based audit tables.

The helpers are presentation-only: they never alter the underlying records,
repository calls, or business workflows.
"""
from decimal import Decimal, InvalidOperation
import re
import tkinter as tk

_DIGIT_TRANSLATION = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def _sort_value(value):
    text = str(value or "").strip().translate(_DIGIT_TRANSLATION)
    numeric = text.replace(",", "").replace("٬", "")
    if numeric.startswith("(") and numeric.endswith(")"):
        numeric = "-" + numeric[1:-1]
    try:
        return (0, Decimal(numeric))
    except (InvalidOperation, ValueError):
        return (1, text.casefold())


def attach_table_interactions(tree, clipboard_owner=None):
    """Enable sortable headings, Ctrl+C, Ctrl+A and a small context menu."""
    if getattr(tree, "_audit_table_interactions_attached", False):
        return tree

    columns = tuple(tree["columns"])
    headings = {column: tree.heading(column, "text") for column in columns}
    state = {"column": None, "reverse": False}
    owner = clipboard_owner or tree

    def sort_by(column):
        reverse = state["reverse"] if state["column"] == column else False
        rows = [( _sort_value(tree.set(item, column)), item) for item in tree.get_children("")]
        rows.sort(key=lambda pair: pair[0], reverse=reverse)
        for index, (_, item) in enumerate(rows):
            tree.move(item, "", index)
        for key, title in headings.items():
            suffix = (" ↓" if reverse else " ↑") if key == column else ""
            tree.heading(key, text=title + suffix)
        state.update(column=column, reverse=not reverse)
        return "break"

    for column in columns:
        tree.heading(column, command=lambda key=column: sort_by(key))

    def copy_selection(event=None):
        selected = tree.selection()
        if not selected:
            return "break"
        lines = []
        for item in selected:
            values = tree.item(item, "values")
            lines.append("\t".join(str(value) for value in values))
        try:
            owner.clipboard_clear()
            owner.clipboard_append("\n".join(lines))
        except tk.TclError:
            pass
        return "break"

    def select_all(event=None):
        items = tree.get_children("")
        if items:
            tree.selection_set(items)
        return "break"

    tree.bind("<Control-c>", copy_selection, add="+")
    tree.bind("<Control-C>", copy_selection, add="+")
    tree.bind("<Control-a>", select_all, add="+")
    tree.bind("<Control-A>", select_all, add="+")

    menu = tk.Menu(tree, tearoff=False)
    menu.add_command(label="کپی ردیف‌های انتخاب‌شده", command=copy_selection)
    menu.add_command(label="انتخاب همه ردیف‌ها", command=select_all)

    def show_context_menu(event):
        row = tree.identify_row(event.y)
        if row and row not in tree.selection():
            tree.selection_set(row)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    tree.bind("<Button-3>", show_context_menu, add="+")
    tree._audit_table_interactions_attached = True
    tree._audit_table_sort_state = state
    tree._audit_table_copy = copy_selection
    tree._audit_table_select_all = select_all
    return tree
