﻿from tkinter import messagebox, ttk


class RiskViewMixin:
    def setup_risk_tab(self):
        form = ttk.LabelFrame(self.tab_risks, text="ثبت ریسک")
        form.pack(fill="x", padx=10, pady=8)

        ttk.Label(form, text="عنوان:").grid(row=0, column=0, padx=5, pady=8)
        self.ent_risk_title = ttk.Entry(form, width=35)
        self.ent_risk_title.grid(row=0, column=1, padx=5)

        ttk.Label(form, text="امتیاز ۱ تا ۲۵:").grid(row=0, column=2, padx=5)
        self.ent_risk_score = ttk.Spinbox(form, from_=1, to=25, width=6)
        self.ent_risk_score.set("1")
        self.ent_risk_score.grid(row=0, column=3, padx=5)

        ttk.Label(form, text="کنترل داخلی:").grid(row=1, column=0, padx=5, pady=8)
        self.ent_risk_ctrl = ttk.Entry(form, width=50)
        self.ent_risk_ctrl.grid(row=1, column=1, columnspan=2, sticky="ew", padx=5)

        ttk.Button(form, text="افزودن", command=self.add_risk).grid(row=1, column=3, padx=5)

        self.tree_risks = self.make_tree(
            self.tab_risks,
            [
                ("id", "شناسه", 65),
                ("title", "عنوان ریسک", 250),
                ("score", "امتیاز", 75),
                ("control", "کنترل داخلی", 300),
                ("workpapers", "تعداد کاربرگ", 95),
                ("findings", "تعداد یافته", 95),
            ],
        )
        nav_bar = self.add_record_navigation(self.tab_risks, self.tree_risks, on_edit=self.edit_selected_risk, label="ریسک")
        ttk.Button(nav_bar, text="حذف ریسک", command=self.delete_selected_risk).pack(side="left", padx=2)


    def delete_selected_risk(self):
        selected = self.tree_risks.selection()
        if not selected:
            messagebox.showinfo("انتخاب ریسک", "ابتدا یک ریسک را انتخاب کنید.")
            return
        values = self.tree_risks.item(selected[0], "values")
        risk_id = int(values[0])
        if not messagebox.askyesno("تأیید حذف", "آیا از حذف این ریسک اطمینان دارید؟"):
            return
        try:
            self.services.risks.delete(risk_id)
        except ValueError as exc:
            messagebox.showwarning("حذف ریسک ممکن نیست", str(exc))
            return
        except Exception as exc:
            messagebox.showerror("خطا در حذف ریسک", str(exc))
            return
        self.refresh_risks()
        self.ent_risk_title.delete(0, "end")
        self.ent_risk_ctrl.delete(0, "end")
        if hasattr(self, "refresh_dashboard"):
            self.refresh_dashboard()


    def edit_selected_risk(self):
        selected = self.tree_risks.selection()
        if not selected:
            messagebox.showinfo("انتخاب ریسک", "ابتدا یک ریسک را انتخاب کنید.")
            return
        values = self.tree_risks.item(selected[0], "values")
        project_id = self.get_current_project_id()
        if not project_id:
            return
        risk = self.services.risks.get(project_id, int(values[0]))
        if not risk:
            messagebox.showerror("یافت نشد", "اطلاعات ریسک پیدا نشد.")
            return
        from tkinter import Toplevel
        win = Toplevel(self.root); win.title("ویرایش ریسک"); win.transient(self.root); win.grab_set()
        self._style_dialog(win)
        win.resizable(False, False)
        fields = []
        for row, (label, value) in enumerate((("عنوان ریسک", risk[2]), ("امتیاز ۱ تا ۲۵", risk[3]), ("کنترل داخلی", risk[4] or ""))):
            ttk.Label(win, text=label).grid(row=row, column=1, padx=8, pady=7, sticky="e")
            ent = ttk.Entry(win, width=42); ent.grid(row=row, column=0, padx=8, pady=7); ent.insert(0, str(value))
            fields.append(ent)
        def save():
            try:
                self.services.risks.update(project_id, int(risk[0]), fields[0].get(), fields[1].get(), fields[2].get())
                win.destroy(); self.refresh_risks(); self.restore_tree_selection(self.tree_risks, risk[0])
                if hasattr(self, "refresh_dashboard"): self.refresh_dashboard()
            except Exception as exc: messagebox.showerror("خطا در ویرایش", str(exc), parent=win)
        ttk.Button(win, text="ذخیره تغییرات", command=save).grid(row=3, column=0, pady=10)

    def add_risk(self):
        pid = self.get_current_project_id()
        title = self.ent_risk_title.get().strip()
        if not pid or not title:
            messagebox.showwarning("اطلاعات ناقص", "پرونده و عنوان ریسک لازم است.")
            return
        try:
            score = int(self.ent_risk_score.get())
            self.services.risks.create(
                pid, title, score, self.ent_risk_ctrl.get().strip()
            )
            self.ent_risk_title.delete(0, "end")
            self.ent_risk_ctrl.delete(0, "end")
            self.refresh_risks()
            if hasattr(self, "refresh_workpapers"):
                self.refresh_workpapers()
            if hasattr(self, "refresh_audit_tests"):
                self.refresh_audit_tests()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
        except Exception as exc:
            messagebox.showerror("خطا در ثبت ریسک", str(exc))

    def refresh_risks(self):
        if not hasattr(self, "tree_risks"):
            return
        self.clear_tree(self.tree_risks)
        nav_refresh = getattr(self.tree_risks, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
        pid = self.get_current_project_id()
        if not pid:
            return
        for row in self.services.risks.for_project_detailed(pid):
            self.tree_risks.insert(
                "", "end",
                values=tuple(value if value is not None else "" for value in row),
            )
        nav_refresh = getattr(self.tree_risks, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
