"""Read-only shared execution dashboard for financial and internal audits."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import csv
import json

from services.unified_audit_execution_service import UnifiedAuditExecutionService


class UnifiedAuditExecutionViewMixin:
    def setup_unified_audit_execution_tab(self):
        self.unified_execution_service = UnifiedAuditExecutionService()
        self.unified_execution_result = None
        root = ttk.Frame(self.tab_unified_execution, padding=10)
        root.pack(fill="both", expand=True)
        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text="موتور مشترک اجرای حسابرسی صورت‌های مالی و حسابرسی داخلی",
                  font=("Tahoma", 14, "bold")).pack(side="right")
        self.unified_mode = ttk.Combobox(header, state="readonly", width=25,
            values=["تلفیقی (هر دو حوزه)", "صورت‌های مالی", "حسابرسی داخلی"])
        self.unified_mode.current(0)
        self.unified_mode.pack(side="right", padx=8)
        ttk.Button(header, text="اجرای ارزیابی", command=self.refresh_unified_execution).pack(side="left", padx=3)
        ttk.Button(header, text="خروجی JSON", command=lambda: self.export_unified_execution("json")).pack(side="left", padx=3)
        ttk.Button(header, text="خروجی CSV", command=lambda: self.export_unified_execution("csv")).pack(side="left", padx=3)

        self.unified_summary = ttk.Label(root, text="برای شروع، پرونده‌ای را انتخاب و ارزیابی را اجرا کنید.",
                                         font=("Tahoma", 11, "bold"), anchor="e")
        self.unified_summary.pack(fill="x", pady=6)
        cards = ttk.Frame(root)
        cards.pack(fill="x", pady=5)
        self.unified_cards = {}
        metrics = [("risks", "ریسک"), ("programs", "برنامه"), ("tests", "آزمون"),
                   ("samples", "نمونه"), ("findings", "یافته"), ("evidence_links", "شواهد یافته"),
                   ("open_gaps", "خلأ مستندسازی"), ("high_priority_gaps", "خلأ با اولویت بالا")]
        for i, (key, label) in enumerate(metrics):
            frame = ttk.LabelFrame(cards, text=label, padding=5)
            frame.grid(row=i // 4, column=i % 4, sticky="nsew", padx=3, pady=3)
            value = ttk.Label(frame, text="—", font=("Tahoma", 14, "bold"))
            value.pack(padx=12, pady=4)
            self.unified_cards[key] = value
        for col in range(4):
            cards.columnconfigure(col, weight=1)

        columns = ("priority", "type", "id", "title", "issue", "action")
        self.unified_gap_tree = ttk.Treeview(root, columns=columns, show="headings", height=13)
        heads = {"priority": "اولویت", "type": "نوع", "id": "شناسه", "title": "عنوان",
                 "issue": "خلأ یا مسئله", "action": "اقدام پیشنهادی"}
        widths = {"priority": 80, "type": 90, "id": 65, "title": 170, "issue": 300, "action": 300}
        for col in columns:
            self.unified_gap_tree.heading(col, text=heads[col])
            self.unified_gap_tree.column(col, width=widths[col], anchor="e", stretch=col in ("issue", "action", "title"))
        self.unified_gap_tree.pack(fill="both", expand=True, pady=6)
        self.unified_note = ttk.Label(root,
            text="این ابزار صرفاً تکمیل و ردیابی مستندات را ارزیابی می‌کند؛ پوشش ریسک یا وجود سند به‌تنهایی اثبات‌کننده کفایت شواهد نیست.",
            wraplength=1100, justify="right")
        self.unified_note.pack(fill="x", pady=4)

    def refresh_unified_execution(self):
        project_id = self.get_current_project_id()
        if not project_id:
            messagebox.showwarning("پرونده", "ابتدا یک پرونده حسابرسی انتخاب کنید.")
            return
        mode = {"تلفیقی (هر دو حوزه)": "combined", "صورت‌های مالی": "financial", "حسابرسی داخلی": "internal"}.get(self.unified_mode.get(), "combined")
        try:
            result = self.unified_execution_service.for_project(project_id, mode=mode)
            self.unified_execution_result = result
            self.unified_summary.config(text=f"{result['mode_label']} | پوشش ارتباط ریسک با آزمون: {result['risk_coverage_percent']}٪")
            for key, label in self.unified_cards.items():
                label.config(text=str(result["summary"].get(key, 0)))
            for item in self.unified_gap_tree.get_children():
                self.unified_gap_tree.delete(item)
            for index, gap in enumerate(result["gaps"]):
                self.unified_gap_tree.insert("", "end", iid=str(index), values=(gap["priority"], gap["entity_type"],
                    gap["entity_id"] or "—", gap["title"], gap["issue"], gap["action"]))
        except Exception as exc:
            messagebox.showerror("خطای موتور اجرای حسابرسی", str(exc))

    def export_unified_execution(self, file_type):
        result = self.unified_execution_result
        if not result:
            messagebox.showwarning("خروجی", "ابتدا ارزیابی را اجرا کنید.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json" if file_type == "json" else ".csv",
            filetypes=[("JSON", "*.json"), ("CSV", "*.csv")])
        if not path:
            return
        try:
            if file_type == "json":
                with open(path, "w", encoding="utf-8") as handle:
                    json.dump(result, handle, ensure_ascii=False, indent=2)
            else:
                with open(path, "w", encoding="utf-8-sig", newline="") as handle:
                    writer = csv.DictWriter(handle, fieldnames=["priority", "entity_type", "entity_id", "title", "issue", "action"])
                    writer.writeheader()
                    writer.writerows(result["gaps"])
            messagebox.showinfo("خروجی", "فایل با موفقیت ذخیره شد.")
        except OSError as exc:
            messagebox.showerror("خطای ذخیره", str(exc))
