
"""Advanced management dashboard for the audit system."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import sqlite3
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


class DashboardViewMixin:

    def setup_dashboard_tab(self):
        self.dashboard_cards = {}
        self.dashboard_data = {}
        self.risk_threshold = tk.IntVar(value=15)

        container = ttk.Frame(self.tab_dashboard, padding=12)
        container.pack(fill="both", expand=True)

        ttk.Label(
            container,
            text="داشبورد مدیریتی حسابرسی",
            font=("Tahoma", 16, "bold")
        ).pack(anchor="e", pady=(0, 12))

        cards_frame = ttk.Frame(container)
        cards_frame.pack(fill="x", pady=5)

        metrics = [
            ("projects", "تعداد پرونده‌ها"),
            ("risks", "تعداد ریسک‌ها"),
            ("workpapers", "تعداد کاربرگ‌ها"),
            ("findings", "تعداد یافته‌ها"),
            ("open_findings", "یافته‌های باز"),
            ("accounts", "حساب‌های تراز آزمایشی"),
        ]

        for index, (key, title) in enumerate(metrics):
            card = ttk.LabelFrame(
                cards_frame, text=title, padding=10
            )
            card.grid(
                row=index // 3,
                column=index % 3,
                padx=5, pady=5, sticky="nsew"
            )

            value = ttk.Label(
                card, text="0",
                font=("Tahoma", 18, "bold")
            )
            value.pack(pady=5)
            self.dashboard_cards[key] = value

        for col in range(3):
            cards_frame.columnconfigure(col, weight=1)

        ttk.Separator(container).pack(fill="x", pady=10)

        controls = ttk.Frame(container)
        controls.pack(fill="x", pady=5)

        ttk.Label(
            controls, text="آستانه هشدار ریسک:"
        ).pack(side="right", padx=5)

        ttk.Spinbox(
            controls,
            from_=1,
            to=100,
            width=6,
            textvariable=self.risk_threshold,
            command=self.refresh_dashboard
        ).pack(side="right", padx=5)

        ttk.Button(
            controls,
            text="به‌روزرسانی",
            command=self.refresh_dashboard
        ).pack(side="left", padx=5)

        ttk.Button(
            controls,
            text="خروجی Excel",
            command=self.export_dashboard_excel
        ).pack(side="left", padx=5)

        ttk.Button(
            controls,
            text="گزارش مدیریتی",
            command=self.export_management_report
        ).pack(side="left", padx=5)

        charts = ttk.Frame(container)
        charts.pack(fill="both", expand=True, pady=8)

        risk_frame = ttk.LabelFrame(
            charts, text="نمودار امتیاز ریسک‌ها", padding=8
        )
        risk_frame.pack(
            side="right", fill="both", expand=True, padx=5
        )

        self.risk_canvas = tk.Canvas(
            risk_frame, height=230,
            background="white", highlightthickness=0
        )
        self.risk_canvas.pack(fill="both", expand=True)

        progress_frame = ttk.LabelFrame(
            charts, text="پیشرفت حسابرسی", padding=8
        )
        progress_frame.pack(
            side="left", fill="both", expand=True, padx=5
        )

        self.progress_text = ttk.Label(
            progress_frame,
            text="هنوز کاربرگی ثبت نشده است",
            font=("Tahoma", 11)
        )
        self.progress_text.pack(anchor="e", pady=10)

        self.progress_bar = ttk.Progressbar(
            progress_frame, maximum=100, mode="determinate"
        )
        self.progress_bar.pack(fill="x", pady=8)

        self.findings_text = ttk.Label(
            progress_frame,
            text="هنوز یافته‌ای ثبت نشده است",
            font=("Tahoma", 10),
            justify="right"
        )
        self.findings_text.pack(anchor="e", pady=10)

        ttk.Separator(container).pack(fill="x", pady=8)

        self.alert_text = tk.Text(
            container, height=5, wrap="word",
            font=("Tahoma", 10), state="disabled"
        )
        self.alert_text.pack(fill="x", pady=5)

        self.dashboard_status = ttk.Label(
            container, text="آماده به کار"
        )
        self.dashboard_status.pack(anchor="e", pady=5)

        self.refresh_dashboard()

    def _get_dashboard_data(self):
        project_id = self.get_current_project_id()

        with self.get_conn() as conn:
            cursor = conn.cursor()

            tables = {
                "projects": "projects",
                "risks": "risks",
                "workpapers": "workpapers",
                "findings": "findings",
                "accounts": "trial_balance",
            }

            data = {}

            for key, table in tables.items():
                if key == "projects" or project_id is None:
                    cursor.execute(
                        f"SELECT COUNT(*) FROM {table}"
                    )
                else:
                    cursor.execute(
                        f"SELECT COUNT(*) FROM {table} WHERE project_id=?",
                        (project_id,)
                    )
                data[key] = cursor.fetchone()[0]

            data["project_id"] = project_id

            if project_id is None:
                cursor.execute(
                    "SELECT title, score FROM risks ORDER BY score DESC"
                )
                risk_rows = cursor.fetchall()

                cursor.execute(
                    "SELECT status, COUNT(*) FROM workpapers GROUP BY status"
                )
                workpaper_rows = cursor.fetchall()

                cursor.execute(
                    "SELECT status, COUNT(*) FROM findings GROUP BY status"
                )
                finding_rows = cursor.fetchall()

                cursor.execute(
                    "SELECT status FROM workpapers"
                )
                all_workpapers = cursor.fetchall()

                cursor.execute(
                    "SELECT status FROM findings"
                )
                all_findings = cursor.fetchall()
            else:
                cursor.execute(
                    """SELECT title, score FROM risks
                       WHERE project_id=? ORDER BY score DESC""",
                    (project_id,)
                )
                risk_rows = cursor.fetchall()

                cursor.execute(
                    """SELECT status, COUNT(*) FROM workpapers
                       WHERE project_id=? GROUP BY status""",
                    (project_id,)
                )
                workpaper_rows = cursor.fetchall()

                cursor.execute(
                    """SELECT status, COUNT(*) FROM findings
                       WHERE project_id=? GROUP BY status""",
                    (project_id,)
                )
                finding_rows = cursor.fetchall()

                cursor.execute(
                    "SELECT status FROM workpapers WHERE project_id=?",
                    (project_id,)
                )
                all_workpapers = cursor.fetchall()

                cursor.execute(
                    "SELECT status FROM findings WHERE project_id=?",
                    (project_id,)
                )
                all_findings = cursor.fetchall()

        data["risk_rows"] = risk_rows
        data["workpaper_rows"] = workpaper_rows
        data["finding_rows"] = finding_rows
        data["all_workpapers"] = all_workpapers
        data["all_findings"] = all_findings

        return data

    @staticmethod
    def _normalize_status(value):
        return str(value or "").strip().replace("ي", "ی").replace("ك", "ک").lower()

    def _is_closed(self, status):
        value = self._normalize_status(status)
        closed_values = (
            "بسته", "مختومه", "رفع‌شده", "رفع شده",
            "تکمیل شده", "تکمیل‌شده", "انجام شده",
            "انجام‌شده", "completed", "closed", "done"
        )
        return value in closed_values

    def refresh_dashboard(self):
        try:
            data = self._get_dashboard_data()
            self.dashboard_data = data

            open_findings = sum(
                1 for row in data["all_findings"]
                if not self._is_closed(row[0])
            )

            values = {
                "projects": data["projects"],
                "risks": data["risks"],
                "workpapers": data["workpapers"],
                "findings": data["findings"],
                "open_findings": open_findings,
                "accounts": data["accounts"],
            }

            for key, value in values.items():
                self.dashboard_cards[key].configure(
                    text=f"{value:,}"
                )

            self._draw_risk_chart(data["risk_rows"])
            self._update_progress(data)
            self._update_findings(data)
            self._update_alerts(data)

            self.dashboard_status.configure(
                text="آمار با موفقیت به‌روزرسانی شد"
            )

        except Exception as exc:
            self.dashboard_status.configure(
                text=f"خطا در دریافت آمار: {exc}"
            )

    def _draw_risk_chart(self, risks):
        canvas = self.risk_canvas
        canvas.delete("all")

        width = max(canvas.winfo_width(), 350)
        height = max(canvas.winfo_height(), 220)

        if not risks:
            canvas.create_text(
                width // 2, height // 2,
                text="هنوز ریسکی ثبت نشده است",
                font=("Tahoma", 10)
            )
            return

        max_score = max(max(int(r[1]), 1) for r in risks)
        threshold = self.risk_threshold.get()

        visible = risks[:8]
        bar_height = 22
        gap = 9

        for index, (title, score) in enumerate(visible):
            y = 20 + index * (bar_height + gap)

            canvas.create_text(
                width - 8, y + 10,
                text=str(title)[:22],
                anchor="e",
                font=("Tahoma", 8)
            )

            bar_start = 10
            bar_end = width - 155
            available = max(bar_end - bar_start, 50)

            length = int(available * int(score) / max_score)

            canvas.create_rectangle(
                bar_start, y,
                bar_start + length, y + bar_height,
                fill="#C0504D" if int(score) >= threshold else "#4F81BD",
                outline=""
            )

            canvas.create_text(
                bar_start + length + 25,
                y + 10,
                text=str(score),
                font=("Tahoma", 9, "bold")
            )

    def _update_progress(self, data):
        rows = data["all_workpapers"]
        total = len(rows)

        completed = sum(
            1 for row in rows if self._is_closed(row[0])
        )

        percent = round(completed * 100 / total) if total else 0

        self.progress_bar["value"] = percent

        if total:
            self.progress_text.configure(
                text=f"کاربرگ تکمیل‌شده: {completed} از {total} ({percent}٪)"
            )
        else:
            self.progress_text.configure(
                text="هنوز کاربرگی ثبت نشده است"
            )

    def _update_findings(self, data):
        rows = data["all_findings"]

        if not rows:
            self.findings_text.configure(
                text="هنوز یافته‌ای ثبت نشده است"
            )
            return

        closed = sum(
            1 for row in rows if self._is_closed(row[0])
        )
        opened = len(rows) - closed

        self.findings_text.configure(
            text=f"کل یافته‌ها: {len(rows)} | باز: {opened} | بسته: {closed}"
        )

    def _update_alerts(self, data):
        threshold = self.risk_threshold.get()
        high_risks = [
            (title, score)
            for title, score in data["risk_rows"]
            if int(score) >= threshold
        ]

        messages = []

        if high_risks:
            messages.append(
                f"هشدار: {len(high_risks)} ریسک با امتیاز "
                f"{threshold} یا بیشتر شناسایی شد."
            )
            for title, score in high_risks:
                messages.append(f"• {title}: {score}")
        else:
            messages.append(
                "ریسکی بالاتر از آستانه هشدار فعلی وجود ندارد."
            )

        if data["workpapers"] == 0:
            messages.append("• هنوز کاربرگی برای این محدوده ثبت نشده است.")

        if data["findings"] == 0:
            messages.append("• هنوز یافته‌ای برای این محدوده ثبت نشده است.")

        self.alert_text.configure(state="normal")
        self.alert_text.delete("1.0", "end")
        self.alert_text.insert("1.0", "\n".join(messages))
        self.alert_text.configure(state="disabled")

    def export_dashboard_excel(self):
        if not self.dashboard_data:
            messagebox.showwarning(
                "گزارش", "ابتدا داشبورد را به‌روزرسانی کنید."
            )
            return

        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile="Audit_Management_Report.xlsx"
        )

        if not path:
            return

        try:
            data = self.dashboard_data
            wb = Workbook()

            ws = wb.active
            ws.title = "آمار مدیریتی"

            ws.append(["شاخص", "مقدار"])
            summary = [
                ("تعداد پرونده‌ها", data["projects"]),
                ("تعداد ریسک‌ها", data["risks"]),
                ("تعداد کاربرگ‌ها", data["workpapers"]),
                ("تعداد یافته‌ها", data["findings"]),
                ("تعداد حساب‌ها", data["accounts"]),
                ("آستانه هشدار", self.risk_threshold.get()),
            ]

            for row in summary:
                ws.append(list(row))

            risk_ws = wb.create_sheet("ریسک‌ها")
            risk_ws.append(["عنوان ریسک", "امتیاز"])
            for row in data["risk_rows"]:
                risk_ws.append(list(row))

            work_ws = wb.create_sheet("کاربرگ‌ها")
            work_ws.append(["وضعیت", "تعداد"])
            for row in data["workpaper_rows"]:
                work_ws.append(list(row))

            finding_ws = wb.create_sheet("یافته‌ها")
            finding_ws.append(["وضعیت", "تعداد"])
            for row in data["finding_rows"]:
                finding_ws.append(list(row))

            for sheet in wb.worksheets:
                sheet.freeze_panes = "A2"
                sheet.sheet_view.rightToLeft = True

                for cell in sheet[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(
                        "solid", fgColor="1F4E78"
                    )
                    cell.alignment = Alignment(horizontal="center")

                for column in sheet.columns:
                    letter = get_column_letter(column[0].column)
                    max_length = max(
                        len(str(cell.value or "")) for cell in column
                    )
                    sheet.column_dimensions[letter].width = min(
                        max(max_length + 4, 14), 45
                    )

            wb.save(path)

            messagebox.showinfo(
                "گزارش Excel",
                "فایل Excel با موفقیت ذخیره شد."
            )

        except Exception as exc:
            messagebox.showerror(
                "خطا", f"تهیه Excel ناموفق بود:\n{exc}"
            )

    def export_management_report(self):
        if not self.dashboard_data:
            messagebox.showwarning(
                "گزارش", "ابتدا داشبورد را به‌روزرسانی کنید."
            )
            return

        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش مدیریتی",
            defaultextension=".txt",
            filetypes=[("Text", "*.txt")],
            initialfile="Audit_Management_Report.txt"
        )

        if not path:
            return

        data = self.dashboard_data
        threshold = self.risk_threshold.get()

        high_risks = [
            (title, score)
            for title, score in data["risk_rows"]
            if int(score) >= threshold
        ]

        completed = sum(
            1 for row in data["all_workpapers"]
            if self._is_closed(row[0])
        )

        total = len(data["all_workpapers"])
        progress = round(completed * 100 / total) if total else 0

        lines = [
            "گزارش مدیریتی حسابرسی",
            "=" * 45,
            f"تاریخ تهیه: {datetime.now():%Y-%m-%d %H:%M}",
            "",
            f"تعداد پرونده‌ها: {data['projects']}",
            f"تعداد ریسک‌ها: {data['risks']}",
            f"تعداد کاربرگ‌ها: {data['workpapers']}",
            f"تعداد یافته‌ها: {data['findings']}",
            f"تعداد حساب‌ها: {data['accounts']}",
            "",
            f"پیشرفت کاربرگ‌ها: {progress}٪",
            f"آستانه هشدار ریسک: {threshold}",
            "",
            "ریسک‌های نیازمند توجه:"
        ]

        if high_risks:
            for title, score in high_risks:
                lines.append(f"- {title}: {score}")
        else:
            lines.append("موردی بالاتر از آستانه مشاهده نشد.")

        Path(path).write_text(
            "\n".join(lines), encoding="utf-8-sig"
        )

        messagebox.showinfo(
            "گزارش مدیریتی",
            "گزارش با موفقیت ذخیره شد."
        )
