import csv, io, math, os, random, re, sqlite3, tkinter as tk
from collections import Counter
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from services.number_utils import parse_amount, safe_csv_text

class TrialBalanceViewMixin:
    def setup_trial_balance_tab(self):
            buttons = ttk.Frame(self.tab_tb)
            buttons.pack(fill="x", padx=10, pady=9)
    
            ttk.Button(
                buttons,
                text="ورود CSV / Excel",
                command=self.import_trial_balance,
            ).pack(side="left", padx=5)
    
            ttk.Button(
                buttons,
                text="خروجی تراز CSV",
                command=self.export_trial_balance_csv,
            ).pack(side="left", padx=5)
    
            ttk.Label(
                self.tab_tb,
                text=(
                    "ستون‌های لازم: نام حساب، مانده بدهکار، مانده بستانکار. "
                    "کد حساب اختیاری است. فایل XLSX/XLSM به openpyxl نیاز دارد."
                ),
                wraplength=1100,
                justify="right",
            ).pack(anchor="e", padx=15, pady=5)
    
            self.lbl_tb_summary = ttk.Label(
                self.tab_tb,
                text="برای این پرونده تراز آزمایشی وارد نشده است.",
            )
            self.lbl_tb_summary.pack(anchor="e", padx=15, pady=7)
    
            self.tree_tb = self.make_tree(
                self.tab_tb,
                [
                    ("code", "کد حساب", 115),
                    ("name", "نام حساب", 260),
                    ("debit", "مانده بدهکار", 155),
                    ("credit", "مانده بستانکار", 155),
                    ("net", "خالص بدهکار/(بستانکار)", 190),
                    ("flags", "موارد نیازمند بررسی", 340),
                ],
            )
    
    def normalize_tb_header(self, value):
            text = str(value or "").strip().lower()
            text = text.translate(str.maketrans({"ي": "ی", "ك": "ک"}))
            return re.sub(r"[\s\u200c_\-./()]+", "", text)
    
    def find_tb_columns(self, header):
            aliases = {
                "name": {
                    "نامحساب", "شرححساب", "سرفصل",
                    "accountname", "account", "name",
                },
                "code": {
                    "کد", "کدحساب", "accountcode", "code",
                },
                "debit": {
                    "بدهکار", "ماندهبدهکار",
                    "ماندهبدهکارپایاندوره",
                    "debit", "debitbalance", "closingdebitbalance",
                },
                "credit": {
                    "بستانکار", "ماندهبستانکار",
                    "ماندهبستانکارپایاندوره",
                    "credit", "creditbalance", "closingcreditbalance",
                },
            }
    
            found = {}
            for index, value in enumerate(header):
                normalized = self.normalize_tb_header(value)
                for key, options in aliases.items():
                    if key not in found and normalized in options:
                        found[key] = index
            return found
    
    def read_trial_balance_file(self, path):
        return self.services.trial_balance_tools.read_file(path)
    
    def percentile(self, sorted_values, fraction):
            position = (len(sorted_values) - 1) * fraction
            lower = int(position)
            upper = min(lower + 1, len(sorted_values) - 1)
            weight = position - lower
            return (
                sorted_values[lower] * (1 - weight)
                + sorted_values[upper] * weight
            )
    
    def add_tb_flags(self, records):
        return self.services.trial_balance_tools.add_flags(records)
    
    def import_trial_balance(self):
            pid = self.get_current_project_id()
            if not pid:
                messagebox.showwarning(
                    "خطا", "ابتدا پرونده حسابرسی را انتخاب کنید."
                )
                return
    
            path = filedialog.askopenfilename(
                title="فایل تراز آزمایشی",
                filetypes=[
                    ("Excel یا CSV", "*.xlsx *.xlsm *.csv"),
                    ("همه فایل‌ها", "*.*"),
                ],
            )
            if not path:
                return
    
            try:
                records = self.read_trial_balance_file(path)
            except Exception as exc:
                messagebox.showerror("خطا در ورود تراز", str(exc))
                return
    
            if not messagebox.askyesno(
                "تأیید جایگزینی",
                f"{len(records)} حساب شناسایی شد.\n"
                "تراز قبلی همین پرونده جایگزین شود؟",
            ):
                return
    
            try:
                with self.get_conn() as conn:
                    conn.execute(
                        "DELETE FROM trial_balance WHERE project_id = ?",
                        (pid,),
                    )
                    conn.executemany(
                        """
                        INSERT INTO trial_balance
                            (project_id, account_code, account_name,
                             debit, credit, net, flags)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        [
                            (
                                pid,
                                row["code"],
                                row["name"],
                                row["debit"],
                                row["credit"],
                                row["net"],
                                row["flags"],
                            )
                            for row in records
                        ],
                    )
            except sqlite3.Error as exc:
                messagebox.showerror(
                    "خطای پایگاه داده",
                    f"تراز قبلی تغییر نکرد:\n{exc}",
                )
                return
    
            self.refresh_trial_balance()
    
            total_debit = math.fsum(
                row["debit"] for row in records
            )
            total_credit = math.fsum(
                row["credit"] for row in records
            )
    
            messagebox.showinfo(
                "ورود موفق",
                f"{len(records)} حساب وارد شد.\n"
                f"جمع بدهکار: {total_debit:,.2f}\n"
                f"جمع بستانکار: {total_credit:,.2f}\n"
                f"اختلاف: {total_debit - total_credit:,.2f}",
            )
    
    def refresh_trial_balance(self):
            self.clear_tree(self.tree_tb)
            pid = self.get_current_project_id()
    
            if not pid:
                self.lbl_tb_summary.config(text="پرونده‌ای انتخاب نشده است.")
                return
    
            with self.get_conn() as conn:
                rows = conn.execute(
                    """
                    SELECT account_code, account_name,
                           debit, credit, net, flags
                    FROM trial_balance
                    WHERE project_id = ?
                    ORDER BY account_code, account_name
                    """,
                    (pid,),
                ).fetchall()
    
            if not rows:
                self.lbl_tb_summary.config(
                    text="برای این پرونده تراز آزمایشی وارد نشده است."
                )
                return
    
            debit = math.fsum(row[2] for row in rows)
            credit = math.fsum(row[3] for row in rows)
            difference = debit - credit
            flagged = sum(bool(row[5]) for row in rows)
            status = (
                "متوازن"
                if abs(difference) <= 0.01
                else "نامتوازن؛ نیازمند بررسی"
            )
    
            self.lbl_tb_summary.config(
                text=(
                    f"تعداد حساب: {len(rows)} | پرچم‌دار: {flagged} | "
                    f"بدهکار: {debit:,.2f} | "
                    f"بستانکار: {credit:,.2f} | "
                    f"اختلاف: {difference:,.2f} — {status}"
                )
            )
    
            for code, name, dr, cr, net, flags in rows:
                self.tree_tb.insert(
                    "",
                    "end",
                    values=(
                        code or "",
                        name,
                        f"{dr:,.2f}",
                        f"{cr:,.2f}",
                        f"{net:,.2f}",
                        flags or "",
                    ),
                )
    
    def export_trial_balance_csv(self):
            pid = self.get_current_project_id()
            if not pid:
                messagebox.showwarning(
                    "خطا", "ابتدا پرونده حسابرسی را انتخاب کنید."
                )
                return
    
            with self.get_conn() as conn:
                rows = conn.execute(
                    """
                    SELECT account_code, account_name,
                           debit, credit, net, flags
                    FROM trial_balance
                    WHERE project_id = ?
                    ORDER BY account_code, account_name
                    """,
                    (pid,),
                ).fetchall()
    
            if not rows:
                messagebox.showinfo(
                    "راهنما", "برای این پرونده تراز آزمایشی وجود ندارد."
                )
                return
    
            path = filedialog.asksaveasfilename(
                title="ذخیره تراز آزمایشی",
                defaultextension=".csv",
                filetypes=[("CSV", "*.csv")],
            )
            if not path:
                return
    
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as file:
                    writer = csv.writer(file)
                    writer.writerow([
                        "کد حساب",
                        "نام حساب",
                        "مانده بدهکار",
                        "مانده بستانکار",
                        "خالص بدهکار/(بستانکار)",
                        "موارد نیازمند بررسی",
                    ])
                    for row in rows:
                        writer.writerow(
                            [safe_csv_text(value) for value in row]
                        )
                messagebox.showinfo("موفقیت", f"فایل ذخیره شد:\n{path}")
            except OSError as exc:
                messagebox.showerror("خطای ذخیره", str(exc))

