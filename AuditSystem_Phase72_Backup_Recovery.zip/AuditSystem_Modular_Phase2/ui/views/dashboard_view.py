"""Advanced management dashboard with audit-team performance."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from services.management_dashboard_service import ManagementDashboardService
from services.audit_executive_dashboard_service import AuditExecutiveDashboardService
from services.phase31_workspace_service import Phase31WorkspaceService
from services.task_center_service import TaskCenterService
from services.notification_center_service import NotificationCenterService
from services.quality_dashboard_service import QualityDashboardService


class DashboardViewMixin:

    def setup_dashboard_tab(self):
        self.dashboard_cards = {}
        self.dashboard_data = {}
        self.risk_threshold = tk.IntVar(value=15)

        container = ttk.Frame(self.tab_dashboard, padding=12)
        container.pack(fill="both", expand=True)

        self.workspace_service = Phase31WorkspaceService()
        self._setup_phase31_workspace(container)
        self._setup_executive_kpi_strip(container)

        ttk.Label(
            container,
            text="داشبورد مدیریتی حسابرسی",
            font=("Tahoma", 16, "bold")
        ).pack(anchor="e", pady=(0, 12))

        cards_frame = ttk.Frame(container)
        cards_frame.pack(fill="x", pady=5)

        metrics = [
            ("projects", "تعداد پرونده‌ها"),
            ("risks", "تعداد ریسک‌ها"),
            ("workpapers", "تعداد کاربرگ‌ها"),
            ("findings", "تعداد یافته‌ها"),
            ("open_findings", "یافته‌های باز"),
            ("accounts", "حساب‌های تراز آزمایشی"),
            ("audit_tests", "آزمون‌های حسابرسی"),
            ("linked_workpapers", "کاربرگ متصل به ریسک"),
            ("linked_findings", "یافته متصل به کاربرگ"),
            ("finding_evidence", "مستندات یافته‌ها"),
            ("pending_test_reviews", "آزمون‌های در انتظار بررسی"),
            ("returned_tests", "آزمون‌های نیازمند اصلاح"),
            ("critical_open_findings", "یافته‌های بااهمیت باز"),
        ]

        for index, (key, title) in enumerate(metrics):
            card = ttk.LabelFrame(cards_frame, text=title, padding=10)
            card.grid(
                row=index // 3, column=index % 3,
                padx=5, pady=5, sticky="nsew"
            )
            value = ttk.Label(
                card, text="0", font=("Tahoma", 18, "bold")
            )
            value.pack(pady=5)
            self.dashboard_cards[key] = value

        for col in range(3):
            cards_frame.columnconfigure(col, weight=1)

        ttk.Separator(container).pack(fill="x", pady=10)

        controls = ttk.Frame(container)
        controls.pack(fill="x", pady=5)

        ttk.Label(controls, text="آستانه هشدار ریسک:").pack(
            side="right", padx=5
        )
        ttk.Spinbox(
            controls, from_=1, to=100, width=6,
            textvariable=self.risk_threshold,
            command=self.refresh_dashboard
        ).pack(side="right", padx=5)

        ttk.Button(
            controls, text="به‌روزرسانی",
            command=self.refresh_dashboard
        ).pack(side="left", padx=5)
        ttk.Button(
            controls, text="خروجی Excel",
            command=self.export_dashboard_excel
        ).pack(side="left", padx=5)
        ttk.Button(
            controls, text="گزارش مدیریتی",
            command=self.export_management_report
        ).pack(side="left", padx=5)

        charts = ttk.Frame(container)
        charts.pack(fill="both", expand=True, pady=8)

        risk_frame = ttk.LabelFrame(
            charts, text="نمودار امتیاز ریسک‌ها", padding=8
        )
        risk_frame.pack(
            side="right", fill="both", expand=True, padx=5
        )

        self.risk_canvas = tk.Canvas(
            risk_frame, height=230,
            background="white", highlightthickness=0
        )
        self.risk_canvas.pack(fill="both", expand=True)

        progress_frame = ttk.LabelFrame(
            charts, text="پیشرفت حسابرسی", padding=8
        )
        progress_frame.pack(
            side="left", fill="both", expand=True, padx=5
        )

        self.progress_text = ttk.Label(
            progress_frame,
            text="هنوز کاربرگی ثبت نشده است",
            font=("Tahoma", 11)
        )
        self.progress_text.pack(anchor="e", pady=10)

        self.progress_bar = ttk.Progressbar(
            progress_frame, maximum=100, mode="determinate"
        )
        self.progress_bar.pack(fill="x", pady=8)

        self.findings_text = ttk.Label(
            progress_frame,
            text="هنوز یافته‌ای ثبت نشده است",
            font=("Tahoma", 10),
            justify="right"
        )
        self.findings_text.pack(anchor="e", pady=10)

        # Team performance section
        self._setup_team_dashboard(container)
        self._setup_quality_dashboard(container)

        ttk.Separator(container).pack(fill="x", pady=8)

        queue_frame = ttk.LabelFrame(
            container, text="صف اولویت‌های مدیریتی و موارد نیازمند اقدام", padding=8
        )
        queue_frame.pack(fill="both", expand=True, pady=(8, 4))
        queue_columns = ("priority", "category", "subject", "action", "reference")
        self.management_action_tree = ttk.Treeview(
            queue_frame, columns=queue_columns, show="headings", height=7
        )
        queue_headings = {
            "priority": "اولویت", "category": "حوزه",
            "subject": "موضوع", "action": "اقدام پیشنهادی",
            "reference": "مرجع",
        }
        queue_widths = {"priority": 75, "category": 75, "subject": 170,
                        "action": 300, "reference": 150}
        for column in queue_columns:
            self.management_action_tree.heading(column, text=queue_headings[column])
            self.management_action_tree.column(
                column, width=queue_widths[column], anchor="e",
                stretch=column in ("subject", "action")
            )
        queue_scroll = ttk.Scrollbar(
            queue_frame, orient="vertical", command=self.management_action_tree.yview
        )
        self.management_action_tree.configure(yscrollcommand=queue_scroll.set)
        self.management_action_tree.pack(side="right", fill="both", expand=True)
        queue_scroll.pack(side="left", fill="y")

        # Unified read-only task center, sourced from existing project records.
        task_frame = ttk.LabelFrame(
            container, text="مرکز مدیریت کارها و پیگیری اقدامات حسابرسی", padding=8
        )
        task_frame.pack(fill="both", expand=True, pady=(8, 4))
        task_toolbar = ttk.Frame(task_frame)
        task_toolbar.pack(fill="x", pady=(0, 5))
        self.task_center_filter = tk.StringVar(value="همه موارد")
        ttk.Label(task_toolbar, text="نمایش:").pack(side="right", padx=4)
        self.task_center_filter_box = ttk.Combobox(
            task_toolbar, textvariable=self.task_center_filter, state="readonly",
            values=("همه موارد", "فقط موارد متأخر"), width=18
        )
        self.task_center_filter_box.pack(side="right", padx=4)
        self.task_center_filter_box.bind("<<ComboboxSelected>>", lambda _e: self._refresh_task_center())
        ttk.Button(task_toolbar, text="به‌روزرسانی", command=self._refresh_task_center).pack(side="left", padx=4)
        self.task_center_summary = ttk.Label(task_toolbar, text="در حال بارگذاری...")
        self.task_center_summary.pack(side="left", padx=8)

        task_columns = ("priority", "category", "title", "status", "owner", "due_date")
        self.task_center_tree = ttk.Treeview(
            task_frame, columns=task_columns, show="headings", height=7
        )
        task_headings = {
            "priority": "وضعیت زمانی", "category": "نوع کار", "title": "عنوان",
            "status": "وضعیت فعلی", "owner": "مسئول / ارجاع", "due_date": "مهلت انجام"
        }
        task_widths = {"priority": 90, "category": 100, "title": 260,
                       "status": 150, "owner": 125, "due_date": 105}
        for column in task_columns:
            self.task_center_tree.heading(column, text=task_headings[column])
            self.task_center_tree.column(column, width=task_widths[column], anchor="e",
                                         stretch=column in ("title", "status"))
        task_scroll = ttk.Scrollbar(task_frame, orient="vertical", command=self.task_center_tree.yview)
        self.task_center_tree.configure(yscrollcommand=task_scroll.set)
        self.task_center_tree.pack(side="right", fill="both", expand=True)
        task_scroll.pack(side="left", fill="y")
        self.task_center_tree.tag_configure("overdue", foreground="#B42318")
        self._task_center_records = {}

        # Read-only in-app notifications derived from the task-center snapshot.
        notification_frame = ttk.LabelFrame(
            container, text="مرکز اعلان‌ها و یادآوری‌های حسابرسی", padding=8
        )
        notification_frame.pack(fill="both", expand=True, pady=(8, 4))
        notification_toolbar = ttk.Frame(notification_frame)
        notification_toolbar.pack(fill="x", pady=(0, 5))
        ttk.Label(notification_toolbar, text="هشدار پیش از سررسید (روز):").pack(side="right", padx=4)
        self.notification_days_ahead = tk.IntVar(value=3)
        ttk.Spinbox(
            notification_toolbar, from_=0, to=90, width=5,
            textvariable=self.notification_days_ahead, command=self._refresh_notification_center
        ).pack(side="right", padx=4)
        ttk.Button(notification_toolbar, text="به‌روزرسانی اعلان‌ها",
                   command=self._refresh_notification_center).pack(side="left", padx=4)
        self.notification_summary = ttk.Label(notification_toolbar, text="در حال بارگذاری...")
        self.notification_summary.pack(side="left", padx=8)

        notification_columns = ("severity", "category", "title", "message", "owner", "due_date")
        self.notification_tree = ttk.Treeview(
            notification_frame, columns=notification_columns, show="headings", height=5
        )
        notification_headings = {
            "severity": "نوع هشدار", "category": "حوزه", "title": "موضوع",
            "message": "یادآوری", "owner": "مسئول", "due_date": "سررسید"
        }
        notification_widths = {"severity": 95, "category": 95, "title": 190,
                               "message": 270, "owner": 115, "due_date": 100}
        for column in notification_columns:
            self.notification_tree.heading(column, text=notification_headings[column])
            self.notification_tree.column(column, width=notification_widths[column], anchor="e",
                                           stretch=column in ("title", "message"))
        notification_scroll = ttk.Scrollbar(
            notification_frame, orient="vertical", command=self.notification_tree.yview
        )
        self.notification_tree.configure(yscrollcommand=notification_scroll.set)
        self.notification_tree.pack(side="right", fill="both", expand=True)
        notification_scroll.pack(side="left", fill="y")
        self.notification_tree.tag_configure("critical", foreground="#B42318")
        self.notification_tree.tag_configure("warning", foreground="#B54708")
        self.notification_tree.tag_configure("action", foreground="#175CD3")

        self.alert_text = tk.Text(
            container, height=5, wrap="word",
            font=("Tahoma", 10), state="disabled"
        )
        self.alert_text.pack(fill="x", pady=5)

        self.dashboard_status = ttk.Label(
            container, text="آماده به کار"
        )
        self.dashboard_status.pack(anchor="e", pady=5)

        self.refresh_dashboard()

    def _setup_executive_kpi_strip(self, parent):
        """Add a compact, data-driven executive KPI strip above the legacy dashboard."""
        panel = ttk.LabelFrame(parent, text="شاخص‌های اجرایی مدیریت حسابرسی", padding=8)
        panel.pack(fill="x", pady=(0, 8))
        definitions = (
            ("project_count", "کل پرونده‌ها"),
            ("audit_test_count", "آزمون‌های حسابرسی"),
            ("high_risk_count", "ریسک‌های بالا"),
            ("workpaper_completion_percent", "درصد تکمیل کاربرگ"),
            ("open_finding_count", "یافته‌های باز"),
            ("pending_review_count", "در انتظار بازبینی"),
        )
        self.executive_kpi_values = {}
        for index, (key, title) in enumerate(definitions):
            card = ttk.LabelFrame(panel, text=title, padding=(8, 6))
            card.grid(row=0, column=index, padx=3, pady=2, sticky="nsew")
            value = ttk.Label(card, text="—", font=("Tahoma", 14, "bold"))
            value.pack(pady=2)
            self.executive_kpi_values[key] = value
            panel.columnconfigure(index, weight=1)

    def _update_executive_kpi_strip(self, data):
        """Refresh executive KPIs using current database rows; this is read-only."""
        snapshot = AuditExecutiveDashboardService.snapshot(
            projects=data.get("project_detail_rows", []),
            risks=data.get("risk_rows", []),
            workpapers=data.get("workpaper_detail_rows", []),
            findings=data.get("finding_detail_rows", []),
            tests=data.get("test_detail_rows", []),
        )
        data["executive_snapshot"] = snapshot
        display = {
            "project_count": snapshot["project_count"],
            "audit_test_count": snapshot["audit_test_count"],
            "high_risk_count": snapshot["high_risk_count"],
            "workpaper_completion_percent": f'{snapshot["workpaper_completion_percent"]}٪',
            "open_finding_count": snapshot["open_finding_count"],
            "pending_review_count": snapshot["pending_review_count"],
        }
        for key, value in display.items():
            widget = self.executive_kpi_values.get(key)
            if widget is not None:
                widget.configure(text=f"{value:,}" if isinstance(value, int) else str(value))

    def _setup_phase31_workspace(self, parent):
        """Compact smart-search and recent-activity area above the KPI dashboard."""
        panel = ttk.LabelFrame(parent, text="مرکز هوشمند پرونده", padding=8)
        panel.pack(fill="x", pady=(0, 9))
        top = ttk.Frame(panel)
        top.pack(fill="x")
        self.workspace_search_var = tk.StringVar()
        entry = ttk.Entry(top, textvariable=self.workspace_search_var, justify="right")
        entry.pack(side="right", fill="x", expand=True, padx=(0, 6), ipady=4)
        entry.bind("<Return>", lambda _event: self.run_workspace_search())
        ttk.Button(top, text="جستجوی سراسری", command=self.run_workspace_search).pack(side="right", padx=4)
        ttk.Button(top, text="پاک‌سازی", command=self.clear_workspace_search).pack(side="right", padx=4)
        ttk.Button(top, text="تازه‌سازی فعالیت‌ها", command=self.refresh_workspace_activity).pack(side="left", padx=4)

        # Advanced, read-only filters; values are discovered from the active database schema.
        filters_bar = ttk.Frame(panel)
        filters_bar.pack(fill="x", pady=(6, 0))
        self.workspace_filter_vars = {
            "project": tk.StringVar(value="همه پرونده‌ها"),
            "module": tk.StringVar(value="همه"),
            "status": tk.StringVar(value="همه"),
            "responsible": tk.StringVar(value="همه"),
            "period": tk.StringVar(value="همه"),
        }
        self.workspace_project_filter_map = {"همه پرونده‌ها": None}
        filter_specs = (
            ("project", "پرونده", ["همه پرونده‌ها"]),
            ("module", "ماژول", ["همه"] + sorted({item[3] for item in self.workspace_service.SEARCH_TARGETS})),
            ("status", "وضعیت", ["همه"]),
            ("responsible", "مسئول", ["همه"]),
            ("period", "دوره", ["همه"]),
        )
        self.workspace_filter_boxes = {}
        for key, label, values in filter_specs:
            ttk.Label(filters_bar, text=f"{label}:").pack(side="right", padx=(7, 2))
            combo = ttk.Combobox(filters_bar, textvariable=self.workspace_filter_vars[key],
                                 values=values, state="readonly", width=18, justify="right")
            combo.pack(side="right", padx=2)
            self.workspace_filter_boxes[key] = combo
        self.workspace_filter_boxes["project"].bind(
            "<<ComboboxSelected>>", lambda _event: self.refresh_workspace_filter_options()
        )
        self.refresh_workspace_filter_options()

        # Navigation shortcuts were removed: the global right sidebar is the
        # single navigation surface. Dashboard controls here remain task actions.

        lower = ttk.Frame(panel)
        lower.pack(fill="x", pady=(7, 0))
        results_box = ttk.LabelFrame(lower, text="نتایج جستجو", padding=5)
        results_box.pack(side="right", fill="both", expand=True, padx=(0, 4))
        activity_box = ttk.LabelFrame(lower, text="آخرین فعالیت‌ها", padding=5)
        activity_box.pack(side="left", fill="both", expand=True, padx=(4, 0))
        self.workspace_search_tree = ttk.Treeview(results_box,
            columns=("title", "module", "context"), show="headings", height=4)
        for col, title, width in (("title", "عنوان", 180), ("module", "ماژول", 125), ("context", "شرح", 180)):
            self.workspace_search_tree.heading(col, text=title)
            self.workspace_search_tree.column(col, width=width, anchor="e")
        self.workspace_search_tree.pack(fill="both", expand=True)
        self.workspace_search_tree.bind("<Double-1>", self.open_workspace_search_result)
        self.workspace_activity_tree = ttk.Treeview(activity_box,
            columns=("date", "type", "event", "detail"), show="headings", height=4)
        for col, title, width in (("date", "زمان", 120), ("type", "حوزه", 95), ("event", "رویداد", 100), ("detail", "جزئیات", 170)):
            self.workspace_activity_tree.heading(col, text=title)
            self.workspace_activity_tree.column(col, width=width, anchor="e")
        self.workspace_activity_tree.pack(fill="both", expand=True)
        self._workspace_search_records = {}
        self.refresh_workspace_activity()

    def run_workspace_search(self):
        query = self.workspace_search_var.get().strip()
        self.clear_tree(self.workspace_search_tree)
        self._workspace_search_records = {}
        if len(query) < 2:
            self.dashboard_status.configure(text="برای جستجو حداقل دو نویسه وارد کنید")
            return
        try:
            with self.get_conn() as conn:
                filters = {key: variable.get() for key, variable in self.workspace_filter_vars.items()}
                selected_project = self.workspace_project_filter_map.get(
                    filters.get("project", "همه پرونده‌ها"), self.get_current_project_id()
                )
                rows = self.workspace_service.search(
                    conn, query, selected_project, filters=filters
                )
            for index, row in enumerate(rows):
                iid = str(index)
                self._workspace_search_records[iid] = row
                self.workspace_search_tree.insert("", "end", iid=iid,
                    values=(row["title"], row["module"], row["context"]))
            self.dashboard_status.configure(text=f"{len(rows)} نتیجه برای «{query}» پیدا شد")
        except Exception as exc:
            self.dashboard_status.configure(text=f"خطا در جستجوی سراسری: {exc}")

    def clear_workspace_search(self):
        self.workspace_search_var.set("")
        self.clear_tree(self.workspace_search_tree)
        self._workspace_search_records = {}
        for key, variable in getattr(self, "workspace_filter_vars", {}).items():
            variable.set("همه پرونده‌ها" if key == "project" else "همه")
        self.refresh_workspace_filter_options()
        if hasattr(self, "dashboard_status"):
            self.dashboard_status.configure(text="جستجو و فیلترها پاک شدند")

    def refresh_workspace_filter_options(self):
        """Refresh filter choices without modifying data or database schema."""
        if not hasattr(self, "workspace_filter_boxes"):
            return
        try:
            with self.get_conn() as conn:
                projects = self.workspace_service.project_options(conn)
                project_values = ["همه پرونده‌ها"]
                project_map = {"همه پرونده‌ها": None}
                current_project_id = self.get_current_project_id()
                current_label = "همه پرونده‌ها"
                for project in projects:
                    label = f"{project['name']} — {project['id']}"
                    project_values.append(label)
                    project_map[label] = project["id"]
                    if project["id"] == current_project_id:
                        current_label = label
                self.workspace_project_filter_map = project_map
                self.workspace_filter_boxes["project"]["values"] = project_values
                selected_label = self.workspace_filter_vars["project"].get()
                if selected_label not in project_values:
                    selected_label = current_label
                    self.workspace_filter_vars["project"].set(selected_label)
                selected_project_id = project_map.get(selected_label)
                options = self.workspace_service.filter_options(conn, selected_project_id)
            for key in ("status", "responsible", "period"):
                values = ["همه"] + options.get(key, [])
                self.workspace_filter_boxes[key]["values"] = values
                if self.workspace_filter_vars[key].get() not in values:
                    self.workspace_filter_vars[key].set("همه")
        except Exception:
            # Search remains available even if an older database has no filter metadata.
            for key in ("status", "responsible", "period"):
                self.workspace_filter_boxes[key]["values"] = ["همه"]
                self.workspace_filter_vars[key].set("همه")
            self.workspace_filter_boxes["project"]["values"] = ["همه پرونده‌ها"]
            self.workspace_project_filter_map = {"همه پرونده‌ها": None}
            self.workspace_filter_vars["project"].set("همه پرونده‌ها")

    def _open_workspace_title(self, title):
        for _button, nav_title, frame in getattr(self, "_nav_items", []):
            if nav_title == title:
                self.show_workspace(frame, nav_title)
                return

    def open_workspace_search_result(self, _event=None):
        selected = self.workspace_search_tree.selection()
        if not selected:
            return
        row = self._workspace_search_records.get(selected[0])
        if not row:
            return
        frame_by_title = {title: frame for _button, title, frame in getattr(self, "_nav_items", [])}
        frame = frame_by_title.get(row["module"])
        if frame is not None:
            self.show_workspace(frame, row["module"])
        self.dashboard_status.configure(text=f"نتیجه انتخاب‌شده: {row['title']} | شناسه: {row['id']}")

    def refresh_workspace_activity(self):
        if not hasattr(self, "workspace_activity_tree"):
            return
        self.clear_tree(self.workspace_activity_tree)
        try:
            with self.get_conn() as conn:
                rows = self.workspace_service.recent_activity(conn, self.get_current_project_id(), 20)
            for row in rows:
                self.workspace_activity_tree.insert("", "end", values=(
                    row["date"], row["type"], row["event"], row["detail"]))
            if not rows:
                self.workspace_activity_tree.insert("", "end", values=("—", "—", "هنوز فعالیتی ثبت نشده", "—"))
        except Exception as exc:
            self.workspace_activity_tree.insert("", "end", values=("—", "خطا", str(exc), "—"))

    def _get_dashboard_data(self):
        project_id = self.get_current_project_id()

        with self.get_conn() as conn:
            cursor = conn.cursor()
            tables = {
                "projects": "projects",
                "risks": "risks",
                "workpapers": "workpapers",
                "findings": "findings",
                "accounts": "trial_balance",
                "audit_tests": "audit_tests",
                "audit_programs": "audit_programs",
                "finding_evidence": "finding_evidence",
            }
            data = {}
            for key, table in tables.items():
                if key == "projects" or project_id is None:
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                else:
                    cursor.execute(
                        f"SELECT COUNT(*) FROM {table} WHERE project_id=?",
                        (project_id,),
                    )
                data[key] = cursor.fetchone()[0]

            # Current schema has no project-status field; do not infer status.
            cursor.execute("SELECT id, name, period FROM projects ORDER BY id")
            data["project_detail_rows"] = [
                (row[0], row[1], "نامشخص") for row in cursor.fetchall()
            ]

            scope = "" if project_id is None else " WHERE project_id=?"
            params = () if project_id is None else (project_id,)

            cursor.execute(
                "SELECT COUNT(*) FROM workpapers" + scope +
                ("" if not scope else " AND risk_id IS NOT NULL")
                if scope else "SELECT COUNT(*) FROM workpapers WHERE risk_id IS NOT NULL",
                params,
            )
            data["linked_workpapers"] = cursor.fetchone()[0]

            cursor.execute(
                ("SELECT COUNT(*) FROM audit_programs WHERE risk_id IS NOT NULL" if project_id is None
                 else "SELECT COUNT(*) FROM audit_programs WHERE project_id=? AND risk_id IS NOT NULL"),
                params,
            )
            data["linked_programs"] = cursor.fetchone()[0]

            cursor.execute(
                "SELECT COUNT(*) FROM findings" + scope +
                ("" if not scope else " AND workpaper_id IS NOT NULL")
                if scope else "SELECT COUNT(*) FROM findings WHERE workpaper_id IS NOT NULL",
                params,
            )
            data["linked_findings"] = cursor.fetchone()[0]

            if project_id is None:
                cursor.execute("SELECT title, score FROM risks ORDER BY score DESC")
                risk_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM workpapers GROUP BY status")
                workpaper_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM findings GROUP BY status")
                finding_rows = cursor.fetchall()
                cursor.execute("SELECT severity, COUNT(*) FROM findings GROUP BY severity")
                finding_severity_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM audit_tests GROUP BY status")
                audit_test_rows = cursor.fetchall()
                cursor.execute("SELECT status FROM workpapers")
                all_workpapers = cursor.fetchall()
                cursor.execute("SELECT status FROM findings")
                all_findings = cursor.fetchall()
                cursor.execute("SELECT id, title, score FROM risks WHERE score IS NULL OR score < 1 OR score > 25")
                invalid_risks = cursor.fetchall()
                cursor.execute("SELECT id, title FROM workpapers WHERE risk_id IS NULL")
                unlinked_workpaper_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM findings WHERE workpaper_id IS NULL")
                unlinked_finding_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM audit_tests WHERE workpaper_id IS NULL")
                unlinked_test_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM audit_programs WHERE risk_id IS NULL")
                unlinked_program_rows = cursor.fetchall()
                cursor.execute("""SELECT e.id, e.finding_id, f.title, e.file_path,
                                       e.description, m.full_name, e.created_at
                                FROM finding_evidence e
                                JOIN findings f ON f.id=e.finding_id AND f.project_id=e.project_id
                                LEFT JOIN team_members m ON m.id=e.added_by_member_id AND m.project_id=e.project_id
                                ORDER BY e.id DESC""")
                finding_evidence_rows = cursor.fetchall()
                cursor.execute("""SELECT f.id, f.title FROM findings f
                                 LEFT JOIN finding_evidence e ON e.finding_id=f.id AND e.project_id=f.project_id
                                 WHERE f.severity IN ('بااهمیت','اساسی') AND f.status='باز'
                                 GROUP BY f.id HAVING COUNT(e.id)=0""")
                findings_without_evidence = cursor.fetchall()
            else:
                cursor.execute("SELECT title, score FROM risks WHERE project_id=? ORDER BY score DESC", params)
                risk_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM workpapers WHERE project_id=? GROUP BY status", params)
                workpaper_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM findings WHERE project_id=? GROUP BY status", params)
                finding_rows = cursor.fetchall()
                cursor.execute("SELECT severity, COUNT(*) FROM findings WHERE project_id=? GROUP BY severity", params)
                finding_severity_rows = cursor.fetchall()
                cursor.execute("SELECT status, COUNT(*) FROM audit_tests WHERE project_id=? GROUP BY status", params)
                audit_test_rows = cursor.fetchall()
                cursor.execute("SELECT status FROM workpapers WHERE project_id=?", params)
                all_workpapers = cursor.fetchall()
                cursor.execute("SELECT status FROM findings WHERE project_id=?", params)
                all_findings = cursor.fetchall()
                cursor.execute("SELECT id, title, score FROM risks WHERE project_id=? AND (score IS NULL OR score < 1 OR score > 25)", params)
                invalid_risks = cursor.fetchall()
                cursor.execute("SELECT id, title FROM workpapers WHERE project_id=? AND risk_id IS NULL", params)
                unlinked_workpaper_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM findings WHERE project_id=? AND workpaper_id IS NULL", params)
                unlinked_finding_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM audit_tests WHERE project_id=? AND workpaper_id IS NULL", params)
                unlinked_test_rows = cursor.fetchall()
                cursor.execute("SELECT id, title FROM audit_programs WHERE project_id=? AND risk_id IS NULL", params)
                unlinked_program_rows = cursor.fetchall()
                cursor.execute("""SELECT e.id, e.finding_id, f.title, e.file_path,
                                       e.description, m.full_name, e.created_at
                                FROM finding_evidence e
                                JOIN findings f ON f.id=e.finding_id AND f.project_id=e.project_id
                                LEFT JOIN team_members m ON m.id=e.added_by_member_id AND m.project_id=e.project_id
                                WHERE e.project_id=? ORDER BY e.id DESC""", params)
                finding_evidence_rows = cursor.fetchall()
                cursor.execute("""SELECT f.id, f.title FROM findings f
                                 LEFT JOIN finding_evidence e ON e.finding_id=f.id AND e.project_id=f.project_id
                                 WHERE f.project_id=? AND f.severity IN ('بااهمیت','اساسی') AND f.status='باز'
                                 GROUP BY f.id HAVING COUNT(e.id)=0""", params)
                findings_without_evidence = cursor.fetchall()

            if project_id is None:
                cursor.execute("SELECT id, title, status FROM workpapers ORDER BY id")
                workpaper_detail_rows = cursor.fetchall()
                cursor.execute("SELECT id, title, severity, status, owner FROM findings ORDER BY id")
                finding_detail_rows = cursor.fetchall()
                cursor.execute("SELECT id, title, status FROM audit_tests ORDER BY id")
                test_detail_rows = cursor.fetchall()
            else:
                cursor.execute("SELECT id, title, status FROM workpapers WHERE project_id=? ORDER BY id", params)
                workpaper_detail_rows = cursor.fetchall()
                cursor.execute("SELECT id, title, severity, status, owner FROM findings WHERE project_id=? ORDER BY id", params)
                finding_detail_rows = cursor.fetchall()
                cursor.execute("SELECT id, title, status FROM audit_tests WHERE project_id=? ORDER BY id", params)
                test_detail_rows = cursor.fetchall()

        data.update({
            "project_id": project_id,
            "risk_rows": risk_rows,
            "workpaper_rows": workpaper_rows,
            "finding_rows": finding_rows,
            "finding_severity_rows": finding_severity_rows,
            "audit_test_rows": audit_test_rows,
            "all_workpapers": all_workpapers,
            "all_findings": all_findings,
            "invalid_risks": invalid_risks,
            "unlinked_workpaper_rows": unlinked_workpaper_rows,
            "unlinked_finding_rows": unlinked_finding_rows,
            "unlinked_test_rows": unlinked_test_rows,
            "unlinked_program_rows": unlinked_program_rows,
            "findings_without_evidence": findings_without_evidence,
            "finding_evidence_rows": finding_evidence_rows,
            "workpaper_detail_rows": workpaper_detail_rows,
            "finding_detail_rows": finding_detail_rows,
            "test_detail_rows": test_detail_rows,
        })
        return data

    @staticmethod
    def _normalize_status(value):
        return (
            str(value or "").strip()
            .replace("ي", "ی").replace("ك", "ک")
            .replace("\u200c", " ")
        ).lower()

    def _is_closed(self, status):
        return ManagementDashboardService.is_closed(status)

    def refresh_dashboard(self):
        try:
            data = self._get_dashboard_data()
            self.dashboard_data = data
            self._update_executive_kpi_strip(data)
            snapshot = ManagementDashboardService.build_snapshot(
                risk_rows=data["risk_rows"],
                workpaper_rows=data["workpaper_detail_rows"],
                finding_rows=data["finding_detail_rows"],
                test_rows=data["test_detail_rows"],
                findings_without_evidence=data.get("findings_without_evidence", []),
                unlinked_workpapers=data.get("unlinked_workpaper_rows", []),
                unlinked_findings=data.get("unlinked_finding_rows", []),
                unlinked_tests=data.get("unlinked_test_rows", []),
                unlinked_programs=data.get("unlinked_program_rows", []),
                risk_threshold=self.risk_threshold.get(),
            )
            data["management_snapshot"] = snapshot

            open_findings = sum(
                1 for row in data["all_findings"]
                if not self._is_closed(row[0])
            )

            values = {
                "projects": data["projects"],
                "risks": data["risks"],
                "workpapers": data["workpapers"],
                "findings": data["findings"],
                "open_findings": open_findings,
                "accounts": data["accounts"],
                "audit_tests": data["audit_tests"],
                "linked_workpapers": data["linked_workpapers"],
                "linked_findings": data["linked_findings"],
                "finding_evidence": data["finding_evidence"],
                "pending_test_reviews": snapshot["pending_test_reviews"],
                "returned_tests": snapshot["returned_tests"],
                "critical_open_findings": snapshot["critical_open_findings"],
            }

            for key, value in values.items():
                self.dashboard_cards[key].configure(text=f"{value:,}")

            self._draw_risk_chart(data["risk_rows"])
            self._update_progress(data)
            self._update_findings(data)
            self._update_alerts(data)
            self._refresh_management_action_queue(snapshot)
            self._refresh_team_dashboard()
            self._refresh_quality_dashboard()
            self._refresh_task_center()
            self._refresh_notification_center()
            self.refresh_workspace_activity()

            self.dashboard_status.configure(
                text="آمار با موفقیت به‌روزرسانی شد"
            )
        except Exception as exc:
            self.dashboard_status.configure(
                text=f"خطا در دریافت آمار: {exc}"
            )

    def _refresh_task_center(self):
        if not hasattr(self, "task_center_tree"):
            return
        for item in self.task_center_tree.get_children():
            self.task_center_tree.delete(item)
        self._task_center_records = {}
        try:
            with self.get_conn() as conn:
                snapshot = TaskCenterService.snapshot(
                    conn, project_id=self.get_current_project_id()
                )
            tasks = snapshot["tasks"]
            if self.task_center_filter.get() == "فقط موارد متأخر":
                tasks = [task for task in tasks if task["overdue"]]
            for task in tasks:
                item = self.task_center_tree.insert(
                    "", "end",
                    values=(task["priority"], task["category"], task["title"],
                            task["status"], task["owner"], task["due_date"] or "—"),
                    tags=("overdue",) if task["overdue"] else ()
                )
                self._task_center_records[item] = task
            self.task_center_summary.configure(
                text=f"کل موارد: {snapshot['total']} | متأخر: {snapshot['overdue']} | نمایش: {len(tasks)}"
            )
            if not tasks:
                self.task_center_tree.insert(
                    "", "end", values=("—", "—", "موردی برای پیگیری ثبت نشده است", "—", "—", "—")
                )
        except Exception as exc:
            self.task_center_summary.configure(text=f"خطا در بارگذاری مرکز کارها: {exc}")
            self.task_center_tree.insert(
                "", "end", values=("خطا", "—", str(exc), "—", "—", "—")
            )

    def _refresh_notification_center(self):
        if not hasattr(self, "notification_tree"):
            return
        for item in self.notification_tree.get_children():
            self.notification_tree.delete(item)
        try:
            with self.get_conn() as conn:
                task_snapshot = TaskCenterService.snapshot(
                    conn, project_id=self.get_current_project_id()
                )
            try:
                days_ahead = self.notification_days_ahead.get()
            except (ValueError, tk.TclError):
                days_ahead = 3
                self.notification_days_ahead.set(days_ahead)
            snapshot = NotificationCenterService.build(
                task_snapshot, days_ahead=days_ahead
            )
            for notification in snapshot["notifications"]:
                self.notification_tree.insert(
                    "", "end",
                    values=(notification["label"], notification["category"],
                            notification["title"], notification["message"],
                            notification["owner"], notification["due_date"] or "—"),
                    tags=(notification["severity"],)
                )
            self.notification_summary.configure(
                text=(f'کل اعلان‌ها: {snapshot["total"]} | '
                      f'مهلت‌گذشته: {snapshot["overdue"]} | '
                      f'مهلت نزدیک: {snapshot["due_soon"]} | '
                      f'نیازمند پیگیری: {snapshot["action_required"]}')
            )
            if not snapshot["notifications"]:
                self.notification_tree.insert(
                    "", "end", values=("—", "—", "اعلان فعالی وجود ندارد",
                                        "موردی برای یادآوری شناسایی نشد", "—", "—")
                )
        except Exception as exc:
            self.notification_summary.configure(text=f"خطا در بارگذاری اعلان‌ها: {exc}")
            self.notification_tree.insert(
                "", "end", values=("خطا", "—", str(exc), "—", "—", "—")
            )

    def _refresh_management_action_queue(self, snapshot):
        if not hasattr(self, "management_action_tree"):
            return
        for item in self.management_action_tree.get_children():
            self.management_action_tree.delete(item)
        for action in snapshot.get("actions", []):
            self.management_action_tree.insert(
                "", "end",
                values=(action["priority"], action["category"],
                        action["subject"], action["action"], action["reference"])
            )
        if not snapshot.get("actions"):
            self.management_action_tree.insert(
                "", "end",
                values=("—", "—", "موردی ثبت نشده", "اقدام مدیریتی بازی شناسایی نشد", "—")
            )

    def _draw_risk_chart(self, risks):
        canvas = self.risk_canvas
        canvas.delete("all")
        width = max(canvas.winfo_width(), 350)
        height = max(canvas.winfo_height(), 220)

        if not risks:
            canvas.create_text(
                width // 2, height // 2,
                text="هنوز ریسکی ثبت نشده است",
                font=("Tahoma", 10)
            )
            return

        max_score = max(max(int(r[1] or 0), 1) for r in risks)
        threshold = self.risk_threshold.get()
        visible = risks[:8]
        bar_height = 22
        gap = 9

        for index, (title, score) in enumerate(visible):
            score = int(score or 0)
            y = 20 + index * (bar_height + gap)
            canvas.create_text(
                width - 8, y + 10,
                text=str(title)[:22], anchor="e",
                font=("Tahoma", 8)
            )
            bar_start = 10
            bar_end = width - 155
            available = max(bar_end - bar_start, 50)
            length = int(available * score / max_score)
            canvas.create_rectangle(
                bar_start, y, bar_start + length, y + bar_height,
                fill="#C0504D" if score >= threshold else "#4F81BD",
                outline=""
            )
            canvas.create_text(
                bar_start + length + 25, y + 10,
                text=str(score), font=("Tahoma", 9, "bold")
            )

    def _update_progress(self, data):
        rows = data["all_workpapers"]
        total = len(rows)
        completed = sum(1 for row in rows if self._is_closed(row[0]))
        percent = round(completed * 100 / total) if total else 0
        self.progress_bar["value"] = percent

        if total:
            self.progress_text.configure(
                text=f"کاربرگ تکمیل‌شده: {completed} از {total} ({percent}٪)"
            )
        else:
            self.progress_text.configure(text="هنوز کاربرگی ثبت نشده است")

    def _update_findings(self, data):
        rows = data["all_findings"]
        if not rows:
            self.findings_text.configure(text="هنوز یافته‌ای ثبت نشده است")
            return

        closed = sum(1 for row in rows if self._is_closed(row[0]))
        opened = len(rows) - closed
        linked = self.dashboard_data.get("linked_findings", 0)
        self.findings_text.configure(
            text=(
                f"کل یافته‌ها: {len(rows)} | باز: {opened} | بسته: {closed} | "
                f"متصل به کاربرگ: {linked}"
            )
        )

    def _update_alerts(self, data):
        threshold = self.risk_threshold.get()
        high_risks = [
            (title, score) for title, score in data["risk_rows"]
            if int(score or 0) >= threshold
        ]
        messages = []

        if high_risks:
            messages.append(
                f"هشدار: {len(high_risks)} ریسک با امتیاز "
                f"{threshold} یا بیشتر شناسایی شد."
            )
            for title, score in high_risks:
                messages.append(f"• {title}: {score}")
        else:
            messages.append("ریسکی بالاتر از آستانه هشدار فعلی وجود ندارد.")

        if data["workpapers"] == 0:
            messages.append("• هنوز کاربرگی برای این محدوده ثبت نشده است.")
        if data["findings"] == 0:
            messages.append("• هنوز یافته‌ای برای این محدوده ثبت نشده است.")
        if data.get("unlinked_workpaper_rows"):
            messages.append(
                f"• {len(data['unlinked_workpaper_rows'])} کاربرگ به ریسک مرتبط نشده است."
            )
        if data.get("unlinked_finding_rows"):
            messages.append(
                f"• {len(data['unlinked_finding_rows'])} یافته به کاربرگ مرتبط نشده است."
            )
        if data.get("unlinked_test_rows"):
            messages.append(
                f"• {len(data['unlinked_test_rows'])} آزمون فاقد کاربرگ مرتبط است."
            )
        if data.get("unlinked_program_rows"):
            messages.append(
                f"• {len(data['unlinked_program_rows'])} برنامه حسابرسی فاقد ریسک مرتبط است."
            )
        if data.get("invalid_risks"):
            messages.append(
                f"• {len(data['invalid_risks'])} ریسک دارای امتیاز خارج از دامنه ۱ تا ۲۵ است."
            )
        if data.get("findings_without_evidence"):
            messages.append(
                f"• {len(data['findings_without_evidence'])} یافته بااهمیت یا اساسیِ باز فاقد مستند پشتیبان است."
            )

        self.alert_text.configure(state="normal")
        self.alert_text.delete("1.0", "end")
        self.alert_text.insert("1.0", "\n".join(messages))
        self.alert_text.configure(state="disabled")

    def _setup_team_dashboard(self, parent):
        frame = ttk.LabelFrame(
            parent, text="عملکرد تیم حسابرسی", padding=10
        )
        frame.pack(fill="both", expand=True, pady=8)

        cards = ttk.Frame(frame)
        cards.pack(fill="x", pady=5)
        self.team_dashboard_cards = {}

        metrics = [
            ("assigned", "کاربرگ تخصیص‌یافته"),
            ("approved", "تأیید نهایی"),
            ("pending", "در انتظار بررسی"),
            ("revision", "نیازمند اصلاح"),
            ("unassigned", "بدون مسئول"),
        ]

        for index, (key, title) in enumerate(metrics):
            card = ttk.LabelFrame(cards, text=title, padding=6)
            card.grid(row=0, column=index, padx=3, pady=3, sticky="nsew")
            label = ttk.Label(
                card, text="0", font=("Tahoma", 14, "bold")
            )
            label.pack(pady=4)
            self.team_dashboard_cards[key] = label
            cards.columnconfigure(index, weight=1)

        ttk.Label(
            frame, text="مقایسه عملکرد اعضای تیم",
            font=("Tahoma", 10, "bold")
        ).pack(anchor="e", pady=(8, 4))

        columns = (
            "name", "role", "assigned", "approved",
            "pending", "revision", "progress"
        )
        self.team_dashboard_tree = ttk.Treeview(
            frame, columns=columns, show="headings", height=5
        )
        headings = {
            "name": "نام عضو", "role": "سمت",
            "assigned": "تخصیص", "approved": "تأیید",
            "pending": "در انتظار", "revision": "اصلاح",
            "progress": "پیشرفت"
        }
        widths = {
            "name": 150, "role": 110, "assigned": 65,
            "approved": 65, "pending": 85,
            "revision": 65, "progress": 75
        }
        for col in columns:
            self.team_dashboard_tree.heading(col, text=headings[col])
            self.team_dashboard_tree.column(
                col, width=widths[col], anchor="center"
            )
        self.team_dashboard_tree.pack(fill="x", expand=True)

        self.team_dashboard_note = ttk.Label(frame, text="", font=("Tahoma", 9))
        self.team_dashboard_note.pack(anchor="e", pady=4)

    def _refresh_team_dashboard(self):
        if not hasattr(self, "team_dashboard_tree"):
            return

        for item in self.team_dashboard_tree.get_children():
            self.team_dashboard_tree.delete(item)

        project_id = self.get_current_project_id()
        if project_id is None:
            for label in self.team_dashboard_cards.values():
                label.configure(text="0")
            self.team_dashboard_note.configure(
                text="برای مشاهده عملکرد تیم، یک پرونده انتخاب کنید."
            )
            return

        with self.get_conn() as conn:
            members = conn.execute(
                """SELECT id, full_name, role, is_active
                   FROM team_members
                   WHERE project_id=?
                   ORDER BY is_active DESC, full_name""",
                (project_id,)
            ).fetchall()

            workpapers = conn.execute(
                """SELECT assigned_member_id, status
                   FROM workpapers WHERE project_id=?""",
                (project_id,)
            ).fetchall()

        def normalized(value):
            return self._normalize_status(value).replace(" ", "")

        approved_statuses = {"نهاییوتایید"}
        pending_statuses = {"درانتظاربررسیمدیر"}
        revision_statuses = {"نیازمنداصلاح"}

        assigned_rows = [row for row in workpapers if row[0] is not None]
        approved_total = sum(
            1 for row in workpapers if normalized(row[1]) in approved_statuses
        )
        pending_total = sum(
            1 for row in workpapers if normalized(row[1]) in pending_statuses
        )
        revision_total = sum(
            1 for row in workpapers if normalized(row[1]) in revision_statuses
        )
        unassigned_total = len(workpapers) - len(assigned_rows)

        totals = {
            "assigned": len(assigned_rows),
            "approved": approved_total,
            "pending": pending_total,
            "revision": revision_total,
            "unassigned": unassigned_total,
        }
        for key, value in totals.items():
            self.team_dashboard_cards[key].configure(text=f"{value:,}")

        for member_id, name, role, is_active in members:
            member_rows = [
                row for row in assigned_rows if row[0] == member_id
            ]
            total = len(member_rows)
            approved = sum(
                1 for row in member_rows
                if normalized(row[1]) in approved_statuses
            )
            pending = sum(
                1 for row in member_rows
                if normalized(row[1]) in pending_statuses
            )
            revision = sum(
                1 for row in member_rows
                if normalized(row[1]) in revision_statuses
            )
            progress = round(approved * 100 / total) if total else 0
            display_name = name or ""
            if not is_active:
                display_name += " (غیرفعال)"

            self.team_dashboard_tree.insert(
                "", "end",
                values=(
                    display_name, role or "", total,
                    approved, pending, revision, f"{progress}٪"
                )
            )

        if not members:
            note = "هنوز عضوی برای این پرونده ثبت نشده است."
        else:
            team_progress = (
                round(approved_total * 100 / len(workpapers))
                if workpapers else 0
            )
            note = (
                f"تعداد اعضا: {len(members)} | "
                f"کل کاربرگ‌ها: {len(workpapers)} | "
                f"پیشرفت تأیید نهایی تیم: {team_progress}٪"
            )
        self.team_dashboard_note.configure(text=note)

    def _setup_quality_dashboard(self, parent):
        frame = ttk.LabelFrame(parent, text="داشبورد هوشمند مدیریت کیفیت حسابرسی", padding=9)
        frame.pack(fill="both", expand=True, pady=8)
        cards = ttk.Frame(frame)
        cards.pack(fill="x")
        self.quality_dashboard_cards = {}
        for index, (key, title) in enumerate((
            ("total_requests", "کل درخواست‌های تأیید"),
            ("pending_requests", "در انتظار اقدام"),
            ("overdue_requests", "درخواست‌های معوق"),
            ("returned_requests", "برگشتی جهت اصلاح"),
            ("approved_requests", "تأیید نهایی"),
            ("average_review_days", "میانگین چرخه تأیید (روز)"),
        )):
            card = ttk.LabelFrame(cards, text=title, padding=6)
            card.grid(row=0, column=index, padx=3, pady=3, sticky="nsew")
            value = ttk.Label(card, text="—", font=("Tahoma", 13, "bold"))
            value.pack(pady=4)
            self.quality_dashboard_cards[key] = value
            cards.columnconfigure(index, weight=1)
        ttk.Label(frame, text="عملکرد سرپرستان بر اساس رویدادهای ثبت‌شده در تاریخچه تأیید", 
                  font=("Tahoma", 10, "bold")).pack(anchor="e", pady=(8, 4))
        cols = ("name", "reviewed", "returned", "approved")
        self.quality_supervisor_tree = ttk.Treeview(frame, columns=cols, show="headings", height=4)
        for col, title, width in (("name", "سرپرست", 190), ("reviewed", "بازبینی ثبت‌شده", 120),
                                  ("returned", "برگشت جهت اصلاح", 120), ("approved", "تأیید نهایی پرونده", 130)):
            self.quality_supervisor_tree.heading(col, text=title)
            self.quality_supervisor_tree.column(col, width=width, anchor="e")
        self.quality_supervisor_tree.pack(fill="x", expand=True)
        self.quality_dashboard_note = ttk.Label(frame, text="شاخص‌ها فقط از گردش تأیید موجود محاسبه می‌شوند.")
        self.quality_dashboard_note.pack(anchor="e", pady=(4, 0))

    def _refresh_quality_dashboard(self):
        if not hasattr(self, "quality_supervisor_tree"):
            return
        for item in self.quality_supervisor_tree.get_children():
            self.quality_supervisor_tree.delete(item)
        project_id = self.get_current_project_id()
        if project_id is None:
            snapshot = QualityDashboardService.build_snapshot([])
            self.quality_dashboard_note.configure(text="برای مشاهده شاخص‌های کیفیت، یک پرونده انتخاب کنید.")
        else:
            with self.get_conn() as conn:
                requests = conn.execute("""SELECT id, status, current_stage, submitted_at,
                    completed_at, supervisor_member_id FROM approval_requests
                    WHERE project_id=? AND archived_at IS NULL ORDER BY id""", (project_id,)).fetchall()
                history = conn.execute("""SELECT h.actor_member_id, COALESCE(m.full_name, ''),
                    h.stage, h.event_type, h.created_at FROM approval_history h
                    LEFT JOIN team_members m ON m.id=h.actor_member_id AND m.project_id=h.project_id
                    WHERE h.project_id=? ORDER BY h.id""", (project_id,)).fetchall()
                members = {r[0]: r[1] for r in conn.execute(
                    "SELECT id, full_name FROM team_members WHERE project_id=?", (project_id,)).fetchall()}
            snapshot = QualityDashboardService.build_snapshot(requests, history)
            self.quality_dashboard_note.configure(
                text=f"درصد تأیید نهایی: {snapshot['completion_percent']}٪ | "
                     "زمان متوسط فقط برای درخواست‌های دارای زمان ثبت‌شده محاسبه می‌شود.")
        for key, value in snapshot.items():
            if key == "supervisors":
                continue
            widget = self.quality_dashboard_cards.get(key)
            if widget is not None:
                widget.configure(text="—" if value is None else str(value))
        for member_id, metrics in snapshot["supervisors"].items():
            name = metrics.get("name") or (members.get(member_id, "") if project_id is not None else "")
            self.quality_supervisor_tree.insert("", "end", values=(
                name, metrics.get("reviewed", 0), metrics.get("returned", 0), metrics.get("approved", 0)))

    def export_dashboard_excel(self):
        if not self.dashboard_data:
            messagebox.showwarning(
                "گزارش", "ابتدا داشبورد را به‌روزرسانی کنید."
            )
            return

        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile="Audit_Management_Report.xlsx"
        )
        if not path:
            return

        try:
            data = self.dashboard_data
            wb = Workbook()
            ws = wb.active
            ws.title = "آمار مدیریتی"
            ws.append(["شاخص", "مقدار"])

            summary = [
                ("تعداد پرونده‌ها", data["projects"]),
                ("تعداد ریسک‌ها", data["risks"]),
                ("تعداد کاربرگ‌ها", data["workpapers"]),
                ("تعداد یافته‌ها", data["findings"]),
                ("تعداد حساب‌ها", data["accounts"]),
                ("تعداد آزمون‌های حسابرسی", data.get("audit_tests", 0)),
                ("کاربرگ‌های متصل به ریسک", data.get("linked_workpapers", 0)),
                ("یافته‌های متصل به کاربرگ", data.get("linked_findings", 0)),
                ("مستندات یافته‌ها", data.get("finding_evidence", 0)),
                ("آزمون‌های در انتظار بررسی", data.get("management_snapshot", {}).get("pending_test_reviews", 0)),
                ("آزمون‌های نیازمند اصلاح", data.get("management_snapshot", {}).get("returned_tests", 0)),
                ("یافته‌های بااهمیت باز", data.get("management_snapshot", {}).get("critical_open_findings", 0)),
                ("تعداد اقدامات مدیریتی", data.get("management_snapshot", {}).get("action_count", 0)),
                ("آستانه هشدار", self.risk_threshold.get()),
            ]
            for row in summary:
                ws.append(list(row))

            risk_ws = wb.create_sheet("ریسک‌ها")
            risk_ws.append(["عنوان ریسک", "امتیاز"])
            for row in data["risk_rows"]:
                risk_ws.append(list(row))

            work_ws = wb.create_sheet("کاربرگ‌ها")
            work_ws.append(["وضعیت", "تعداد"])
            for row in data["workpaper_rows"]:
                work_ws.append(list(row))

            finding_ws = wb.create_sheet("یافته‌ها")
            finding_ws.append(["وضعیت", "تعداد"])
            for row in data["finding_rows"]:
                finding_ws.append(list(row))

            severity_ws = wb.create_sheet("اهمیت یافته‌ها")
            severity_ws.append(["اهمیت", "تعداد"])
            for row in data.get("finding_severity_rows", []):
                severity_ws.append(list(row))

            tests_ws = wb.create_sheet("آزمون‌های حسابرسی")
            tests_ws.append(["وضعیت آزمون", "تعداد"])
            for row in data.get("audit_test_rows", []):
                tests_ws.append(list(row))

            links_ws = wb.create_sheet("وضعیت ارتباطات")
            links_ws.append(["شاخص ارتباطی", "تعداد"])
            links_ws.append(["برنامه حسابرسی متصل به ریسک", data.get("linked_programs", 0)])
            links_ws.append(["برنامه حسابرسی بدون ریسک", len(data.get("unlinked_program_rows", []))])
            links_ws.append(["کاربرگ متصل به ریسک", data.get("linked_workpapers", 0)])
            links_ws.append(["کاربرگ بدون ریسک", len(data.get("unlinked_workpaper_rows", []))])
            links_ws.append(["یافته متصل به کاربرگ", data.get("linked_findings", 0)])
            links_ws.append(["یافته بدون کاربرگ", len(data.get("unlinked_finding_rows", []))])
            links_ws.append(["آزمون بدون کاربرگ", len(data.get("unlinked_test_rows", []))])
            links_ws.append(["یافته بااهمیت/اساسی بدون مستند", len(data.get("findings_without_evidence", []))])

            action_ws = wb.create_sheet("اقدامات مدیریتی")
            action_ws.append(["اولویت", "حوزه", "موضوع", "اقدام پیشنهادی", "مرجع"])
            for action in data.get("management_snapshot", {}).get("actions", []):
                action_ws.append([
                    action["priority"], action["category"], action["subject"],
                    action["action"], action["reference"]
                ])

            evidence_ws = wb.create_sheet("مستندات یافته‌ها")
            evidence_ws.append(["شناسه مستند", "شناسه یافته", "عنوان یافته", "مسیر فایل", "شرح", "ثبت‌کننده", "زمان ثبت"])
            for row in data.get("finding_evidence_rows", []):
                evidence_ws.append(list(row))

            team_ws = wb.create_sheet("عملکرد تیم")
            team_ws.append([
                "نام عضو", "سمت", "تعداد تخصیص",
                "تأیید نهایی", "در انتظار بررسی",
                "نیازمند اصلاح", "درصد پیشرفت"
            ])
            project_id = data.get("project_id")
            if project_id is not None:
                with self.get_conn() as conn:
                    members = conn.execute(
                        """SELECT id, full_name, role, is_active
                           FROM team_members WHERE project_id=?
                           ORDER BY full_name""",
                        (project_id,)
                    ).fetchall()
                    wp_rows = conn.execute(
                        """SELECT assigned_member_id, status
                           FROM workpapers WHERE project_id=?""",
                        (project_id,)
                    ).fetchall()

                def norm(value):
                    return self._normalize_status(value).replace(" ", "")

                for member_id, name, role, active in members:
                    rows = [r for r in wp_rows if r[0] == member_id]
                    count = len(rows)
                    approved = sum(
                        1 for r in rows if norm(r[1]) == "نهاییوتایید"
                    )
                    pending = sum(
                        1 for r in rows if norm(r[1]) == "درانتظاربررسیمدیر"
                    )
                    revision = sum(
                        1 for r in rows if norm(r[1]) == "نیازمنداصلاح"
                    )
                    percent = round(approved * 100 / count) if count else 0
                    team_ws.append([
                        name, role, count, approved, pending,
                        revision, f"{percent}%"
                    ])

            for sheet in wb.worksheets:
                sheet.freeze_panes = "A2"
                sheet.sheet_view.rightToLeft = True
                for cell in sheet[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill("solid", fgColor="1F4E78")
                    cell.alignment = Alignment(horizontal="center")
                for column in sheet.columns:
                    letter = get_column_letter(column[0].column)
                    max_length = max(
                        len(str(cell.value or "")) for cell in column
                    )
                    sheet.column_dimensions[letter].width = min(
                        max(max_length + 4, 14), 45
                    )

            wb.save(path)
            messagebox.showinfo(
                "گزارش Excel", "فایل Excel با موفقیت ذخیره شد."
            )
        except Exception as exc:
            messagebox.showerror(
                "خطا", f"تهیه Excel ناموفق بود:\n{exc}"
            )

    def export_management_report(self):
        if not self.dashboard_data:
            messagebox.showwarning(
                "گزارش", "ابتدا داشبورد را به‌روزرسانی کنید."
            )
            return

        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش مدیریتی",
            defaultextension=".txt",
            filetypes=[("Text", "*.txt")],
            initialfile="Audit_Management_Report.txt"
        )
        if not path:
            return

        data = self.dashboard_data
        threshold = self.risk_threshold.get()
        high_risks = [
            (title, score) for title, score in data["risk_rows"]
            if int(score or 0) >= threshold
        ]
        completed = sum(
            1 for row in data["all_workpapers"]
            if self._is_closed(row[0])
        )
        total = len(data["all_workpapers"])
        progress = round(completed * 100 / total) if total else 0

        lines = [
            "گزارش مدیریتی حسابرسی",
            "=" * 45,
            f"تاریخ تهیه: {datetime.now():%Y-%m-%d %H:%M}",
            "",
            f"تعداد پرونده‌ها: {data['projects']}",
            f"تعداد ریسک‌ها: {data['risks']}",
            f"تعداد کاربرگ‌ها: {data['workpapers']}",
            f"تعداد یافته‌ها: {data['findings']}",
            f"تعداد حساب‌ها: {data['accounts']}",
            f"تعداد آزمون‌های حسابرسی: {data.get('audit_tests', 0)}",
            f"برنامه‌های حسابرسی متصل به ریسک: {data.get('linked_programs', 0)}",
            f"کاربرگ‌های متصل به ریسک: {data.get('linked_workpapers', 0)}",
            f"یافته‌های متصل به کاربرگ: {data.get('linked_findings', 0)}",
            f"مستندات ثبت‌شده یافته‌ها: {data.get('finding_evidence', 0)}",
            f"آزمون‌های در انتظار بررسی سرپرست: {data.get('management_snapshot', {}).get('pending_test_reviews', 0)}",
            f"آزمون‌های نیازمند اصلاح: {data.get('management_snapshot', {}).get('returned_tests', 0)}",
            f"یافته‌های بااهمیت باز: {data.get('management_snapshot', {}).get('critical_open_findings', 0)}",
            f"اقدامات مدیریتی پیشنهادی: {data.get('management_snapshot', {}).get('action_count', 0)}",
            "",
            f"پیشرفت کاربرگ‌ها: {progress}٪",
            f"آستانه هشدار ریسک: {threshold}",
            "",
            "ریسک‌های نیازمند توجه:"
        ]

        if high_risks:
            for title, score in high_risks:
                lines.append(f"- {title}: {score}")
        else:
            lines.append("موردی بالاتر از آستانه مشاهده نشد.")

        lines.extend(["", "صف اقدامات مدیریتی:"])
        for action in data.get("management_snapshot", {}).get("actions", []):
            lines.append(
                f"- [{action['priority']}] {action['category']} | "
                f"{action['subject']} | {action['action']} | {action['reference']}"
            )
        if not data.get("management_snapshot", {}).get("actions"):
            lines.append("اقدام مدیریتی بازی شناسایی نشد.")

        project_id = data.get("project_id")
        if project_id is not None:
            with self.get_conn() as conn:
                team_count = conn.execute(
                    "SELECT COUNT(*) FROM team_members WHERE project_id=?",
                    (project_id,)
                ).fetchone()[0]
                team_wp = conn.execute(
                    """SELECT assigned_member_id, status
                       FROM workpapers WHERE project_id=?""",
                    (project_id,)
                ).fetchall()

            assigned = sum(1 for row in team_wp if row[0] is not None)
            approved = sum(
                1 for row in team_wp
                if self._normalize_status(row[1]).replace(" ", "")
                == "نهاییوتایید"
            )
            pending = sum(
                1 for row in team_wp
                if self._normalize_status(row[1]).replace(" ", "")
                == "درانتظاربررسیمدیر"
            )
            unassigned = len(team_wp) - assigned
            team_progress = round(approved * 100 / len(team_wp)) if team_wp else 0
            lines.extend([
                "",
                "عملکرد تیم حسابرسی:",
                f"تعداد اعضای تیم: {team_count}",
                f"کاربرگ‌های تخصیص‌یافته: {assigned}",
                f"تأیید نهایی: {approved}",
                f"در انتظار بررسی: {pending}",
                f"بدون مسئول: {unassigned}",
                f"پیشرفت تأیید نهایی تیم: {team_progress}٪",
            ])

        Path(path).write_text("\n".join(lines), encoding="utf-8-sig")
        messagebox.showinfo(
            "گزارش مدیریتی", "گزارش با موفقیت ذخیره شد."
        )
