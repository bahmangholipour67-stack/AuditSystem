﻿import tkinter as tk
from tkinter import ttk, messagebox


class TeamViewMixin:

    def setup_team_tab(self):
        form = ttk.LabelFrame(self.tab_team, text="ثبت و مدیریت اعضای تیم حسابرسی")
        form.pack(fill="x", padx=10, pady=8)

        ttk.Label(form, text="نام و نام خانوادگی:").grid(
            row=0, column=0, padx=5, pady=7, sticky="e"
        )
        self.ent_team_name = ttk.Entry(form, width=28)
        self.ent_team_name.grid(row=0, column=1, padx=5, pady=7)

        ttk.Label(form, text="سمت:").grid(
            row=0, column=2, padx=5, pady=7, sticky="e"
        )
        self.combo_team_role = ttk.Combobox(
            form,
            values=[
                "مدیر حسابرسی",
                "سرپرست حسابرسی",
                "حسابرس ارشد",
                "حسابرس",
                "کارآموز حسابرسی"
            ],
            state="readonly",
            width=23
        )
        self.combo_team_role.current(3)
        self.combo_team_role.grid(row=0, column=3, padx=5, pady=7)

        ttk.Label(form, text="تلفن:").grid(
            row=1, column=0, padx=5, pady=7, sticky="e"
        )
        self.ent_team_phone = ttk.Entry(form, width=28)
        self.ent_team_phone.grid(row=1, column=1, padx=5, pady=7)

        ttk.Label(form, text="ایمیل:").grid(
            row=1, column=2, padx=5, pady=7, sticky="e"
        )
        self.ent_team_email = ttk.Entry(form, width=26)
        self.ent_team_email.grid(row=1, column=3, padx=5, pady=7)

        buttons = ttk.Frame(form)
        buttons.grid(row=2, column=0, columnspan=4, sticky="e", padx=5, pady=8)

        ttk.Button(
            buttons, text="ثبت عضو جدید",
            command=self.add_team_member
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons, text="ویرایش عضو انتخاب‌شده",
            command=self.update_team_member
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons, text="فعال / غیرفعال",
            command=self.toggle_team_member
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons, text="پاک کردن فرم",
            command=self.clear_team_form
        ).pack(side="right", padx=4)

        self.tree_team = self.make_tree(self.tab_team, [
            ("id", "شناسه", 65),
            ("full_name", "نام و نام خانوادگی", 220),
            ("role", "سمت", 180),
            ("phone", "تلفن", 140),
            ("email", "ایمیل", 220),
            ("status", "وضعیت", 100)
        ])

        self.add_record_navigation(self.tab_team, self.tree_team, on_edit=self.update_team_member, label="عضو تیم")

        self.tree_team.bind(
            "<<TreeviewSelect>>", self.on_team_selected
        )

    def clear_team_form(self):
        self.ent_team_name.delete(0, "end")
        self.ent_team_phone.delete(0, "end")
        self.ent_team_email.delete(0, "end")
        self.combo_team_role.current(3)
        self.tree_team.selection_remove(self.tree_team.selection())

    def add_team_member(self):
        project_id = self.get_current_project_id()
        name = self.ent_team_name.get().strip()
        role = self.combo_team_role.get().strip()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا یک پرونده حسابرسی انتخاب کنید."
            )
            return

        if not name or not role:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "نام عضو و سمت او الزامی است."
            )
            return

        self.services.team.create(
            project_id, name, role,
            self.ent_team_phone.get().strip(),
            self.ent_team_email.get().strip()
        )
        self.clear_team_form()
        self.refresh_team()
        self.refresh_workpapers()
        messagebox.showinfo("ثبت موفق", "عضو تیم با موفقیت ثبت شد.")

    def on_team_selected(self, event=None):
        selected = self.tree_team.selection()
        if not selected:
            return
        values = self.tree_team.item(selected[0], "values")
        if not values:
            return

        self.ent_team_name.delete(0, "end")
        self.ent_team_name.insert(0, values[1])
        self.combo_team_role.set(values[2])
        self.ent_team_phone.delete(0, "end")
        self.ent_team_phone.insert(0, values[3])
        self.ent_team_email.delete(0, "end")
        self.ent_team_email.insert(0, values[4])

    def update_team_member(self):
        selected = self.tree_team.selection()
        if not selected:
            messagebox.showwarning("انتخاب عضو", "ابتدا یک عضو را از جدول انتخاب کنید.")
            return

        values = self.tree_team.item(selected[0], "values")
        member_id = int(values[0])
        name = self.ent_team_name.get().strip()
        role = self.combo_team_role.get().strip()

        if not name or not role:
            messagebox.showwarning("اطلاعات ناقص", "نام و سمت عضو الزامی است.")
            return

        self.services.team.update(
            member_id, name, role,
            self.ent_team_phone.get().strip(),
            self.ent_team_email.get().strip()
        )
        self.refresh_team()
        self.refresh_workpapers()
        messagebox.showinfo("ویرایش موفق", "اطلاعات عضو تیم به‌روزرسانی شد.")

    def toggle_team_member(self):
        selected = self.tree_team.selection()
        if not selected:
            messagebox.showwarning("انتخاب عضو", "ابتدا یک عضو را انتخاب کنید.")
            return

        values = self.tree_team.item(selected[0], "values")
        member_id = int(values[0])
        if values[5] == "فعال":
            self.services.team.deactivate(member_id)
        else:
            self.services.team.activate(member_id)

        self.refresh_team()
        self.refresh_workpapers()

    def refresh_team(self):
        if not hasattr(self, "tree_team"):
            return
        self.clear_tree(self.tree_team)
        nav_refresh = getattr(self.tree_team, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
        project_id = self.get_current_project_id()
        if not project_id:
            return

        for row in self.services.team.for_project(project_id):
            member_id, name, role, phone, email, active, created = row
            self.tree_team.insert(
                "", "end",
                values=(
                    member_id, name, role, phone or "", email or "",
                    "فعال" if active else "غیرفعال"
                )
            )
        nav_refresh = getattr(self.tree_team, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
