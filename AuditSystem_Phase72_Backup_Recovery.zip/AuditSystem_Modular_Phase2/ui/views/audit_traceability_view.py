"""Read-only audit traceability tab."""

import tkinter as tk
from tkinter import ttk, messagebox

from services.audit_traceability_service import AuditTraceabilityService


class AuditTraceabilityViewMixin:
    def setup_audit_traceability_tab(self):
        self.audit_traceability_service = AuditTraceabilityService()
        self.audit_traceability_data = None

        root = ttk.Frame(self.tab_audit_traceability, padding=12)
        root.pack(fill="both", expand=True)
        ttk.Label(
            root, text="ردیابی ارتباط ریسک، برنامه، آزمون، شواهد و یافته",
            font=("Tahoma", 14, "bold"),
        ).pack(anchor="e", pady=(0, 8))

        bar = ttk.Frame(root)
        bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="به‌روزرسانی گزارش", command=self.refresh_audit_traceability).pack(side="right", padx=4)
        self.audit_traceability_summary = ttk.Label(
            bar, text="برای مشاهده وضعیت ارتباطات، پرونده را انتخاب و گزارش را به‌روزرسانی کنید."
        )
        self.audit_traceability_summary.pack(side="right", padx=10)

        columns = ("priority", "entity", "id", "title", "problem")
        self.audit_traceability_tree = ttk.Treeview(root, columns=columns, show="headings", height=14)
        headings = {
            "priority": ("اولویت", 75), "entity": ("نوع رکورد", 100),
            "id": ("شناسه", 65), "title": ("عنوان", 220),
            "problem": ("خلأ یا ناسازگاری شناسایی‌شده", 520),
        }
        for key, (label, width) in headings.items():
            self.audit_traceability_tree.heading(key, text=label)
            self.audit_traceability_tree.column(key, width=width, anchor="e" if key in {"title", "problem"} else "center")
        self.audit_traceability_tree.pack(fill="both", expand=True, pady=6)
        self.audit_traceability_tree.bind("<<TreeviewSelect>>", self.show_audit_traceability_detail)

        ttk.Label(root, text="اقدام پیشنهادی و توضیحات:", font=("Tahoma", 10, "bold")).pack(anchor="e", pady=(6, 2))
        self.audit_traceability_detail = tk.Text(root, height=6, wrap="word", font=("Tahoma", 9), state="disabled")
        self.audit_traceability_detail.pack(fill="x", pady=4)
        self.audit_traceability_status = ttk.Label(root, text="گزارش فقط‌خواندنی است؛ هیچ داده‌ای را تغییر نمی‌دهد.")
        self.audit_traceability_status.pack(anchor="e", pady=3)

    def refresh_audit_traceability(self):
        project_id = self.get_current_project_id()
        if not project_id:
            self.audit_traceability_status.configure(text="ابتدا یک پرونده حسابرسی انتخاب کنید.")
            return
        try:
            data = self.audit_traceability_service.for_project(project_id)
            self.audit_traceability_data = data
            for item in self.audit_traceability_tree.get_children():
                self.audit_traceability_tree.delete(item)
            for index, issue in enumerate(data["issues"]):
                self.audit_traceability_tree.insert(
                    "", "end", iid=str(index),
                    values=(issue["priority"], issue["entity_type"], issue["entity_id"], issue["title"], issue["problem"]),
                )
            summary = data["summary"]
            self.audit_traceability_summary.configure(
                text=(f"ریسک‌ها: {summary['risk_count']} | پوشش ریسک به آزمون: "
                      f"{summary['risk_test_coverage_percent']}٪ | ادعاهای پوشش‌داده‌شده: "
                      f"{summary['distinct_assertion_count']} | موارد نیازمند پیگیری: "
                      f"{summary['issue_count']} | اولویت بالا/فوری: {summary['high_priority_count']}")
            )
            self.audit_traceability_status.configure(text="گزارش ردیابی با موفقیت به‌روزرسانی شد.")
            self._set_audit_traceability_detail("برای مشاهده پیشنهاد اصلاح، یک مورد را از فهرست انتخاب کنید.")
        except Exception as exc:
            self.audit_traceability_status.configure(text=f"خطا در تهیه گزارش: {exc}")
            messagebox.showerror("ردیابی حسابرسی", str(exc))

    def _set_audit_traceability_detail(self, value):
        self.audit_traceability_detail.configure(state="normal")
        self.audit_traceability_detail.delete("1.0", "end")
        self.audit_traceability_detail.insert("1.0", value)
        self.audit_traceability_detail.configure(state="disabled")

    def show_audit_traceability_detail(self, event=None):
        if not self.audit_traceability_data:
            return
        selected = self.audit_traceability_tree.selection()
        if not selected:
            return
        try:
            issue = self.audit_traceability_data["issues"][int(selected[0])]
        except (ValueError, IndexError):
            return
        lines = [
            f"نوع رکورد: {issue['entity_type']}",
            f"شناسه: {issue['entity_id']}",
            f"عنوان: {issue['title']}",
            f"اولویت: {issue['priority']}",
            "",
            f"شرح: {issue['problem']}",
            "",
            f"اقدام پیشنهادی: {issue['recommendation']}",
            "",
            "یادآوری: این پیشنهاد جایگزین قضاوت حرفه‌ای حسابرس نیست.",
        ]
        self._set_audit_traceability_detail("\n".join(lines))
