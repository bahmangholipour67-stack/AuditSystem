import os
import webbrowser
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk


class FindingViewMixin:
    def setup_finding_tab(self):
        form = ttk.LabelFrame(self.tab_findings, text="ثبت یافته")
        form.pack(fill="x", padx=10, pady=8)

        ttk.Label(form, text="شرح:").grid(row=0, column=0, padx=5, pady=8)
        self.ent_find_title = ttk.Entry(form, width=35)
        self.ent_find_title.grid(row=0, column=1, padx=5)

        ttk.Label(form, text="اهمیت:").grid(row=0, column=2, padx=5)
        self.combo_find_sev = ttk.Combobox(
            form, values=["کم", "متوسط", "بااهمیت", "اساسی"],
            state="readonly", width=16,
        )
        self.combo_find_sev.current(1)
        self.combo_find_sev.grid(row=0, column=3, padx=5)

        ttk.Label(form, text="اقدام اصلاحی:").grid(row=1, column=0, padx=5, pady=8)
        self.ent_find_act = ttk.Entry(form, width=35)
        self.ent_find_act.grid(row=1, column=1, padx=5)

        ttk.Label(form, text="مسئول:").grid(row=1, column=2, padx=5)
        self.ent_find_owner = ttk.Entry(form, width=18)
        self.ent_find_owner.grid(row=1, column=3, padx=5)

        ttk.Label(form, text="کاربرگ مرتبط:").grid(row=2, column=0, padx=5, pady=7)
        self.combo_find_workpaper = ttk.Combobox(form, state="readonly", width=55)
        self.combo_find_workpaper.grid(row=2, column=1, columnspan=2, padx=5, pady=7, sticky="ew")

        ttk.Button(form, text="ثبت یافته", command=self.add_finding).grid(
            row=2, column=3, sticky="e", padx=5, pady=8
        )

        actions = ttk.Frame(self.tab_findings)
        actions.pack(fill="x", padx=12, pady=3)
        ttk.Button(actions, text="اتصال کاربرگ به یافته انتخاب‌شده", command=self.link_selected_finding_workpaper).pack(side="right", padx=4)
        ttk.Button(actions, text="بستن یافته انتخاب‌شده", command=self.close_selected_finding).pack(side="right", padx=4)
        ttk.Button(actions, text="افزودن مستند", command=self.add_finding_evidence).pack(side="right", padx=4)
        ttk.Button(actions, text="مشاهده مستندات", command=self.show_finding_evidence).pack(side="right", padx=4)

        self.tree_finds = self.make_tree(
            self.tab_findings,
            [
                ("id", "شناسه", 55),
                ("title", "شرح یافته", 210),
                ("severity", "اهمیت", 85),
                ("action", "اقدام اصلاحی", 190),
                ("owner", "مسئول", 110),
                ("status", "وضعیت", 85),
                ("workpaper", "کاربرگ مرتبط", 160),
                ("risk", "ریسک مرتبط", 150),
            ],
        )
        self._finding_workpaper_labels = {}
        self._finding_workpaper_by_id = {}
        self.add_record_navigation(self.tab_findings, self.tree_finds, on_edit=self.edit_selected_finding, on_delete=self.delete_selected_finding, label="یافته")
        self.tree_finds.bind("<<TreeviewSelect>>", self.on_finding_selected)
        self.refresh_findings()

    def _refresh_finding_workpapers(self, project_id):
        self._finding_workpaper_labels = {}
        self._finding_workpaper_by_id = {}
        options = ["بدون کاربرگ مرتبط"]
        for row in self.services.workpapers.for_project(project_id):
            workpaper_id, title = row[0], row[1]
            label = f"{title} (#{workpaper_id})"
            options.append(label)
            self._finding_workpaper_labels[label] = workpaper_id
            self._finding_workpaper_by_id[workpaper_id] = label
        self.combo_find_workpaper["values"] = options
        if self.combo_find_workpaper.get() not in options:
            self.combo_find_workpaper.set(options[0])

    def on_finding_selected(self, event=None):
        selected = self.tree_finds.selection()
        if not selected:
            return
        values = self.tree_finds.item(selected[0], "values")
        if not values:
            return
        # The table shows the workpaper title; resolve it through the current
        # project map so the combo always points to a project-scoped ID.
        shown_label = str(values[6] or "")
        if shown_label in self._finding_workpaper_labels:
            self.combo_find_workpaper.set(shown_label)
        elif shown_label == "بدون کاربرگ مرتبط":
            self.combo_find_workpaper.set("بدون کاربرگ مرتبط")

    def add_finding(self):
        pid = self.get_current_project_id()
        title = self.ent_find_title.get().strip()
        if not pid or not title:
            messagebox.showwarning("اطلاعات ناقص", "پرونده و شرح یافته لازم است.")
            return
        workpaper_id = self._finding_workpaper_labels.get(self.combo_find_workpaper.get())
        try:
            self.services.findings.create(
                pid, title, self.combo_find_sev.get(),
                self.ent_find_act.get().strip(), self.ent_find_owner.get().strip(),
                workpaper_id=workpaper_id,
            )
            for entry in (self.ent_find_title, self.ent_find_act, self.ent_find_owner):
                entry.delete(0, "end")
            self.refresh_findings()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
            messagebox.showinfo("ثبت موفق", "یافته با ارتباط‌های انتخاب‌شده ثبت شد.")
        except Exception as exc:
            messagebox.showerror("خطا در ثبت یافته", str(exc))


    def edit_selected_finding(self):
        selected = self.tree_finds.selection()
        if not selected:
            messagebox.showinfo("انتخاب یافته", "ابتدا یک یافته را انتخاب کنید."); return
        values = self.tree_finds.item(selected[0], "values")
        if str(values[5]) != "باز":
            messagebox.showwarning("ویرایش محدود", "فقط یافته‌های باز قابل ویرایش هستند."); return
        project_id = self.get_current_project_id()
        rows = self.services.findings.for_project(project_id) if project_id else []
        finding = next((r for r in rows if int(r[0]) == int(values[0])), None)
        if not finding: return
        win = tk.Toplevel(self.root); win.title("ویرایش یافته"); win.geometry("520x300"); win.transient(self.root); win.grab_set()
        self._style_dialog(win)
        labels = ("شرح یافته", "اهمیت", "اقدام اصلاحی", "مسئول")
        entries = []
        for i, (label, value) in enumerate(zip(labels, (finding[1], finding[2], finding[3], finding[4]))):
            ttk.Label(win, text=label).grid(row=i, column=1, padx=8, pady=7, sticky="e")
            if i == 1:
                field = ttk.Combobox(win, values=["کم", "متوسط", "بااهمیت", "اساسی"], state="readonly", width=35); field.set(value or "متوسط")
            else:
                field = ttk.Entry(win, width=38); field.insert(0, value or "")
            field.grid(row=i, column=0, padx=8, pady=7); entries.append(field)
        def save():
            try:
                self.services.findings.update(project_id, int(finding[0]), entries[0].get(), entries[1].get(), entries[2].get(), entries[3].get())
                win.destroy(); self.refresh_findings(); self.restore_tree_selection(self.tree_finds, finding[0])
                if hasattr(self, "refresh_dashboard"): self.refresh_dashboard()
            except Exception as exc: messagebox.showerror("خطا در ویرایش", str(exc), parent=win)
        ttk.Button(win, text="ذخیره تغییرات", command=save).grid(row=4, column=0, pady=10)

    def link_selected_finding_workpaper(self):
        pid = self.get_current_project_id()
        selected = self.tree_finds.selection()
        if not pid or not selected:
            messagebox.showinfo("راهنما", "ابتدا یک یافته را انتخاب کنید.")
            return
        finding_id = int(self.tree_finds.item(selected[0], "values")[0])
        workpaper_id = self._finding_workpaper_labels.get(self.combo_find_workpaper.get())
        try:
            self.services.findings.link_workpaper(pid, finding_id, workpaper_id)
            self.refresh_findings()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
        except Exception as exc:
            messagebox.showerror("خطا در اتصال", str(exc))

    def _selected_finding_id(self):
        selected = self.tree_finds.selection()
        if not selected:
            messagebox.showinfo("انتخاب یافته", "ابتدا یک یافته را انتخاب کنید.")
            return None
        return int(self.tree_finds.item(selected[0], "values")[0])

    def add_finding_evidence(self):
        project_id = self.get_current_project_id()
        finding_id = self._selected_finding_id()
        if not project_id or not finding_id:
            return
        file_path = filedialog.askopenfilename(
            title="انتخاب مستند پشتیبان یافته",
            filetypes=[
                ("همه فایل‌ها", "*.*"),
                ("PDF", "*.pdf"),
                ("Excel", "*.xlsx *.xls"),
                ("Word", "*.docx *.doc"),
                ("تصاویر", "*.png *.jpg *.jpeg *.tif *.tiff"),
            ],
        )
        if not file_path:
            return
        member = self.get_active_member()
        if not member:
            messagebox.showwarning(
                "عضو فعال", "برای ثبت نام ثبت‌کننده، ابتدا عضو فعال را از نوار بالای برنامه انتخاب کنید."
            )
            return
        try:
            self.services.findings.add_evidence(
                project_id, finding_id, file_path,
                added_by_member_id=member["id"],
            )
            messagebox.showinfo("ثبت مستند", "مستند پشتیبان یافته ثبت شد.")
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
        except Exception as exc:
            messagebox.showerror("خطا در ثبت مستند", str(exc))

    def show_finding_evidence(self):
        project_id = self.get_current_project_id()
        finding_id = self._selected_finding_id()
        if not project_id or not finding_id:
            return
        rows = self.services.findings.evidence_for_finding(project_id, finding_id)
        window = tk.Toplevel(self.tab_findings)
        self._style_dialog(window)
        window.title("مستندات پشتیبان یافته")
        window.geometry("900x360")
        tree = ttk.Treeview(
            window, columns=("id", "path", "description", "actor", "date"),
            show="headings", height=10,
        )
        headings = {
            "id": "شناسه", "path": "مسیر فایل", "description": "شرح",
            "actor": "ثبت‌کننده", "date": "زمان ثبت",
        }
        widths = {"id": 55, "path": 360, "description": 180, "actor": 110, "date": 140}
        for col in headings:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="center")
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        for row in rows:
            tree.insert("", "end", values=tuple(value or "" for value in row))

        def open_selected_evidence():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("انتخاب مستند", "یک مستند را انتخاب کنید.")
                return
            path = Path(tree.item(selected[0], "values")[1])
            if not path.is_file():
                messagebox.showerror("فایل پیدا نشد", "فایل در مسیر ثبت‌شده موجود نیست.")
                return
            try:
                if hasattr(os, "startfile"):
                    os.startfile(str(path))
                else:
                    webbrowser.open(path.resolve().as_uri())
            except Exception as exc:
                messagebox.showerror("خطا در باز کردن فایل", str(exc))

        ttk.Button(window, text="باز کردن مستند انتخاب‌شده", command=open_selected_evidence).pack(anchor="e", padx=8, pady=(0, 8))
        if not rows:
            messagebox.showinfo("مستندات", "برای این یافته هنوز مستندی ثبت نشده است.")

    def close_selected_finding(self):
        pid = self.get_current_project_id()
        selected = self.tree_finds.selection()
        if not pid or not selected:
            messagebox.showinfo("راهنما", "یک یافته را انتخاب کنید.")
            return
        finding_id = int(self.tree_finds.item(selected[0], "values")[0])
        try:
            self.services.findings.close(pid, finding_id)
            self.refresh_findings()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_findings(self):
        if not hasattr(self, "tree_finds"):
            return
        self.clear_tree(self.tree_finds)
        nav_refresh = getattr(self.tree_finds, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
        pid = self.get_current_project_id()
        if not pid:
            self._finding_workpaper_labels = {}
            self._finding_workpaper_by_id = {}
            self.combo_find_workpaper["values"] = ["بدون کاربرگ مرتبط"]
            self.combo_find_workpaper.set("بدون کاربرگ مرتبط")
            return
        self._refresh_finding_workpapers(pid)
        for row in self.services.findings.for_project(pid):
            finding_id, title, severity, action, owner, status, wp_id, wp_title, risk_id, risk_title = row
            self.tree_finds.insert(
                "", "end",
                values=(
                    finding_id, title or "", severity or "", action or "",
                    owner or "", status or "",
                    self._finding_workpaper_by_id.get(wp_id, "بدون کاربرگ مرتبط"),
                    risk_title or "بدون ریسک",
                ),
            )
        nav_refresh = getattr(self.tree_finds, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()

    def delete_selected_finding(self):
        selected = self.tree_finds.selection()
        if not selected:
            messagebox.showinfo("انتخاب یافته", "ابتدا یک یافته را انتخاب کنید.")
            return
        vals = self.tree_finds.item(selected[0], "values")
        pid = self.get_current_project_id()
        if not pid:
            return
        if not messagebox.askyesno("تأیید حذف یافته", "فقط یافته باز و فاقد مستندات یا ارجاعات قابل حذف است. آیا ادامه می‌دهید؟"):
            return
        try:
            self.services.findings.delete(pid, int(vals[0]))
            self.refresh_findings()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
            messagebox.showinfo("حذف یافته", "یافته باز حذف شد.")
        except ValueError as exc:
            messagebox.showwarning("حذف یافته ممکن نیست", str(exc))
        except Exception as exc:
            messagebox.showerror("خطا در حذف یافته", str(exc))
