"""Operational UI for the version-bound approval workflow."""
import tkinter as tk
from tkinter import ttk, messagebox

from services.approval_workflow_service import ApprovalWorkflowService
from database.connection import connect


class ApprovalCenterViewMixin:
    def setup_approval_center_tab(self):
        self.approval_service = ApprovalWorkflowService()
        root = ttk.Frame(self.tab_approval_center, padding=10)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text="مرکز مدیریت تأییدها و کنترل کیفیت", font=("Tahoma", 15, "bold")).pack(side="right")
        ttk.Button(header, text="به‌روزرسانی", command=self.refresh_approval_center).pack(side="left", padx=4)
        ttk.Button(header, text="مشاهده تاریخچه", command=self.show_approval_history).pack(side="left", padx=4)

        inbox_frame = ttk.LabelFrame(root, text="کارت‌های اقدام عضو فعال", padding=7)
        inbox_frame.pack(fill="x", pady=(0, 6))
        inbox_cols = ("request", "entity", "title", "stage", "submitted")
        self.approval_inbox_tree = ttk.Treeview(inbox_frame, columns=inbox_cols, show="headings", height=4)
        inbox_headings = {"request": "درخواست", "entity": "نوع مدرک", "title": "عنوان مدرک", "stage": "مرحله اقدام", "submitted": "تاریخ ارسال"}
        inbox_widths = {"request": 65, "entity": 100, "title": 340, "stage": 150, "submitted": 145}
        for col in inbox_cols:
            self.approval_inbox_tree.heading(col, text=inbox_headings[col])
            self.approval_inbox_tree.column(col, width=inbox_widths[col], anchor="center")
        self.approval_inbox_tree.pack(fill="x", expand=False)
        self.approval_inbox_tree.bind("<Double-1>", self.open_approval_inbox_item)
        self.approval_inbox_note = ttk.Label(inbox_frame, text="برای مشاهده وظایف، عضو فعال پرونده را از نوار بالای برنامه انتخاب کنید.", anchor="e")
        self.approval_inbox_note.pack(fill="x", pady=(4, 0))

        create = ttk.LabelFrame(root, text="ارسال مدرک برای گردش تأیید", padding=8)
        create.pack(fill="x", pady=5)
        ttk.Label(create, text="نوع مدرک").grid(row=0, column=0, padx=4, pady=4, sticky="e")
        self.approval_entity_type = ttk.Combobox(create, state="readonly", width=18, values=["workpaper", "audit_test"])
        self.approval_entity_type.current(0)
        self.approval_entity_type.grid(row=0, column=1, padx=4, pady=4)
        ttk.Label(create, text="شناسه مدرک").grid(row=0, column=2, padx=4, pady=4, sticky="e")
        self.approval_entity_id = ttk.Entry(create, width=10)
        self.approval_entity_id.grid(row=0, column=3, padx=4, pady=4)
        self.approval_member_boxes = {}
        member_fields = [("submitter", "ارسال‌کننده"), ("supervisor", "سرپرست"), ("manager", "مدیر"), ("quality", "کنترل کیفیت")]
        for idx, (key, label) in enumerate(member_fields):
            row, col = 1 + idx // 2, (idx % 2) * 2
            ttk.Label(create, text=label).grid(row=row, column=col, padx=4, pady=4, sticky="e")
            combo = ttk.Combobox(create, state="readonly", width=27)
            combo.grid(row=row, column=col + 1, padx=4, pady=4, sticky="ew")
            self.approval_member_boxes[key] = combo
        ttk.Button(create, text="ارسال برای تأیید", command=self.submit_approval_request).grid(row=3, column=0, columnspan=4, pady=6)
        create.columnconfigure(1, weight=1)
        create.columnconfigure(3, weight=1)

        ttk.Label(root, text="درخواست‌های تأیید پرونده", font=("Tahoma", 11, "bold")).pack(anchor="e", pady=(8, 3))
        cols = ("id", "entity", "entity_id", "status", "stage", "submitter", "submitted")
        self.approval_tree = ttk.Treeview(root, columns=cols, show="headings", height=9)
        headings = {"id": "شناسه", "entity": "نوع مدرک", "entity_id": "شناسه مدرک", "status": "وضعیت", "stage": "مرحله جاری", "submitter": "ارسال‌کننده", "submitted": "تاریخ ارسال"}
        widths = {"id": 55, "entity": 100, "entity_id": 90, "status": 150, "stage": 150, "submitter": 180, "submitted": 145}
        for col in cols:
            self.approval_tree.heading(col, text=headings[col])
            self.approval_tree.column(col, width=widths[col], anchor="center")
        self.approval_tree.pack(fill="both", expand=True, pady=4)

        action = ttk.LabelFrame(root, text="اقدام بازبین روی مرحله جاری", padding=8)
        action.pack(fill="x", pady=5)
        ttk.Label(action, text="عضو اقدام‌کننده").grid(row=0, column=0, padx=4, pady=4)
        self.approval_actor = ttk.Combobox(action, state="readonly", width=32)
        self.approval_actor.grid(row=0, column=1, padx=4, pady=4)
        ttk.Label(action, text="توضیحات / علت برگشت").grid(row=0, column=2, padx=4, pady=4)
        self.approval_comment = ttk.Entry(action, width=48)
        self.approval_comment.grid(row=0, column=3, padx=4, pady=4, sticky="ew")
        ttk.Button(action, text="تأیید مرحله", command=lambda: self.decide_approval("approve")).grid(row=1, column=1, padx=4, pady=5)
        ttk.Button(action, text="برگشت برای اصلاح", command=lambda: self.decide_approval("return")).grid(row=1, column=2, padx=4, pady=5)
        action.columnconfigure(3, weight=1)
        self.approval_center_note = ttk.Label(root, text="توجه: انتخاب عضو در این صفحه جایگزین احراز هویت امن نیست؛ کنترل نقش و عضویت در سرویس انجام می‌شود.", wraplength=1100, justify="right")
        self.approval_center_note.pack(fill="x", pady=4)
        self.refresh_approval_center()

    def _approval_members(self):
        project_id = self.get_current_project_id()
        if not project_id:
            return []
        with connect(self.db_path) as conn:
            rows = conn.execute("SELECT id, full_name, role FROM team_members WHERE project_id=? AND is_active=1 ORDER BY full_name", (project_id,)).fetchall()
        return rows

    def refresh_approval_center(self):
        if not hasattr(self, "approval_tree"):
            return
        project_id = self.get_current_project_id()
        self.refresh_approval_inbox()
        for tree_item in self.approval_tree.get_children():
            self.approval_tree.delete(tree_item)
        members = self._approval_members()
        choices = [f"{row[0]} | {row[1]} ({row[2]})" for row in members]
        for combo in self.approval_member_boxes.values():
            combo["values"] = choices
            if choices and not combo.get():
                combo.current(0)
        self.approval_actor["values"] = choices
        active_id = getattr(self, "active_member_id", None)
        active_choice = next((choice for choice in choices if choice.split(" | ", 1)[0] == str(active_id)), None)
        if active_choice:
            self.approval_actor.set(active_choice)
        elif choices and not self.approval_actor.get():
            self.approval_actor.current(0)
        if not project_id:
            return
        with connect(self.db_path) as conn:
            rows = conn.execute("""SELECT a.id, a.entity_type, a.entity_id, a.status, a.current_stage,
                m.full_name, a.submitted_at FROM approval_requests a LEFT JOIN team_members m
                ON m.id=a.submitted_by_member_id AND m.project_id=a.project_id
                WHERE a.project_id=? AND a.archived_at IS NULL ORDER BY a.id DESC""", (project_id,)).fetchall()
        stage_labels = {"supervisor": "سرپرست", "manager": "مدیر", "quality": "کنترل کیفیت", "complete": "تکمیل"}
        status_labels = {"pending_supervisor": "در انتظار سرپرست", "pending_manager": "در انتظار مدیر", "pending_quality": "در انتظار کنترل کیفیت", "returned": "برگشت برای اصلاح", "approved": "تأیید نهایی"}
        entity_labels = {"workpaper": "کاربرگ", "audit_test": "آزمون حسابرسی"}
        for row in rows:
            self.approval_tree.insert("", "end", iid=str(row[0]), values=(row[0], entity_labels.get(row[1], row[1]), row[2], status_labels.get(row[3], row[3]), stage_labels.get(row[4], row[4]), row[5] or "—", row[6] or "—"))

    def refresh_approval_inbox(self):
        tree = getattr(self, "approval_inbox_tree", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        project_id = self.get_current_project_id()
        member_id = getattr(self, "active_member_id", None)
        if not project_id or not member_id:
            self.approval_inbox_note.config(text="برای مشاهده وظایف، عضو فعال پرونده را از نوار بالای برنامه انتخاب کنید.")
            return
        try:
            rows = self.approval_service.inbox(project_id, member_id)
        except ValueError as exc:
            self.approval_inbox_note.config(text=str(exc))
            return
        stage_labels = {"supervisor": "بازبینی سرپرست", "manager": "تأیید مدیر حسابرسی", "quality": "کنترل کیفیت نهایی"}
        entity_labels = {"workpaper": "کاربرگ", "audit_test": "آزمون حسابرسی"}
        for row in rows:
            tree.insert("", "end", iid=str(row[0]), values=(row[0], entity_labels.get(row[1], row[1]), row[7] or f"{row[1]} #{row[2]}", stage_labels.get(row[4], row[4]), row[5] or "—"))
        self.approval_inbox_note.config(text=f"{len(rows)} درخواست در انتظار اقدام شماست." if rows else "در حال حاضر درخواست معوقی برای عضو فعال وجود ندارد.")

    def open_approval_inbox_item(self, event=None):
        selected = self.approval_inbox_tree.selection() if hasattr(self, "approval_inbox_tree") else ()
        if not selected:
            return
        request_id = str(selected[0])
        if self.approval_tree.exists(request_id):
            self.approval_tree.selection_set(request_id)
            self.approval_tree.focus(request_id)
            self.approval_tree.see(request_id)

    def _approval_member_id(self, combo):
        value = combo.get().strip()
        if not value or " | " not in value:
            raise ValueError("برای تمام نقش‌ها یک عضو فعال انتخاب کنید.")
        return int(value.split(" | ", 1)[0])

    def submit_approval_request(self):
        project_id = self.get_current_project_id()
        if not project_id:
            messagebox.showwarning("پرونده", "ابتدا پرونده حسابرسی را انتخاب کنید.")
            return
        try:
            entity_id = int(self.approval_entity_id.get().strip())
            ids = {key: self._approval_member_id(combo) for key, combo in self.approval_member_boxes.items()}
            request_id = self.approval_service.submit(project_id, self.approval_entity_type.get(), entity_id, ids["submitter"], ids["supervisor"], ids["manager"], ids["quality"])
            self.refresh_approval_center()
            messagebox.showinfo("ارسال موفق", f"درخواست تأیید با شناسه {request_id} ثبت شد.")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("عدم امکان ارسال", str(exc))
        except Exception as exc:
            messagebox.showerror("خطای ارسال درخواست", str(exc))

    def decide_approval(self, decision):
        project_id = self.get_current_project_id()
        selected = self.approval_tree.selection()
        if not project_id or not selected:
            messagebox.showwarning("انتخاب درخواست", "ابتدا یک درخواست را انتخاب کنید.")
            return
        try:
            actor_id = self._approval_member_id(self.approval_actor)
            self.approval_service.decide(project_id, int(selected[0]), actor_id, decision, self.approval_comment.get())
            self.approval_comment.delete(0, "end")
            self.refresh_approval_center()
            messagebox.showinfo("ثبت تصمیم", "تصمیم با موفقیت در تاریخچه گردش تأیید ثبت شد.")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("تصمیم غیرمجاز", str(exc))
        except Exception as exc:
            messagebox.showerror("خطای ثبت تصمیم", str(exc))

    def show_approval_history(self):
        project_id = self.get_current_project_id()
        selected = self.approval_tree.selection() if hasattr(self, "approval_tree") else ()
        if not project_id or not selected:
            messagebox.showwarning("انتخاب درخواست", "برای مشاهده تاریخچه، یک درخواست را انتخاب کنید.")
            return
        rows = self.approval_service.history(project_id, int(selected[0]))
        win = tk.Toplevel(self.root)
        self._style_dialog(win)
        win.title("تاریخچه گردش تأیید")
        win.geometry("900x420")
        cols = ("date", "event", "stage", "actor", "role", "comment")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        labels = {"date": "زمان", "event": "رویداد", "stage": "مرحله", "actor": "اقدام‌کننده", "role": "سمت", "comment": "توضیحات"}
        for col in cols:
            tree.heading(col, text=labels[col])
            tree.column(col, width=135 if col != "comment" else 280, anchor="e")
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        for row in rows:
            tree.insert("", "end", values=(row[8], row[1], row[2], row[4] or row[3], row[5], row[6]))
