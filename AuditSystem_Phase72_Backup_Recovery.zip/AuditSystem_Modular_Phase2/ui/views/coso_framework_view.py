"""COSO principles dashboard and project-scoped assessment UI."""
from tkinter import ttk, messagebox, simpledialog, filedialog, Toplevel, Text
import json
from services.coso_risk_control_service import CosoRiskControlService
from services.coso_assessment_report_service import CosoAssessmentReportService


class CosoFrameworkViewMixin:
    def setup_coso_framework_tab(self):
        self.coso_service = CosoRiskControlService(self.db_path)
        self.coso_report_service = CosoAssessmentReportService(self.db_path)
        root = ttk.Frame(self.tab_coso_framework, padding=10); root.pack(fill="both", expand=True)
        head = ttk.Frame(root); head.pack(fill="x")
        ttk.Label(head, text="چارچوب COSO؛ ارزیابی پنج مؤلفه و ۱۷ اصل", font=("Tahoma", 13, "bold")).pack(side="right")
        ttk.Button(head, text="تازه‌سازی ارزیابی", command=self.refresh_coso_framework).pack(side="left", padx=3)
        ttk.Button(head, text="نگاشت کنترل به اصل", command=self.map_coso_control).pack(side="left", padx=3)
        ttk.Button(head, text="ثبت ارزیابی اصل", command=self.assess_coso_principle).pack(side="left", padx=3)
        ttk.Button(head, text="تکمیل چک‌لیست اصل", command=self.open_coso_checklist).pack(side="left", padx=3)
        ttk.Button(head, text="گزارش پیشرفت چک‌لیست", command=self.show_coso_checklist_report).pack(side="left", padx=3)
        ttk.Button(head, text="گزارش حرفه‌ای ارزیابی COSO", command=self.open_coso_professional_report).pack(side="left", padx=3)
        self.coso_summary_label = ttk.Label(root, text="")
        self.coso_summary_label.pack(anchor="e", pady=8)
        cols=("code","component","principle","title","mapped","rating","evidence")
        self.coso_tree=ttk.Treeview(root,columns=cols,show="headings",height=18)
        labels={"code":"کد","component":"مؤلفه","principle":"اصل","title":"عنوان اصل","mapped":"تعداد کنترل","rating":"امتیاز","evidence":"شواهد"}
        widths={"code":55,"component":150,"principle":55,"title":330,"mapped":90,"rating":75,"evidence":250}
        for col in cols:
            self.coso_tree.heading(col,text=labels[col]); self.coso_tree.column(col,width=widths[col],anchor="e")
        self.coso_tree.pack(fill="both",expand=True)
        ttk.Label(root,text="این داشبورد ابزار مستندسازی و ارزیابی است؛ امتیاز یا تکمیل اصول به‌تنهایی به معنی انطباق قطعی با COSO نیست.",wraplength=1100).pack(anchor="e",pady=6)
        self.refresh_coso_framework()

    def _coso_project(self):
        pid=self.get_current_project_id()
        if not pid: messagebox.showwarning("پرونده","ابتدا پرونده حسابرسی را انتخاب کنید.")
        return pid

    def refresh_coso_framework(self):
        if not hasattr(self,"coso_tree"): return
        for item in self.coso_tree.get_children(): self.coso_tree.delete(item)
        pid=self.get_current_project_id()
        if not pid: return
        try:
            report=self.coso_service.build_report(pid); s=report["summary"]
            self.coso_summary_label.config(text=f"اصول: {s['principle_count']} | ارزیابی‌شده: {s['assessed_count']} | دارای نگاشت کنترل: {s['mapped_count']} | خلأها: {s['gap_count']} | میانگین امتیاز: {s['average_rating'] if s['average_rating'] is not None else '—'}")
            for p in report["principles"]:
                self.coso_tree.insert("","end",iid=p["code"],values=(p["code"],p["component"],p["principle_no"],p["title"],p["mapping_count"],p["rating"] or "—",p["evidence"] or "—"))
        except Exception as e: messagebox.showerror("COSO",str(e))

    def map_coso_control(self):
        pid=self._coso_project()
        if not pid:return
        code=self._selected_coso_code()
        if not code:return
        controls=self.services.risks  # keep UI independent from direct SQL for risk records
        control_id=simpledialog.askinteger("نگاشت کنترل","شناسه کنترل داخلی:",parent=self.root,minvalue=1)
        if not control_id:return
        risk_id=simpledialog.askinteger("ریسک مرتبط","شناسه ریسک (اختیاری؛ خالی = بدون ریسک):",parent=self.root,minvalue=1)
        rationale=simpledialog.askstring("توجیه نگاشت","توضیح ارتباط کنترل با اصل COSO:",parent=self.root) or ""
        try:self.coso_service.map_control(pid,control_id,code,risk_id,rationale); self.refresh_coso_framework()
        except Exception as e:messagebox.showerror("نگاشت COSO",str(e))

    def assess_coso_principle(self):
        pid=self._coso_project()
        if not pid:return
        code=self._selected_coso_code()
        if not code:return
        rating=simpledialog.askinteger("امتیاز اصل COSO","امتیاز از ۱ تا ۵:",parent=self.root,minvalue=1,maxvalue=5)
        if rating is None:return
        evidence=simpledialog.askstring("شواهد","شرح یا ارجاع شواهد ارزیابی:",parent=self.root)
        if not evidence:return
        conclusion=simpledialog.askstring("نتیجه","جمع‌بندی ارزیابی:",parent=self.root) or ""
        assessor=simpledialog.askstring("ارزیاب","نام ارزیاب:",parent=self.root) or ""
        try:self.coso_service.assess_principle(pid,code,rating,evidence,conclusion,assessor); self.refresh_coso_framework()
        except Exception as e:messagebox.showerror("ارزیابی COSO",str(e))


    def show_coso_checklist_report(self):
        pid=self._coso_project()
        if not pid:return
        try:
            report=self.coso_service.checklist_report(pid); s=report["summary"]
            message=(f"تعداد پرسش‌ها: {s['question_count']}\nتکمیل‌شده: {s['answered_count']} ({s['completion_percent']}%)\n"
                     f"بله: {s['yes_count']} | خیر: {s['no_count']} | تاحدی: {s['partial_count']}\n"
                     f"قابل‌اعمال نیست: {s['not_applicable_count']} | بی‌پاسخ: {s['unanswered_count']}\n"
                     f"موارد دارای ضعف: {s['weakness_count']} | نیازمند تکمیل شواهد: {s['evidence_gap_count']}")
            messagebox.showinfo("گزارش چک‌لیست COSO",message,parent=self.root)
        except Exception as e:messagebox.showerror("گزارش COSO",str(e),parent=self.root)

    def open_coso_checklist(self):
        pid=self._coso_project()
        if not pid:return
        code=self._selected_coso_code()
        if not code:return
        from tkinter import Toplevel, Text, StringVar
        win=Toplevel(self.root); win.title(f"چک‌لیست ارزیابی COSO - {code}"); win.geometry("1120x700"); win.transient(self.root)
        self._style_dialog(win)
        win.columnconfigure(0,weight=3); win.columnconfigure(1,weight=2); win.rowconfigure(0,weight=1)
        left=ttk.Frame(win,padding=8); left.grid(row=0,column=0,sticky="nsew")
        right=ttk.Frame(win,padding=8); right.grid(row=0,column=1,sticky="nsew")
        cols=("no","question","answer","evidence")
        tree=ttk.Treeview(left,columns=cols,show="headings",height=22)
        for c,t,w in (("no","ردیف",55),("question","پرسش ارزیابی",570),("answer","پاسخ",125),("evidence","ارجاع مدرک",160)):
            tree.heading(c,text=t);tree.column(c,width=w,anchor="e")
        tree.pack(fill="both",expand=True)
        rows=self.coso_service.checklist(pid,code); by_id={}
        for r in rows:
            iid=str(r["question_id"]);by_id[iid]=r
            tree.insert("","end",iid=iid,values=(r["question_no"],r["question_text"],r["answer"] or "پاسخ‌داده‌نشده",r["evidence_ref"] or "—"))
        ttk.Label(right,text="فرم پاسخ به پرسش انتخاب‌شده",font=("Tahoma",11,"bold")).pack(anchor="e",pady=(0,8))
        ttk.Label(right,text="پرسش:",wraplength=420).pack(anchor="e")
        question_label=ttk.Label(right,text="ابتدا یک پرسش را انتخاب کنید.",wraplength=420,justify="right")
        question_label.pack(fill="x",pady=(2,8))
        ttk.Label(right,text="پاسخ").pack(anchor="e")
        answer=StringVar(value="پاسخ‌داده‌نشده")
        answer_box=ttk.Combobox(right,textvariable=answer,state="readonly",values=("بله","خیر","تاحدی","قابل‌اعمال نیست","پاسخ‌داده‌نشده"));answer_box.pack(fill="x",pady=3)
        widgets={}
        def add_text(label,height=3):
            ttk.Label(right,text=label).pack(anchor="e",pady=(5,0))
            t=Text(right,height=height,wrap="word");t.pack(fill="x",pady=2);widgets[label]=t;return t
        add_text("توضیحات و مبنای پاسخ",3)
        add_text("ارجاع شواهد / شماره سند",2)
        add_text("ضعف یا استثنای مشاهده‌شده",2)
        add_text("اقدام اصلاحی پیشنهادی",2)
        ttk.Label(right,text="مسئول اقدام").pack(anchor="e")
        owner=ttk.Entry(right);owner.pack(fill="x",pady=2)
        ttk.Label(right,text="سررسید (مثلاً ۱۴۰۵/۱۲/۲۹)").pack(anchor="e")
        due=ttk.Entry(right);due.pack(fill="x",pady=2)
        ttk.Label(right,text="نام ارزیاب").pack(anchor="e")
        assessor=ttk.Entry(right);assessor.pack(fill="x",pady=2)
        current={"id":None}
        def set_text(label,value):
            w=widgets[label];w.delete("1.0","end");w.insert("1.0",value or "")
        def load(_event=None):
            sel=tree.selection()
            if not sel:return
            r=by_id[sel[0]];current["id"]=r["question_id"]
            question_label.config(text=r["question_text"])
            answer.set(r["answer"] or "پاسخ‌داده‌نشده")
            set_text("توضیحات و مبنای پاسخ",r["explanation"]);set_text("ارجاع شواهد / شماره سند",r["evidence_ref"])
            set_text("ضعف یا استثنای مشاهده‌شده",r["weakness"]);set_text("اقدام اصلاحی پیشنهادی",r["corrective_action"])
            owner.delete(0,"end");owner.insert(0,r["owner"] or "")
            due.delete(0,"end");due.insert(0,r["due_date"] or "")
            assessor.delete(0,"end");assessor.insert(0,r["assessor"] or "")
        tree.bind("<<TreeviewSelect>>",load)
        def value(label):return widgets[label].get("1.0","end").strip()
        def save():
            qid=current["id"]
            if not qid:messagebox.showwarning("انتخاب پرسش","ابتدا یک پرسش را انتخاب کنید.",parent=win);return
            try:
                self.coso_service.save_checklist_response(pid,qid,answer.get(),value("توضیحات و مبنای پاسخ"),value("ارجاع شواهد / شماره سند"),value("ضعف یا استثنای مشاهده‌شده"),value("اقدام اصلاحی پیشنهادی"),owner.get(),due.get(),assessor.get())
                r=by_id[str(qid)];r.update(answer=answer.get(),explanation=value("توضیحات و مبنای پاسخ"),evidence_ref=value("ارجاع شواهد / شماره سند"),weakness=value("ضعف یا استثنای مشاهده‌شده"),corrective_action=value("اقدام اصلاحی پیشنهادی"),owner=owner.get(),due_date=due.get(),assessor=assessor.get())
                tree.item(str(qid),values=(r["question_no"],r["question_text"],answer.get(),r["evidence_ref"] or "—"))
                messagebox.showinfo("ذخیره شد","پاسخ چک‌لیست ذخیره شد.",parent=win)
                self.refresh_coso_framework()
            except Exception as e:messagebox.showerror("ذخیره پاسخ",str(e),parent=win)
        ttk.Button(right,text="ذخیره پاسخ این پرسش",command=save).pack(fill="x",pady=8)
        ttk.Label(left,text="برای هر پرسش پاسخ را انتخاب کنید؛ برای پاسخ‌های بله، خیر و تاحدی، توضیح یا ارجاع شواهد الزامی است.",wraplength=650).pack(anchor="e",pady=6)
        if rows:tree.selection_set(str(rows[0]["question_id"]));load()

    def _selected_coso_code(self):
        selected=self.coso_tree.selection()
        if not selected: messagebox.showwarning("اصل COSO","ابتدا یک اصل را انتخاب کنید."); return None
        return selected[0]


    def open_coso_professional_report(self):
        """Preview and export the evidence-aware COSO assessment report."""
        pid = self._coso_project()
        if not pid:
            return
        try:
            report = self.coso_report_service.build(pid)
        except Exception as exc:
            messagebox.showerror("گزارش حرفه‌ای COSO", str(exc), parent=self.root)
            return

        win = Toplevel(self.root)

        self._style_dialog(win)
        win.title("گزارش حرفه‌ای ارزیابی چارچوب COSO")
        win.geometry("1120x760")
        win.transient(self.root)
        win.columnconfigure(0, weight=1)
        win.rowconfigure(1, weight=1)
        header = ttk.Frame(win, padding=10)
        header.grid(row=0, column=0, sticky="ew")
        summary = report["summary"]
        ttk.Label(header, text=f"پرونده: {report['project'].get('name', '')} | دوره: {report['project'].get('period', '')}", font=("Tahoma", 10, "bold")).pack(anchor="e")
        ttk.Label(header, text=f"وضعیت: {summary['overall_status']} | تکمیل: {summary['completion_percent']}% | پاسخ‌داده‌شده: {summary['answered_count']} از {summary['question_count']} | خیر: {summary['no_count']} | تاحدی: {summary['partial_count']} | بی‌پاسخ: {summary['unanswered_count']} | خلأ شواهد: {summary['evidence_gap_count']}", wraplength=1050).pack(anchor="e", pady=5)
        body = Text(win, wrap="word", font=("Tahoma", 10), padx=10, pady=10)
        body.grid(row=1, column=0, sticky="nsew", padx=10)
        body.insert("end", "خلاصه پنج مؤلفه COSO\n" + "=" * 90 + "\n")
        for comp in report["components"]:
            body.insert("end", f"{comp['component_no']}. {comp['component']} | تکمیل {comp['completion_percent']}% | بله {comp['yes_count']} | خیر {comp['no_count']} | تاحدی {comp['partial_count']} | بی‌پاسخ {comp['unanswered_count']} | وضعیت: {comp['assessment_status']}\n")
        body.insert("end", "\nتحلیل اصول ۱۷گانه\n" + "=" * 90 + "\n")
        for principle in report["principles"]:
            body.insert("end", f"{principle['code']} ـ اصل {principle['principle_no']}: {principle['title']}\n")
            body.insert("end", f"پیشرفت {principle['answered_count']}/{principle['question_count']} ({principle['completion_percent']}%) | خیر {principle['no_count']} | تاحدی {principle['partial_count']} | فاقد ارجاع شواهد {principle['evidence_gap_count']} | کنترل نگاشت‌شده {principle['mapped_controls']} | کنترل آزمون‌شده {principle['tested_controls']} | یافته مرتبط {principle['linked_findings']} | امتیاز مستقل {principle['rating'] if principle['rating'] is not None else 'ثبت نشده'}\n")
            for q in principle["questions"]:
                if q["answer"] in ("خیر", "تاحدی", "پاسخ‌داده‌نشده") or (q["answer"] not in ("پاسخ‌داده‌نشده", "قابل‌اعمال نیست") and not q["evidence_ref"]):
                    body.insert("end", f"  پرسش {q['question_no']}: {q['question_text']}\n  پاسخ: {q['answer']} | ضعف: {q['weakness'] or 'ثبت نشده'} | شواهد: {q['evidence_ref'] or 'ارجاع مستقل ثبت نشده'} | اقدام: {q['corrective_action'] or 'ثبت نشده'} | مسئول: {q['owner'] or 'تعیین نشده'} | سررسید: {q['due_date'] or 'تعیین نشده'}\n")
            body.insert("end", "\n")
        body.insert("end", "ملاحظات و محدودیت‌ها\n" + "=" * 90 + "\n")
        for note in report["methodology"]:
            body.insert("end", "• " + note + "\n")
        body.configure(state="disabled")

        footer = ttk.Frame(win, padding=10)
        footer.grid(row=2, column=0, sticky="ew")
        def export(kind):
            extensions = {"excel": ("xlsx", "Excel Workbook"), "word": ("docx", "Word Document"), "json": ("json", "JSON")}
            ext, label = extensions[kind]
            path = filedialog.asksaveasfilename(parent=win, title="ذخیره گزارش COSO", defaultextension="." + ext, filetypes=[(label, "*." + ext)])
            if not path:
                return
            try:
                if kind == "excel": self.coso_report_service.export_excel(report, path)
                elif kind == "word": self.coso_report_service.export_word(report, path)
                else:
                    with open(path, "w", encoding="utf-8") as output:
                        json.dump(report, output, ensure_ascii=False, indent=2, default=str)
                messagebox.showinfo("گزارش ذخیره شد", f"گزارش با موفقیت ذخیره شد:\n{path}", parent=win)
            except Exception as exc:
                messagebox.showerror("خطای خروجی", str(exc), parent=win)
        ttk.Button(footer, text="خروجی Excel", command=lambda: export("excel")).pack(side="left", padx=4)
        ttk.Button(footer, text="خروجی Word", command=lambda: export("word")).pack(side="left", padx=4)
        ttk.Button(footer, text="خروجی JSON", command=lambda: export("json")).pack(side="left", padx=4)
        ttk.Label(footer, text="گزارش فقط‌خواندنی است؛ برای نتیجه‌گیری درباره اثربخشی، آزمون و قضاوت حرفه‌ای لازم است.").pack(side="right", padx=8)
