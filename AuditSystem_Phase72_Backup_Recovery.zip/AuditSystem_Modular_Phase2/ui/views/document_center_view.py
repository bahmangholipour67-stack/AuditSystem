"""Integrated document repository and document-request tracking tab."""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from repositories.document_repository import DocumentRepository
from repositories.document_request_repository import DocumentRequestRepository


class DocumentCenterViewMixin:
    def setup_document_center_tab(self):
        self.document_repository = DocumentRepository(self.db_path)
        self.document_request_repository = DocumentRequestRepository(self.db_path)
        root = ttk.Frame(self.tab_documents, padding=10)
        root.pack(fill="both", expand=True)
        ttk.Label(root, text="مرکز اسناد و پیگیری درخواست مدارک", font=("Tahoma", 14, "bold")).pack(anchor="e", pady=(0, 8))
        panes = ttk.Panedwindow(root, orient="vertical")
        panes.pack(fill="both", expand=True)
        docs = ttk.LabelFrame(panes, text="مخزن اسناد پرونده")
        reqs = ttk.LabelFrame(panes, text="درخواست‌های مدارک")
        panes.add(docs, weight=1); panes.add(reqs, weight=1)
        doc_bar = ttk.Frame(docs); doc_bar.pack(fill="x", padx=5, pady=4)
        ttk.Button(doc_bar, text="ثبت سند جدید", command=self.add_engagement_document).pack(side="right", padx=3)
        ttk.Button(doc_bar, text="اتصال به ریسک/کاربرگ/یافته/آزمون", command=self.link_engagement_document).pack(side="right", padx=3)
        ttk.Button(doc_bar, text="بایگانی سند", command=self.archive_engagement_document).pack(side="right", padx=3)
        ttk.Button(doc_bar, text="بازیابی فهرست", command=self.refresh_document_center).pack(side="left", padx=3)
        self.document_tree = ttk.Treeview(docs, columns=("id","title","category","file","size","created"), show="headings", height=5)
        for key, label, width in (("id","شناسه",55),("title","عنوان سند",230),("category","طبقه",100),("file","نام فایل",220),("size","حجم (بایت)",100),("created","تاریخ ثبت",140)):
            self.document_tree.heading(key,text=label); self.document_tree.column(key,width=width,anchor="e")
        self.document_tree.pack(fill="both",expand=True,padx=5,pady=4)
        req_bar = ttk.Frame(reqs); req_bar.pack(fill="x", padx=5, pady=4)
        ttk.Button(req_bar, text="درخواست جدید", command=self.add_document_request).pack(side="right", padx=3)
        ttk.Button(req_bar, text="تغییر وضعیت درخواست", command=self.advance_document_request).pack(side="right", padx=3)
        ttk.Button(req_bar, text="بایگانی درخواست", command=self.archive_document_request).pack(side="right", padx=3)
        self.document_request_tree = ttk.Treeview(reqs, columns=("id","title","from","due","priority","status"), show="headings", height=6)
        for key,label,width in (("id","شناسه",55),("title","عنوان درخواست",250),("from","درخواست‌شده از",150),("due","مهلت",100),("priority","اولویت",80),("status","وضعیت",120)):
            self.document_request_tree.heading(key,text=label); self.document_request_tree.column(key,width=width,anchor="e")
        self.document_request_tree.pack(fill="both",expand=True,padx=5,pady=4)
        self.document_center_status = ttk.Label(root,text="ابتدا پرونده موردنظر را انتخاب کنید.")
        self.document_center_status.pack(anchor="e",pady=4)

    def refresh_document_center(self):
        project_id = self.get_current_project_id()
        if not project_id:
            self.document_center_status.configure(text="ابتدا پرونده حسابرسی را انتخاب کنید."); return
        for tree in (self.document_tree,self.document_request_tree):
            for item in tree.get_children(): tree.delete(item)
        docs = self.document_repository.list_for_project(project_id)
        requests = self.document_request_repository.list_for_project(project_id)
        for row in docs:
            self.document_tree.insert("","end",iid=str(row["id"]),values=(row["id"],row["title"],row["category"],row["file_name"],row["size_bytes"],row["created_at"]))
        for row in requests:
            self.document_request_tree.insert("","end",iid=str(row["id"]),values=(row["id"],row["title"],row["requested_from"],row["due_date"],row["priority"],row["status"]))
        self.document_center_status.configure(text=f"اسناد فعال: {len(docs)} | درخواست‌های فعال: {len(requests)}")

    def add_engagement_document(self):
        project_id = self.get_current_project_id()
        if not project_id: messagebox.showwarning("مخزن اسناد","ابتدا پرونده را انتخاب کنید."); return
        path = filedialog.askopenfilename(title="انتخاب فایل مستند")
        if not path: return
        title = simpledialog.askstring("ثبت سند","عنوان سند را وارد کنید:",parent=self.root)
        if not title: return
        category = simpledialog.askstring("طبقه‌بندی سند","طبقه سند (مثلاً بانک، فروش، قرارداد):",initialvalue="عمومی",parent=self.root) or "عمومی"
        description = simpledialog.askstring("توضیحات سند","توضیحات (اختیاری):",parent=self.root) or ""
        try:
            self.document_repository.register(project_id,title,path,category,description,self.active_member_id)
            self.refresh_document_center()
            messagebox.showinfo("مخزن اسناد","سند با موفقیت در پرونده ثبت شد.")
        except Exception as exc: messagebox.showerror("ثبت سند",str(exc))

    def link_engagement_document(self):
        project_id=self.get_current_project_id(); selected=self.document_tree.selection()
        if not project_id or not selected:
            messagebox.showwarning("اتصال سند","ابتدا یک سند را انتخاب کنید."); return
        relation_type=simpledialog.askstring(
            "نوع ارتباط", "نوع مقصد را وارد کنید: risk / workpaper / finding / audit_test / audit_program", parent=self.root
        )
        if not relation_type: return
        relation_id=simpledialog.askinteger("شناسه مقصد","شناسه رکورد مقصد در همین پرونده:",parent=self.root,minvalue=1)
        if not relation_id: return
        try:
            created=self.document_repository.link(project_id,int(selected[0]),relation_type.strip(),relation_id)
            messagebox.showinfo("اتصال سند", "ارتباط سند ثبت شد." if created else "این ارتباط قبلاً ثبت شده بود.")
        except Exception as exc: messagebox.showerror("اتصال سند",str(exc))

    def archive_engagement_document(self):
        project_id=self.get_current_project_id(); selected=self.document_tree.selection()
        if not project_id or not selected: messagebox.showwarning("بایگانی سند","یک سند را انتخاب کنید."); return
        reason=simpledialog.askstring("علت بایگانی","علت بایگانی سند:",parent=self.root)
        if not reason: return
        try:
            self.document_repository.archive(project_id,int(selected[0]),reason,self.active_member_id)
            self.refresh_document_center()
        except Exception as exc: messagebox.showerror("بایگانی سند",str(exc))

    def add_document_request(self):
        project_id=self.get_current_project_id()
        if not project_id: messagebox.showwarning("درخواست مدرک","ابتدا پرونده را انتخاب کنید."); return
        title=simpledialog.askstring("درخواست مدرک","عنوان مدرک درخواستی:",parent=self.root)
        if not title: return
        requested_from=simpledialog.askstring("درخواست مدرک","مدرک از چه شخص/واحدی درخواست شده؟",parent=self.root) or ""
        due=simpledialog.askstring("مهلت درخواست","مهلت (مثلاً 1405/09/30):",parent=self.root) or ""
        priority=simpledialog.askstring("اولویت","اولویت: عادی، مهم یا فوری",initialvalue="عادی",parent=self.root) or "عادی"
        description=simpledialog.askstring("شرح درخواست","شرح تکمیلی:",parent=self.root) or ""
        try:
            self.document_request_repository.create(project_id,title,description,requested_from,due_date=due,priority=priority,created_by_member_id=self.active_member_id)
            self.refresh_document_center()
        except Exception as exc: messagebox.showerror("ثبت درخواست",str(exc))

    def advance_document_request(self):
        project_id=self.get_current_project_id(); selected=self.document_request_tree.selection()
        if not project_id or not selected: messagebox.showwarning("وضعیت درخواست","یک درخواست را انتخاب کنید."); return
        statuses=list(self.document_request_repository.STATUSES)
        status=simpledialog.askstring("تغییر وضعیت", "وضعیت جدید را دقیقاً وارد کنید:\n"+"، ".join(statuses),parent=self.root)
        if not status: return
        note=simpledialog.askstring("یادداشت تغییر وضعیت","توضیح تغییر (اختیاری):",parent=self.root) or ""
        try:
            self.document_request_repository.update_status(project_id,int(selected[0]),status,self.active_member_id,note)
            self.refresh_document_center()
        except Exception as exc: messagebox.showerror("تغییر وضعیت",str(exc))

    def archive_document_request(self):
        project_id=self.get_current_project_id(); selected=self.document_request_tree.selection()
        if not project_id or not selected: messagebox.showwarning("بایگانی درخواست","یک درخواست را انتخاب کنید."); return
        reason=simpledialog.askstring("علت بایگانی","علت بایگانی درخواست:",parent=self.root)
        if not reason: return
        try:
            self.document_request_repository.archive(project_id,int(selected[0]),reason,self.active_member_id)
            self.refresh_document_center()
        except Exception as exc: messagebox.showerror("بایگانی درخواست",str(exc))
