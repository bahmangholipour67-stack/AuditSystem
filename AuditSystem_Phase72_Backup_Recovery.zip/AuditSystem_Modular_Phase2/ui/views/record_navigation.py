"""Reusable record navigation controls for Treeview-backed screens."""
from tkinter import ttk


class RecordNavigationMixin:
    def add_record_navigation(self, parent, tree, *, on_edit=None, on_delete=None, label="رکورد"):
        bar = ttk.Frame(parent)
        bar.pack(fill="x", padx=10, pady=(2, 6))
        state = {"label": None}

        def rows():
            return list(tree.get_children(""))

        def update_label():
            items = rows()
            selected = tree.selection()
            if not items:
                state["label"].config(text=f"{label}: ۰ از ۰")
                return
            index = items.index(selected[0]) + 1 if selected and selected[0] in items else 0
            state["label"].config(text=f"{label}: {index} از {len(items)}")

        def select_at(index):
            items = rows()
            if not items:
                update_label()
                return
            index = max(0, min(index, len(items) - 1))
            item = items[index]
            tree.selection_set(item)
            tree.focus(item)
            tree.see(item)
            tree.event_generate("<<TreeviewSelect>>")
            update_label()

        def move(delta):
            items = rows()
            if not items:
                return
            selected = tree.selection()
            current = items.index(selected[0]) if selected and selected[0] in items else 0
            select_at(current + delta)

        ttk.Button(bar, text="اولین", command=lambda: select_at(0)).pack(side="right", padx=2)
        ttk.Button(bar, text="قبلی", command=lambda: move(-1)).pack(side="right", padx=2)
        ttk.Button(bar, text="بعدی", command=lambda: move(1)).pack(side="right", padx=2)
        ttk.Button(bar, text="آخرین", command=lambda: select_at(len(rows()) - 1)).pack(side="right", padx=2)
        if on_edit:
            ttk.Button(bar, text="ویرایش رکورد انتخاب‌شده", command=on_edit).pack(side="left", padx=2)
        if on_delete:
            ttk.Button(bar, text="حذف رکورد انتخاب‌شده", command=on_delete).pack(side="left", padx=2)
        state["label"] = ttk.Label(bar, text=f"{label}: ۰ از ۰")
        state["label"].pack(side="left", padx=10)
        tree.bind("<<TreeviewSelect>>", lambda event: update_label(), add="+")
        tree.bind("<ButtonRelease-1>", lambda event: update_label(), add="+")
        tree._record_navigation_refresh = update_label
        update_label()
        return bar

    @staticmethod
    def restore_tree_selection(tree, record_id):
        if record_id is None:
            return
        for item in tree.get_children(""):
            values = tree.item(item, "values")
            if values and str(values[0]) == str(record_id):
                tree.selection_set(item)
                tree.focus(item)
                tree.see(item)
                tree.event_generate("<<TreeviewSelect>>")
                refresh = getattr(tree, "_record_navigation_refresh", None)
                if refresh:
                    refresh()
                return
