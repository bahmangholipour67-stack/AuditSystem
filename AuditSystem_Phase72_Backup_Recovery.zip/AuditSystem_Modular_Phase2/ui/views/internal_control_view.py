"""Desktop workspace for internal controls and corrective actions."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from services.internal_control_service import InternalControlService


class InternalControlViewMixin:
    def setup_internal_control_tab(self):
        self.internal_control_service = InternalControlService(self.db_path)
        root = ttk.Frame(self.tab_internal_controls, padding=10)
        root.pack(fill="both", expand=True)
        bar = ttk.Frame(root); bar.pack(fill="x", pady=(0, 8))
        ttk.Label(bar, text="مدیریت کنترل‌های داخلی، آزمون‌ها و اقدامات اصلاحی", font=("Tahoma", 13, "bold")).pack(side="right")
        for label, command in [("کنترل جدید", self.add_internal_control), ("ثبت آزمون", self.add_control_test), ("ثبت یافته", self.add_control_finding), ("برنامه اقدام", self.add_corrective_action), ("تازه‌سازی", self.refresh_internal_controls)]:
            ttk.Button(bar, text=label, command=command).pack(side="left", padx=3)
        ttk.Label(root, text="کنترل‌ها", font=("Tahoma", 10, "bold")).pack(anchor="e")
        cols=("id","title","risk_id","owner","type","method","frequency")
        self.internal_control_tree=ttk.Treeview(root,columns=cols,show="headings",height=8)
        heads={"id":"شناسه","title":"عنوان کنترل","risk_id":"ریسک","owner":"مالک کنترل","type":"نوع","method":"روش","frequency":"تناوب"}
        widths={"id":55,"title":260,"risk_id":60,"owner":150,"type":100,"method":80,"frequency":100}
        for c in cols:
            self.internal_control_tree.heading(c,text=heads[c]); self.internal_control_tree.column(c,width=widths[c],anchor="e")
        self.internal_control_tree.pack(fill="x",expand=False,pady=5)
        ttk.Label(root,text="یافته‌های کنترل داخلی",font=("Tahoma",10,"bold")).pack(anchor="e",pady=(8,0))
        fcols=("id","title","severity","status","owner","likelihood","impact")
        self.internal_finding_tree=ttk.Treeview(root,columns=fcols,show="headings",height=8)
        fheads={"id":"شناسه","title":"یافته","severity":"اهمیت","status":"وضعیت","owner":"مسئول","likelihood":"احتمال","impact":"اثر"}
        for c in fcols:
            self.internal_finding_tree.heading(c,text=fheads[c]); self.internal_finding_tree.column(c,width=130 if c=="title" else 85,anchor="e")
        self.internal_finding_tree.pack(fill="both",expand=True,pady=5)
        ttk.Label(root,text="بستن یافته فقط پس از ثبت اقدام اصلاحی، مستند رفع و آزمون پیگیری موفق امکان‌پذیر است.",wraplength=1100).pack(fill="x",pady=4)
        actions=ttk.Frame(root); actions.pack(fill="x",pady=4)
        ttk.Button(actions,text="ثبت نتیجه پیگیری اقدام",command=self.verify_internal_action).pack(side="right",padx=3)
        ttk.Button(actions,text="بستن یافته انتخاب‌شده",command=self.close_internal_finding).pack(side="right",padx=3)
        self.refresh_internal_controls()

    def _internal_project(self):
        pid=self.get_current_project_id()
        if not pid: messagebox.showwarning("پرونده","ابتدا پرونده حسابرسی را انتخاب کنید."); return None
        return pid

    def _selected_control_id(self):
        sel=self.internal_control_tree.selection()
        if not sel: messagebox.showwarning("کنترل","ابتدا یک کنترل را انتخاب کنید."); return None
        return int(sel[0])

    def _selected_finding_id(self):
        sel=self.internal_finding_tree.selection()
        if not sel: messagebox.showwarning("یافته","ابتدا یک یافته را انتخاب کنید."); return None
        return int(sel[0])

    def add_internal_control(self):
        pid=self._internal_project();
        if not pid:return
        title=simpledialog.askstring("کنترل جدید","عنوان کنترل:",parent=self.root)
        if not title:return
        objective=simpledialog.askstring("هدف کنترل","هدف کنترل:",parent=self.root) or ""
        owner=simpledialog.askstring("مالک کنترل","مسئول کنترل:",parent=self.root) or ""
        risk=simpledialog.askstring("ریسک مرتبط","شناسه ریسک (اختیاری):",parent=self.root) or ""
        try:
            self.internal_control_service.create_control(pid,title,objective,int(risk) if risk.strip() else None,owner)
            self.refresh_internal_controls()
        except Exception as e: messagebox.showerror("ثبت کنترل",str(e))

    def add_control_test(self):
        pid=self._internal_project(); cid=self._selected_control_id()
        if not pid or cid is None:return
        stage=simpledialog.askstring("مرحله آزمون","مرحله: طراحی / پیاده‌سازی / اثربخشی عملیاتی",parent=self.root)
        result=simpledialog.askstring("نتیجه آزمون","نتیجه: موثر / دارای نقص / ناموثر / آزمون‌نشده",parent=self.root)
        if not stage or not result:return
        sample=simpledialog.askinteger("حجم نمونه","حجم نمونه:",parent=self.root,initialvalue=0,minvalue=0)
        exc=simpledialog.askinteger("استثناها","تعداد استثنا:",parent=self.root,initialvalue=0,minvalue=0)
        evidence=simpledialog.askstring("شواهد","شرح یا ارجاع شواهد:",parent=self.root) or ""
        try:self.internal_control_service.record_control_test(pid,cid,stage,result,sample or 0,exc or 0,evidence); messagebox.showinfo("آزمون","آزمون ثبت شد.")
        except Exception as e:messagebox.showerror("ثبت آزمون",str(e))

    def add_control_finding(self):
        pid=self._internal_project(); cid=self._selected_control_id()
        if not pid or cid is None:return
        title=simpledialog.askstring("یافته","عنوان یافته:",parent=self.root)
        condition=simpledialog.askstring("شرط","وضعیت مشاهده‌شده:",parent=self.root)
        criteria=simpledialog.askstring("معیار","معیار مورد انتظار:",parent=self.root)
        if not title or not condition or not criteria:return
        cause=simpledialog.askstring("علت","علت:",parent=self.root) or ""
        effect=simpledialog.askstring("اثر","اثر یا پیامد:",parent=self.root) or ""
        try:self.internal_control_service.create_control_finding(pid,cid,title,condition,criteria,cause,effect); self.refresh_internal_controls()
        except Exception as e:messagebox.showerror("ثبت یافته",str(e))

    def add_corrective_action(self):
        pid=self._internal_project(); fid=self._selected_finding_id()
        if not pid or fid is None:return
        title=simpledialog.askstring("اقدام اصلاحی","شرح اقدام:",parent=self.root)
        owner=simpledialog.askstring("مسئول","مسئول اقدام:",parent=self.root)
        due=simpledialog.askstring("سررسید","سررسید (مثلاً 1405/12/29):",parent=self.root)
        if not title or not owner or not due:return
        try:
            self.internal_control_service.create_action(pid,fid,title,owner,due)
            messagebox.showinfo("اقدام اصلاحی","اقدام ثبت شد. پس از اجرا، از طریق ثبت وضعیت اقدام و مستند پیگیری، تأیید آن انجام می‌شود.")
        except Exception as e:messagebox.showerror("ثبت اقدام",str(e))

    def verify_internal_action(self):
        pid=self._internal_project(); fid=self._selected_finding_id()
        if not pid or fid is None:return
        actions=self.internal_control_service.list_actions(pid,fid)
        if not actions: messagebox.showwarning("اقدام","برای این یافته هنوز اقدام اصلاحی ثبت نشده است."); return
        choices=[f"{a['id']} | {a['title']} | {a['status']}" for a in actions]
        choice=simpledialog.askstring("انتخاب اقدام","شناسه اقدام را وارد کنید:\n"+"\n".join(choices),parent=self.root)
        if not choice:return
        evidence=simpledialog.askstring("مستند رفع","شرح یا شناسه مستند رفع:",parent=self.root)
        if not evidence:return
        note=simpledialog.askstring("نتیجه پیگیری","شرح آزمون پیگیری:",parent=self.root) or ""
        try:
            self.internal_control_service.update_action(pid,int(choice),"تأییدشده",note,evidence,"موفق")
            messagebox.showinfo("پیگیری","اقدام اصلاحی با ثبت مستند و نتیجه موفق تأیید شد.")
        except Exception as e:messagebox.showerror("تأیید اقدام",str(e))

    def close_internal_finding(self):
        pid=self._internal_project(); fid=self._selected_finding_id()
        if not pid or fid is None:return
        reviewer=simpledialog.askstring("بازبین","نام بازبین:",parent=self.root) or ""
        comment=simpledialog.askstring("توضیح بستن","توضیح بررسی شواهد:",parent=self.root) or ""
        try:
            self.internal_control_service.close_finding(pid,fid,reviewer,comment)
            self.refresh_internal_controls()
            messagebox.showinfo("یافته","یافته پس از بررسی اقدامات اصلاحی و شواهد پیگیری بسته شد.")
        except Exception as e:messagebox.showerror("بستن یافته",str(e))

    def refresh_internal_controls(self):
        if not hasattr(self,"internal_control_tree"):return
        pid=self.get_current_project_id()
        for tree in (self.internal_control_tree,self.internal_finding_tree):
            for item in tree.get_children():tree.delete(item)
        if not pid:return
        try:
            for x in self.internal_control_service.list_controls(pid):
                self.internal_control_tree.insert("","end",iid=str(x["id"]),values=(x["id"],x["title"],x["risk_id"] or "—",x["owner"],x["control_type"],x["method"],x["frequency"]))
            for x in self.internal_control_service.list_findings(pid):
                self.internal_finding_tree.insert("","end",iid=str(x["id"]),values=(x["id"],x["title"],x["severity"],x["status"],x["owner"],x["likelihood"],x["impact"]))
        except Exception as e:messagebox.showerror("بارگذاری کنترل‌ها",str(e))
