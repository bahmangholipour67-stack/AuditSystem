
import tkinter as tk
from tkinter import ttk, messagebox


class WorkpaperViewMixin:

    WORKFLOW_STATUSES = [
        "پیش‌نویس",
        "در انتظار بررسی مدیر",
        "تأیید سرپرست",
        "نیازمند اصلاح",
        "نهایی و تأیید",
    ]

    def setup_workpaper_tab(self):
        form = ttk.LabelFrame(
            self.tab_workpapers,
            text="ثبت کاربرگ"
        )
        form.pack(fill="x", padx=10, pady=8)

        ttk.Label(form, text="سرفصل:").grid(
            row=0, column=0, padx=5, pady=8
        )
        self.ent_wp_title = ttk.Entry(form, width=30)
        self.ent_wp_title.grid(row=0, column=1, padx=5)

        ttk.Label(form, text="روش رسیدگی:").grid(
            row=0, column=2, padx=5
        )
        self.ent_wp_proc = ttk.Entry(form, width=38)
        self.ent_wp_proc.grid(row=0, column=3, padx=5)

        ttk.Label(form, text="نتیجه:").grid(
            row=1, column=0, padx=5, pady=8
        )
        self.ent_wp_res = ttk.Entry(form, width=30)
        self.ent_wp_res.grid(row=1, column=1, padx=5)

        ttk.Label(form, text="وضعیت اولیه:").grid(
            row=1, column=2, padx=5
        )
        self.combo_wp_status = ttk.Combobox(
            form,
            values=["پیش‌نویس"],
            state="readonly",
            width=22
        )
        self.combo_wp_status.current(0)
        self.combo_wp_status.grid(
            row=1, column=3, sticky="w", padx=5
        )

        ttk.Label(form, text="ریسک مرتبط:").grid(
            row=2, column=0, padx=5, pady=7
        )
        self.combo_wp_risk = ttk.Combobox(
            form, state="readonly", width=48
        )
        self.combo_wp_risk.grid(
            row=2, column=1, columnspan=2, sticky="ew", padx=5, pady=7
        )

        ttk.Button(
            form,
            text="ثبت کاربرگ",
            command=self.add_workpaper
        ).grid(row=2, column=3, sticky="e", padx=5, pady=8)

        assignment = ttk.LabelFrame(
            self.tab_workpapers,
            text="تخصیص مسئول و بررسی‌کننده"
        )
        assignment.pack(fill="x", padx=10, pady=5)

        ttk.Label(
            assignment,
            text="حسابرس مسئول:"
        ).grid(row=0, column=0, padx=5, pady=7)

        self.combo_wp_assignee = ttk.Combobox(
            assignment,
            state="readonly",
            width=30
        )
        self.combo_wp_assignee.grid(
            row=0, column=1, padx=5, pady=7
        )

        ttk.Label(
            assignment,
            text="سرپرست بررسی‌کننده:"
        ).grid(row=0, column=2, padx=5, pady=7)

        self.combo_wp_reviewer = ttk.Combobox(
            assignment,
            state="readonly",
            width=30
        )
        self.combo_wp_reviewer.grid(
            row=0, column=3, padx=5, pady=7
        )

        ttk.Button(
            assignment,
            text="ثبت تخصیص",
            command=self.assign_workpaper
        ).grid(row=0, column=4, padx=8)

        ttk.Button(
            assignment,
            text="ثبت ریسک مرتبط",
            command=self.link_selected_workpaper_risk
        ).grid(row=0, column=5, padx=8)

        workflow = ttk.LabelFrame(
            self.tab_workpapers,
            text="گردش بررسی و تأیید کاربرگ"
        )
        workflow.pack(fill="x", padx=10, pady=5)

        ttk.Label(
            workflow,
            text="عضو فعال:"
        ).grid(row=0, column=0, padx=5, pady=7)

        self.lbl_wp_actor = ttk.Label(
            workflow, text="ابتدا عضو فعال را از نوار بالای برنامه انتخاب کنید.",
            width=42
        )
        self.lbl_wp_actor.grid(
            row=0, column=1, padx=5, pady=7, sticky="w"
        )

        ttk.Label(
            workflow,
            text="توضیحات:"
        ).grid(row=0, column=2, padx=5)

        self.ent_wp_notes = ttk.Entry(
            workflow,
            width=38
        )
        self.ent_wp_notes.grid(
            row=0, column=3, padx=5
        )

        buttons = ttk.Frame(workflow)
        buttons.grid(
            row=1, column=0, columnspan=4,
            sticky="e", padx=5, pady=7
        )

        ttk.Button(
            buttons,
            text="ارسال برای بررسی",
            command=lambda: self.change_workpaper_status(
                "در انتظار بررسی مدیر"
            )
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="تأیید سرپرست",
            command=lambda: self.change_workpaper_status(
                "تأیید سرپرست"
            )
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="نیازمند اصلاح",
            command=lambda: self.change_workpaper_status(
                "نیازمند اصلاح"
            )
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="تأیید نهایی",
            command=lambda: self.change_workpaper_status(
                "نهایی و تأیید"
            )
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="مشاهده تاریخچه",
            command=self.show_workpaper_history
        ).pack(side="right", padx=4)

        self.tree_wps = self.make_tree(
            self.tab_workpapers,
            [
                ("id", "شناسه", 55),
                ("title", "سرفصل", 180),
                ("procedure", "روش رسیدگی", 220),
                ("result", "نتیجه", 180),
                ("status", "وضعیت", 145),
                ("assignee", "حسابرس مسئول", 140),
                ("reviewer", "بررسی‌کننده", 140),
                ("risk", "ریسک مرتبط", 180),
            ],
        )

        self.add_record_navigation(self.tab_workpapers, self.tree_wps, on_edit=self.edit_selected_workpaper, on_delete=self.delete_selected_workpaper, label="کاربرگ")

        self.tree_wps.bind(
            "<<TreeviewSelect>>",
            self.on_workpaper_selected
        )

        self._wp_rows = {}
        self._wp_members = {}
        self._wp_member_labels = {}
        self._wp_risk_labels = {}

        self.refresh_workpapers()


    def edit_selected_workpaper(self):
        selected = self.tree_wps.selection()
        if not selected:
            messagebox.showinfo("انتخاب کاربرگ", "ابتدا یک کاربرگ را انتخاب کنید."); return
        values = self.tree_wps.item(selected[0], "values")
        if str(values[4]) not in ("پیش‌نویس", "نیازمند اصلاح"):
            messagebox.showwarning("ویرایش محدود", "ویرایش محتوا فقط برای کاربرگ پیش‌نویس یا نیازمند اصلاح مجاز است."); return
        project_id = self.get_current_project_id()
        rows = self.services.workpapers.for_project(project_id) if project_id else []
        workpaper = next((r for r in rows if int(r[0]) == int(values[0])), None)
        if not workpaper: return
        win = tk.Toplevel(self.root); win.title("ویرایش کاربرگ"); win.geometry("540x250"); win.transient(self.root); win.grab_set()
        self._style_dialog(win)
        labels = ("سرفصل", "روش رسیدگی", "نتیجه")
        entries = []
        for i, (label, value) in enumerate(zip(labels, workpaper[1:4])):
            ttk.Label(win, text=label).grid(row=i, column=1, padx=8, pady=8, sticky="e")
            ent = ttk.Entry(win, width=45); ent.grid(row=i, column=0, padx=8, pady=8); ent.insert(0, value or ""); entries.append(ent)
        def save():
            try:
                self.services.workpapers.update_content(project_id, int(workpaper[0]), entries[0].get(), entries[1].get(), entries[2].get())
                win.destroy(); self.refresh_workpapers(); self.restore_tree_selection(self.tree_wps, workpaper[0])
                if hasattr(self, "refresh_dashboard"): self.refresh_dashboard()
            except Exception as exc: messagebox.showerror("خطا در ویرایش", str(exc), parent=win)
        ttk.Button(win, text="ذخیره تغییرات", command=save).grid(row=3, column=0, pady=10)

    def add_workpaper(self):
        pid = self.get_current_project_id()
        title = self.ent_wp_title.get().strip()

        if not pid or not title:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "ابتدا پرونده را انتخاب کنید و سرفصل کاربرگ را وارد کنید."
            )
            return

        try:
            risk_id = self._wp_risk_labels.get(self.combo_wp_risk.get())
            self.services.workpapers.create(
                pid,
                title,
                self.ent_wp_proc.get().strip(),
                self.ent_wp_res.get().strip(),
                "پیش‌نویس",
                risk_id=risk_id,
            )

            for entry in (
                self.ent_wp_title,
                self.ent_wp_proc,
                self.ent_wp_res
            ):
                entry.delete(0, "end")

            self.refresh_workpapers()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()

            messagebox.showinfo(
                "ثبت موفق",
                "کاربرگ با وضعیت پیش‌نویس ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_workpapers(self):
        if not hasattr(self, "tree_wps"):
            return

        self.clear_tree(self.tree_wps)
        nav_refresh = getattr(self.tree_wps, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()
        self._wp_rows = {}

        pid = self.get_current_project_id()

        if not pid:
            self._refresh_workpaper_members([])
            self._wp_risk_labels = {}
            self._wp_risk_by_id = {}
            self.combo_wp_risk["values"] = ["بدون ریسک مرتبط"]
            self.combo_wp_risk.set("بدون ریسک مرتبط")
            return

        members = self.services.team.for_project(
            pid,
            active_only=True
        )

        self._refresh_workpaper_members(members)
        self._refresh_workpaper_risks(pid)

        rows = self.services.workpapers.for_project_detailed(pid)

        for row in rows:
            (
                wp_id,
                title,
                procedure,
                result,
                status,
                assigned_id,
                assigned_name,
                reviewer_id,
                reviewer_name,
                approved_by,
                reviewed_at,
                approved_at,
                risk_id,
                risk_title
            ) = row

            self._wp_rows[wp_id] = row

            self.tree_wps.insert(
                "",
                "end",
                values=(
                    wp_id,
                    title or "",
                    procedure or "",
                    result or "",
                    status or "",
                    assigned_name or "تعیین نشده",
                    reviewer_name or "تعیین نشده",
                    risk_title or "بدون ریسک مرتبط"
                )
            )

        nav_refresh = getattr(self.tree_wps, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()

    def _refresh_workpaper_members(self, members):
        self._wp_members = {}
        self._wp_member_labels = {}

        options = []

        for member in members:
            member_id, name, role = member[0], member[1], member[2]

            label = f"{name} - {role} (#{member_id})"

            options.append(label)
            self._wp_members[member_id] = label
            self._wp_member_labels[label] = member_id

        for combo in (
            self.combo_wp_assignee,
            self.combo_wp_reviewer
        ):
            combo["values"] = [""] + options

            if combo.get() not in combo["values"]:
                combo.set("")

    def on_workpaper_selected(self, event=None):
        selected = self.tree_wps.selection()

        if not selected:
            return

        values = self.tree_wps.item(
            selected[0],
            "values"
        )

        if not values:
            return

        wp_id = int(values[0])
        row = self._wp_rows.get(wp_id)

        if not row:
            return

        assigned_id = row[5]
        reviewer_id = row[7]
        risk_id = row[12]

        self.combo_wp_assignee.set(
            self._wp_members.get(assigned_id, "")
        )

        self.combo_wp_reviewer.set(
            self._wp_members.get(reviewer_id, "")
        )
        self.combo_wp_risk.set(self._wp_risk_by_id.get(risk_id, "بدون ریسک مرتبط"))

    def _refresh_workpaper_risks(self, project_id):
        self._wp_risk_labels = {}
        self._wp_risk_by_id = {}
        options = ["بدون ریسک مرتبط"]
        for risk in self.services.risks.for_project(project_id):
            risk_id, title, score, _control = risk
            label = f"{title} (امتیاز {score}) - #{risk_id}"
            options.append(label)
            self._wp_risk_labels[label] = risk_id
            self._wp_risk_by_id[risk_id] = label
        self.combo_wp_risk["values"] = options
        if self.combo_wp_risk.get() not in options:
            self.combo_wp_risk.set(options[0])

    def _selected_workpaper_id(self):
        selected = self.tree_wps.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب کاربرگ",
                "ابتدا یک کاربرگ را از جدول انتخاب کنید."
            )
            return None

        values = self.tree_wps.item(
            selected[0],
            "values"
        )

        return int(values[0])

    def link_selected_workpaper_risk(self):
        project_id = self.get_current_project_id()
        workpaper_id = self._selected_workpaper_id()
        if not project_id or not workpaper_id:
            return
        risk_id = self._wp_risk_labels.get(self.combo_wp_risk.get())
        try:
            self.services.workpapers.link_risk(
                project_id, workpaper_id, risk_id
            )
            self.refresh_workpapers()
            if hasattr(self, "refresh_findings"):
                self.refresh_findings()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
            messagebox.showinfo(
                "ارتباط ریسک",
                "ارتباط ریسک و کاربرگ با موفقیت به‌روزرسانی شد."
            )
        except Exception as exc:
            messagebox.showerror("خطا در ارتباط ریسک", str(exc))

    def assign_workpaper(self):
        pid = self.get_current_project_id()
        wp_id = self._selected_workpaper_id()

        if not pid or not wp_id:
            return

        assignee = self._wp_member_labels.get(
            self.combo_wp_assignee.get()
        )

        reviewer = self._wp_member_labels.get(
            self.combo_wp_reviewer.get()
        )

        if not assignee:
            messagebox.showwarning(
                "تخصیص ناقص",
                "حسابرس مسئول را انتخاب کنید."
            )
            return

        if not reviewer:
            messagebox.showwarning(
                "تخصیص ناقص",
                "سرپرست بررسی‌کننده را انتخاب کنید."
            )
            return

        if assignee == reviewer:
            messagebox.showwarning(
                "تخصیص نامعتبر",
                "حسابرس مسئول و بررسی‌کننده نباید یک نفر باشند."
            )
            return

        try:
            self.services.workpapers.update_assignment(
                pid,
                wp_id,
                assignee,
                reviewer
            )

            self.refresh_workpapers()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()

            messagebox.showinfo(
                "تخصیص موفق",
                "مسئول و بررسی‌کننده کاربرگ ثبت شدند."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def change_workpaper_status(self, new_status):
        pid = self.get_current_project_id()
        wp_id = self._selected_workpaper_id()

        if not pid or not wp_id:
            return

        row = self._wp_rows.get(wp_id)

        if not row:
            return

        if new_status == "در انتظار بررسی مدیر":
            if not row[5] or not row[7]:
                messagebox.showwarning(
                    "تخصیص ناقص",
                    "ابتدا حسابرس مسئول و سرپرست بررسی‌کننده را تعیین کنید."
                )
                return

        if new_status == "نهایی و تأیید":
            if not row[7]:
                messagebox.showwarning(
                    "بررسی‌کننده مشخص نیست",
                    "برای تأیید نهایی باید سرپرست بررسی‌کننده تعیین شده باشد."
                )
                return

        active_member = self.get_active_member()
        actor_id = active_member["id"] if active_member else None

        if hasattr(self, "lbl_wp_actor"):
            self.lbl_wp_actor.config(
                text=(
                    f"{active_member['full_name']} - {active_member['role']}"
                    if active_member else "عضو فعال انتخاب نشده است."
                )
            )

        notes = self.ent_wp_notes.get().strip()

        if not actor_id:
            messagebox.showwarning(
                "عضو فعال",
                "برای انجام این عملیات ابتدا عضو فعال را از نوار بالای برنامه انتخاب کنید."
            )
            return

        try:
            self.services.workpapers.update_workflow(
                pid,
                wp_id,
                new_status,
                actor_id,
                notes
            )

            self.ent_wp_notes.delete(0, "end")
            self.refresh_workpapers()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()

            messagebox.showinfo(
                "ثبت گردش کار",
                f"وضعیت کاربرگ به «{new_status}» تغییر کرد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def show_workpaper_history(self):
        wp_id = self._selected_workpaper_id()

        if not wp_id:
            return

        try:
            history = self.services.workpapers.history(wp_id)

            window = tk.Toplevel(self.tab_workpapers)

            self._style_dialog(window)
            window.title("تاریخچه کاربرگ")
            window.geometry("950x400")

            columns = (
                "id",
                "action",
                "previous",
                "new",
                "actor",
                "notes",
                "date"
            )

            tree = ttk.Treeview(
                window,
                columns=columns,
                show="headings"
            )

            headings = {
                "id": "شناسه",
                "action": "عملیات",
                "previous": "وضعیت قبلی",
                "new": "وضعیت جدید",
                "actor": "ثبت‌کننده",
                "notes": "توضیحات",
                "date": "تاریخ"
            }

            widths = {
                "id": 55,
                "action": 100,
                "previous": 130,
                "new": 130,
                "actor": 120,
                "notes": 200,
                "date": 160
            }

            for col in columns:
                tree.heading(col, text=headings[col])
                tree.column(
                    col,
                    width=widths[col],
                    anchor="center"
                )

            scrollbar = ttk.Scrollbar(
                window,
                orient="vertical",
                command=tree.yview
            )
            tree.configure(yscrollcommand=scrollbar.set)

            tree.pack(
                side="left",
                fill="both",
                expand=True,
                padx=8,
                pady=8
            )

            scrollbar.pack(
                side="right",
                fill="y",
                pady=8
            )

            for item in history:
                tree.insert(
                    "",
                    "end",
                    values=tuple(
                        value if value is not None else ""
                        for value in item
                    )
                )

            if not history:
                messagebox.showinfo(
                    "تاریخچه",
                    "برای این کاربرگ هنوز سابقه‌ای ثبت نشده است."
                )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def delete_selected_workpaper(self):
        selected = self.tree_wps.selection()
        if not selected:
            messagebox.showinfo("انتخاب کاربرگ", "ابتدا یک کاربرگ را انتخاب کنید.")
            return
        vals = self.tree_wps.item(selected[0], "values")
        pid = self.get_current_project_id()
        if not pid:
            return
        if not messagebox.askyesno("تأیید حذف کاربرگ", "فقط کاربرگ پیش‌نویسِ بدون سابقه و ارتباط قابل حذف است. آیا ادامه می‌دهید؟"):
            return
        try:
            self.services.workpapers.delete(pid, int(vals[0]))
            self.refresh_workpapers()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()
            messagebox.showinfo("حذف کاربرگ", "کاربرگ پیش‌نویس حذف شد.")
        except ValueError as exc:
            messagebox.showwarning("حذف کاربرگ ممکن نیست", str(exc))
        except Exception as exc:
            messagebox.showerror("خطا در حذف کاربرگ", str(exc))
