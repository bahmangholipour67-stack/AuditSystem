"""Misstatement register and materiality evaluation UI."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from repositories.misstatement_repository import MisstatementRepository


class MisstatementViewMixin:
    def setup_misstatement_tab(self):
        self.misstatement_repository = MisstatementRepository(self.db_path)
        root = ttk.Frame(self.tab_misstatements, padding=10)
        root.pack(fill="both", expand=True)
        ttk.Label(root, text="مدیریت تحریفات و ارزیابی اهمیت", font=("Tahoma", 14, "bold")).pack(anchor="e", pady=(0, 8))
        bar = ttk.Frame(root); bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="تعریف سطوح اهمیت", command=self.configure_misstatement_materiality).pack(side="right", padx=3)
        ttk.Button(bar, text="ثبت تحریف", command=self.add_misstatement).pack(side="right", padx=3)
        ttk.Button(bar, text="تغییر وضعیت", command=self.change_misstatement_status).pack(side="right", padx=3)
        ttk.Button(bar, text="بایگانی تحریف", command=self.archive_misstatement).pack(side="right", padx=3)
        ttk.Button(bar, text="ارزیابی مجدد", command=self.refresh_misstatements).pack(side="left", padx=3)
        self.misstatement_tree = ttk.Treeview(root, columns=("id","title","type","account","amount","status","source"), show="headings", height=13)
        for key,label,width in (("id","شناسه",55),("title","شرح تحریف",220),("type","نوع",90),("account","حساب",130),("amount","مبلغ",120),("status","وضعیت",110),("source","منشأ",130)):
            self.misstatement_tree.heading(key,text=label); self.misstatement_tree.column(key,width=width,anchor="e")
        self.misstatement_tree.pack(fill="both",expand=True,padx=4,pady=5)
        self.misstatement_summary = ttk.Label(root, text="ابتدا پرونده را انتخاب کنید.", justify="right", anchor="e")
        self.misstatement_summary.pack(fill="x", pady=6)

    def refresh_misstatements(self):
        project_id = self.get_current_project_id()
        if not project_id or not hasattr(self, "misstatement_tree"):
            return
        for item in self.misstatement_tree.get_children(): self.misstatement_tree.delete(item)
        rows = self.misstatement_repository.list_for_project(project_id)
        for row in rows:
            self.misstatement_tree.insert("", "end", iid=str(row["id"]), values=(row["id"],row["title"],row["misstatement_type"],row["account_name"],f'{float(row["amount"] or 0):,.2f}',row["status"],row["source"]))
        result = self.misstatement_repository.evaluate(project_id)
        mat = result["materiality"]
        if not mat:
            self.misstatement_summary.configure(text=f"تحریف‌های فعال: {len(rows)} | سطوح اهمیت هنوز تعریف نشده است.")
            return
        state = "از اهمیت کلی عبور کرده" if result["overall_materiality_exceeded"] else "کمتر از اهمیت کلی"
        self.misstatement_summary.configure(text=(
            f'اهمیت کلی: {mat["overall_materiality"]:,.2f} | اهمیت عملکردی: {mat["performance_materiality"]:,.2f} | '
            f'حد آستانه ناچیز: {mat["clearly_trivial"]:,.2f}\n'
            f'تحریف اصلاح‌نشده/مورد اختلاف: {result["uncorrected_count"]} مورد | جمع ناخالص: {result["uncorrected_total"]:,.2f} | '
            f'تحریف اصلاح‌شده: {result["corrected_count"]} مورد | نتیجه مقایسه: {state}\n'
            f'واقعی: {result["uncorrected_by_type"]["واقعی"]:,.2f} | قضاوتی: {result["uncorrected_by_type"]["قضاوتی"]:,.2f} | '
            f'برآوردی: {result["uncorrected_by_type"]["برآوردی"]:,.2f}\n'
            'توجه: این مقایسه به‌تنهایی مبنای تعیین نوع اظهارنظر نیست؛ تهاتر بین حساب‌ها انجام نشده است.'
        ))

    def configure_misstatement_materiality(self):
        project_id = self.get_current_project_id()
        if not project_id: messagebox.showwarning("اهمیت", "ابتدا پرونده را انتخاب کنید."); return
        current = self.misstatement_repository.get_materiality(project_id) or {}
        def ask(label, key):
            return simpledialog.askfloat("تعیین اهمیت", label, parent=self.root, initialvalue=current.get(key), minvalue=0.0)
        overall = ask("اهمیت کلی:", "overall_materiality")
        if overall is None: return
        performance = ask("اهمیت عملکردی:", "performance_materiality")
        if performance is None: return
        trivial = ask("حد آستانه اقلام ناچیز:", "clearly_trivial")
        if trivial is None: return
        basis = simpledialog.askstring("مبنای اهمیت", "مبنای تعیین اهمیت (مثلاً سود قبل از مالیات، درآمد یا دارایی):", parent=self.root) or ""
        try:
            self.misstatement_repository.set_materiality(project_id,overall,performance,trivial,basis,self.active_member_id)
            self.refresh_misstatements(); messagebox.showinfo("اهمیت", "سطوح اهمیت ذخیره شد.")
        except Exception as exc: messagebox.showerror("تعیین اهمیت",str(exc))

    def add_misstatement(self):
        project_id = self.get_current_project_id()
        if not project_id: messagebox.showwarning("ثبت تحریف", "ابتدا پرونده را انتخاب کنید."); return
        title = simpledialog.askstring("ثبت تحریف", "شرح یا عنوان تحریف:", parent=self.root)
        if not title: return
        kind = simpledialog.askstring("نوع تحریف", "نوع: واقعی، قضاوتی یا برآوردی", parent=self.root)
        if not kind: return
        account = simpledialog.askstring("حساب", "نام حساب/سرفصل:", parent=self.root) or ""
        amount = simpledialog.askfloat("مبلغ تحریف", "مبلغ تحریف (به واحد پولی پرونده):", parent=self.root, minvalue=0.0)
        if amount is None: return
        source = simpledialog.askstring("منشأ تحریف", "منشأ/مرجع شناسایی (آزمون، سند، رسیدگی تحلیلی و ...):", parent=self.root) or ""
        description = simpledialog.askstring("شرح تکمیلی", "شرح، مبنای محاسبه و اثر احتمالی (اختیاری):", parent=self.root) or ""
        def optional_id(prompt):
            value = simpledialog.askstring("ارتباط با پرونده", prompt + " (در صورت نبود خالی بگذارید):", parent=self.root)
            if not value: return None
            try: return int(value)
            except ValueError: raise ValueError("شناسه ارتباطی باید عدد صحیح باشد.")
        try:
            finding = optional_id("شناسه یافته مرتبط")
            workpaper = optional_id("شناسه کاربرگ مرتبط")
            test = optional_id("شناسه آزمون حسابرسی مرتبط")
            self.misstatement_repository.create(project_id,title,kind.strip(),amount,account,description,source,
                finding_id=finding,workpaper_id=workpaper,audit_test_id=test,actor_member_id=self.active_member_id)
            self.refresh_misstatements()
        except Exception as exc: messagebox.showerror("ثبت تحریف",str(exc))

    def change_misstatement_status(self):
        project_id=self.get_current_project_id(); selected=self.misstatement_tree.selection()
        if not project_id or not selected: messagebox.showwarning("وضعیت تحریف","یک تحریف را انتخاب کنید."); return
        status=simpledialog.askstring("وضعیت تحریف","وضعیت: " + "، ".join(self.misstatement_repository.STATUSES),parent=self.root)
        if not status: return
        note=simpledialog.askstring("یادداشت","توضیح تغییر وضعیت (اختیاری):",parent=self.root) or ""
        try:
            self.misstatement_repository.update_status(project_id,int(selected[0]),status.strip(),self.active_member_id,note)
            self.refresh_misstatements()
        except Exception as exc: messagebox.showerror("وضعیت تحریف",str(exc))

    def archive_misstatement(self):
        project_id=self.get_current_project_id(); selected=self.misstatement_tree.selection()
        if not project_id or not selected: messagebox.showwarning("بایگانی تحریف","یک تحریف را انتخاب کنید."); return
        reason=simpledialog.askstring("بایگانی تحریف","علت بایگانی:",parent=self.root)
        if not reason: return
        try:
            self.misstatement_repository.archive(project_id,int(selected[0]),reason,self.active_member_id)
            self.refresh_misstatements()
        except Exception as exc: messagebox.showerror("بایگانی تحریف",str(exc))
