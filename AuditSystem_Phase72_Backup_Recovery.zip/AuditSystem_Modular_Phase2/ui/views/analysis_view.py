import csv, io, math, os, random, re, sqlite3, tkinter as tk
from collections import Counter
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from services.number_utils import parse_amount, safe_csv_text

class AnalysisViewMixin:
    def setup_ratio_tab(self):
            ttk.Label(
                self.tab_ratios,
                text=(
                    "تمام ارقام دو دوره را با واحد یکسان وارد کنید. "
                    "خالی گذاشتن مقدار مجاز نیست؛ صفر را صریح وارد کنید."
                ),
            ).pack(anchor="e", padx=12, pady=8)
    
            fields = [
                ("sales_t", "فروش جاری"),
                ("sales_p", "فروش قبل"),
                ("recv_t", "دریافتنی جاری"),
                ("recv_p", "دریافتنی قبل"),
                ("cogs_t", "بهای تمام‌شده جاری"),
                ("cogs_p", "بهای تمام‌شده قبل"),
                ("ca_t", "دارایی جاری"),
                ("ca_p", "دارایی جاری قبل"),
                ("ppe_t", "دارایی ثابت خالص"),
                ("ppe_p", "دارایی ثابت خالص قبل"),
                ("ta_t", "کل دارایی جاری"),
                ("ta_p", "کل دارایی قبل"),
                ("dep_t", "استهلاک جاری"),
                ("dep_p", "استهلاک قبل"),
                ("sga_t", "هزینه فروش/اداری جاری"),
                ("sga_p", "هزینه فروش/اداری قبل"),
                ("ni_t", "سود خالص جاری"),
                ("cfo_t", "نقد عملیاتی جاری"),
                ("cl_t", "بدهی جاری"),
                ("cl_p", "بدهی جاری قبل"),
                ("ltd_t", "بدهی بلندمدت"),
                ("ltd_p", "بدهی بلندمدت قبل"),
            ]
    
            self.ratio_entries = {}
            grid = ttk.Frame(self.tab_ratios)
            grid.pack(fill="x", padx=12, pady=5)
    
            for index, (key, label) in enumerate(fields):
                row, group = divmod(index, 3)
                ttk.Label(grid, text=label + ":").grid(
                    row=row,
                    column=group * 2,
                    sticky="e",
                    padx=4,
                    pady=4,
                )
                entry = ttk.Entry(grid, width=14)
                entry.grid(
                    row=row,
                    column=group * 2 + 1,
                    padx=4,
                    pady=4,
                )
                self.ratio_entries[key] = entry
    
            ttk.Button(
                self.tab_ratios,
                text="محاسبه M-Score",
                command=self.run_mscore,
            ).pack(pady=10)
    
            self.lbl_mscore = ttk.Label(
                self.tab_ratios,
                text="برای محاسبه، تمام فیلدها را تکمیل کنید.",
                justify="right",
            )
            self.lbl_mscore.pack(padx=15, pady=5, anchor="e")
    
            ttk.Label(
                self.tab_ratios,
                text=(
                    "توجه: TATA در این نسخه با تقریب "
                    "(سود خالص − جریان نقد عملیاتی) / کل دارایی محاسبه می‌شود. "
                    "این جایگزین دقیق تعریف اقلام تعهدی مقاله اصلی نیست."
                ),
                wraplength=1000,
                justify="right",
            ).pack(padx=15, pady=6, anchor="e")
    
    def run_mscore(self):
        try:
            values = {}
            for key, entry in self.ratio_entries.items():
                text = entry.get().strip()
                if not text:
                    raise ValueError(f"فیلد «{key}» خالی است.")
                values[key] = text
            result = self.services.beneish.calculate(values)
        except (ValueError, OverflowError) as exc:
            messagebox.showerror("محاسبه ناممکن", str(exc))
            return
        score = result["score"]
        idx = result["indices"]
        assessment = ("بالاتر از آستانه غربالگری؛ نیازمند بررسی بیشتر"
                      if result["screening_flag"] else "پایین‌تر یا مساوی آستانه غربالگری")
        self.lbl_mscore.config(text=(
            f"M-Score = {score:.3f} | {assessment}\n"
            f"DSRI={idx['DSRI']:.3f}  GMI={idx['GMI']:.3f}  "
            f"AQI={idx['AQI']:.3f}  SGI={idx['SGI']:.3f}\n"
            f"DEPI={idx['DEPI']:.3f}  SGAI={idx['SGAI']:.3f}  "
            f"LVGI={idx['LVGI']:.3f}  TATA≈{idx['TATA']:.3f}"))

