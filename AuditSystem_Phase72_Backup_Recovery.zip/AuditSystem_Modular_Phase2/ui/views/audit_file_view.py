"""Audit-file quality-control tab and report export actions."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from services.audit_file_quality_service import AuditFileQualityService
from reports.audit_report_generator import AuditReportGenerator


class AuditFileViewMixin:
    def setup_audit_file_tab(self):
        self.audit_quality_service = AuditFileQualityService(self.db_path)
        self.audit_report_generator = AuditReportGenerator()
        self.audit_quality_data = None

        root = ttk.Frame(self.tab_audit_file, padding=12)
        root.pack(fill="both", expand=True)

        ttk.Label(
            root, text="کنترل کیفیت و تکمیل پرونده حسابرسی",
            font=("Tahoma", 15, "bold")
        ).pack(anchor="e", pady=(0, 8))

        controls = ttk.Frame(root)
        controls.pack(fill="x", pady=5)
        ttk.Button(
            controls, text="اجرای کنترل‌های کیفیت",
            command=self.refresh_audit_file_quality
        ).pack(side="right", padx=4)
        ttk.Button(
            controls, text="خروجی Word",
            command=lambda: self.export_audit_quality_report("docx")
        ).pack(side="left", padx=4)
        ttk.Button(
            controls, text="خروجی Excel",
            command=lambda: self.export_audit_quality_report("xlsx")
        ).pack(side="left", padx=4)
        ttk.Button(
            controls, text="خروجی PDF",
            command=lambda: self.export_audit_quality_report("pdf")
        ).pack(side="left", padx=4)

        self.audit_quality_summary = ttk.Label(
            root, text="برای شروع، پرونده را انتخاب و کنترل‌های کیفیت را اجرا کنید.",
            font=("Tahoma", 10), justify="right"
        )
        self.audit_quality_summary.pack(fill="x", anchor="e", pady=8)

        columns = ("severity", "title", "count")
        self.audit_quality_tree = ttk.Treeview(
            root, columns=columns, show="headings", height=13
        )
        self.audit_quality_tree.heading("severity", text="شدت")
        self.audit_quality_tree.heading("title", text="عنوان کنترل")
        self.audit_quality_tree.heading("count", text="تعداد موارد")
        self.audit_quality_tree.column("severity", width=90, anchor="center")
        self.audit_quality_tree.column("title", width=520, anchor="e")
        self.audit_quality_tree.column("count", width=90, anchor="center")
        self.audit_quality_tree.pack(fill="both", expand=True, pady=5)
        self.audit_quality_tree.bind(
            "<<TreeviewSelect>>", self.show_audit_quality_details
        )

        ttk.Label(root, text="جزئیات و اقدام پیشنهادی:", font=("Tahoma", 10, "bold")).pack(anchor="e", pady=(6, 2))
        self.audit_quality_details = tk.Text(
            root, height=7, wrap="word", font=("Tahoma", 9), state="disabled"
        )
        self.audit_quality_details.pack(fill="x", pady=4)
        self.audit_quality_status = ttk.Label(root, text="آماده اجرا")
        self.audit_quality_status.pack(anchor="e", pady=4)

    def refresh_audit_file_quality(self):
        project_id = self.get_current_project_id()
        if not project_id:
            self.audit_quality_status.configure(text="ابتدا یک پرونده حسابرسی انتخاب کنید.")
            return
        try:
            data = self.audit_quality_service.run(project_id)
            self.audit_quality_data = data
            for item in self.audit_quality_tree.get_children():
                self.audit_quality_tree.delete(item)
            for index, check in enumerate(data["checks"]):
                self.audit_quality_tree.insert(
                    "", "end", iid=str(index),
                    values=(check["severity"], check["title"], check["count"])
                )
            summary = data["summary"]
            self.audit_quality_summary.configure(
                text=(
                    f"پرونده: {data['project'].get('name', '')} | "
                    f"موارد نیازمند پیگیری: {summary['issue_count']} | "
                    f"بحرانی: {summary['critical_count']} | "
                    f"بااهمیت: {summary['high_count']} | "
                    f"متوسط: {summary['medium_count']} | "
                    f"کنترل‌های بدون مغایرت: {summary['passed_checks']} از {summary['total_checks']}"
                )
            )
            self.audit_quality_status.configure(text="کنترل کیفیت با موفقیت انجام شد.")
            self._set_audit_quality_details(
                "برای مشاهده جزئیات، یکی از کنترل‌ها را از فهرست انتخاب کنید."
            )
        except Exception as exc:
            self.audit_quality_status.configure(text=f"خطا در کنترل کیفیت: {exc}")
            messagebox.showerror("کنترل کیفیت پرونده", str(exc))

    def _set_audit_quality_details(self, value):
        self.audit_quality_details.configure(state="normal")
        self.audit_quality_details.delete("1.0", "end")
        self.audit_quality_details.insert("1.0", value)
        self.audit_quality_details.configure(state="disabled")

    def show_audit_quality_details(self, event=None):
        if not self.audit_quality_data:
            return
        selected = self.audit_quality_tree.selection()
        if not selected:
            return
        try:
            check = self.audit_quality_data["checks"][int(selected[0])]
        except (ValueError, IndexError):
            return
        lines = [
            f"کنترل: {check['title']}",
            f"شدت: {check['severity']}",
            f"تعداد موارد: {check['count']}",
            "",
            f"اقدام پیشنهادی: {check['recommendation']}",
        ]
        for item in check["items"]:
            lines.extend([
                "", f"شناسه: {item.get('id', '')}",
                f"عنوان: {item.get('title', '')}",
                f"شرح: {item.get('detail', '')}",
            ])
        self._set_audit_quality_details("\n".join(lines))

    def export_audit_quality_report(self, file_format):
        if not self.audit_quality_data:
            self.refresh_audit_file_quality()
        if not self.audit_quality_data:
            return
        extensions = {"docx": ".docx", "xlsx": ".xlsx", "pdf": ".pdf"}
        labels = {"docx": "Word", "xlsx": "Excel", "pdf": "PDF"}
        extension = extensions[file_format]
        path = filedialog.asksaveasfilename(
            title=f"ذخیره گزارش {labels[file_format]}",
            defaultextension=extension,
            filetypes=[(labels[file_format], f"*{extension}")],
            initialfile=f"Audit_File_Quality{extension}",
        )
        if not path:
            return
        try:
            self.audit_report_generator.export(
                self.audit_quality_data, path, file_format
            )
            messagebox.showinfo("گزارش", f"گزارش با موفقیت ذخیره شد:\n{path}")
        except Exception as exc:
            messagebox.showerror("خطای تهیه گزارش", str(exc))
