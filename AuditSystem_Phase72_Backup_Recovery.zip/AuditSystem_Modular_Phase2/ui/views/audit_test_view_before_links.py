
import tkinter as tk
from tkinter import ttk, messagebox


class AuditTestViewMixin:

    def setup_audit_test_tab(self):
        # ---------------- Programs ----------------
        program_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۱. تعریف برنامه حسابرسی"
        )
        program_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(program_form, text="عنوان برنامه:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_program_title = ttk.Entry(
            program_form, width=30
        )
        self.ent_at_program_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(program_form, text="حوزه حسابرسی:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.ent_at_area = ttk.Entry(program_form, width=25)
        self.ent_at_area.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(program_form, text="هدف برنامه:").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_objective = ttk.Entry(
            program_form, width=70
        )
        self.ent_at_objective.grid(
            row=1, column=1, columnspan=3,
            padx=5, pady=6, sticky="ew"
        )

        ttk.Button(
            program_form,
            text="ثبت برنامه حسابرسی",
            command=self.add_audit_program
        ).grid(row=2, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_programs = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان برنامه", 230),
                ("area", "حوزه حسابرسی", 160),
                ("status", "وضعیت", 100)
            ]
        )
        self.tree_at_programs.bind(
            "<<TreeviewSelect>>",
            self.on_audit_program_selected
        )

        # ---------------- Tests ----------------
        test_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۲. تعریف آزمون حسابرسی"
        )
        test_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(test_form, text="عنوان آزمون:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_test_title = ttk.Entry(
            test_form, width=30
        )
        self.ent_at_test_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(test_form, text="نوع آزمون:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.combo_at_test_type = ttk.Combobox(
            test_form,
            values=["کنترلی", "ماهوی", "تحلیلی"],
            state="readonly",
            width=15
        )
        self.combo_at_test_type.current(1)
        self.combo_at_test_type.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(test_form, text="حجم جامعه (N):").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_population = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_population.grid(
            row=1, column=1, padx=5, pady=6,
            sticky="w"
        )

        ttk.Label(test_form, text="حجم نمونه (n):").grid(
            row=1, column=2, padx=5, pady=6
        )
        self.ent_at_sample_size = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_sample_size.grid(
            row=1, column=3, padx=5, pady=6,
            sticky="w"
        )

        ttk.Button(
            test_form,
            text="ثبت آزمون",
            command=self.add_audit_test
        ).grid(row=2, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_tests = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان آزمون", 240),
                ("population", "جامعه", 90),
                ("sample", "نمونه", 90),
                ("status", "وضعیت", 120)
            ]
        )
        self.tree_at_tests.bind(
            "<<TreeviewSelect>>",
            self.on_audit_test_selected
        )

        # ---------------- Sample operations ----------------
        sample_bar = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۳. انتخاب نمونه و ثبت نتیجه رسیدگی"
        )
        sample_bar.pack(fill="x", padx=10, pady=6)

        ttk.Button(
            sample_bar,
            text="انتخاب نمونه تصادفی",
            command=self.generate_audit_samples
        ).pack(side="right", padx=5, pady=6)

        ttk.Label(
            sample_bar, text="نتیجه رسیدگی:"
        ).pack(side="right", padx=5)

        self.combo_at_result = ttk.Combobox(
            sample_bar,
            values=[
                "تأیید",
                "مغایرت",
                "عدم انطباق",
                "نیازمند بررسی"
            ],
            state="readonly",
            width=17
        )
        self.combo_at_result.current(0)
        self.combo_at_result.pack(side="right", padx=5)

        ttk.Label(
            sample_bar, text="شرح نتیجه / مغایرت:"
        ).pack(side="right", padx=5)

        self.ent_at_result_note = ttk.Entry(
            sample_bar, width=35
        )
        self.ent_at_result_note.pack(
            side="right", padx=5
        )

        ttk.Button(
            sample_bar,
            text="ثبت نتیجه نمونه انتخاب‌شده",
            command=self.save_audit_sample_result
        ).pack(side="right", padx=5)

        self.tree_at_samples = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 55),
                ("number", "ردیف نمونه", 85),
                ("population_row", "ردیف جامعه", 95),
                ("result", "نتیجه", 120),
                ("exception", "شرح مغایرت", 300)
            ]
        )

        self.lbl_at_progress = ttk.Label(
            self.tab_audit_tests,
            text="ابتدا یک آزمون را انتخاب کنید.",
            font=("Tahoma", 10, "bold")
        )
        self.lbl_at_progress.pack(
            anchor="e", padx=15, pady=8
        )

    # -------------------------------------------------
    # Programs
    # -------------------------------------------------

    def add_audit_program(self):
        project_id = self.get_current_project_id()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا یک پرونده حسابرسی انتخاب کنید."
            )
            return

        title = self.ent_at_program_title.get().strip()

        if not title:
            messagebox.showwarning(
                "عنوان الزامی",
                "عنوان برنامه حسابرسی را وارد کنید."
            )
            return

        try:
            self.services.audit_tests.create_program(
                project_id,
                title,
                audit_area=self.ent_at_area.get().strip(),
                objective=self.ent_at_objective.get().strip()
            )

            self.ent_at_program_title.delete(0, "end")
            self.ent_at_area.delete(0, "end")
            self.ent_at_objective.delete(0, "end")

            self.refresh_audit_tests()
            messagebox.showinfo(
                "ثبت موفق",
                "برنامه حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def on_audit_program_selected(self, event=None):
        self.refresh_audit_test_list()

    def refresh_audit_program_list(self):
        self.clear_tree(self.tree_at_programs)

        project_id = self.get_current_project_id()
        if not project_id:
            return

        for row in self.services.audit_tests.list_programs(
            project_id
        ):
            self.tree_at_programs.insert(
                "", "end",
                values=(
                    row["id"],
                    row["title"],
                    row["audit_area"] or "",
                    row["status"] or ""
                )
            )

    # -------------------------------------------------
    # Tests
    # -------------------------------------------------

    def add_audit_test(self):
        project_id = self.get_current_project_id()
        selected = self.tree_at_programs.selection()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا پرونده حسابرسی را انتخاب کنید."
            )
            return

        if not selected:
            messagebox.showwarning(
                "برنامه انتخاب نشده",
                "ابتدا یک برنامه حسابرسی انتخاب کنید."
            )
            return

        program_values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(program_values[0])

        try:
            self.services.audit_tests.create_test(
                project_id,
                program_id,
                self.ent_at_test_title.get().strip(),
                self.ent_at_population.get(),
                self.ent_at_sample_size.get(),
                test_type=self.combo_at_test_type.get()
            )

            self.ent_at_test_title.delete(0, "end")
            self.ent_at_population.delete(0, "end")
            self.ent_at_sample_size.delete(0, "end")

            self.refresh_audit_test_list()

            messagebox.showinfo(
                "ثبت موفق",
                "آزمون حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_test_list(self):
        self.clear_tree(self.tree_at_tests)
        self.clear_tree(self.tree_at_samples)

        self.lbl_at_progress.config(
            text="برای مشاهده نمونه‌ها، یک آزمون انتخاب کنید."
        )

        selected = self.tree_at_programs.selection()
        if not selected:
            return

        values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(values[0])

        for row in self.services.audit_tests.list_tests(
            program_id
        ):
            self.tree_at_tests.insert(
                "", "end",
                values=(
                    row["id"],
                    row["title"],
                    row["population_size"],
                    row["sample_size"],
                    row["status"] or ""
                )
            )

    def on_audit_test_selected(self, event=None):
        self.refresh_audit_sample_list()

    # -------------------------------------------------
    # Samples
    # -------------------------------------------------

    def generate_audit_samples(self):
        project_id = self.get_current_project_id()
        selected = self.tree_at_tests.selection()

        if not project_id or not selected:
            messagebox.showwarning(
                "انتخاب آزمون",
                "ابتدا یک آزمون را انتخاب کنید."
            )
            return

        values = self.tree_at_tests.item(
            selected[0], "values"
        )
        test_id = int(values[0])

        if not messagebox.askyesno(
            "انتخاب نمونه",
            "نمونه‌های تصادفی برای این آزمون ایجاد شوند؟"
        ):
            return

        try:
            result = self.services.audit_tests.generate_samples(
                project_id, test_id
            )

            self.refresh_audit_sample_list()
            self.refresh_audit_test_list()

            messagebox.showinfo(
                "انتخاب نمونه موفق",
                f"تعداد نمونه: {result['count']}\n"
                f"Seed: {result['seed']}\n"
                "شماره ردیف‌های جامعه:\n"
                + ", ".join(map(str, result["selected"]))
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_sample_list(self):
        self.clear_tree(self.tree_at_samples)

        selected = self.tree_at_tests.selection()
        if not selected:
            return

        values = self.tree_at_tests.item(
            selected[0], "values"
        )
        test_id = int(values[0])

        samples = self.services.audit_tests.list_samples(
            test_id
        )

        for row in samples:
            self.tree_at_samples.insert(
                "", "end",
                values=(
                    row["id"],
                    row["sample_no"],
                    row["population_row"],
                    row["result"],
                    row["exception_description"] or ""
                )
            )

        progress = self.services.audit_tests.progress(test_id)

        self.lbl_at_progress.config(
            text=(
                f"تعداد نمونه: {progress['total_samples'] or 0} | "
                f"رسیدگی‌شده: {progress['tested_samples'] or 0} | "
                f"رسیدگی‌نشده: {progress['untested_samples'] or 0} | "
                f"مغایرت: {progress['exception_samples'] or 0} | "
                f"درصد پیشرفت: {progress['completion_percent']}٪"
            )
        )

    def save_audit_sample_result(self):
        selected = self.tree_at_samples.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب نمونه",
                "ابتدا یک نمونه را از جدول انتخاب کنید."
            )
            return

        values = self.tree_at_samples.item(
            selected[0], "values"
        )
        sample_id = int(values[0])

        result = self.combo_at_result.get()
        if not result:
            messagebox.showwarning(
                "نتیجه رسیدگی",
                "نتیجه رسیدگی را انتخاب کنید."
            )
            return

        note = self.ent_at_result_note.get().strip()

        if result in ("مغایرت", "عدم انطباق") and not note:
            messagebox.showwarning(
                "شرح مغایرت",
                "برای مغایرت یا عدم انطباق، شرح آن الزامی است."
            )
            return

        try:
            self.services.audit_tests.record_sample_result(
                sample_id,
                result,
                exception_description=note
            )

            self.ent_at_result_note.delete(0, "end")
            self.refresh_audit_sample_list()

            messagebox.showinfo(
                "ثبت موفق",
                "نتیجه رسیدگی نمونه ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    # -------------------------------------------------
    # Refresh
    # -------------------------------------------------

    def refresh_audit_tests(self):
        if not hasattr(self, "tree_at_programs"):
            return

        self.refresh_audit_program_list()
        self.refresh_audit_test_list()
