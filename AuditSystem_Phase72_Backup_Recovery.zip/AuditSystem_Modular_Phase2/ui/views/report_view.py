"""Integrated engagement report export actions."""

import csv
import json
import tkinter as tk
from tkinter import filedialog, messagebox

from services.integrated_report_service import IntegratedReportService


class ReportViewMixin:
    def export_project_data(self):
        project_id = self.get_current_project_id()
        if not project_id:
            messagebox.showwarning("خطا", "ابتدا پرونده حسابرسی را انتخاب کنید.")
            return

        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش یکپارچه پرونده",
            defaultextension=".csv",
            filetypes=[("گزارش یکپارچه CSV", "*.csv"), ("گزارش JSON", "*.json")],
        )
        if not path:
            return

        try:
            report = IntegratedReportService(self.db_path).build(project_id)
            if path.lower().endswith(".json"):
                with open(path, "w", encoding="utf-8") as output:
                    json.dump(report, output, ensure_ascii=False, indent=2, default=str)
            else:
                self._write_integrated_csv(report, path)
            messagebox.showinfo("موفقیت", f"گزارش یکپارچه پرونده ذخیره شد:\n{path}")
        except (OSError, ValueError, tk.TclError) as exc:
            messagebox.showerror("خطای گزارش", str(exc))
        except Exception as exc:
            messagebox.showerror("خطای گزارش", f"تهیه گزارش با خطا مواجه شد:\n{exc}")

    @staticmethod
    def _write_integrated_csv(report, path):
        summary_labels = {
            "risk_count": "تعداد ریسک‌ها",
            "high_risk_count": "ریسک‌های با امتیاز ۱۶ و بالاتر",
            "workpaper_count": "تعداد کاربرگ‌ها",
            "program_count": "تعداد برنامه‌های حسابرسی",
            "test_count": "تعداد آزمون‌ها",
            "sample_count": "تعداد نمونه‌ها",
            "sample_exception_count": "نمونه‌های دارای استثنا/مغایرت ثبت‌شده",
            "finding_count": "تعداد یافته‌ها",
            "open_finding_count": "یافته‌های باز",
            "evidence_count": "تعداد مستندات یافته‌ها",
            "document_count": "تعداد اسناد فعال مخزن پرونده",
            "document_link_count": "تعداد ارتباط اسناد با اجزای پرونده",
            "document_request_count": "تعداد درخواست‌های فعال مدارک",
            "open_document_request_count": "درخواست‌های باز مدارک",
            "misstatement_count": "تعداد تحریفات فعال",
            "uncorrected_misstatement_count": "تعداد تحریفات اصلاح‌نشده/مورد اختلاف",
            "uncorrected_misstatement_total": "جمع ناخالص تحریفات اصلاح‌نشده/مورد اختلاف",
            "trial_balance_account_count": "تعداد حساب‌های تراز آزمایشی",
            "trial_balance_debit_total": "جمع بدهکار تراز آزمایشی",
            "trial_balance_credit_total": "جمع بستانکار تراز آزمایشی",
            "trial_balance_difference": "اختلاف بدهکار و بستانکار",
            "recorded_misstatement_total": "جمع مبلغ تحریف ثبت‌شده در نمونه‌ها",
            "samples_with_recorded_misstatement": "تعداد نمونه دارای مبلغ تحریف ثبت‌شده",
            "coso_assessment_completion_percent": "درصد تکمیل ارزیابی COSO",
            "coso_assessment_evidence_gap_count": "خلأ ارجاع شواهد COSO",
            "coso_assessment_unanswered_count": "پرسش‌های بی‌پاسخ COSO",
        }
        with open(path, "w", newline="", encoding="utf-8-sig") as output:
            writer = csv.writer(output)
            project = report["project"]
            writer.writerow(["گزارش یکپارچه پرونده حسابرسی"])
            writer.writerow(["نام پرونده", project.get("name", "")])
            writer.writerow(["دوره", project.get("period", "")])
            writer.writerow(["نوع حسابرسی", project.get("audit_type", "")])
            writer.writerow(["مدیر پرونده", project.get("manager", "")])
            writer.writerow(["وضعیت پرونده", project.get("status", "")])
            writer.writerow(["تاریخ تهیه", report.get("generated_at", "")])
            writer.writerow([])
            writer.writerow(["خلاصه مدیریتی", "مقدار"])
            for key, label in summary_labels.items():
                writer.writerow([label, report["summary"].get(key, 0)])
            for key in ("workpaper_status", "program_status", "test_status"):
                writer.writerow(["توزیع وضعیت", key])
                for status, count in report["summary"].get(key, {}).items():
                    writer.writerow([status, count])
            for section_key, rows in report["sections"].items():
                writer.writerow([])
                writer.writerow([section_key])
                if not rows:
                    writer.writerow(["داده‌ای برای این بخش ثبت نشده است."])
                    continue
                headers = list(rows[0].keys())
                writer.writerow(headers)
                for row in rows:
                    writer.writerow([row.get(header, "") for header in headers])
            coso_report = report.get("coso_assessment_report")
            if coso_report:
                writer.writerow([])
                writer.writerow(["خلاصه ارزیابی حرفه‌ای COSO"])
                writer.writerow(["وضعیت", coso_report["summary"]["overall_status"]])
                writer.writerow(["تکمیل", coso_report["summary"]["completion_percent"]])
                writer.writerow(["موارد نیازمند بررسی", coso_report["summary"]["weakness_count"]])
                writer.writerow(["خلأ شواهد", coso_report["summary"]["evidence_gap_count"]])
                writer.writerow(["مؤلفه", "تعداد پرسش", "تکمیل درصدی", "خیر", "تاحدی", "بی‌پاسخ", "وضعیت"])
                for component in coso_report["components"]:
                    writer.writerow([component["component"], component["question_count"], component["completion_percent"], component["no_count"], component["partial_count"], component["unanswered_count"], component["assessment_status"]])
                writer.writerow(["کد اصل", "عنوان اصل", "تکمیل درصدی", "خیر", "تاحدی", "خلأ شواهد", "کنترل نگاشت‌شده", "کنترل آزمون‌شده", "یافته مرتبط", "وضعیت"])
                for principle in coso_report["principles"]:
                    writer.writerow([principle["code"], principle["title"], principle["completion_percent"], principle["no_count"], principle["partial_count"], principle["evidence_gap_count"], principle["mapped_controls"], principle["tested_controls"], principle["linked_findings"], principle["assessment_status"]])
            if report["unavailable_sections"]:
                writer.writerow([])
                writer.writerow(["بخش‌های موجود نبودند و در این گزارش خالی‌اند"])
                for label in report["unavailable_sections"]:
                    writer.writerow([label])
            writer.writerow([])
            writer.writerow(["محدودیت‌ها و ملاحظات"])
            for note in report["limitations"]:
                writer.writerow([note])
