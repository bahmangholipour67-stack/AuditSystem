﻿
import tkinter as tk
from tkinter import ttk, messagebox

from services.audit_test_catalog import list_templates
from services.audit_test_planning import AuditTestPlanningService


class AuditTestViewMixin:

    def setup_audit_test_tab(self):
        # Keep the supervisor lookup safe even before a test is selected.
        self._at_supervisor_map = {}
        self._at_risk_map = {}
        self._at_program_risk_map = {}
        self._at_template_map = {}
        self._at_selected_template = None

        # ---------------- Programs ----------------
        program_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۱. تعریف برنامه حسابرسی"
        )
        program_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(program_form, text="عنوان برنامه:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_program_title = ttk.Entry(
            program_form, width=30
        )
        self.ent_at_program_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(program_form, text="حوزه حسابرسی:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.ent_at_area = ttk.Entry(program_form, width=25)
        self.ent_at_area.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(program_form, text="هدف برنامه:").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_objective = ttk.Entry(
            program_form, width=70
        )
        self.ent_at_objective.grid(
            row=1, column=1, columnspan=3,
            padx=5, pady=6, sticky="ew"
        )

        ttk.Label(program_form, text="ریسک مرتبط:").grid(
            row=2, column=0, padx=5, pady=6
        )
        self.combo_at_program_risk = ttk.Combobox(
            program_form, state="readonly", width=48
        )
        self.combo_at_program_risk.grid(
            row=2, column=1, columnspan=2, padx=5, pady=6, sticky="ew"
        )

        ttk.Button(
            program_form,
            text="ثبت برنامه حسابرسی",
            command=self.add_audit_program
        ).grid(row=2, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_programs = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان برنامه", 230),
                ("area", "حوزه حسابرسی", 145),
                ("status", "وضعیت", 95),
                ("risk", "ریسک مرتبط", 180)
            ]
        )
        self.add_record_navigation(self.tab_audit_tests, self.tree_at_programs, label="برنامه حسابرسی")
        self.tree_at_programs.bind(
            "<<TreeviewSelect>>",
            self.on_audit_program_selected
        )

        # ---------------- Tests ----------------
        test_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۲. تعریف آزمون حسابرسی"
        )
        test_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(test_form, text="عنوان آزمون:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_test_title = ttk.Entry(
            test_form, width=30
        )
        self.ent_at_test_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(test_form, text="نوع آزمون:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.combo_at_test_type = ttk.Combobox(
            test_form,
            values=["کنترلی", "ماهوی", "تحلیلی"],
            state="readonly",
            width=15
        )
        self.combo_at_test_type.current(1)
        self.combo_at_test_type.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(test_form, text="حجم جامعه (N):").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_population = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_population.grid(
            row=1, column=1, padx=5, pady=6,
            sticky="w"
        )

        ttk.Label(test_form, text="حجم نمونه (n):").grid(
            row=1, column=2, padx=5, pady=6
        )
        self.ent_at_sample_size = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_sample_size.grid(
            row=1, column=3, padx=5, pady=6,
            sticky="w"
        )

        ttk.Label(test_form, text="الگوی آزمون:").grid(
            row=2, column=0, padx=5, pady=6
        )
        self.combo_at_template = ttk.Combobox(
            test_form, state="readonly", width=58
        )
        self.combo_at_template.grid(
            row=2, column=1, columnspan=2, padx=5, pady=6, sticky="ew"
        )
        self.load_audit_test_template_choices()

        ttk.Button(
            test_form,
            text="نمایش و اعمال الگو",
            command=self.apply_audit_test_template
        ).grid(row=2, column=3, padx=5, pady=6, sticky="e")

        ttk.Button(
            test_form,
            text="ثبت آزمون",
            command=self.add_audit_test
        ).grid(row=3, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_tests = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان آزمون", 240),
                ("population", "جامعه", 90),
                ("sample", "نمونه", 90),
                ("method", "روش نمونه‌گیری", 115),
                ("status", "وضعیت", 120)
            ]
        )
        self.add_record_navigation(self.tab_audit_tests, self.tree_at_tests, label="آزمون حسابرسی")
        self.tree_at_tests.bind(
            "<<TreeviewSelect>>",
            self.on_audit_test_selected
        )

        # ---------------- Links ----------------
        link_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۳. ارتباط آزمون با کاربرگ و یافته"
        )
        link_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(
            link_form, text="کاربرگ حسابرسی:"
        ).grid(row=0, column=0, padx=5, pady=6)

        self.combo_at_workpaper = ttk.Combobox(
            link_form,
            state="readonly",
            width=42
        )
        self.combo_at_workpaper.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Button(
            link_form,
            text="اتصال کاربرگ",
            command=self.link_audit_test_workpaper
        ).grid(row=0, column=2, padx=5, pady=6)

        ttk.Button(
            link_form,
            text="قطع اتصال کاربرگ",
            command=self.unlink_audit_test_workpaper
        ).grid(row=0, column=3, padx=5, pady=6)

        ttk.Label(
            link_form, text="یافته حسابرسی:"
        ).grid(row=1, column=0, padx=5, pady=6)

        self.combo_at_finding = ttk.Combobox(
            link_form,
            state="readonly",
            width=42
        )
        self.combo_at_finding.grid(
            row=1, column=1, padx=5, pady=6
        )

        ttk.Button(
            link_form,
            text="اتصال یافته",
            command=self.link_audit_test_finding
        ).grid(row=1, column=2, padx=5, pady=6)

        ttk.Button(
            link_form,
            text="قطع اتصال یافته",
            command=self.unlink_audit_test_finding
        ).grid(row=1, column=3, padx=5, pady=6)

        self.lbl_at_links = ttk.Label(
            link_form,
            text="ابتدا یک آزمون را انتخاب کنید."
        )
        self.lbl_at_links.grid(
            row=2, column=0, columnspan=4,
            padx=5, pady=6, sticky="e"
        )

        # ---------------- Sample operations ----------------
        sample_bar = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۴. انتخاب نمونه و ثبت نتیجه رسیدگی"
        )
        sample_bar.pack(fill="x", padx=10, pady=6)

        ttk.Label(sample_bar, text="روش نمونه‌گیری:").pack(side="right", padx=5)
        self.combo_at_sampling_method = ttk.Combobox(
            sample_bar,
            values=["تصادفی ساده", "سیستماتیک"],
            state="readonly",
            width=15,
        )
        self.combo_at_sampling_method.current(0)
        self.combo_at_sampling_method.pack(side="right", padx=5)

        ttk.Button(
            sample_bar,
            text="انتخاب نمونه",
            command=self.generate_audit_samples
        ).pack(side="right", padx=5, pady=6)

        ttk.Label(
            sample_bar, text="نتیجه رسیدگی:"
        ).pack(side="right", padx=5)

        self.combo_at_result = ttk.Combobox(
            sample_bar,
            values=[
                "تأیید",
                "مغایرت",
                "عدم انطباق",
                "نیازمند بررسی"
            ],
            state="readonly",
            width=17
        )
        self.combo_at_result.current(0)
        self.combo_at_result.pack(side="right", padx=5)

        ttk.Label(
            sample_bar, text="شرح نتیجه / مغایرت:"
        ).pack(side="right", padx=5)

        self.ent_at_result_note = ttk.Entry(
            sample_bar, width=35
        )
        self.ent_at_result_note.pack(
            side="right", padx=5
        )

        ttk.Label(sample_bar, text="مبلغ مغایرت:").pack(side="right", padx=5)
        self.ent_at_misstatement_amount = ttk.Entry(sample_bar, width=14)
        self.ent_at_misstatement_amount.pack(side="right", padx=5)

        ttk.Button(
            sample_bar,
            text="ثبت نتیجه نمونه انتخاب‌شده",
            command=self.save_audit_sample_result
        ).pack(side="right", padx=5)

        self.tree_at_samples = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 55),
                ("number", "ردیف نمونه", 85),
                ("population_row", "ردیف جامعه", 95),
                ("result", "نتیجه", 120),
                ("misstatement", "مبلغ مغایرت", 120),
                ("exception", "شرح مغایرت", 260)
            ]
        )

        self.lbl_at_progress = ttk.Label(
            self.tab_audit_tests,
            text="ابتدا یک آزمون را انتخاب کنید.",
            font=("Tahoma", 10, "bold")
        )
        self.lbl_at_progress.pack(
            anchor="e", padx=15, pady=8
        )

        # ---------------- Automated evaluation ----------------
        evaluation = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۶. ارزیابی خودکار و پیش‌نویس نتیجه‌گیری"
        )
        evaluation.pack(fill="x", padx=10, pady=6)

        ttk.Label(evaluation, text="حد انحراف قابل تحمل ٪ (کنترلی):").grid(
            row=0, column=0, padx=5, pady=5, sticky="e"
        )
        self.ent_at_tolerable_deviation = ttk.Entry(evaluation, width=12)
        self.ent_at_tolerable_deviation.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(evaluation, text="اهمیت عملکردی (ماهوی):").grid(
            row=0, column=2, padx=5, pady=5, sticky="e"
        )
        self.ent_at_performance_materiality = ttk.Entry(evaluation, width=16)
        self.ent_at_performance_materiality.grid(row=0, column=3, padx=5, pady=5)

        ttk.Label(evaluation, text="مبلغ واقعی (تحلیلی):").grid(
            row=1, column=0, padx=5, pady=5, sticky="e"
        )
        self.ent_at_analytical_actual = ttk.Entry(evaluation, width=12)
        self.ent_at_analytical_actual.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(evaluation, text="مبلغ مورد انتظار:").grid(
            row=1, column=2, padx=5, pady=5, sticky="e"
        )
        self.ent_at_analytical_expected = ttk.Entry(evaluation, width=16)
        self.ent_at_analytical_expected.grid(row=1, column=3, padx=5, pady=5)

        ttk.Label(evaluation, text="آستانه اختلاف مبلغی:").grid(
            row=2, column=0, padx=5, pady=5, sticky="e"
        )
        self.ent_at_analytical_amount_threshold = ttk.Entry(evaluation, width=12)
        self.ent_at_analytical_amount_threshold.grid(row=2, column=1, padx=5, pady=5)

        ttk.Label(evaluation, text="یا آستانه اختلاف درصدی:").grid(
            row=2, column=2, padx=5, pady=5, sticky="e"
        )
        self.ent_at_analytical_percent_threshold = ttk.Entry(evaluation, width=16)
        self.ent_at_analytical_percent_threshold.grid(row=2, column=3, padx=5, pady=5)

        ttk.Button(
            evaluation,
            text="ارزیابی آزمون و تولید پیش‌نویس نتیجه‌گیری",
            command=self.evaluate_selected_audit_test
        ).grid(row=3, column=0, columnspan=4, padx=5, pady=8, sticky="e")

        self.lbl_at_evaluation = ttk.Label(
            evaluation,
            text="نتیجه ارزیابی پس از انتخاب آزمون و تکمیل آستانه‌های مربوط نمایش داده می‌شود.",
            justify="right", wraplength=1050
        )
        self.lbl_at_evaluation.grid(
            row=4, column=0, columnspan=4, padx=5, pady=6, sticky="ew"
        )


        # ---------------- Review and approval workflow ----------------
        approval = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۵. نتیجه‌گیری و گردش تأیید آزمون"
        )
        approval.pack(fill="x", padx=10, pady=6)

        ttk.Label(approval, text="نتیجه‌گیری حسابرسی:").grid(
            row=0, column=0, padx=5, pady=5, sticky="e"
        )
        self.ent_at_conclusion = ttk.Entry(approval, width=75)
        self.ent_at_conclusion.grid(
            row=0, column=1, columnspan=3, padx=5, pady=5, sticky="ew"
        )
        ttk.Button(
            approval, text="ذخیره نتیجه‌گیری",
            command=self.save_audit_test_conclusion
        ).grid(row=0, column=4, padx=5, pady=5)

        ttk.Label(approval, text="سرپرست بررسی‌کننده:").grid(
            row=1, column=0, padx=5, pady=5, sticky="e"
        )
        self.combo_at_supervisor = ttk.Combobox(
            approval, state="readonly", width=35
        )
        self.combo_at_supervisor.grid(
            row=1, column=1, padx=5, pady=5, sticky="w"
        )
        ttk.Button(
            approval, text="ارسال برای بررسی سرپرست",
            command=self.submit_audit_test_for_review
        ).grid(row=1, column=2, padx=5, pady=5)

        ttk.Label(approval, text="توضیح بررسی / اصلاح:").grid(
            row=2, column=0, padx=5, pady=5, sticky="e"
        )
        self.ent_at_review_comment = ttk.Entry(approval, width=55)
        self.ent_at_review_comment.grid(
            row=2, column=1, columnspan=2, padx=5, pady=5, sticky="ew"
        )
        ttk.Button(
            approval, text="تأیید سرپرست",
            command=lambda: self.review_audit_test("approve")
        ).grid(row=2, column=3, padx=5, pady=5)
        ttk.Button(
            approval, text="برگشت برای اصلاح",
            command=lambda: self.review_audit_test("return")
        ).grid(row=2, column=4, padx=5, pady=5)

        ttk.Button(
            approval, text="تأیید نهایی مدیر حسابرسی",
            command=self.manager_approve_audit_test
        ).grid(row=3, column=4, padx=5, pady=5, sticky="e")

        self.lbl_at_approval_status = ttk.Label(
            approval, text="برای مشاهده وضعیت، یک آزمون انتخاب کنید."
        )
        self.lbl_at_approval_status.grid(
            row=3, column=0, columnspan=4, padx=5, pady=5, sticky="e"
        )

        self.tree_at_history = self.make_tree(
            self.tab_audit_tests,
            [
                ("created_at", "زمان", 145),
                ("action", "عملیات", 190),
                ("actor", "انجام‌دهنده", 150),
                ("details", "شرح", 450),
            ]
        )


    # -------------------------------------------------
    # Programs
    # -------------------------------------------------

    def add_audit_program(self):
        project_id = self.get_current_project_id()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا یک پرونده حسابرسی انتخاب کنید."
            )
            return

        title = self.ent_at_program_title.get().strip()

        if not title:
            messagebox.showwarning(
                "عنوان الزامی",
                "عنوان برنامه حسابرسی را وارد کنید."
            )
            return

        try:
            risk_id = self._at_risk_map.get(self.combo_at_program_risk.get())
            self.services.audit_tests.create_program(
                project_id,
                title,
                audit_area=self.ent_at_area.get().strip(),
                objective=self.ent_at_objective.get().strip(),
                risk_id=risk_id,
            )

            self.ent_at_program_title.delete(0, "end")
            self.ent_at_area.delete(0, "end")
            self.ent_at_objective.delete(0, "end")
            self.combo_at_program_risk.set("")

            self.refresh_audit_tests()
            if hasattr(self, "refresh_dashboard"):
                self.refresh_dashboard()

            messagebox.showinfo(
                "ثبت موفق",
                "برنامه حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def on_audit_program_selected(self, event=None):
        selected = self.tree_at_programs.selection()
        if selected:
            values = self.tree_at_programs.item(selected[0], "values")
            if values:
                program_id = int(values[0])
                risk_id = self._at_program_risk_map.get(program_id)
                risk_label = next(
                    (label for label, item_id in self._at_risk_map.items() if item_id == risk_id),
                    "",
                )
                self.combo_at_program_risk.set(risk_label)
        self.refresh_audit_test_list()

    def refresh_audit_program_list(self):
        self.clear_tree(self.tree_at_programs)

        project_id = self.get_current_project_id()
        self._at_program_risk_map = {}
        if not project_id:
            self.combo_at_program_risk["values"] = ()
            self.combo_at_program_risk.set("")
            return

        for row in self.services.audit_tests.list_programs(project_id):
            self._at_program_risk_map[row["id"]] = row.get("risk_id")
            self.tree_at_programs.insert(
                "", "end",
                values=(
                    row["id"], row["title"], row["audit_area"] or "",
                    row["status"] or "", row.get("risk_title") or "بدون ریسک مرتبط"
                )
            )
        nav_refresh = getattr(self.tree_at_programs, "_record_navigation_refresh", None)
        if nav_refresh:
            nav_refresh()

    # -------------------------------------------------
    # Tests
    # -------------------------------------------------

    def load_audit_test_template_choices(self):
        """Load effective templates, including library and current-project edits."""
        self._at_template_map = {}
        labels = []
        project_id = self.get_current_project_id()
        template_service = getattr(self.services, "audit_templates", None)
        rows = template_service.list_templates(project_id) if template_service else list_templates()
        for template in rows:
            label = f"{template.get('industry', 'عمومی')} | {template['cycle']} | {template['title']}"
            self._at_template_map[label] = template['id']
            labels.append(label)
        self.combo_at_template["values"] = labels
        if self.combo_at_template.get() not in labels:
            self.combo_at_template.set("")

    def _template_editor_content(self, template, widgets):
        content = dict(template)
        content["title"] = widgets["title"].get().strip()
        content["cycle"] = widgets["cycle"].get().strip()
        content["test_type"] = widgets["test_type"].get().strip()
        content["assertions"] = [x.strip() for x in widgets["assertions"].get().replace("،", ",").split(",") if x.strip()]
        for key in ("objective", "population_description", "procedure", "evidence"):
            content[key] = widgets[key].get("1.0", "end-1c").strip()
        return content

    def _apply_template_to_test_form(self, template):
        self._at_selected_template = dict(template)
        self.ent_at_test_title.delete(0, "end")
        self.ent_at_test_title.insert(0, template["title"])
        self.combo_at_test_type.set(template["test_type"])
        self.load_audit_test_template_choices()
        label = next((key for key, value in self._at_template_map.items() if value == template["id"]), "")
        if label:
            self.combo_at_template.set(label)

    def apply_audit_test_template(self):
        """Open the editable template drawer for review, customization and application."""
        label = self.combo_at_template.get().strip()
        template_id = self._at_template_map.get(label)
        project_id = self.get_current_project_id()
        template_service = getattr(self.services, "audit_templates", None)
        template = template_service.get_template(template_id, project_id) if template_service and template_id else None
        if not template and template_id:
            from services.audit_test_catalog import get_template
            template = get_template(template_id)
        if not template:
            messagebox.showwarning("انتخاب الگو", "ابتدا یک الگوی معتبر از فهرست انتخاب کنید.")
            return

        drawer = tk.Toplevel(self.root)

        self._style_dialog(drawer)
        drawer.title("نمایش، ویرایش و اعمال الگوی آزمون")
        drawer.geometry("820x760")
        drawer.minsize(680, 600)
        drawer.transient(self.root)
        drawer.grab_set()

        outer = ttk.Frame(drawer, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="اطلاعات الگو را ویرایش کنید؛ سپس تغییرات را در کتابخانه اصلی یا فقط پرونده جاری ذخیره کنید.",
                  wraplength=760, justify="right").pack(fill="x", pady=(0, 10))

        form = ttk.Frame(outer)
        form.pack(fill="both", expand=True)
        widgets = {}

        def add_entry(key, caption, row, width=65):
            ttk.Label(form, text=caption).grid(row=row, column=0, sticky="ne", padx=6, pady=5)
            entry = ttk.Entry(form, width=width)
            entry.grid(row=row, column=1, sticky="ew", padx=6, pady=5)
            entry.insert(0, str(template.get(key, "")))
            widgets[key] = entry

        form.columnconfigure(1, weight=1)
        add_entry("title", "عنوان الگو:", 0)
        add_entry("cycle", "حوزه حسابرسی:", 1)
        ttk.Label(form, text="نوع آزمون:").grid(row=2, column=0, sticky="ne", padx=6, pady=5)
        type_box = ttk.Combobox(form, values=["کنترلی", "ماهوی", "تحلیلی"], state="readonly")
        type_box.grid(row=2, column=1, sticky="ew", padx=6, pady=5)
        type_box.set(template.get("test_type", "ماهوی"))
        widgets["test_type"] = type_box
        add_entry("assertions", "ادعاهای مرتبط (با ویرگول جدا کنید):", 3)
        widgets["assertions"].delete(0, "end")
        widgets["assertions"].insert(0, "، ".join(template.get("assertions", [])))

        def add_text(key, caption, row, height):
            ttk.Label(form, text=caption).grid(row=row, column=0, sticky="ne", padx=6, pady=5)
            frame = ttk.Frame(form)
            frame.grid(row=row, column=1, sticky="nsew", padx=6, pady=5)
            editor = tk.Text(frame, height=height, wrap="word", undo=True)
            scroll = ttk.Scrollbar(frame, orient="vertical", command=editor.yview)
            editor.configure(yscrollcommand=scroll.set)
            editor.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            editor.insert("1.0", str(template.get(key, "")))
            widgets[key] = editor

        add_text("objective", "هدف آزمون:", 4, 3)
        add_text("population_description", "شرح جامعه:", 5, 3)
        add_text("procedure", "مراحل و روش اجرا:", 6, 8)
        add_text("evidence", "شواهد مورد انتظار:", 7, 4)
        for row in range(4, 8):
            form.rowconfigure(row, weight=1 if row == 6 else 0)

        status_var = tk.StringVar(value="تغییرات ذخیره‌نشده")
        ttk.Label(outer, textvariable=status_var, foreground="#555555").pack(anchor="e", pady=(6, 2))

        def collect():
            values = self._template_editor_content(template, widgets)
            values["id"] = template["id"]
            return values

        def save_library():
            try:
                values = collect()
                template_service.save_to_library(template["id"], values, getattr(self, "active_member_id", None))
                template.update(values)
                self._at_selected_template = dict(values)
                self.load_audit_test_template_choices()
                status_var.set("نسخه اصلی کتابخانه ذخیره شد؛ برای پرونده‌های آینده نیز قابل استفاده است.")
                messagebox.showinfo("ذخیره الگو", "تغییرات در کتابخانه اصلی الگوها ذخیره شد.", parent=drawer)
            except Exception as exc:
                messagebox.showerror("خطا در ذخیره", str(exc), parent=drawer)

        def save_project():
            try:
                if not project_id:
                    raise ValueError("ابتدا پرونده حسابرسی را انتخاب کنید.")
                values = collect()
                template_service.save_to_project(project_id, template["id"], values, getattr(self, "active_member_id", None))
                template.update(values)
                self._at_selected_template = dict(values)
                self.load_audit_test_template_choices()
                status_var.set("نسخه اختصاصی این پرونده ذخیره شد؛ نسخه اصلی بدون تغییر باقی ماند.")
                messagebox.showinfo("ذخیره الگوی پرونده", "تغییرات فقط برای پرونده جاری ذخیره شد.", parent=drawer)
            except Exception as exc:
                messagebox.showerror("خطا در ذخیره", str(exc), parent=drawer)

        def show_history():
            try:
                rows = template_service.history(template["id"], project_id)
                if not rows:
                    messagebox.showinfo("سوابق ویرایش", "برای این الگو سابقه‌ای ثبت نشده است.", parent=drawer)
                    return
                history_win = tk.Toplevel(drawer)
                self._style_dialog(history_win)
                history_win.title("سوابق و بازگردانی نسخه الگو")
                history_win.geometry("650x390")
                history_win.transient(drawer)
                history_list = tk.Listbox(history_win, height=13, font=("Tahoma", 9))
                history_list.pack(fill="both", expand=True, padx=10, pady=10)
                for row in rows:
                    scope = "کتابخانه اصلی" if row.get("scope") == "library" else f"پرونده {row.get('project_id')}"
                    history_list.insert("end", f"نسخه #{row['id']} | {scope} | {row.get('created_at') or ''}")
                history_list.selection_set(0)
                def restore_selected():
                    selected_rows = history_list.curselection()
                    if not selected_rows:
                        messagebox.showwarning("انتخاب نسخه", "یک نسخه از سوابق را انتخاب کنید.", parent=history_win)
                        return
                    chosen = rows[selected_rows[0]]
                    if not messagebox.askyesno("تأیید بازگردانی", "محتوای این نسخه جایگزین نسخه فعلی شود؟\nیک سابقه جدید از عملیات بازگردانی نیز ثبت خواهد شد.", parent=history_win):
                        return
                    try:
                        template_service.restore_history(chosen["id"], getattr(self, "active_member_id", None))
                        refreshed = template_service.get_template(template["id"], project_id)
                        template.update(refreshed or {})
                        for key in ("title", "cycle", "objective", "population_description", "procedure", "evidence"):
                            if key in widgets:
                                if key in ("title", "cycle"):
                                    widgets[key].delete(0, "end")
                                    widgets[key].insert(0, template.get(key, ""))
                                else:
                                    widgets[key].delete("1.0", "end")
                                    widgets[key].insert("1.0", template.get(key, ""))
                        widgets["test_type"].set(template.get("test_type", "ماهوی"))
                        widgets["assertions"].delete(0, "end")
                        widgets["assertions"].insert(0, "، ".join(template.get("assertions", [])))
                        self._at_selected_template = dict(template)
                        self.load_audit_test_template_choices()
                        status_var.set("نسخه انتخاب‌شده بازگردانی شد.")
                        history_win.destroy()
                        messagebox.showinfo("بازگردانی موفق", "نسخه انتخاب‌شده بازیابی شد.", parent=drawer)
                    except Exception as exc:
                        messagebox.showerror("خطا در بازگردانی", str(exc), parent=history_win)
                controls = ttk.Frame(history_win)
                controls.pack(fill="x", padx=10, pady=(0, 10))
                ttk.Button(controls, text="بازگردانی نسخه انتخاب‌شده", command=restore_selected).pack(side="right", padx=4)
                ttk.Button(controls, text="بستن", command=history_win.destroy).pack(side="left", padx=4)
            except Exception as exc:
                messagebox.showerror("خطا", str(exc), parent=drawer)

        def apply_and_close():
            try:
                from services.audit_template_service import AuditTemplateService
                values = AuditTemplateService.validate(collect())
                values["id"] = template["id"]
                self._apply_template_to_test_form(values)
                drawer.destroy()
                messagebox.showinfo("اعمال الگو", "الگوی ویرایش‌شده در فرم تعریف آزمون قرار گرفت. برای ثبت نهایی، آزمون را ثبت کنید.")
            except Exception as exc:
                messagebox.showerror("اطلاعات ناقص", str(exc), parent=drawer)

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="اعمال در فرم آزمون", command=apply_and_close).pack(side="right", padx=4)
        ttk.Button(buttons, text="ذخیره در کتابخانه اصلی", command=save_library).pack(side="right", padx=4)
        ttk.Button(buttons, text="ذخیره فقط در پرونده جاری", command=save_project,
                   state="normal" if project_id else "disabled").pack(side="right", padx=4)
        ttk.Button(buttons, text="سوابق ویرایش", command=show_history).pack(side="left", padx=4)
        ttk.Button(buttons, text="بستن", command=drawer.destroy).pack(side="left", padx=4)

    def add_audit_test(self):
        project_id = self.get_current_project_id()
        selected = self.tree_at_programs.selection()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا پرونده حسابرسی را انتخاب کنید."
            )
            return

        if not selected:
            messagebox.showwarning(
                "برنامه انتخاب نشده",
                "ابتدا یک برنامه حسابرسی انتخاب کنید."
            )
            return

        program_values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(program_values[0])

        try:
            self.services.audit_tests.create_test(
                project_id,
                program_id,
                self.ent_at_test_title.get().strip(),
                self.ent_at_population.get(),
                self.ent_at_sample_size.get(),
                test_type=self.combo_at_test_type.get(),
                procedure=(self._at_selected_template or {}).get("procedure", ""),
                population_description=(self._at_selected_template or {}).get(
                    "population_description", ""
                ),
                template_id=(self._at_selected_template or {}).get("id", ""),
                template_objective=(self._at_selected_template or {}).get("objective", ""),
                template_assertions=__import__("json").dumps(
                    (self._at_selected_template or {}).get("assertions", []), ensure_ascii=False
                ),
                expected_evidence=(self._at_selected_template or {}).get("evidence", ""),
            )

            self.ent_at_test_title.delete(0, "end")
            self.ent_at_population.delete(0, "end")
            self.ent_at_sample_size.delete(0, "end")
            self._at_selected_template = None
            self.combo_at_template.set("")

            self.refresh_audit_test_list()

            messagebox.showinfo(
                "ثبت موفق",
                "آزمون حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_test_list(self):
        previous_test_id = None
        selected_before_refresh = self.tree_at_tests.selection()
        if selected_before_refresh:
            previous_values = self.tree_at_tests.item(
                selected_before_refresh[0], "values"
            )
            if previous_values:
                previous_test_id = int(previous_values[0])

        self.clear_tree(self.tree_at_tests)
        self.clear_tree(self.tree_at_samples)

        self.lbl_at_progress.config(
            text="برای مشاهده نمونه‌ها، یک آزمون انتخاب کنید."
        )
        self.lbl_at_links.config(
            text="برای مشاهده ارتباط‌ها، یک آزمون انتخاب کنید."
        )

        selected = self.tree_at_programs.selection()
        if not selected:
            self.refresh_audit_link_choices()
            return

        values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(values[0])

        for row in self.services.audit_tests.list_tests(program_id):
            item_id = self.tree_at_tests.insert(
                "", "end",
                values=(
                    row["id"], row["title"], row["population_size"],
                    row["sample_size"], row.get("sampling_method") or "", row["status"] or ""
                )
            )
            if previous_test_id is not None and int(row["id"]) == previous_test_id:
                self.tree_at_tests.selection_set(item_id)
                self.tree_at_tests.focus(item_id)

        self.refresh_audit_link_choices()
        if self.tree_at_tests.selection():
            self.refresh_audit_sample_list()
            self.refresh_audit_approval_panel()

    def on_audit_test_selected(self, event=None):
        self.refresh_audit_sample_list()
        self.refresh_audit_link_choices()
        self.refresh_audit_approval_panel()

    # -------------------------------------------------
    # Workpaper and finding links
    # -------------------------------------------------

    @staticmethod
    def _combo_id(combo):
        value = combo.get().strip()
        if not value:
            return None

        try:
            return int(value.split(" | ", 1)[0])
        except (ValueError, IndexError):
            return None

    def refresh_audit_link_choices(self):
        project_id = self.get_current_project_id()

        self.combo_at_workpaper["values"] = ()
        self.combo_at_finding["values"] = ()
        self.combo_at_program_risk["values"] = ()
        self._at_risk_map = {}

        if not project_id:
            self.combo_at_program_risk.set("")
            return

        try:
            workpapers = (
                self.services.audit_tests.available_workpapers(
                    project_id
                )
            )
            findings = (
                self.services.audit_tests.available_findings(
                    project_id
                )
            )

            risks = self.services.risks.for_project(project_id)
            self._at_risk_map = {
                f"{row[1]} (امتیاز {row[2]}) - #{row[0]}": row[0]
                for row in risks
            }
            self.combo_at_program_risk["values"] = list(self._at_risk_map)

            self._at_workpaper_map = {
                f"{row['id']} | {row['title']}": row["id"]
                for row in workpapers
            }
            self._at_finding_map = {
                f"{row['id']} | {row['title']}": row["id"]
                for row in findings
            }

            self.combo_at_workpaper["values"] = list(
                self._at_workpaper_map
            )
            self.combo_at_finding["values"] = list(
                self._at_finding_map
            )

            selected = self.tree_at_tests.selection()
            if selected:
                test_id = int(
                    self.tree_at_tests.item(
                        selected[0], "values"
                    )[0]
                )
                self.refresh_audit_test_links(test_id)

        except Exception as exc:
            messagebox.showerror(
                "خطای دریافت اطلاعات ارتباط‌ها",
                str(exc)
            )

    def refresh_audit_test_links(self, test_id):
        project_id = self.get_current_project_id()
        if not project_id:
            return

        data = self.services.audit_tests.test_links(
            project_id, test_id
        )

        if not data:
            self.lbl_at_links.config(
                text="آزمون انتخاب‌شده پیدا نشد."
            )
            return

        workpaper_id = data["workpaper_id"]
        finding_id = data["finding_id"]

        self.combo_at_workpaper.set("")
        self.combo_at_finding.set("")

        if workpaper_id is not None:
            for label, item_id in self._at_workpaper_map.items():
                if item_id == workpaper_id:
                    self.combo_at_workpaper.set(label)
                    break

        if finding_id is not None:
            for label, item_id in self._at_finding_map.items():
                if item_id == finding_id:
                    self.combo_at_finding.set(label)
                    break

        self.lbl_at_links.config(
            text=(
                f"کاربرگ: {data['workpaper_title'] or 'بدون ارتباط'}"
                f" | یافته: {data['finding_title'] or 'بدون ارتباط'}"
            )
        )

    def _selected_test_id(self):
        selected = self.tree_at_tests.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب آزمون",
                "ابتدا یک آزمون را انتخاب کنید."
            )
            return None

        return int(
            self.tree_at_tests.item(
                selected[0], "values"
            )[0]
        )

    def link_audit_test_workpaper(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        workpaper_id = self._combo_id(
            self.combo_at_workpaper
        )

        if not project_id or not test_id or not workpaper_id:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "پروژه، آزمون و کاربرگ را انتخاب کنید."
            )
            return

        try:
            self.services.audit_tests.link_workpaper(
                project_id, test_id, workpaper_id
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "ثبت موفق",
                "کاربرگ به آزمون متصل شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def unlink_audit_test_workpaper(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "قطع ارتباط",
            "ارتباط کاربرگ با این آزمون قطع شود؟"
        ):
            return

        try:
            self.services.audit_tests.link_workpaper(
                project_id, test_id, None
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "انجام شد",
                "ارتباط کاربرگ قطع شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def link_audit_test_finding(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        finding_id = self._combo_id(
            self.combo_at_finding
        )

        if not project_id or not test_id or not finding_id:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "پروژه، آزمون و یافته را انتخاب کنید."
            )
            return

        try:
            self.services.audit_tests.link_finding(
                project_id, test_id, finding_id
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "ثبت موفق",
                "یافته به آزمون متصل شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def unlink_audit_test_finding(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "قطع ارتباط",
            "ارتباط یافته با این آزمون قطع شود؟"
        ):
            return

        try:
            self.services.audit_tests.link_finding(
                project_id, test_id, None
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "انجام شد",
                "ارتباط یافته قطع شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    # -------------------------------------------------
    # Samples
    # -------------------------------------------------

    def generate_audit_samples(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "انتخاب نمونه",
            f"نمونه‌ها با روش «{self.combo_at_sampling_method.get()}» برای این آزمون ایجاد شوند؟"
        ):
            return

        try:
            method = self.combo_at_sampling_method.get() or "تصادفی ساده"
            result = self.services.audit_tests.generate_samples(
                project_id, test_id, method=method
            )

            self.refresh_audit_sample_list()
            self.refresh_audit_test_list()

            messagebox.showinfo(
                "انتخاب نمونه موفق",
                f"روش: {result['method']}\n"
                f"تعداد نمونه: {result['count']}\n"
                f"Seed: {result['seed']}\n"
                "شماره ردیف‌های جامعه:\n"
                + ", ".join(map(str, result["selected"]))
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_sample_list(self):
        self.clear_tree(self.tree_at_samples)

        test_id = self._selected_test_id()
        if not test_id:
            return

        samples = self.services.audit_tests.list_samples(
            test_id
        )

        for row in samples:
            self.tree_at_samples.insert(
                "", "end",
                values=(
                    row["id"],
                    row["sample_no"],
                    row["population_row"],
                    row["result"],
                    row.get("misstatement_amount") if row.get("misstatement_amount") is not None else "",
                    row["exception_description"] or ""
                )
            )

        progress = self.services.audit_tests.progress(test_id)

        self.lbl_at_progress.config(
            text=(
                f"تعداد نمونه: {progress['total_samples'] or 0} | "
                f"رسیدگی‌شده: {progress['tested_samples'] or 0} | "
                f"رسیدگی‌نشده: {progress['untested_samples'] or 0} | "
                f"مغایرت: {progress['exception_samples'] or 0} | "
                f"درصد پیشرفت: {progress['completion_percent']}٪"
            )
        )

    def save_audit_sample_result(self):
        selected = self.tree_at_samples.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب نمونه",
                "ابتدا یک نمونه را از جدول انتخاب کنید."
            )
            return

        values = self.tree_at_samples.item(
            selected[0], "values"
        )
        sample_id = int(values[0])

        result = self.combo_at_result.get()
        if not result:
            messagebox.showwarning(
                "نتیجه رسیدگی",
                "نتیجه رسیدگی را انتخاب کنید."
            )
            return

        note = self.ent_at_result_note.get().strip()
        raw_misstatement = self.ent_at_misstatement_amount.get().strip()
        try:
            misstatement_amount = None if not raw_misstatement else float(raw_misstatement.replace(",", ""))
            if misstatement_amount is not None and misstatement_amount < 0:
                raise ValueError("مبلغ مغایرت نمی‌تواند منفی باشد.")
        except ValueError as exc:
            messagebox.showwarning("مبلغ مغایرت", str(exc) if str(exc) else "مبلغ مغایرت باید عددی باشد.")
            return

        if result in ("مغایرت", "عدم انطباق") and not note:
            messagebox.showwarning(
                "شرح مغایرت",
                "برای مغایرت یا عدم انطباق، شرح آن الزامی است."
            )
            return

        try:
            member = self.get_active_member()
            if not member:
                raise ValueError("ابتدا عضو فعال حسابرسی را انتخاب کنید.")

            self.services.audit_tests.record_sample_result(
                sample_id,
                result,
                exception_description=note,
                misstatement_amount=misstatement_amount,
                actor_member_id=member["id"],
                tested_by_member_id=member["id"]
            )

            self.ent_at_result_note.delete(0, "end")
            self.ent_at_misstatement_amount.delete(0, "end")
            self.refresh_audit_sample_list()

            messagebox.showinfo(
                "ثبت موفق",
                "نتیجه رسیدگی نمونه ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def evaluate_selected_audit_test(self):
        test_id = self._selected_test_id()
        if not test_id:
            messagebox.showwarning("انتخاب آزمون", "ابتدا یک آزمون حسابرسی انتخاب کنید.")
            return
        try:
            test = self.services.audit_tests.repository.get_test(test_id)
            if not test:
                raise ValueError("آزمون انتخاب‌شده پیدا نشد.")
            test_type = str(test.get("test_type") or "ماهوی").strip()
            parameters = {}
            if test_type == "کنترلی":
                parameters["tolerable_deviation_rate"] = self.ent_at_tolerable_deviation.get().strip()
            elif test_type == "ماهوی":
                parameters["performance_materiality"] = self.ent_at_performance_materiality.get().strip()
            elif test_type == "تحلیلی":
                amount_threshold = self.ent_at_analytical_amount_threshold.get().strip()
                percent_threshold = self.ent_at_analytical_percent_threshold.get().strip()
                parameters.update({
                    "actual": self.ent_at_analytical_actual.get().strip(),
                    "expected": self.ent_at_analytical_expected.get().strip(),
                    "tolerable_difference_amount": amount_threshold or None,
                    "tolerable_difference_percent": percent_threshold or None,
                })
            else:
                raise ValueError("نوع آزمون برای ارزیابی پشتیبانی نمی‌شود.")

            result = self.services.audit_tests.evaluate_test_for_conclusion(
                test_id, **parameters
            )
            if test_type == "کنترلی":
                summary = (
                    f"آزمون کنترل: {result['assessment']}. "
                    f"انحراف مشاهده‌شده: {result['observed_deviation_rate_percent']}٪ "
                    f"در {result['tested_samples']} نمونه رسیدگی‌شده از "
                    f"{result['total_samples']} نمونه؛ حد قابل تحمل: "
                    f"{result['tolerable_deviation_rate_percent']}٪."
                )
            elif test_type == "ماهوی":
                summary = (
                    f"آزمون ماهوی: {result['assessment']}. مجموع مغایرت‌های "
                    f"شناسایی‌شده در نمونه‌ها: {result['identified_misstatement']:,.2f}؛ "
                    f"اهمیت عملکردی: {result['performance_materiality']:,.2f}."
                )
            else:
                summary = (
                    f"روش تحلیلی: {result['assessment']}. مبلغ واقعی: {result['actual']:,.2f}؛ "
                    f"مبلغ مورد انتظار: {result['expected']:,.2f}؛ "
                    f"اختلاف: {result['variance']:,.2f}."
                )

            limitations = "\n".join(f"• {item}" for item in result.get("limitations", []))
            draft = (
                summary + " این ارزیابی صرفاً مبنای کمکی برای قضاوت حسابرس است؛ "
                "نتیجه‌گیری نهایی باید با بررسی شواهد و شرایط پرونده توسط حسابرس تعیین شود."
            )
            self.ent_at_conclusion.delete(0, "end")
            self.ent_at_conclusion.insert(0, draft)
            self.lbl_at_evaluation.config(text=summary)
            messagebox.showinfo(
                "ارزیابی آزمون انجام شد",
                summary + "\n\nمحدودیت‌ها:\n" + limitations +
                "\n\nپیش‌نویس در فیلد نتیجه‌گیری قرار گرفت؛ برای ثبت رسمی، دکمه ذخیره نتیجه‌گیری را بزنید."
            )
        except Exception as exc:
            messagebox.showerror("خطا در ارزیابی آزمون", str(exc))

    # -------------------------------------------------
    # Conclusion and approval workflow
    # -------------------------------------------------

    def refresh_audit_approval_panel(self):
        if not hasattr(self, "tree_at_history"):
            return

        # Always clear prior-test values; otherwise a previous supervisor can
        # remain selected when the newly selected test has no supervisor.
        self._at_supervisor_map = {}
        self.combo_at_supervisor.set("")
        self.combo_at_supervisor["values"] = ()
        self.ent_at_conclusion.delete(0, "end")
        self.clear_tree(self.tree_at_history)

        selected = self.tree_at_tests.selection()
        if not selected:
            self.lbl_at_approval_status.config(
                text="برای مشاهده وضعیت، یک آزمون انتخاب کنید."
            )
            return

        test_id = int(self.tree_at_tests.item(selected[0], "values")[0])
        project_id = self.get_current_project_id()
        if not project_id:
            self.lbl_at_approval_status.config(text="ابتدا پرونده را انتخاب کنید.")
            return

        test = self.services.audit_tests.repository.get_test(test_id)
        if not test or test.get("project_id") != project_id:
            self.lbl_at_approval_status.config(text="آزمون انتخاب‌شده معتبر نیست.")
            return

        self.ent_at_conclusion.insert(0, test.get("conclusion") or "")
        members = self.services.team.for_project(project_id, active_only=True)
        supervisors = [row for row in members if row[2] == "سرپرست حسابرسی"]
        self._at_supervisor_map = {
            f"{row[1]} (شناسه {row[0]})": row[0] for row in supervisors
        }
        self.combo_at_supervisor["values"] = list(self._at_supervisor_map)

        current_supervisor = test.get("supervisor_member_id")
        if current_supervisor:
            for label, member_id in self._at_supervisor_map.items():
                if member_id == current_supervisor:
                    self.combo_at_supervisor.set(label)
                    break

        self.lbl_at_approval_status.config(
            text=f"وضعیت: {test.get('status') or '-'} | "
                 f"تصمیم سرپرست: {test.get('supervisor_decision') or '-'}"
        )

        for item in self.services.audit_tests.history(test_id):
            self.tree_at_history.insert(
                "", "end",
                values=(item.get("created_at", ""), item.get("action", ""),
                        item.get("actor_name") or "سیستم/نامشخص", item.get("details", ""))
            )

    def save_audit_test_conclusion(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        member = self.get_active_member()
        if not project_id or not test_id:
            return
        if not member:
            messagebox.showwarning("عضو فعال", "ابتدا عضو فعال حسابرسی را انتخاب کنید.")
            return
        try:
            self.services.audit_tests.save_conclusion(
                project_id, test_id, member["id"], self.ent_at_conclusion.get()
            )
            self.refresh_audit_approval_panel()
            messagebox.showinfo("ثبت موفق", "نتیجه‌گیری آزمون ذخیره شد.")
        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def submit_audit_test_for_review(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        member = self.get_active_member()
        supervisor_id = self._at_supervisor_map.get(self.combo_at_supervisor.get())
        if not project_id or not test_id:
            return
        if not member or not supervisor_id:
            messagebox.showwarning("اطلاعات ناقص", "عضو فعال و سرپرست بررسی‌کننده را انتخاب کنید.")
            return
        try:
            self.services.audit_tests.submit_test(
                project_id, test_id, member["id"], supervisor_id
            )
            self.refresh_audit_test_list()
            self.refresh_audit_approval_panel()
            messagebox.showinfo("ارسال موفق", "آزمون برای بررسی سرپرست ارسال شد.")
        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def review_audit_test(self, decision):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        member = self.get_active_member()
        if not project_id or not test_id:
            return
        if not member:
            messagebox.showwarning("عضو فعال", "ابتدا عضو فعال را انتخاب کنید.")
            return
        try:
            self.services.audit_tests.supervisor_review(
                project_id, test_id, member["id"], decision,
                self.ent_at_review_comment.get().strip()
            )
            self.refresh_audit_test_list()
            self.refresh_audit_approval_panel()
            messagebox.showinfo("ثبت تصمیم", "تصمیم سرپرست ثبت شد.")
        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def manager_approve_audit_test(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        member = self.get_active_member()
        if not project_id or not test_id:
            return
        if not member:
            messagebox.showwarning("عضو فعال", "ابتدا عضو فعال را انتخاب کنید.")
            return
        try:
            self.services.audit_tests.manager_approve(
                project_id, test_id, member["id"],
                self.ent_at_review_comment.get().strip()
            )
            self.refresh_audit_test_list()
            self.refresh_audit_approval_panel()
            messagebox.showinfo("تأیید نهایی", "آزمون با تأیید نهایی مدیر ثبت شد.")
        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    # -------------------------------------------------
    # Refresh
    # -------------------------------------------------

    def refresh_audit_tests(self):
        if not hasattr(self, "tree_at_programs"):
            return

        self.load_audit_test_template_choices()
        self.refresh_audit_program_list()
        self.refresh_audit_test_list()
