
import tkinter as tk
from tkinter import ttk, messagebox


class AuditTestViewMixin:

    def setup_audit_test_tab(self):
        # ---------------- Programs ----------------
        program_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۱. تعریف برنامه حسابرسی"
        )
        program_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(program_form, text="عنوان برنامه:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_program_title = ttk.Entry(
            program_form, width=30
        )
        self.ent_at_program_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(program_form, text="حوزه حسابرسی:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.ent_at_area = ttk.Entry(program_form, width=25)
        self.ent_at_area.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(program_form, text="هدف برنامه:").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_objective = ttk.Entry(
            program_form, width=70
        )
        self.ent_at_objective.grid(
            row=1, column=1, columnspan=3,
            padx=5, pady=6, sticky="ew"
        )

        ttk.Button(
            program_form,
            text="ثبت برنامه حسابرسی",
            command=self.add_audit_program
        ).grid(row=2, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_programs = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان برنامه", 230),
                ("area", "حوزه حسابرسی", 160),
                ("status", "وضعیت", 100)
            ]
        )
        self.tree_at_programs.bind(
            "<<TreeviewSelect>>",
            self.on_audit_program_selected
        )

        # ---------------- Tests ----------------
        test_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۲. تعریف آزمون حسابرسی"
        )
        test_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(test_form, text="عنوان آزمون:").grid(
            row=0, column=0, padx=5, pady=6
        )
        self.ent_at_test_title = ttk.Entry(
            test_form, width=30
        )
        self.ent_at_test_title.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Label(test_form, text="نوع آزمون:").grid(
            row=0, column=2, padx=5, pady=6
        )
        self.combo_at_test_type = ttk.Combobox(
            test_form,
            values=["کنترلی", "ماهوی", "تحلیلی"],
            state="readonly",
            width=15
        )
        self.combo_at_test_type.current(1)
        self.combo_at_test_type.grid(
            row=0, column=3, padx=5, pady=6
        )

        ttk.Label(test_form, text="حجم جامعه (N):").grid(
            row=1, column=0, padx=5, pady=6
        )
        self.ent_at_population = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_population.grid(
            row=1, column=1, padx=5, pady=6,
            sticky="w"
        )

        ttk.Label(test_form, text="حجم نمونه (n):").grid(
            row=1, column=2, padx=5, pady=6
        )
        self.ent_at_sample_size = ttk.Entry(
            test_form, width=12
        )
        self.ent_at_sample_size.grid(
            row=1, column=3, padx=5, pady=6,
            sticky="w"
        )

        ttk.Button(
            test_form,
            text="ثبت آزمون",
            command=self.add_audit_test
        ).grid(row=2, column=3, padx=5, pady=7, sticky="e")

        self.tree_at_tests = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 60),
                ("title", "عنوان آزمون", 240),
                ("population", "جامعه", 90),
                ("sample", "نمونه", 90),
                ("status", "وضعیت", 120)
            ]
        )
        self.tree_at_tests.bind(
            "<<TreeviewSelect>>",
            self.on_audit_test_selected
        )

        # ---------------- Links ----------------
        link_form = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۳. ارتباط آزمون با کاربرگ و یافته"
        )
        link_form.pack(fill="x", padx=10, pady=6)

        ttk.Label(
            link_form, text="کاربرگ حسابرسی:"
        ).grid(row=0, column=0, padx=5, pady=6)

        self.combo_at_workpaper = ttk.Combobox(
            link_form,
            state="readonly",
            width=42
        )
        self.combo_at_workpaper.grid(
            row=0, column=1, padx=5, pady=6
        )

        ttk.Button(
            link_form,
            text="اتصال کاربرگ",
            command=self.link_audit_test_workpaper
        ).grid(row=0, column=2, padx=5, pady=6)

        ttk.Button(
            link_form,
            text="قطع اتصال کاربرگ",
            command=self.unlink_audit_test_workpaper
        ).grid(row=0, column=3, padx=5, pady=6)

        ttk.Label(
            link_form, text="یافته حسابرسی:"
        ).grid(row=1, column=0, padx=5, pady=6)

        self.combo_at_finding = ttk.Combobox(
            link_form,
            state="readonly",
            width=42
        )
        self.combo_at_finding.grid(
            row=1, column=1, padx=5, pady=6
        )

        ttk.Button(
            link_form,
            text="اتصال یافته",
            command=self.link_audit_test_finding
        ).grid(row=1, column=2, padx=5, pady=6)

        ttk.Button(
            link_form,
            text="قطع اتصال یافته",
            command=self.unlink_audit_test_finding
        ).grid(row=1, column=3, padx=5, pady=6)

        self.lbl_at_links = ttk.Label(
            link_form,
            text="ابتدا یک آزمون را انتخاب کنید."
        )
        self.lbl_at_links.grid(
            row=2, column=0, columnspan=4,
            padx=5, pady=6, sticky="e"
        )

        # ---------------- Sample operations ----------------
        sample_bar = ttk.LabelFrame(
            self.tab_audit_tests,
            text="۴. انتخاب نمونه و ثبت نتیجه رسیدگی"
        )
        sample_bar.pack(fill="x", padx=10, pady=6)

        ttk.Button(
            sample_bar,
            text="انتخاب نمونه تصادفی",
            command=self.generate_audit_samples
        ).pack(side="right", padx=5, pady=6)

        ttk.Label(
            sample_bar, text="نتیجه رسیدگی:"
        ).pack(side="right", padx=5)

        self.combo_at_result = ttk.Combobox(
            sample_bar,
            values=[
                "تأیید",
                "مغایرت",
                "عدم انطباق",
                "نیازمند بررسی"
            ],
            state="readonly",
            width=17
        )
        self.combo_at_result.current(0)
        self.combo_at_result.pack(side="right", padx=5)

        ttk.Label(
            sample_bar, text="شرح نتیجه / مغایرت:"
        ).pack(side="right", padx=5)

        self.ent_at_result_note = ttk.Entry(
            sample_bar, width=35
        )
        self.ent_at_result_note.pack(
            side="right", padx=5
        )

        ttk.Button(
            sample_bar,
            text="ثبت نتیجه نمونه انتخاب‌شده",
            command=self.save_audit_sample_result
        ).pack(side="right", padx=5)

        self.tree_at_samples = self.make_tree(
            self.tab_audit_tests,
            [
                ("id", "شناسه", 55),
                ("number", "ردیف نمونه", 85),
                ("population_row", "ردیف جامعه", 95),
                ("result", "نتیجه", 120),
                ("exception", "شرح مغایرت", 300)
            ]
        )

        self.lbl_at_progress = ttk.Label(
            self.tab_audit_tests,
            text="ابتدا یک آزمون را انتخاب کنید.",
            font=("Tahoma", 10, "bold")
        )
        self.lbl_at_progress.pack(
            anchor="e", padx=15, pady=8
        )

    # -------------------------------------------------
    # Programs
    # -------------------------------------------------

    def add_audit_program(self):
        project_id = self.get_current_project_id()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا یک پرونده حسابرسی انتخاب کنید."
            )
            return

        title = self.ent_at_program_title.get().strip()

        if not title:
            messagebox.showwarning(
                "عنوان الزامی",
                "عنوان برنامه حسابرسی را وارد کنید."
            )
            return

        try:
            self.services.audit_tests.create_program(
                project_id,
                title,
                audit_area=self.ent_at_area.get().strip(),
                objective=self.ent_at_objective.get().strip()
            )

            self.ent_at_program_title.delete(0, "end")
            self.ent_at_area.delete(0, "end")
            self.ent_at_objective.delete(0, "end")

            self.refresh_audit_tests()

            messagebox.showinfo(
                "ثبت موفق",
                "برنامه حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def on_audit_program_selected(self, event=None):
        self.refresh_audit_test_list()

    def refresh_audit_program_list(self):
        self.clear_tree(self.tree_at_programs)

        project_id = self.get_current_project_id()
        if not project_id:
            return

        for row in self.services.audit_tests.list_programs(
            project_id
        ):
            self.tree_at_programs.insert(
                "", "end",
                values=(
                    row["id"],
                    row["title"],
                    row["audit_area"] or "",
                    row["status"] or ""
                )
            )

    # -------------------------------------------------
    # Tests
    # -------------------------------------------------

    def add_audit_test(self):
        project_id = self.get_current_project_id()
        selected = self.tree_at_programs.selection()

        if not project_id:
            messagebox.showwarning(
                "پرونده انتخاب نشده",
                "ابتدا پرونده حسابرسی را انتخاب کنید."
            )
            return

        if not selected:
            messagebox.showwarning(
                "برنامه انتخاب نشده",
                "ابتدا یک برنامه حسابرسی انتخاب کنید."
            )
            return

        program_values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(program_values[0])

        try:
            self.services.audit_tests.create_test(
                project_id,
                program_id,
                self.ent_at_test_title.get().strip(),
                self.ent_at_population.get(),
                self.ent_at_sample_size.get(),
                test_type=self.combo_at_test_type.get()
            )

            self.ent_at_test_title.delete(0, "end")
            self.ent_at_population.delete(0, "end")
            self.ent_at_sample_size.delete(0, "end")

            self.refresh_audit_test_list()

            messagebox.showinfo(
                "ثبت موفق",
                "آزمون حسابرسی ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_test_list(self):
        self.clear_tree(self.tree_at_tests)
        self.clear_tree(self.tree_at_samples)

        self.lbl_at_progress.config(
            text="برای مشاهده نمونه‌ها، یک آزمون انتخاب کنید."
        )
        self.lbl_at_links.config(
            text="برای مشاهده ارتباط‌ها، یک آزمون انتخاب کنید."
        )

        selected = self.tree_at_programs.selection()
        if not selected:
            self.refresh_audit_link_choices()
            return

        values = self.tree_at_programs.item(
            selected[0], "values"
        )
        program_id = int(values[0])

        for row in self.services.audit_tests.list_tests(
            program_id
        ):
            self.tree_at_tests.insert(
                "", "end",
                values=(
                    row["id"],
                    row["title"],
                    row["population_size"],
                    row["sample_size"],
                    row["status"] or ""
                )
            )

        self.refresh_audit_link_choices()

    def on_audit_test_selected(self, event=None):
        self.refresh_audit_sample_list()
        self.refresh_audit_link_choices()

    # -------------------------------------------------
    # Workpaper and finding links
    # -------------------------------------------------

    @staticmethod
    def _combo_id(combo):
        value = combo.get().strip()
        if not value:
            return None

        try:
            return int(value.split(" | ", 1)[0])
        except (ValueError, IndexError):
            return None

    def refresh_audit_link_choices(self):
        project_id = self.get_current_project_id()

        self.combo_at_workpaper["values"] = ()
        self.combo_at_finding["values"] = ()

        if not project_id:
            return

        try:
            workpapers = (
                self.services.audit_tests.available_workpapers(
                    project_id
                )
            )
            findings = (
                self.services.audit_tests.available_findings(
                    project_id
                )
            )

            self._at_workpaper_map = {
                f"{row['id']} | {row['title']}": row["id"]
                for row in workpapers
            }
            self._at_finding_map = {
                f"{row['id']} | {row['title']}": row["id"]
                for row in findings
            }

            self.combo_at_workpaper["values"] = list(
                self._at_workpaper_map
            )
            self.combo_at_finding["values"] = list(
                self._at_finding_map
            )

            selected = self.tree_at_tests.selection()
            if selected:
                test_id = int(
                    self.tree_at_tests.item(
                        selected[0], "values"
                    )[0]
                )
                self.refresh_audit_test_links(test_id)

        except Exception as exc:
            messagebox.showerror(
                "خطای دریافت اطلاعات ارتباط‌ها",
                str(exc)
            )

    def refresh_audit_test_links(self, test_id):
        project_id = self.get_current_project_id()
        if not project_id:
            return

        data = self.services.audit_tests.test_links(
            project_id, test_id
        )

        if not data:
            self.lbl_at_links.config(
                text="آزمون انتخاب‌شده پیدا نشد."
            )
            return

        workpaper_id = data["workpaper_id"]
        finding_id = data["finding_id"]

        self.combo_at_workpaper.set("")
        self.combo_at_finding.set("")

        if workpaper_id is not None:
            for label, item_id in self._at_workpaper_map.items():
                if item_id == workpaper_id:
                    self.combo_at_workpaper.set(label)
                    break

        if finding_id is not None:
            for label, item_id in self._at_finding_map.items():
                if item_id == finding_id:
                    self.combo_at_finding.set(label)
                    break

        self.lbl_at_links.config(
            text=(
                f"کاربرگ: {data['workpaper_title'] or 'بدون ارتباط'}"
                f" | یافته: {data['finding_title'] or 'بدون ارتباط'}"
            )
        )

    def _selected_test_id(self):
        selected = self.tree_at_tests.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب آزمون",
                "ابتدا یک آزمون را انتخاب کنید."
            )
            return None

        return int(
            self.tree_at_tests.item(
                selected[0], "values"
            )[0]
        )

    def link_audit_test_workpaper(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        workpaper_id = self._combo_id(
            self.combo_at_workpaper
        )

        if not project_id or not test_id or not workpaper_id:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "پروژه، آزمون و کاربرگ را انتخاب کنید."
            )
            return

        try:
            self.services.audit_tests.link_workpaper(
                project_id, test_id, workpaper_id
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "ثبت موفق",
                "کاربرگ به آزمون متصل شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def unlink_audit_test_workpaper(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "قطع ارتباط",
            "ارتباط کاربرگ با این آزمون قطع شود؟"
        ):
            return

        try:
            self.services.audit_tests.link_workpaper(
                project_id, test_id, None
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "انجام شد",
                "ارتباط کاربرگ قطع شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def link_audit_test_finding(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()
        finding_id = self._combo_id(
            self.combo_at_finding
        )

        if not project_id or not test_id or not finding_id:
            messagebox.showwarning(
                "اطلاعات ناقص",
                "پروژه، آزمون و یافته را انتخاب کنید."
            )
            return

        try:
            self.services.audit_tests.link_finding(
                project_id, test_id, finding_id
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "ثبت موفق",
                "یافته به آزمون متصل شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def unlink_audit_test_finding(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "قطع ارتباط",
            "ارتباط یافته با این آزمون قطع شود؟"
        ):
            return

        try:
            self.services.audit_tests.link_finding(
                project_id, test_id, None
            )
            self.refresh_audit_test_links(test_id)

            messagebox.showinfo(
                "انجام شد",
                "ارتباط یافته قطع شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    # -------------------------------------------------
    # Samples
    # -------------------------------------------------

    def generate_audit_samples(self):
        project_id = self.get_current_project_id()
        test_id = self._selected_test_id()

        if not project_id or not test_id:
            return

        if not messagebox.askyesno(
            "انتخاب نمونه",
            "نمونه‌های تصادفی برای این آزمون ایجاد شوند؟"
        ):
            return

        try:
            result = self.services.audit_tests.generate_samples(
                project_id, test_id
            )

            self.refresh_audit_sample_list()
            self.refresh_audit_test_list()

            messagebox.showinfo(
                "انتخاب نمونه موفق",
                f"تعداد نمونه: {result['count']}\n"
                f"Seed: {result['seed']}\n"
                "شماره ردیف‌های جامعه:\n"
                + ", ".join(map(str, result["selected"]))
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    def refresh_audit_sample_list(self):
        self.clear_tree(self.tree_at_samples)

        test_id = self._selected_test_id()
        if not test_id:
            return

        samples = self.services.audit_tests.list_samples(
            test_id
        )

        for row in samples:
            self.tree_at_samples.insert(
                "", "end",
                values=(
                    row["id"],
                    row["sample_no"],
                    row["population_row"],
                    row["result"],
                    row["exception_description"] or ""
                )
            )

        progress = self.services.audit_tests.progress(test_id)

        self.lbl_at_progress.config(
            text=(
                f"تعداد نمونه: {progress['total_samples'] or 0} | "
                f"رسیدگی‌شده: {progress['tested_samples'] or 0} | "
                f"رسیدگی‌نشده: {progress['untested_samples'] or 0} | "
                f"مغایرت: {progress['exception_samples'] or 0} | "
                f"درصد پیشرفت: {progress['completion_percent']}٪"
            )
        )

    def save_audit_sample_result(self):
        selected = self.tree_at_samples.selection()

        if not selected:
            messagebox.showwarning(
                "انتخاب نمونه",
                "ابتدا یک نمونه را از جدول انتخاب کنید."
            )
            return

        values = self.tree_at_samples.item(
            selected[0], "values"
        )
        sample_id = int(values[0])

        result = self.combo_at_result.get()
        if not result:
            messagebox.showwarning(
                "نتیجه رسیدگی",
                "نتیجه رسیدگی را انتخاب کنید."
            )
            return

        note = self.ent_at_result_note.get().strip()

        if result in ("مغایرت", "عدم انطباق") and not note:
            messagebox.showwarning(
                "شرح مغایرت",
                "برای مغایرت یا عدم انطباق، شرح آن الزامی است."
            )
            return

        try:
            self.services.audit_tests.record_sample_result(
                sample_id,
                result,
                exception_description=note
            )

            self.ent_at_result_note.delete(0, "end")
            self.refresh_audit_sample_list()

            messagebox.showinfo(
                "ثبت موفق",
                "نتیجه رسیدگی نمونه ثبت شد."
            )

        except Exception as exc:
            messagebox.showerror("خطا", str(exc))

    # -------------------------------------------------
    # Refresh
    # -------------------------------------------------

    def refresh_audit_tests(self):
        if not hasattr(self, "tree_at_programs"):
            return

        self.refresh_audit_program_list()
        self.refresh_audit_test_list()
