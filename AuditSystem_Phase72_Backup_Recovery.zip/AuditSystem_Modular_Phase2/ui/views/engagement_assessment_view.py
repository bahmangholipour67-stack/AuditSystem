"""Dedicated read-only engagement assessment dashboard."""
import csv
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from services.engagement_assessment_service import EngagementAssessmentService


class EngagementAssessmentViewMixin:
    def setup_engagement_assessment_tab(self):
        self.assessment_result = None
        root = ttk.Frame(self.tab_engagement_assessment, padding=10)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text="داشبورد ارزیابی و آمادگی پرونده",
                  font=("Tahoma", 15, "bold")).pack(side="right")
        ttk.Button(header, text="به‌روزرسانی ارزیابی",
                   command=self.refresh_engagement_assessment).pack(side="left", padx=4)
        ttk.Button(header, text="خروجی JSON",
                   command=lambda: self.export_engagement_assessment("json")).pack(side="left", padx=4)
        ttk.Button(header, text="خروجی CSV",
                   command=lambda: self.export_engagement_assessment("csv")).pack(side="left", padx=4)

        self.assessment_readiness = ttk.Label(
            root, text="برای مشاهده ارزیابی، پرونده‌ای را انتخاب کنید.",
            font=("Tahoma", 12, "bold"), anchor="e")
        self.assessment_readiness.pack(fill="x", pady=6)

        card_frame = ttk.Frame(root)
        card_frame.pack(fill="x", pady=6)
        self.assessment_cards = {}
        metrics = [
            ("risks", "ریسک‌ها"), ("workpapers", "کاربرگ‌ها"),
            ("workpapers_not_final", "کاربرگ نهایی‌نشده"),
            ("tests", "آزمون‌ها"), ("tests_not_final", "آزمون نهایی‌نشده"),
            ("open_findings", "یافته باز"), ("uncorrected_misstatements", "تحریف اصلاح‌نشده"),
            ("document_requests_open", "درخواست مدرک باز"),
            ("critical_issues", "هشدار بحرانی"), ("high_issues", "هشدار زیاد"),
        ]
        for i, (key, label) in enumerate(metrics):
            box = ttk.LabelFrame(card_frame, text=label, padding=6)
            box.grid(row=i // 5, column=i % 5, padx=3, pady=3, sticky="nsew")
            value = ttk.Label(box, text="—", font=("Tahoma", 15, "bold"))
            value.pack(padx=10, pady=4)
            self.assessment_cards[key] = value
        for col in range(5):
            card_frame.columnconfigure(col, weight=1)

        ttk.Label(root, text="فهرست هشدارها و اقدامات موردنیاز",
                  font=("Tahoma", 11, "bold")).pack(anchor="e", pady=(10, 4))
        columns = ("severity", "title", "detail", "references")
        self.assessment_tree = ttk.Treeview(root, columns=columns, show="headings", height=11)
        headings = {"severity": "سطح", "title": "موضوع", "detail": "شرح و مبنای هشدار", "references": "شناسه‌های مرتبط"}
        widths = {"severity": 85, "title": 250, "detail": 520, "references": 160}
        for col in columns:
            self.assessment_tree.heading(col, text=headings[col])
            self.assessment_tree.column(col, width=widths[col], anchor="e", stretch=col in ("title", "detail"))
        self.assessment_tree.pack(fill="both", expand=True)

        self.assessment_detail = tk.Text(root, height=6, wrap="word", font=("Tahoma", 9), state="disabled")
        self.assessment_detail.pack(fill="x", pady=(8, 4))
        self.assessment_tree.bind("<<TreeviewSelect>>", self._show_assessment_issue_detail)
        self.assessment_note = ttk.Label(root, text="ارزیابی صرفاً ابزار پشتیبان تصمیم‌گیری است؛ اظهارنظر نهایی با حسابرس است.",
                                         wraplength=1100, justify="right")
        self.assessment_note.pack(fill="x", anchor="e", pady=4)
        self.refresh_engagement_assessment()

    def refresh_engagement_assessment(self):
        project_id = self.get_current_project_id()
        if not project_id:
            self.assessment_result = None
            self.assessment_readiness.config(text="ابتدا یک پرونده حسابرسی انتخاب کنید.")
            for label in self.assessment_cards.values():
                label.config(text="—")
            for item in self.assessment_tree.get_children():
                self.assessment_tree.delete(item)
            return
        try:
            result = EngagementAssessmentService(self.db_path).build(project_id)
            self.assessment_result = result
            self.assessment_readiness.config(
                text=f"وضعیت ارزیابی: {result['readiness']}   |   پرونده: {result['project']['name']}   |   دوره: {result['project']['period']}"
            )
            for key, label in self.assessment_cards.items():
                label.config(text=str(result["counts"].get(key, 0)))
            for item in self.assessment_tree.get_children():
                self.assessment_tree.delete(item)
            for index, issue in enumerate(result["issues"]):
                refs = "، ".join(str(x) for x in issue.get("references", [])) or "—"
                self.assessment_tree.insert("", "end", iid=str(index), values=(
                    issue["severity"], issue["title"], issue["detail"], refs
                ))
            self._set_assessment_detail("برای مشاهده جزئیات، یک هشدار را انتخاب کنید.")
        except Exception as exc:
            messagebox.showerror("خطای ارزیابی پرونده", str(exc))

    def _set_assessment_detail(self, value):
        self.assessment_detail.config(state="normal")
        self.assessment_detail.delete("1.0", "end")
        self.assessment_detail.insert("1.0", value)
        self.assessment_detail.config(state="disabled")

    def _show_assessment_issue_detail(self, event=None):
        if not self.assessment_result:
            return
        selected = self.assessment_tree.selection()
        if not selected:
            return
        try:
            issue = self.assessment_result["issues"][int(selected[0])]
        except (ValueError, IndexError):
            return
        refs = "، ".join(str(x) for x in issue.get("references", [])) or "مرجع مشخصی ثبت نشده است."
        self._set_assessment_detail(
            f"کد هشدار: {issue['code']}\nسطح: {issue['severity']}\nموضوع: {issue['title']}\n\nشرح: {issue['detail']}\n\nشناسه‌های قابل پیگیری: {refs}"
        )

    def export_engagement_assessment(self, file_format):
        if not self.assessment_result:
            self.refresh_engagement_assessment()
        if not self.assessment_result:
            return
        extension = ".json" if file_format == "json" else ".csv"
        path = filedialog.asksaveasfilename(
            title="ذخیره ارزیابی پرونده", defaultextension=extension,
            filetypes=[("JSON", "*.json")] if file_format == "json" else [("CSV", "*.csv")]
        )
        if not path:
            return
        try:
            result = self.assessment_result
            if file_format == "json":
                with open(path, "w", encoding="utf-8") as output:
                    json.dump(result, output, ensure_ascii=False, indent=2, default=str)
            else:
                with open(path, "w", newline="", encoding="utf-8-sig") as output:
                    writer = csv.writer(output)
                    writer.writerow(["داشبورد ارزیابی پرونده", result["project"]["name"]])
                    writer.writerow(["وضعیت", result["readiness"]])
                    writer.writerow(["شاخص", "مقدار"])
                    for key, value in result["counts"].items():
                        writer.writerow([key, value])
                    writer.writerow([])
                    writer.writerow(["کد هشدار", "سطح", "موضوع", "شرح", "شناسه‌های مرتبط"])
                    for issue in result["issues"]:
                        writer.writerow([issue["code"], issue["severity"], issue["title"], issue["detail"], ",".join(map(str, issue["references"]))])
                    writer.writerow([])
                    writer.writerow(["محدودیت‌ها"])
                    for note in result["limitations"]:
                        writer.writerow([note])
            messagebox.showinfo("موفقیت", f"گزارش ارزیابی ذخیره شد:\n{path}")
        except (OSError, tk.TclError) as exc:
            messagebox.showerror("خطای ذخیره گزارش", str(exc))
