import csv, io, math, os, random, re, sqlite3, tkinter as tk
from collections import Counter
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from services.number_utils import parse_amount, safe_csv_text

class WorkpaperViewMixin:
    def setup_workpaper_tab(self):
            form = ttk.LabelFrame(self.tab_workpapers, text="ثبت کاربرگ")
            form.pack(fill="x", padx=10, pady=8)
    
            ttk.Label(form, text="سرفصل:").grid(row=0, column=0, padx=5, pady=8)
            self.ent_wp_title = ttk.Entry(form, width=30)
            self.ent_wp_title.grid(row=0, column=1, padx=5)
    
            ttk.Label(form, text="روش رسیدگی:").grid(
                row=0, column=2, padx=5
            )
            self.ent_wp_proc = ttk.Entry(form, width=38)
            self.ent_wp_proc.grid(row=0, column=3, padx=5)
    
            ttk.Label(form, text="نتیجه:").grid(row=1, column=0, padx=5, pady=8)
            self.ent_wp_res = ttk.Entry(form, width=30)
            self.ent_wp_res.grid(row=1, column=1, padx=5)
    
            self.combo_wp_status = ttk.Combobox(
                form,
                values=[
                    "پیش‌نویس",
                    "در انتظار بررسی مدیر",
                    "نهایی و تأیید",
                ],
                state="readonly",
                width=22,
            )
            self.combo_wp_status.current(0)
            self.combo_wp_status.grid(row=1, column=3, sticky="w", padx=5)
    
            ttk.Button(
                form, text="ثبت کاربرگ", command=self.add_workpaper
            ).grid(row=2, column=3, sticky="e", padx=5, pady=8)
    
            self.tree_wps = self.make_tree(
                self.tab_workpapers,
                [
                    ("id", "شناسه", 65),
                    ("title", "سرفصل", 220),
                    ("procedure", "روش رسیدگی", 280),
                    ("result", "نتیجه", 290),
                    ("status", "وضعیت", 160),
                ],
            )
    
    def add_workpaper(self):
        pid = self.get_current_project_id(); title = self.ent_wp_title.get().strip()
        if not pid or not title:
            messagebox.showwarning("اطلاعات ناقص", "پرونده و سرفصل کاربرگ لازم است."); return
        self.services.workpapers.create(pid, title, self.ent_wp_proc.get().strip(), self.ent_wp_res.get().strip(), self.combo_wp_status.get())
        for entry in (self.ent_wp_title, self.ent_wp_proc, self.ent_wp_res): entry.delete(0, "end")
        self.refresh_workpapers()
    
    def refresh_workpapers(self):
        self.clear_tree(self.tree_wps); pid = self.get_current_project_id()
        if not pid: return
        for row in self.services.workpapers.for_project(pid):
            self.tree_wps.insert("", "end", values=tuple(v if v is not None else "" for v in row))

