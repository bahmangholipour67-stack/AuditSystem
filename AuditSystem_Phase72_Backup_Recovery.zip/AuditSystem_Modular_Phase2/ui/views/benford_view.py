import csv, io, math, os, random, re, sqlite3, tkinter as tk
from collections import Counter
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from services.number_utils import parse_amount, safe_csv_text

class BenfordViewMixin:
    def setup_benford_tab(self):
            ttk.Label(
                self.tab_benford,
                text=(
                    "هر مبلغ را در یک خط جداگانه وارد کنید. "
                    "جداکننده هزارگان مجاز است؛ مبالغ صفر نادیده گرفته می‌شوند."
                ),
            ).pack(anchor="e", padx=15, pady=8)
    
            self.txt_benford = tk.Text(
                self.tab_benford, height=8, font=("Consolas", 11)
            )
            self.txt_benford.pack(fill="x", padx=15, pady=5)
    
            ttk.Button(
                self.tab_benford,
                text="اجرای تحلیل بنفورد",
                command=self.run_benford_test,
            ).pack(pady=6)
    
            self.tree_benford = self.make_tree(
                self.tab_benford,
                [
                    ("digit", "رقم اول", 90),
                    ("count", "تعداد", 100),
                    ("actual", "مشاهده‌شده", 170),
                    ("expected", "مورد انتظار", 170),
                    ("difference", "اختلاف درصدی", 170),
                ],
            )
    
            self.lbl_benford = ttk.Label(
                self.tab_benford,
                text="این آزمون به‌تنهایی نشانه قطعی تقلب نیست.",
            )
            self.lbl_benford.pack(anchor="e", padx=15, pady=7)
    
    def run_benford_test(self):
        raw = self.txt_benford.get("1.0", "end")
        entries = [line.strip() for line in raw.splitlines() if line.strip()]
        try:
            result = self.services.benford.analyze(entries)
        except ValueError as exc:
            messagebox.showerror("ورودی نامعتبر", str(exc))
            return
        self.clear_tree(self.tree_benford)
        for row in result["rows"]:
            self.tree_benford.insert("", "end", values=(
                row["digit"], row["count"], f"{row['actual']:.2f}%",
                f"{row['expected']:.2f}%", f"{row['difference']:+.2f}%"))
        self.lbl_benford.config(text=(
            f"تعداد: {result['count']} | میانگین قدرمطلق انحراف: "
            f"{result['mad']:.2f} واحد درصد | {result['warning']}"))

