
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog


class ProjectViewMixin:

    PROJECT_STATUSES = [
        "جدید",
        "در حال انجام",
        "در انتظار بررسی",
        "تکمیل‌شده",
    ]

    AUDIT_TYPES = [
        "مستقل",
        "داخلی",
        "عملیاتی",
        "ویژه",
        "مالیاتی",
        "سایر",
    ]

    def setup_project_tab(self):
        tab = self.tab_projects

        search_frame = ttk.LabelFrame(tab, text="جست‌وجوی پرونده")
        search_frame.pack(fill="x", padx=10, pady=8)

        ttk.Label(
            search_frame,
            text="نام شرکت، دوره یا مدیر:"
        ).pack(side="right", padx=6, pady=8)

        self.ent_project_search = ttk.Entry(
            search_frame, width=35
        )
        self.ent_project_search.pack(side="right", padx=6)

        self.ent_project_search.bind(
            "<KeyRelease>",
            lambda event: self.refresh_project_list()
        )

        ttk.Button(
            search_frame,
            text="پاک کردن",
            command=self.clear_project_search
        ).pack(side="right", padx=6)

        buttons = ttk.Frame(tab)
        buttons.pack(fill="x", padx=10, pady=5)

        ttk.Button(
            buttons,
            text="پرونده جدید",
            command=self.popup_project_form
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="ویرایش پرونده",
            command=self.edit_selected_project
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="بایگانی پرونده",
            command=self.archive_selected_project
        ).pack(side="right", padx=4)

        ttk.Button(
            buttons,
            text="تازه‌سازی",
            command=self.refresh_project_list
        ).pack(side="right", padx=4)

        columns = [
            ("id", "شناسه", 65),
            ("name", "نام شرکت / پرونده", 210),
            ("period", "دوره مالی", 85),
            ("audit_type", "نوع حسابرسی", 120),
            ("manager", "مدیر حسابرسی", 130),
            ("start_date", "تاریخ شروع", 100),
            ("end_date", "تاریخ پایان", 100),
            ("status", "وضعیت", 120),
        ]

        self.tree_projects = self.make_tree(tab, columns)

        self.add_record_navigation(tab, self.tree_projects, on_edit=self.edit_selected_project, on_delete=self.delete_selected_project, label="پرونده")

        self.tree_projects.bind(
            "<Double-1>",
            lambda event: self.edit_selected_project()
        )

        self.lbl_project_count = ttk.Label(
            tab,
            text="تعداد پرونده‌ها: ۰"
        )
        self.lbl_project_count.pack(
            anchor="e", padx=15, pady=5
        )

        self.refresh_project_list()

    def clear_project_search(self):
        self.ent_project_search.delete(0, "end")
        self.refresh_project_list()

    def refresh_project_list(self):
        if not hasattr(self, "tree_projects"):
            return

        self.clear_tree(self.tree_projects)

        keyword = self.ent_project_search.get().strip()

        if keyword:
            rows = self.services.projects.search_active(keyword)
        else:
            rows = self.services.projects.active()

        for row in rows:
            values = (
                row[0], row[1], row[2],
                row[4] or "", row[5] or "",
                row[6] or "", row[7] or "",
                row[8] or ""
            )

            self.tree_projects.insert(
                "", "end", values=values
            )

        self.lbl_project_count.config(
            text=f"تعداد پرونده‌ها: {len(rows)}"
        )
        nav_refresh = getattr(self.tree_projects, "_record_navigation_refresh", None)
        if nav_refresh: nav_refresh()

    def popup_project_form(self, project=None):
        win = tk.Toplevel(self.root)
        self._style_dialog(win)

        win.title(
            "ویرایش پرونده" if project else "ثبت پرونده جدید"
        )
        win.geometry("560x590")
        win.transient(self.root)
        win.grab_set()
        win.resizable(False, False)

        form = ttk.Frame(win, padding=15)
        form.pack(fill="both", expand=True)

        fields = {}

        def add_entry(key, label, value, row):
            ttk.Label(
                form, text=label
            ).grid(
                row=row, column=1,
                sticky="e", padx=6, pady=7
            )

            entry = ttk.Entry(form, width=42)
            entry.grid(
                row=row, column=0,
                sticky="ew", padx=6, pady=7
            )

            entry.insert(0, value or "")
            fields[key] = entry

        add_entry(
            "name", "نام شرکت / پرونده:",
            project[1] if project else "", 0
        )

        add_entry(
            "period", "دوره مالی:",
            project[2] if project else "", 1
        )

        ttk.Label(
            form, text="نوع حسابرسی:"
        ).grid(
            row=2, column=1,
            sticky="e", padx=6, pady=7
        )

        audit_type = ttk.Combobox(
            form,
            values=self.AUDIT_TYPES,
            state="readonly",
            width=39
        )
        audit_type.grid(
            row=2, column=0,
            sticky="ew", padx=6, pady=7
        )
        audit_type.set(
            project[4] if project else "مستقل"
        )

        add_entry(
            "manager", "مدیر حسابرسی:",
            project[5] if project else "", 3
        )

        add_entry(
            "start_date", "تاریخ شروع:",
            project[6] if project else "", 4
        )

        add_entry(
            "end_date", "تاریخ پایان:",
            project[7] if project else "", 5
        )

        ttk.Label(
            form, text="وضعیت پرونده:"
        ).grid(
            row=6, column=1,
            sticky="e", padx=6, pady=7
        )

        status = ttk.Combobox(
            form,
            values=self.PROJECT_STATUSES,
            state="readonly",
            width=39
        )
        status.grid(
            row=6, column=0,
            sticky="ew", padx=6, pady=7
        )
        status.set(
            project[8] if project else "جدید"
        )

        ttk.Label(
            form, text="توضیحات:"
        ).grid(
            row=7, column=1,
            sticky="ne", padx=6, pady=7
        )

        description = tk.Text(
            form, width=42, height=5, wrap="word"
        )
        description.grid(
            row=7, column=0,
            sticky="ew", padx=6, pady=7
        )

        if project and project[9]:
            description.insert("1.0", project[9])

        def save():
            name = fields["name"].get().strip()
            period = fields["period"].get().strip()

            if not name or not period:
                messagebox.showwarning(
                    "اطلاعات ناقص",
                    "نام پرونده و دوره مالی الزامی است.",
                    parent=win
                )
                return

            data = (
                name,
                period,
                audit_type.get(),
                fields["manager"].get().strip(),
                fields["start_date"].get().strip(),
                fields["end_date"].get().strip(),
                status.get(),
                description.get("1.0", "end").strip()
            )

            try:
                if project:
                    self.services.projects.update(
                        project[0], *data
                    )
                    selected_id = project[0]
                else:
                    selected_id = self.services.projects.create(
                        *data
                    )

                win.destroy()

                self.refresh_project_list()
                self.load_projects(select_id=selected_id)

                messagebox.showinfo(
                    "ثبت موفق",
                    "اطلاعات پرونده با موفقیت ذخیره شد.",
                    parent=self.root
                )

            except Exception as exc:
                messagebox.showerror(
                    "خطای ذخیره",
                    str(exc),
                    parent=win
                )

        ttk.Button(
            form,
            text="ذخیره اطلاعات",
            command=save
        ).grid(
            row=8, column=0, pady=15
        )

        form.columnconfigure(0, weight=1)

    def edit_selected_project(self):
        selected = self.tree_projects.selection()

        if not selected:
            messagebox.showinfo(
                "انتخاب پرونده",
                "ابتدا یک پرونده را انتخاب کنید."
            )
            return

        project_id = int(
            self.tree_projects.item(
                selected[0], "values"
            )[0]
        )

        project = self.services.projects.get(project_id)

        if project:
            self.popup_project_form(project)

    def delete_selected_project(self):
        selected = self.tree_projects.selection()
        if not selected:
            messagebox.showinfo("انتخاب پرونده", "ابتدا یک پرونده را انتخاب کنید.")
            return
        project_id = int(self.tree_projects.item(selected[0], "values")[0])
        if not messagebox.askyesno("تأیید حذف پرونده", "فقط پرونده‌ای که هیچ اطلاعات وابسته‌ای ندارد حذف می‌شود. آیا ادامه می‌دهید؟"):
            return
        try:
            self.services.projects.delete(project_id)
            self.refresh_project_list()
            self.load_projects()
            messagebox.showinfo("حذف پرونده", "پرونده خالی با موفقیت حذف شد.")
        except ValueError as exc:
            messagebox.showwarning("حذف پرونده ممکن نیست", str(exc))
        except Exception as exc:
            messagebox.showerror("خطا در حذف پرونده", str(exc))


    def setup_archive_tab(self):
        tab = self.tab_archive
        toolbar = ttk.Frame(tab)
        toolbar.pack(fill="x", padx=10, pady=8)

        ttk.Button(toolbar, text="تازه‌سازی بایگانی",
                   command=self.refresh_archive_list).pack(side="right", padx=4)
        ttk.Button(toolbar, text="بازیابی پرونده انتخاب‌شده",
                   command=self.restore_selected_project).pack(side="right", padx=4)
        ttk.Button(toolbar, text="مشاهده سوابق",
                   command=self.show_selected_archive_history).pack(side="right", padx=4)

        columns = [
            ("id", "شناسه", 65),
            ("name", "نام شرکت / پرونده", 210),
            ("period", "دوره مالی", 90),
            ("audit_type", "نوع حسابرسی", 110),
            ("manager", "مدیر حسابرسی", 130),
            ("archived_at", "تاریخ بایگانی", 150),
            ("archive_reason", "علت بایگانی", 260),
        ]
        self.tree_archived_projects = self.make_tree(tab, columns)
        self.lbl_archive_count = ttk.Label(tab, text="تعداد پرونده‌های بایگانی‌شده: ۰")
        self.lbl_archive_count.pack(anchor="e", padx=15, pady=5)
        self.refresh_archive_list()

    def refresh_archive_list(self):
        if not hasattr(self, "tree_archived_projects"):
            return
        self.clear_tree(self.tree_archived_projects)
        rows = self.services.projects.archived()
        for row in rows:
            self.tree_archived_projects.insert("", "end", values=(
                row[0], row[1], row[2], row[4] or "", row[5] or "",
                row[11] or "", row[12] or ""
            ))
        self.lbl_archive_count.config(
            text=f"تعداد پرونده‌های بایگانی‌شده: {len(rows)}"
        )

    def archive_selected_project(self):
        selected = self.tree_projects.selection()
        if not selected:
            messagebox.showinfo("انتخاب پرونده", "ابتدا یک پرونده را انتخاب کنید.")
            return
        project_id = int(self.tree_projects.item(selected[0], "values")[0])
        project = self.services.projects.get(project_id)
        if not project:
            messagebox.showerror("خطا", "پرونده موردنظر پیدا نشد.")
            return
        reason = simpledialog.askstring(
            "علت بایگانی پرونده",
            "علت بایگانی را وارد کنید:",
            initialvalue="اتمام عملیات حسابرسی",
            parent=self.root
        )
        if reason is None:
            return
        try:
            self.services.projects.archive(
                project_id, reason, getattr(self, "active_member_id", None)
            )
            self.refresh_project_list()
            self.refresh_archive_list()
            self.load_projects()
            messagebox.showinfo(
                "بایگانی موفق",
                "پرونده از فهرست فعال خارج شد؛ تمام اطلاعات و مستندات آن حفظ شده‌اند."
            )
        except Exception as exc:
            messagebox.showerror("خطا در بایگانی", str(exc))

    def restore_selected_project(self):
        selected = self.tree_archived_projects.selection()
        if not selected:
            messagebox.showinfo("انتخاب پرونده", "ابتدا یک پرونده بایگانی‌شده را انتخاب کنید.")
            return
        project_id = int(self.tree_archived_projects.item(selected[0], "values")[0])
        if not messagebox.askyesno(
            "تأیید بازیابی",
            "پرونده به فهرست پرونده‌های فعال بازگردانده شود؟",
            parent=self.root
        ):
            return
        try:
            self.services.projects.restore(
                project_id, getattr(self, "active_member_id", None)
            )
            self.refresh_archive_list()
            self.refresh_project_list()
            self.load_projects(select_id=project_id)
            messagebox.showinfo("بازیابی موفق", "پرونده با حفظ سوابق و مستندات بازیابی شد.")
        except Exception as exc:
            messagebox.showerror("خطا در بازیابی", str(exc))

    def show_selected_archive_history(self):
        selected = self.tree_archived_projects.selection()
        if not selected:
            messagebox.showinfo("انتخاب پرونده", "ابتدا یک پرونده بایگانی‌شده را انتخاب کنید.")
            return
        project_id = int(self.tree_archived_projects.item(selected[0], "values")[0])
        history = self.services.projects.archive_history(project_id)
        win = tk.Toplevel(self.root)
        self._style_dialog(win)
        win.title("سوابق بایگانی و بازیابی")
        win.geometry("760x360")
        columns = [("id", "شناسه", 60), ("event", "رویداد", 100),
                   ("reason", "شرح", 300), ("actor", "شناسه کاربر", 100),
                   ("date", "تاریخ", 150)]
        tree = self.make_tree(win, columns)
        for row in history:
            event = "بایگانی" if row[1] == "ARCHIVE" else "بازیابی"
            tree.insert("", "end", values=(row[0], event, row[2], row[3] or "", row[4]))
