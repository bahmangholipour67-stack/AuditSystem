"""Interactive risk heatmap center for project-scoped internal-control findings."""
import tkinter as tk
from tkinter import ttk, messagebox
from database.connection import connect as db_connect

class RiskCenterViewMixin:
    def setup_risk_center_tab(self):
        root = ttk.Frame(self.tab_risk_center, padding=12)
        root.pack(fill="both", expand=True)
        header = ttk.Frame(root); header.pack(fill="x", pady=(0,8))
        ttk.Label(header, text="مرکز هوشمند ریسک | ماتریس احتمال × اثر", font=("Tahoma", 13, "bold")).pack(side="right")
        ttk.Button(header, text="نمایش همه", command=lambda: self._risk_center_show(None,None)).pack(side="left", padx=3)
        ttk.Button(header, text="تازه‌سازی", command=self.refresh_risk_center).pack(side="left", padx=3)
        body=ttk.Frame(root); body.pack(fill="both",expand=True)
        left=ttk.Frame(body); left.pack(side="right",fill="y",padx=(0,12))
        self.risk_center_canvas=tk.Canvas(left,width=430,height=390,background="#FFFFFF",highlightthickness=1,highlightbackground="#DCE2EA")
        self.risk_center_canvas.pack()
        ttk.Label(left,text="محور افقی: اثر  |  محور عمودی: احتمال",font=("Tahoma",9)).pack(anchor="e",pady=4)
        right=ttk.Frame(body); right.pack(side="left",fill="both",expand=True)
        self.risk_center_summary=ttk.Label(right,text="برای مشاهده، پرونده حسابرسی را انتخاب کنید.",font=("Tahoma",10,"bold"),anchor="e")
        self.risk_center_summary.pack(fill="x",pady=(0,6))
        cols=("id","title","likelihood","impact","score","level","status")
        self.risk_center_tree=ttk.Treeview(right,columns=cols,show="headings")
        heads={"id":"شناسه","title":"عنوان یافته","likelihood":"احتمال","impact":"اثر","score":"امتیاز","level":"سطح","status":"وضعیت"}
        widths={"id":55,"title":240,"likelihood":65,"impact":65,"score":70,"level":85,"status":90}
        for c in cols:
            self.risk_center_tree.heading(c,text=heads[c]); self.risk_center_tree.column(c,width=widths[c],anchor="e")
        self.risk_center_tree.pack(fill="both",expand=True)
        self.risk_center_tree.bind("<Double-1>",self._risk_center_open_finding)
        self.refresh_risk_center()

    def refresh_risk_center(self):
        if not hasattr(self,"risk_center_canvas"): return
        pid=self.get_current_project_id()
        canvas=self.risk_center_canvas; canvas.delete("all")
        for item in self.risk_center_tree.get_children(): self.risk_center_tree.delete(item)
        if not pid:
            self.risk_center_summary.configure(text="ابتدا پرونده حسابرسی را انتخاب کنید.")
            canvas.create_text(215,195,text="پرونده‌ای انتخاب نشده",font=("Tahoma",11),fill="#64748B")
            return
        try:
            with db_connect(self.db_path) as conn:
                cur=conn.execute("SELECT id,title,likelihood,impact,status FROM findings WHERE project_id=? AND finding_type='کنترل داخلی' ORDER BY id",(pid,))
                rows=cur.fetchall()
        except Exception as exc:
            self.risk_center_summary.configure(text=f"خطا در بارگذاری: {exc}"); return
        cells={(l,i):[] for l in range(1,6) for i in range(1,6)}; valid=[]
        for row in rows:
            try:
                l,i=int(row[2]),int(row[3])
                if 1<=l<=5 and 1<=i<=5:
                    cells[(l,i)].append(row); valid.append(row)
            except (TypeError,ValueError): continue
        self.risk_center_summary.configure(text=f"یافته‌های کنترل داخلی: {len(rows)}  |  دارای امتیاز معتبر: {len(valid)}")
        self._risk_center_cells=cells
        x0,y0,cell=72,42,58
        colors={1:"#D1FAE5",2:"#A7F3D0",3:"#FEF3C7",4:"#FDBA74",5:"#FCA5A5"}
        canvas.create_text(x0+cell*2.5,y0-25,text="اثر",font=("Tahoma",10,"bold"))
        canvas.create_text(20,y0+cell*2.5,text="احتمال",font=("Tahoma",9,"bold"),angle=90)
        for impact in range(1,6): canvas.create_text(x0+(impact-1)*cell+cell/2,y0+cell*5+17,text=str(impact),font=("Tahoma",10))
        for likelihood in range(5,0,-1):
            canvas.create_text(x0-18,y0+(5-likelihood)*cell+cell/2,text=str(likelihood),font=("Tahoma",10))
            for impact in range(1,6):
                count=len(cells[(likelihood,impact)]); score=likelihood*impact
                color=colors[1] if score<=4 else colors[2] if score<=9 else colors[3] if score<=15 else colors[5]
                x=x0+(impact-1)*cell; y=y0+(5-likelihood)*cell
                rect=canvas.create_rectangle(x,y,x+cell-3,y+cell-3,fill=color,outline="#CBD5E1",tags=(f"cell_{likelihood}_{impact}",))
                canvas.create_text(x+(cell-3)/2,y+(cell-3)/2,text=str(count),font=("Tahoma",12,"bold"),tags=(f"cell_{likelihood}_{impact}",))
                canvas.tag_bind(f"cell_{likelihood}_{impact}","<Button-1>",lambda e,l=likelihood,i=impact:self._risk_center_show(l,i))
        canvas.create_text(215,365,text="کلیک روی خانه برای فهرست یافته‌های همان سطح",font=("Tahoma",9),fill="#475569")
        self._risk_center_show(None,None)

    def _risk_center_show(self, likelihood, impact):
        cells=getattr(self,"_risk_center_cells",{})
        selected=[]
        for (l,i),items in cells.items():
            if (likelihood is None or l==likelihood) and (impact is None or i==impact): selected.extend(items)
        for item in self.risk_center_tree.get_children(): self.risk_center_tree.delete(item)
        for r in selected:
            score=int(r[2])*int(r[3]); level="کم" if score<=4 else "متوسط" if score<=9 else "زیاد" if score<=15 else "بحرانی"
            self.risk_center_tree.insert("","end",iid=str(r[0]),values=(r[0],r[1],r[2],r[3],score,level,r[4]))
        if likelihood is None: label="همه یافته‌ها"
        else: label=f"احتمال {likelihood} × اثر {impact}"
        self.risk_center_summary.configure(text=f"{label} | {len(selected)} یافته")

    def _risk_center_open_finding(self, _event=None):
        selected=self.risk_center_tree.selection()
        if not selected:return
        messagebox.showinfo("جزئیات یافته",f"شناسه یافته: {selected[0]}\nبرای مشاهده و ویرایش، از تب «کنترل‌های داخلی» استفاده کنید.")
