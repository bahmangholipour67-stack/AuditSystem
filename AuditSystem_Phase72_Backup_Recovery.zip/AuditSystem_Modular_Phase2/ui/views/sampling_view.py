import csv, io, math, os, random, re, sqlite3, tkinter as tk
from collections import Counter
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from services.number_utils import parse_amount, safe_csv_text

class SamplingViewMixin:
    def setup_sampling_tab(self):
            ttk.Label(
                self.tab_sampling,
                text=(
                    "از ردیف‌های شماره ۱ تا N، بدون تکرار نمونه انتخاب می‌شود. "
                    "ردیف منتخب لزوماً «شماره سند» نیست؛ "
                    "جامعه باید ترتیب مشخص و ثابت داشته باشد."
                ),
                wraplength=1050,
                justify="right",
            ).pack(anchor="e", padx=15, pady=10)
    
            form = ttk.Frame(self.tab_sampling)
            form.pack(pady=5)
    
            ttk.Label(form, text="تعداد ردیف‌های جامعه N:").grid(
                row=0, column=0, padx=6
            )
            self.ent_pop_size = ttk.Entry(form, width=12)
            self.ent_pop_size.grid(row=0, column=1, padx=6)
    
            ttk.Label(form, text="حجم نمونه n:").grid(
                row=0, column=2, padx=6
            )
            self.ent_sample_size = ttk.Entry(form, width=12)
            self.ent_sample_size.grid(row=0, column=3, padx=6)
    
            ttk.Button(
                form,
                text="انتخاب تصادفی",
                command=self.run_sampling,
            ).grid(row=0, column=4, padx=8)
    
            ttk.Button(
                form,
                text="خروجی کاربرگ CSV",
                command=self.export_samples,
            ).grid(row=0, column=5, padx=8)
    
            self.lbl_sample = ttk.Label(
                self.tab_sampling,
                text="برای این پرونده هنوز نمونه‌ای انتخاب نشده است.",
            )
            self.lbl_sample.pack(anchor="e", padx=15, pady=6)
    
            self.tree_samples = self.make_tree(
                self.tab_sampling,
                [
                    ("number", "شماره نمونه", 160),
                    ("row", "ردیف منتخب از جامعه", 280),
                ],
            )
    
    def run_sampling(self):
        if not self.get_current_project_id():
            messagebox.showwarning("خطا", "ابتدا پرونده حسابرسی را انتخاب کنید.")
            return
        try:
            population = int(self.ent_pop_size.get().strip())
            sample_size = int(self.ent_sample_size.get().strip())
            result = self.services.sampling.select_sample(population, sample_size)
        except ValueError as exc:
            messagebox.showerror("ورودی نامعتبر", str(exc))
            return
        self.sample_seed = result["seed"]
        self.selected_samples = result["selected"]
        self.clear_tree(self.tree_samples)
        for index, row_number in enumerate(self.selected_samples, start=1):
            self.tree_samples.insert("", "end", values=(index, row_number))
        self.lbl_sample.config(text=(
            f"جامعه: {population:,} ردیف | نمونه: {sample_size:,} ردیف | "
            f"بذر بازتولید: {self.sample_seed}"))
    
    def export_samples(self):
            if not self.selected_samples:
                messagebox.showinfo(
                    "راهنما", "ابتدا نمونه‌ها را انتخاب کنید."
                )
                return
    
            path = filedialog.asksaveasfilename(
                title="ذخیره کاربرگ نمونه‌گیری",
                defaultextension=".csv",
                filetypes=[("CSV", "*.csv")],
            )
            if not path:
                return
    
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as file:
                    writer = csv.writer(file)
                    writer.writerow(["شناسه پرونده", self.get_current_project_id()])
                    writer.writerow(["بذر بازتولید انتخاب", self.sample_seed])
                    writer.writerow(["تاریخ تهیه", datetime.now().isoformat(timespec="seconds")])
                    writer.writerow([])
                    writer.writerow([
                        "شماره نمونه",
                        "ردیف منتخب از جامعه",
                        "شناسه واقعی سند",
                        "نتیجه رسیدگی",
                    ])
                    for index, row_number in enumerate(
                        self.selected_samples, start=1
                    ):
                        writer.writerow([index, row_number, "", ""])
    
                messagebox.showinfo("موفقیت", f"کاربرگ ذخیره شد:\n{path}")
            except OSError as exc:
                messagebox.showerror("خطای ذخیره", str(exc))

