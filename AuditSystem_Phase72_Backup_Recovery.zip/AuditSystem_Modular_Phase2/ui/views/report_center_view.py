"""Professional standard-report centre, reusing the read-only report service."""

import csv
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

from reporting.report_center_service import ReportCenterService
from reporting.official_report_template import build_official_docx
from reporting.intelligent_report_draft import IntelligentReportDraftService, export_draft_docx


class ReportCenterViewMixin:
    def setup_report_center_tab(self):
        root = self.tab_report_center
        container = ttk.Frame(root, padding=12)
        container.pack(fill="both", expand=True)

        header = ttk.Frame(container)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text="مرکز جامع گزارشات", style="Header.TLabel").pack(side="right")
        ttk.Label(header, text="گزارش‌های استاندارد و قابل ارائه بر پایه اطلاعات ثبت‌شده پرونده",
                  style="Muted.TLabel").pack(side="right", padx=14)

        filters = ttk.LabelFrame(container, text="انتخاب گزارش", padding=10)
        filters.pack(fill="x", pady=6)
        ttk.Label(filters, text="حوزه گزارش:").pack(side="right", padx=5)
        self.report_category_var = tk.StringVar(value="همه حوزه‌ها")
        self.report_category_box = ttk.Combobox(
            filters, textvariable=self.report_category_var, state="readonly", width=24,
            values=("همه حوزه‌ها", "مدیریتی", "اجرای حسابرسی", "ریسک و کنترل",
                    "یافته‌ها و تحریفات", "اسناد و شواهد", "اطلاعات مالی",
                    "استانداردها و انطباق", "سوابق و ردیابی")
        )
        self.report_category_box.pack(side="right", padx=5)
        self.report_category_box.bind("<<ComboboxSelected>>", self._filter_report_catalogue)
        ttk.Label(filters, text="گزارش:").pack(side="right", padx=(12, 4))
        self.report_choice_var = tk.StringVar()
        self.report_choice_box = ttk.Combobox(filters, textvariable=self.report_choice_var,
                                               state="readonly", width=43)
        self.report_choice_box.pack(side="right", padx=5)
        ttk.Button(filters, text="تهیه گزارش", style="Primary.TButton",
                   command=self._run_selected_standard_report).pack(side="right", padx=8)
        ttk.Button(filters, text="به‌روزرسانی فهرست", command=self._filter_report_catalogue).pack(side="left", padx=4)

        description = ttk.LabelFrame(container, text="شرح گزارش", padding=9)
        description.pack(fill="x", pady=6)
        self.report_description_label = ttk.Label(description, text="یک گزارش را انتخاب کنید.",
                                                   justify="right", anchor="e", wraplength=900)
        self.report_description_label.pack(fill="x")
        self.report_status_label = ttk.Label(container, text="برای تهیه گزارش، پرونده حسابرسی فعال را انتخاب کنید.",
                                              style="Muted.TLabel", anchor="e")
        self.report_status_label.pack(fill="x", pady=(3, 7))

        self._report_catalogue = ReportCenterService(self.db_path).catalogue()
        self._report_visible = []
        self._filter_report_catalogue()

        # Export controls stay above the expanding preview and remain visible.
        actions = ttk.LabelFrame(container, text="خروجی و تهیه سند", padding=7)
        actions.pack(fill="x", pady=(5, 2))
        ttk.Button(actions, text="خروجی Excel", command=self._export_standard_report_xlsx).pack(side="left", padx=3)
        ttk.Button(actions, text="خروجی PDF", command=self._export_standard_report_pdf).pack(side="left", padx=3)
        ttk.Button(actions, text="گزارش رسمی Word", command=self._export_official_report_docx).pack(side="left", padx=3)
        ttk.Button(actions, text="خروجی CSV", command=self._export_standard_report_csv).pack(side="left", padx=3)
        ttk.Button(actions, text="خروجی JSON", command=self._export_standard_report_json).pack(side="left", padx=3)
        ttk.Button(actions, text="پیش‌نویس هوشمند", command=self._run_intelligent_report_draft).pack(side="left", padx=3)
        ttk.Button(actions, text="خروجی Word پیش‌نویس", command=self._export_intelligent_draft_docx).pack(side="left", padx=3)
        self._current_standard_report = None
        self._current_intelligent_draft = None

        preview = ttk.LabelFrame(container, text="پیش‌نمایش گزارش", padding=8)
        preview.pack(fill="both", expand=True, pady=5)
        self.report_preview_tree = ttk.Treeview(preview, columns=("empty",), show="headings", height=14)
        self.report_preview_tree.heading("empty", text="پس از تهیه گزارش، اطلاعات در این قسمت نمایش داده می‌شود")
        self.report_preview_tree.column("empty", width=850, anchor="e")
        ybar = ttk.Scrollbar(preview, orient="vertical", command=self.report_preview_tree.yview)
        xbar = ttk.Scrollbar(preview, orient="horizontal", command=self.report_preview_tree.xview)
        self.report_preview_tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        self.report_preview_tree.pack(side="top", fill="both", expand=True)
        xbar.pack(side="bottom", fill="x")
        ybar.pack(side="left", fill="y")

        self.report_choice_box.bind("<<ComboboxSelected>>", self._describe_selected_standard_report)

    def _filter_report_catalogue(self, _event=None):
        category = self.report_category_var.get()
        self._report_visible = [item for item in self._report_catalogue
                                if category == "همه حوزه‌ها" or item["category"] == category]
        labels = [f'{item["title"]}  —  {item["category"]}' for item in self._report_visible]
        self.report_choice_box.configure(values=labels)
        if labels:
            if self.report_choice_var.get() not in labels:
                self.report_choice_var.set(labels[0])
            self._describe_selected_standard_report()
        else:
            self.report_choice_var.set("")
            self.report_description_label.configure(text="در این حوزه گزارشی تعریف نشده است.")

    def _selected_report_definition(self):
        selected = self.report_choice_var.get()
        for item in self._report_visible:
            if selected == f'{item["title"]}  —  {item["category"]}':
                return item
        return None

    def _describe_selected_standard_report(self, _event=None):
        item = self._selected_report_definition()
        if item:
            self.report_description_label.configure(text=item["description"])

    def _run_selected_standard_report(self):
        definition = self._selected_report_definition()
        project_id = self.get_current_project_id()
        if not definition:
            messagebox.showwarning("انتخاب گزارش", "ابتدا یک گزارش معتبر انتخاب کنید.")
            return
        if not project_id:
            messagebox.showwarning("انتخاب پرونده", "برای تهیه گزارش، ابتدا پرونده حسابرسی را انتخاب کنید.")
            return
        try:
            result = ReportCenterService(self.db_path).build(project_id, definition["id"])
            self._current_standard_report = result
            self._render_standard_report(result)
        except (ValueError, OSError, tk.TclError) as exc:
            messagebox.showerror("خطای گزارش", str(exc))
        except Exception as exc:
            messagebox.showerror("خطای گزارش", f"تهیه گزارش با خطا مواجه شد:\n{exc}")

    def _render_standard_report(self, result):
        tree = self.report_preview_tree
        for child in tree.get_children():
            tree.delete(child)
        columns = result.get("columns") or ["پیام"]
        tree.configure(columns=columns, show="headings")
        for column in columns:
            tree.heading(column, text=column)
            tree.column(column, width=max(125, min(260, len(str(column)) * 16)), anchor="e", stretch=True)
        rows = result.get("rows", [])
        for row in rows:
            tree.insert("", "end", values=[self._report_cell(row.get(column, "")) for column in columns])
        project = result.get("project", {})
        self.report_status_label.configure(
            text=f'گزارش: {result["report"]["title"]}  |  پرونده: {project.get("name", "")}  |  '
                 f'تعداد ردیف: {result.get("row_count", 0)}  |  زمان تهیه: {result.get("generated_at", "")}'
        )

    @staticmethod
    def _report_cell(value):
        if value is None:
            return ""
        if isinstance(value, (dict, list, tuple)):
            return json.dumps(value, ensure_ascii=False, default=str)
        return str(value)

    def _export_standard_report_csv(self):
        self._export_standard_report("csv")

    def _export_standard_report_json(self):
        self._export_standard_report("json")

    def _export_standard_report(self, file_type):
        result = self._current_standard_report
        if not result:
            messagebox.showwarning("گزارش", "ابتدا گزارش را تهیه کنید.")
            return
        extension = ".csv" if file_type == "csv" else ".json"
        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش", defaultextension=extension,
            filetypes=[("CSV", "*.csv")] if file_type == "csv" else [("JSON", "*.json")]
        )
        if not path:
            return
        try:
            if file_type == "json":
                with open(path, "w", encoding="utf-8") as output:
                    json.dump(result, output, ensure_ascii=False, indent=2, default=str)
            else:
                with open(path, "w", newline="", encoding="utf-8-sig") as output:
                    writer = csv.writer(output)
                    writer.writerow(["گزارش", result["report"]["title"]])
                    writer.writerow(["حوزه", result["report"]["category"]])
                    writer.writerow(["پرونده", result["project"].get("name", "")])
                    writer.writerow(["شناسه پرونده", result["project_id"]])
                    writer.writerow(["زمان تهیه", result["generated_at"]])
                    writer.writerow([])
                    columns = result.get("columns", [])
                    writer.writerow(columns)
                    for row in result.get("rows", []):
                        writer.writerow([self._report_cell(row.get(column, "")) for column in columns])
                    writer.writerow([])
                    writer.writerow(["یادداشت‌های گزارش"])
                    for note in result.get("report_notes", []):
                        writer.writerow([note])
                    writer.writerow(["ملاحظات و محدودیت‌ها"])
                    for note in result.get("limitations", []):
                        writer.writerow([note])
            messagebox.showinfo("ذخیره گزارش", f"گزارش با موفقیت ذخیره شد:\n{path}")
        except OSError as exc:
            messagebox.showerror("خطای ذخیره", str(exc))

    def _export_standard_report_xlsx(self):
        result = self._current_standard_report
        if not result:
            messagebox.showwarning("گزارش", "ابتدا گزارش را تهیه کنید.")
            return
        path = filedialog.asksaveasfilename(title="ذخیره گزارش Excel", defaultextension=".xlsx", filetypes=[("Excel Workbook", "*.xlsx")])
        if not path: return
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
            wb = Workbook(); ws = wb.active; ws.title = "گزارش"; ws.sheet_view.rightToLeft = True
            metadata = [("عنوان گزارش", result.get("report", {}).get("title", "")), ("حوزه", result.get("report", {}).get("category", "")), ("پرونده", result.get("project", {}).get("name", "")), ("شناسه پرونده", result.get("project_id", "")), ("زمان تهیه", result.get("generated_at", "")), ("تعداد ردیف", result.get("row_count", 0))]
            for item in metadata: ws.append(list(item))
            ws.append([]); columns = result.get("columns", []) or ["پیام"]; ws.append(columns)
            for row in result.get("rows", []): ws.append([self._report_cell(row.get(col, "")) for col in columns] if result.get("columns") else [""])
            header_row = len(metadata) + 2
            for cell in ws[header_row]: cell.font = Font(name="Tahoma", bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor="14283F")
            for row in ws.iter_rows():
                for cell in row: cell.font = Font(name="Tahoma", size=10); cell.alignment = Alignment(horizontal="right", vertical="top", wrap_text=True)
            for idx, cells in enumerate(ws.columns, 1): ws.column_dimensions[get_column_letter(idx)].width = min(45, max(14, max((len(str(c.value or "")) for c in cells), default=0) + 2))
            ws.freeze_panes = f"A{header_row + 1}"
            if result.get("report_notes") or result.get("limitations"):
                notes = wb.create_sheet("ملاحظات"); notes.sheet_view.rightToLeft = True
                if result.get("report_notes"):
                    notes.append(["یادداشت‌های تهیه و استفاده از گزارش"])
                    for note in result["report_notes"]: notes.append([str(note)])
                if result.get("limitations"):
                    notes.append([]); notes.append(["ملاحظات و محدودیت‌ها"])
                    for note in result["limitations"]: notes.append([str(note)])
                for row in notes.iter_rows():
                    for cell in row:
                        cell.font = Font(name="Tahoma", size=10, bold=cell.row in (1, len(result.get("report_notes", [])) + 3))
                        cell.alignment = Alignment(horizontal="right", vertical="top", wrap_text=True)
                notes.column_dimensions["A"].width = 110
            wb.save(path); messagebox.showinfo("ذخیره گزارش", f"فایل Excel ذخیره شد:\n{path}")
        except Exception as exc: messagebox.showerror("خطای Excel", f"ساخت فایل Excel ناموفق بود:\n{exc}")

    def _export_standard_report_pdf(self):
        result = self._current_standard_report
        if not result:
            messagebox.showwarning("گزارش", "ابتدا گزارش را تهیه کنید."); return
        path = filedialog.asksaveasfilename(title="ذخیره گزارش PDF", defaultextension=".pdf", filetypes=[("PDF Document", "*.pdf")])
        if not path: return
        try:
            import os
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.enums import TA_RIGHT
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            win_fonts = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
            font_path = next((os.path.join(win_fonts, f) for f in ("tahoma.ttf", "arial.ttf") if os.path.isfile(os.path.join(win_fonts, f))), None)
            font_name = "Helvetica"
            if font_path:
                font_name = "AuditTahoma"
                if font_name not in pdfmetrics.getRegisteredFontNames(): pdfmetrics.registerFont(TTFont(font_name, font_path))
            try:
                import arabic_reshaper
                from bidi.algorithm import get_display
                def rtl(v): return get_display(arabic_reshaper.reshape(str(v)))
            except Exception:
                def rtl(v): return str(v)
            styles = getSampleStyleSheet()
            body = ParagraphStyle("AuditBody", parent=styles["BodyText"], fontName=font_name, fontSize=8, leading=12, alignment=TA_RIGHT)
            title = ParagraphStyle("AuditTitle", parent=styles["Title"], fontName=font_name, fontSize=15, leading=20, alignment=TA_RIGHT)
            story = [Paragraph(rtl(result.get("report", {}).get("title", "گزارش حسابرسی")), title), Spacer(1, 10)]
            for label, value in [("حوزه", result.get("report", {}).get("category", "")), ("پرونده", result.get("project", {}).get("name", "")), ("شناسه پرونده", result.get("project_id", "")), ("زمان تهیه", result.get("generated_at", ""))]: story.append(Paragraph(rtl(f"{label}: {value}"), body))
            story.append(Spacer(1, 8)); columns = result.get("columns", []) or ["پیام"]
            data = [[Paragraph(rtl(c), body) for c in columns]]
            for row in result.get("rows", []):
                vals = [self._report_cell(row.get(c, "")) for c in columns] if result.get("columns") else [""]
                data.append([Paragraph(rtl(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"), body) for v in vals])
            table = Table(data, repeatRows=1)
            table.setStyle(TableStyle([("BACKGROUND", (0,0),(-1,0),colors.HexColor("#14283F")), ("TEXTCOLOR",(0,0),(-1,0),colors.white), ("GRID",(0,0),(-1,-1),0.35,colors.HexColor("#CBD5E1")), ("VALIGN",(0,0),(-1,-1),"TOP"), ("ALIGN",(0,0),(-1,-1),"RIGHT"), ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F4F6F9")])]))
            story.append(table)
            if result.get("report_notes"):
                story.extend([Spacer(1, 8), Paragraph(rtl("یادداشت‌های تهیه و استفاده از گزارش"), body)])
                for note in result["report_notes"]: story.append(Paragraph(rtl("• " + str(note)), body))
            if result.get("limitations"):
                story.extend([Spacer(1, 8), Paragraph(rtl("ملاحظات و محدودیت‌ها"), body)])
                for note in result["limitations"]: story.append(Paragraph(rtl("• " + str(note)), body))
            SimpleDocTemplate(path, pagesize=landscape(A4) if len(columns)>4 else A4, rightMargin=28, leftMargin=28, topMargin=30, bottomMargin=30).build(story)
            messagebox.showinfo("ذخیره گزارش", f"فایل PDF ذخیره شد:\n{path}")
        except Exception as exc: messagebox.showerror("خطای PDF", f"ساخت فایل PDF ناموفق بود:\n{exc}")

    def _export_official_report_docx(self):
        result = self._current_standard_report
        if not result:
            messagebox.showwarning("گزارش رسمی", "ابتدا گزارش را تهیه کنید.")
            return
        path = filedialog.asksaveasfilename(
            title="ذخیره گزارش رسمی Word", defaultextension=".docx",
            filetypes=[("Word Document", "*.docx")]
        )
        if not path:
            return
        try:
            build_official_docx(result, path)
            messagebox.showinfo("گزارش رسمی", f"گزارش Word ذخیره شد:\n{path}")
        except Exception as exc:
            messagebox.showerror("خطای گزارش Word", f"ساخت گزارش رسمی با خطا مواجه شد:\n{exc}")

    def _run_intelligent_report_draft(self):
        project_id = self.get_current_project_id()
        if not project_id:
            messagebox.showwarning("پیش‌نویس هوشمند", "ابتدا پرونده حسابرسی را انتخاب کنید.")
            return
        try:
            draft = IntelligentReportDraftService(self.db_path).build(project_id)
            self._current_intelligent_draft = draft
            tree = self.report_preview_tree
            for child in tree.get_children(): tree.delete(child)
            columns = ("بخش", "متن پیش‌نویس")
            tree.configure(columns=columns, show="headings")
            for col in columns: tree.heading(col, text=col); tree.column(col, width=400 if col == columns[0] else 850, anchor="e")
            for section, lines in draft.get("sections", {}).items():
                tree.insert("", "end", values=(section, "\n".join(lines)))
            self.report_status_label.configure(text=f"پیش‌نویس هوشمند | پرونده: {draft.get('project',{}).get('name','')} | فقط بر پایه داده‌های ثبت‌شده؛ نیازمند بازبینی")
        except Exception as exc:
            messagebox.showerror("خطای پیش‌نویس", f"ساخت پیش‌نویس با خطا مواجه شد:\n{exc}")

    def _export_intelligent_draft_docx(self):
        draft = getattr(self, "_current_intelligent_draft", None)
        if not draft:
            messagebox.showwarning("پیش‌نویس", "ابتدا پیش‌نویس هوشمند را تهیه کنید.")
            return
        path = filedialog.asksaveasfilename(title="ذخیره پیش‌نویس Word", defaultextension=".docx", filetypes=[("Word Document", "*.docx")])
        if not path: return
        try:
            export_draft_docx(draft, path)
            messagebox.showinfo("پیش‌نویس Word", f"فایل پیش‌نویس ذخیره شد:\n{path}")
        except Exception as exc:
            messagebox.showerror("خطا", f"ذخیره پیش‌نویس ناموفق بود:\n{exc}")
