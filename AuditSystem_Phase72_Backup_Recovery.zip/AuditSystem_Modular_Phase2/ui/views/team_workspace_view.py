"""Interactive team communications workspace (Phase 59)."""
import tkinter as tk
from tkinter import ttk, messagebox


class TeamWorkspaceViewMixin:
    def setup_team_workspace_tab(self):
        root = self.tab_team_workspace
        intro = ttk.Frame(root, style="Card.TFrame", padding=10)
        intro.pack(fill="x", padx=10, pady=(8, 5))
        ttk.Label(intro, text="مرکز ارتباطات تیم حسابرسی", style="Header.TLabel").pack(anchor="e")
        ttk.Label(intro, text="صندوق ورودی، گفت‌وگوی کاربرگ و ارجاع درخواست بررسی در یک فضای کاری واحد", style="Muted.TLabel").pack(anchor="e", pady=(3, 0))

        controls = ttk.Frame(root, padding=(10, 4))
        controls.pack(fill="x")
        ttk.Label(controls, text="کاربرگ:").pack(side="right", padx=(8, 3))
        self.team_workspace_workpaper = ttk.Combobox(controls, state="readonly", width=42, justify="right")
        self.team_workspace_workpaper.pack(side="right", padx=3)
        self.team_workspace_workpaper.bind("<<ComboboxSelected>>", self._team_workspace_workpaper_changed)
        ttk.Button(controls, text="به‌روزرسانی", command=self.refresh_team_workspace).pack(side="right", padx=6)

        panes = ttk.Panedwindow(root, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=10, pady=6)
        inbox_frame = ttk.LabelFrame(panes, text="صندوق ورودی و ارجاعات", padding=6)
        thread_frame = ttk.LabelFrame(panes, text="گفت‌وگوی کاربرگ", padding=6)
        panes.add(inbox_frame, weight=1)
        panes.add(thread_frame, weight=2)
        self.team_workspace_inbox = ttk.Treeview(inbox_frame, columns=("id", "workpaper", "type", "author", "date"), show="headings", height=12)
        for col, label, width in (("id", "شناسه", 48), ("workpaper", "کاربرگ", 150), ("type", "نوع", 100), ("author", "فرستنده", 100), ("date", "تاریخ", 120)):
            self.team_workspace_inbox.heading(col, text=label)
            self.team_workspace_inbox.column(col, width=width, anchor="e")
        self.team_workspace_inbox.pack(fill="both", expand=True)
        self.team_workspace_inbox.bind("<<TreeviewSelect>>", self._team_workspace_inbox_selected)

        self.team_workspace_thread = ttk.Treeview(thread_frame, columns=("date", "type", "author", "recipient", "body"), show="headings", height=12)
        for col, label, width in (("date", "زمان", 120), ("type", "نوع رویداد", 100), ("author", "ثبت‌کننده", 105), ("recipient", "دریافت‌کننده", 105), ("body", "متن پیام / توضیحات", 360)):
            self.team_workspace_thread.heading(col, text=label)
            self.team_workspace_thread.column(col, width=width, anchor="e")
        self.team_workspace_thread.pack(fill="both", expand=True)

        compose = ttk.LabelFrame(root, text="ثبت پیام یا درخواست بررسی", padding=9)
        compose.pack(fill="x", padx=10, pady=(2, 10))
        row = ttk.Frame(compose)
        row.pack(fill="x")
        ttk.Label(row, text="دریافت‌کننده:").pack(side="right", padx=4)
        self.team_workspace_recipient = ttk.Combobox(row, state="readonly", width=34, justify="right")
        self.team_workspace_recipient.pack(side="right", padx=4)
        self.team_workspace_recipient.bind("<<ComboboxSelected>>", self._team_workspace_recipient_changed)
        ttk.Label(row, text="نوع:").pack(side="right", padx=(12, 4))
        self.team_workspace_event = ttk.Combobox(row, state="readonly", values=["نظر / پیام", "درخواست بررسی"], width=18, justify="right")
        self.team_workspace_event.current(0)
        self.team_workspace_event.pack(side="right", padx=4)
        self.team_workspace_message = tk.Text(compose, height=3, wrap="word", font=("Tahoma", 9))
        self.team_workspace_message.pack(fill="x", pady=7)
        routing = ttk.Frame(compose)
        routing.pack(fill="x", pady=(0, 5))
        ttk.Label(routing, text="ارجاع کاربرگ — حسابرس مسئول:").pack(side="right", padx=4)
        self.team_workspace_assignee = ttk.Combobox(routing, state="readonly", width=27, justify="right")
        self.team_workspace_assignee.pack(side="right", padx=4)
        ttk.Label(routing, text="سرپرست بررسی:").pack(side="right", padx=4)
        self.team_workspace_reviewer = ttk.Combobox(routing, state="readonly", width=27, justify="right")
        self.team_workspace_reviewer.pack(side="right", padx=4)
        actions = ttk.Frame(compose)
        actions.pack(fill="x")
        ttk.Button(actions, text="ارسال پیام / درخواست بررسی", command=self.send_team_workspace_message).pack(side="right", padx=4)
        ttk.Button(actions, text="ارجاع و تخصیص کاربرگ", command=self.route_team_workspace_workpaper).pack(side="right", padx=4)
        ttk.Label(actions, text="سوابق ارتباطی قابل ویرایش یا حذف نیستند.", style="Muted.TLabel").pack(side="right", padx=10)
        self.refresh_team_workspace()

    def refresh_team_workspace(self):
        if not hasattr(self, "team_workspace_inbox"):
            return
        project_id = self.get_current_project_id()
        self.team_workspace_inbox.delete(*self.team_workspace_inbox.get_children())
        self.team_workspace_thread.delete(*self.team_workspace_thread.get_children())
        self._team_workspace_workpaper_rows = []
        self._team_workspace_member_rows = []
        if not project_id:
            self.team_workspace_workpaper["values"] = []
            self.team_workspace_recipient["values"] = []
            return
        self._team_workspace_workpaper_rows = self.services.workpapers.for_project(project_id)
        self.team_workspace_workpaper["values"] = [f"{r[0]} - {r[1]}" for r in self._team_workspace_workpaper_rows]
        self._team_workspace_member_rows = self.services.team.for_project(project_id, active_only=True)
        self.team_workspace_recipient["values"] = [f"{r[0]} - {r[1]} ({r[2]})" for r in self._team_workspace_member_rows]
        auditors = [r for r in self._team_workspace_member_rows if r[2] in ("حسابرس", "حسابرس ارشد")]
        supervisors = [r for r in self._team_workspace_member_rows if r[2] == "سرپرست حسابرسی"]
        self._team_workspace_assignees = auditors
        self._team_workspace_reviewers = supervisors
        self.team_workspace_assignee["values"] = [f"{r[0]} - {r[1]}" for r in auditors]
        self.team_workspace_reviewer["values"] = [f"{r[0]} - {r[1]}" for r in supervisors]
        if auditors and self.team_workspace_assignee.current() < 0:
            self.team_workspace_assignee.current(0)
        if supervisors and self.team_workspace_reviewer.current() < 0:
            self.team_workspace_reviewer.current(0)
        member = self.get_active_member()
        if member:
            for row in self._team_workspace_member_rows:
                if row[0] != member["id"]:
                    continue
                # Keep the active member as the communication identity; recipient is selected separately.
        if self.team_workspace_workpaper["values"] and self.team_workspace_workpaper.current() < 0:
            self.team_workspace_workpaper.current(0)
        if self.team_workspace_recipient["values"] and self.team_workspace_recipient.current() < 0:
            self.team_workspace_recipient.current(0)
        if member:
            for item in self.services.team_communications.inbox(project_id, member["id"]):
                self.team_workspace_inbox.insert("", "end", iid=str(item["id"]), values=(item["id"], item["workpaper_title"], item["event_type"], item["author"], item["created_at"]))
        self._team_workspace_workpaper_changed()

    def _team_workspace_workpaper_changed(self, _event=None):
        if not hasattr(self, "team_workspace_thread"):
            return
        self.team_workspace_thread.delete(*self.team_workspace_thread.get_children())
        index = self.team_workspace_workpaper.current()
        if index < 0 or index >= len(getattr(self, "_team_workspace_workpaper_rows", [])):
            return
        project_id = self.get_current_project_id()
        workpaper_id = self._team_workspace_workpaper_rows[index][0]
        for item in self.services.team_communications.thread(project_id, workpaper_id):
            self.team_workspace_thread.insert("", "end", values=(item["created_at"], item["event_type"], item["author"] or "—", item["recipient"] or "—", item["body"]))

    def _team_workspace_inbox_selected(self, _event=None):
        selected = self.team_workspace_inbox.selection()
        if not selected:
            return
        vals = self.team_workspace_inbox.item(selected[0], "values")
        workpaper_id = int(vals[0]) if False else None
        # Inbox row iid is communication id; resolve workpaper id from service data.
        member = self.get_active_member()
        if not member:
            return
        for item in self.services.team_communications.inbox(self.get_current_project_id(), member["id"]):
            if str(item["id"]) == selected[0]:
                for idx, wp in enumerate(self._team_workspace_workpaper_rows):
                    if wp[0] == item["workpaper_id"]:
                        self.team_workspace_workpaper.current(idx)
                        self._team_workspace_workpaper_changed()
                        break
                break

    def route_team_workspace_workpaper(self):
        project_id = self.get_current_project_id()
        actor = self.get_active_member()
        wp_index = self.team_workspace_workpaper.current()
        assignee_index = self.team_workspace_assignee.current()
        reviewer_index = self.team_workspace_reviewer.current()
        if not project_id or not actor:
            messagebox.showwarning("انتخاب عضو", "ابتدا پرونده و عضو فعال را انتخاب کنید.")
            return
        if wp_index < 0 or wp_index >= len(self._team_workspace_workpaper_rows):
            messagebox.showwarning("انتخاب کاربرگ", "ابتدا کاربرگ موردنظر را انتخاب کنید.")
            return
        if assignee_index < 0 or reviewer_index < 0:
            messagebox.showwarning("تخصیص مسئول", "یک حسابرس مسئول و یک سرپرست بررسی‌کننده انتخاب کنید.")
            return
        workpaper_id = self._team_workspace_workpaper_rows[wp_index][0]
        assignee_id = self._team_workspace_assignees[assignee_index][0]
        reviewer_id = self._team_workspace_reviewers[reviewer_index][0]
        try:
            self.services.team_communications.route_workpaper(
                project_id, workpaper_id, actor["id"], assignee_id, reviewer_id,
                "ارجاع از مرکز ارتباطات تیم"
            )
        except Exception as exc:
            messagebox.showerror("ارجاع ناموفق", str(exc))
            return
        self.refresh_team_workspace()
        messagebox.showinfo("ارجاع موفق", "مسئول اجرا و سرپرست بررسی کاربرگ تعیین شدند و رویداد در تاریخچه ثبت شد.")

    def _team_workspace_recipient_changed(self, _event=None):
        return None

    def send_team_workspace_message(self):
        project_id = self.get_current_project_id()
        author = self.get_active_member()
        wp_index = self.team_workspace_workpaper.current()
        recipient_index = self.team_workspace_recipient.current()
        body = self.team_workspace_message.get("1.0", "end").strip()
        if not project_id or not author:
            messagebox.showwarning("انتخاب عضو", "ابتدا پرونده و عضو فعال را انتخاب کنید.")
            return
        if wp_index < 0 or wp_index >= len(self._team_workspace_workpaper_rows):
            messagebox.showwarning("انتخاب کاربرگ", "ابتدا کاربرگ موردنظر را انتخاب کنید.")
            return
        if recipient_index < 0 or recipient_index >= len(self._team_workspace_member_rows):
            messagebox.showwarning("دریافت‌کننده", "یک دریافت‌کننده فعال انتخاب کنید.")
            return
        workpaper_id = self._team_workspace_workpaper_rows[wp_index][0]
        recipient_id = self._team_workspace_member_rows[recipient_index][0]
        try:
            if self.team_workspace_event.get() == "درخواست بررسی":
                self.services.team_communications.request_review(project_id, workpaper_id, author["id"], recipient_id, body)
            else:
                self.services.team_communications.add_comment(project_id, workpaper_id, author["id"], body, recipient_id)
        except (ValueError, Exception) as exc:
            messagebox.showerror("ثبت ارتباط ناموفق", str(exc))
            return
        self.team_workspace_message.delete("1.0", "end")
        self.refresh_team_workspace()
        messagebox.showinfo("ثبت موفق", "ارتباط در تاریخچه کاربرگ ثبت شد.")
