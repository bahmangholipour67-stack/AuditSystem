@echo off
setlocal
cd /d "%~dp0"
echo Checking AuditSystem database (read-only)...
py -3.12 scripts\check_database_health.py
if errorlevel 1 (
  echo.
  echo Database check did not complete successfully. Review the message above.
)
echo.
pause
endlocal
