# Phase 47 — Unified Navigation

## Purpose
Consolidate user-facing navigation into one sidebar and one workspace. The global workspace-tab strip has been removed.

## Implemented
- The right-side module sidebar remains the sole user-facing module navigator.
- The duplicate global horizontal workspace tab strip and its scrollbar are removed.
- The selected module is indicated by the workspace title and active sidebar button.
- The existing ttk Notebook remains hidden as an internal frame host for compatibility with existing view mixins and callbacks; its tab strip is not exposed.
- Existing module frames, data services, and setup routines are retained.

## Validation caveat
Automated tests validate the Python package. GUI appearance and navigation behavior must still be smoke-tested on Windows in a graphical environment.
