# Phase 58 — Team Communications & Workpaper Routing

This phase adds a project-scoped, append-only communication engine for audit teams.

- Workpaper comments with optional recipient.
- Review requests routed only to an active supervisor in the same engagement.
- A recipient inbox and chronological workpaper thread.
- Routing integration that delegates assignment validation to the existing `WorkpaperRepository` workflow rules and records the routing event.
- Append-only database triggers prevent edits/deletions of communication history.
- Existing workpaper approval states and workpaper history remain unchanged.

The migration is additive and is run through the existing `ensure_schema()` startup path. No existing rows are rewritten.

The service is exposed as `app.services.team_communications`. This phase delivers the tested service/database layer; a dedicated visual communication workspace and notification integration are a subsequent UI phase.
