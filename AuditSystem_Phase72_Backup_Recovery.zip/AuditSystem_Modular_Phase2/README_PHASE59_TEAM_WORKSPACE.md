# Phase 59 – Team Communications Workspace

## Overview
Adds a dedicated **مرکز ارتباطات تیم** workspace to the existing unified right-side navigation. The page brings together project-scoped inbox items, the selected workpaper's communication history, message/comment submission, review requests, and workpaper assignment through the existing workflow repository.

## User workflow
1. Open a project and select the active team member in the application header.
2. Open **مرکز ارتباطات تیم** from the main navigation.
3. Select a workpaper to inspect its immutable communication history.
4. Select an active recipient and submit a comment/message or a review request.
5. To assign a workpaper, select an eligible auditor and a supervisor, then use **ارجاع و تخصیص کاربرگ**. Existing workflow rules validate roles and workpaper state.
6. Inbox items addressed to the active member appear in the left pane. Selecting one opens the related workpaper thread.

## Safeguards
- All reads and writes are scoped to the currently selected project.
- The active member is used as the author/actor; a member must be selected first.
- Review requests continue to enforce the existing supervisor-role rule.
- Assignment continues to use `WorkpaperRepository.update_assignment`, including its role and workpaper-state validations.
- Communication history remains append-only; this phase does not add edit/delete controls.
- No database schema migration is introduced in this phase.

## Validation
- Python compilation: passed.
- Full test suite: **289 passed, 131 subtests passed**.
- Windows GUI interaction has not been visually verified in this environment; please confirm the new workspace on the target Windows installation.
