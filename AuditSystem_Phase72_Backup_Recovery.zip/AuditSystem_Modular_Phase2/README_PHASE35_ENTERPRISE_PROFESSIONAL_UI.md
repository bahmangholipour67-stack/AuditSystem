# Phase 35 — Enterprise Professional UI

## Changes
- Replaced the dominant pastel palette with a restrained enterprise palette: deep navy navigation, white work surfaces, cool light-gray workspace background, and a focused corporate blue accent.
- Restyled the right-side navigation as a dark sidebar with high-contrast labels, group headings, and a distinct selected-module state.
- Restyled primary actions, workspace tabs, and data tables for clearer hierarchy and improved readability.
- Retained the existing right-side navigation, module grouping, search/filter behavior, vertical sidebar scrolling, horizontal workspace-tab scrolling, and automatic visibility of the selected tab.
- Kept `self.palette` and `self.classic_palette` compatibility aliases and preserved all existing module frames, services, database code, and workflows.
- Kept `core/pastel_theme.py` as the module path for backward compatibility; it now exposes Enterprise Professional design tokens.

## Validation performed in the build environment
- `python -m compileall -q .`: passed.
- `PYTHONPATH=. pytest -q`: 227 passed, 131 subtests passed.
- GUI rendering was not launched in this Linux/headless environment; final visual confirmation should be performed on Windows with `python main.py`.

## Run
Open a terminal in the project directory and run:

```bash
python main.py
```
