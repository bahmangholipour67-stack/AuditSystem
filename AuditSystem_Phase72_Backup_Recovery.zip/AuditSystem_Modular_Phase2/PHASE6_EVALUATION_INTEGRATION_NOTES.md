# Phase 6 – Integrated audit-test evaluation

## What changed

- Added `misstatement_amount` to `audit_test_samples` through a safe additive database migration. Existing sample amounts and prior records are retained.
- Added a separate sample-level misstatement amount field to the audit-test screen. The existing `amount` field remains distinct and is not treated as a misstatement amount.
- Added type-aware evaluation from the selected audit test:
  - **Control tests:** maps confirmed sample results to observed deviations and compares the observed rate with the auditor-entered tolerable deviation rate.
  - **Substantive tests:** sums only recorded misstatement amounts. A confirmed pass is treated as zero; unresolved items and exceptions without an entered misstatement amount prevent a complete assessment.
  - **Analytical procedures:** compares actual and expected amounts against exactly one explicit amount or percentage threshold.
- The evaluation creates a draft in the conclusion field. It does not save the conclusion automatically; the auditor must review and explicitly save it.
- Limitations are shown with the evaluation. Sample results are not projected to the population and the software does not replace professional judgment.

## Operational notes

1. Replace the project folder with this complete version, keeping a backup of the existing project folder and database first.
2. Start the application normally. The existing startup migration adds the new nullable column without deleting existing data.
3. For substantive tests, enter the misstatement amount for each exception. Do not enter the sampled book value in that field.
4. For analytical procedures, enter actual, expected, and exactly one threshold type.
5. Review the generated draft and limitations before saving the formal conclusion.

## Verification performed

- Automated unit tests: 100 passed.
- Python compilation: 77 Python files, no compile errors.
- Imports: audit-test UI, service, repository, and migration modules imported successfully.
- Temporary SQLite migration check: new column present; `PRAGMA integrity_check` returned `ok`.
- Tkinter visual interaction was not run in this headless environment; the final screen should be opened on Windows for visual confirmation.
