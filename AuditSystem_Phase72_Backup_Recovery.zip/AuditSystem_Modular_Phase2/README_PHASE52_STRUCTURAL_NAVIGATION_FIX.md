# Phase 52 — Structural Unified Navigation Fix

## Why this correction was necessary
The prior UI hid the `ttk.Notebook` tab strip through a theme-specific style layout. That was not a structural guarantee and could still produce inconsistent results across Windows themes or when another style was applied.

## Changes
- Replaced the active application's `ttk.Notebook` page host with a plain `ttk.Frame` workspace host.
- Each existing module frame is gridded into the same workspace cell; navigation switches pages with `tkraise()`.
- Preserved the existing module frames, view mixins, setup routines, services, repositories, and database layer.
- Removed the dashboard's row of module-navigation shortcuts so the right sidebar remains the only global module-navigation surface.
- Kept dashboard search, refresh, export, and reporting actions because they are task actions, not alternate module navigation.
- Added regression tests proving that the active app contains no `ttk.Notebook` and that dashboard navigation shortcuts are absent.

## Validation
- `python -m compileall -q legacy/audit_app.py ui/views/dashboard_view.py`: passed.
- `python -m pytest -q`: 262 passed, 131 subtests passed.
- GUI rendering on the user's Windows desktop has not been directly observed in this environment; please validate the delivered package on that machine.

## Important
Run the application using the package's normal launcher and the `legacy/audit_app.py` active application entry. Older `legacy/audit_app_before_*.py` files are historical snapshots and are not the active application.
