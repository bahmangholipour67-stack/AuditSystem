@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_CMD=py -3.12"
echo Using Python 3.12 for AuditSystem.
%PYTHON_CMD% --version
if errorlevel 1 goto no_python
set "AUDITSYSTEM_DB_PATH=%~dp0demo_audit_system.db"
%PYTHON_CMD% demo_seed.py --db "%AUDITSYSTEM_DB_PATH%"
if errorlevel 1 (
  echo.
  echo ERROR: Demo database setup failed.
  pause
  exit /b 1
)
echo.
echo Demo data is ready. Starting AuditSystem...
%PYTHON_CMD% main.py
if errorlevel 1 (
  echo.
  echo ERROR: AuditSystem could not start.
  pause
  exit /b 1
)
endlocal
exit /b 0
:no_python
echo.
echo Python 3.12 was not found. Please install Python 3.12 (64-bit).
pause
exit /b 2
