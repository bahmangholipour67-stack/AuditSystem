# Phase 51 — Unified workspace header and contextual identity

## Delivered
- Replaced the standalone module title line with a consistent workspace header surface.
- Added a Persian breadcrumb (`سامانه ‹ گروه ماژول ‹ عنوان ماژول`) for orientation within the single-sidebar navigation model.
- Added a compact context line showing the selected engagement and, when selected, the active team member. Values are read from the existing project/member controls and state; no placeholder engagement data is fabricated.
- Refreshes the context line when the active project or team member changes.
- Centralized navigation-group lookup for the breadcrumb.
- Corrected sidebar active-state determination to use exact module identity. This also fixes the collapsed-sidebar path that referenced an undefined `button_title` variable.
- Preserved existing module frames, services, database schema, callbacks, and the single-navigation architecture.

## Validation
- `python -m compileall -q legacy/audit_app.py` — passed.
- `python -m pytest -q` — 260 passed, 131 subtests passed.
- ZIP integrity (`ZipFile.testzip`) — passed.

## Visual validation limitation
The Tkinter desktop window was not launched in a native Windows session in this environment. Header sizing, RTL rendering, and the collapse/expand appearance should receive a final visual check on the target Windows computer.
