# Phase 31 — Smart Dashboard & Workspace

## Scope
- Adds a compact smart-workspace panel to the existing dashboard.
- Provides project-scoped global search across supported audit records.
- Displays recent append-only history events from existing history tables.
- Adds quick navigation shortcuts to frequently used audit modules.
- Refreshes recent activity when the dashboard refreshes or the active engagement changes.

## Safety and data integrity
- Read-only queries only; this phase introduces no database migration and writes no audit data.
- Search and activity are restricted to the active engagement when one is selected.
- When no engagement is selected, supported records across engagements can be searched/viewed.
- The service discovers optional tables and columns at runtime to remain compatible with existing databases.
- Existing navigation, modules, repositories, services, and backup databases are retained.

## Known limitations
- The activity feed uses existing history tables. If the database has no history events, it falls back to creation/update timestamps on supported records.
- The search opens the relevant module and reports the selected record identifier; it does not yet open the exact record editor. Record-level deep links are a later enhancement.
- GUI appearance and resizing still need a smoke test on the user's Windows desktop.

## Run
```bash
python main.py
```
