# Phase 26 — Internal Control Assessment & Corrective Actions

## Delivered
- Project-scoped internal control register linked to risks.
- Control attributes: objective, owner, frequency, preventive/detective/corrective type, manual/automated/hybrid method, and criteria.
- Separate records for design, implementation, and operating-effectiveness tests, including sample size, exceptions, evidence reference, tester, and notes.
- Internal-control findings stored in the existing shared `findings` table (`finding_type='کنترل داخلی'`), with condition, criteria, cause, effect, likelihood, impact, and control linkage. Existing findings remain `عمومی` by default; financial-statement misstatements remain in their separate misstatement subsystem.
- Corrective action plans with owner, due date, milestones, progress, closure evidence, and follow-up result.
- Closure gate: a control finding cannot be closed unless at least one corrective action exists and every action is approved with closure evidence and a successful follow-up result.
- Append-only history protected by SQLite triggers; control records can be archived/restored without physical deletion.
- Integrated reporting sections and summary counts for controls, tests, internal-control findings, corrective actions, and history.
- New desktop tab: **17. کنترل‌های داخلی و اقدامات اصلاحی**.

## Database migration
`migrate_internal_control_engine` is included in `ensure_schema`. It is idempotent, adds nullable/compatible fields to the existing findings model, and creates project-scoped control, test, corrective-action, and history tables. A view (`internal_control_findings`) exposes only internal-control findings for reporting.

## Important professional limitations
- Test outcomes are recorded conclusions by the engagement team; the application does not independently determine control effectiveness.
- A text evidence reference is stored; this phase does not copy source documents into the evidence repository or verify their contents.
- Team-member names/roles are workflow attribution only; this phase does not implement authenticated user sessions or electronic signatures.
- The UI currently provides core control, test, finding, action, follow-up, and closure flows. Detailed edit/version workflows and automated overdue notifications remain future work.
- The application has been tested in the build environment, not on the user's Windows desktop. Tkinter visual behavior must be confirmed on that machine.

## Verification
Run from the project root:

```bash
python -m pytest -q
python -m compileall -q .
```
