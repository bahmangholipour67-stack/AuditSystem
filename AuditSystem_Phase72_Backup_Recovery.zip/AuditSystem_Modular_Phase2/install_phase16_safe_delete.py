# -*- coding: utf-8 -*-
"""Phase 16 safe-delete integration installer. Run: py install_phase16_safe_delete.py"""
from __future__ import annotations
import ast, datetime, shutil, sys, textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    "repositories/project_repository.py", "repositories/risk_repository.py",
    "repositories/workpaper_repository.py", "repositories/finding_repository.py",
    "ui/views/project_view.py", "ui/views/workpaper_view.py",
    "ui/views/finding_view.py", "ui/views/record_navigation.py",
]

def read(rel):
    p = ROOT / rel
    if not p.is_file():
        raise FileNotFoundError(f"فایل پیدا نشد: {rel}")
    return p.read_text(encoding="utf-8-sig")

def validate(src, rel):
    compile(src, rel, "exec")

def replace_method(src, cls_name, meth_name, body, rel):
    tree = ast.parse(src, filename=rel)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls_name), None)
    if cls is None:
        raise RuntimeError(f"کلاس {cls_name} پیدا نشد: {rel}")
    node = next((n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == meth_name), None)
    if node is None:
        raise RuntimeError(f"متد {cls_name}.{meth_name} پیدا نشد: {rel}")
    lines = src.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = [
        textwrap.indent(textwrap.dedent(body).strip("\n"), "    ") + "\n"
    ]
    return "".join(lines)

def append_method(src, cls_name, body, rel):
    tree = ast.parse(src, filename=rel)
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls_name), None)
    if cls is None or cls is not tree.body[-1]:
        raise RuntimeError(f"ساختار کلاس {cls_name} در {rel} مطابق انتظار نیست.")
    return src.rstrip() + "\n\n" + textwrap.indent(textwrap.dedent(body).strip("\n"), "    ") + "\n"

def add_connect(src):
    if "from database.connection import connect" not in src:
        src = "from database.connection import connect\n" + src
    return src

def once(src, old, new, rel):
    if src.count(old) != 1:
        raise RuntimeError(f"الگوی اتصال رابط در {rel} دقیقاً یک‌بار پیدا نشد.")
    return src.replace(old, new, 1)

def install():
    old = {f: read(f) for f in FILES}
    new = dict(old)

    new["repositories/project_repository.py"] = add_connect(new["repositories/project_repository.py"])
    new["repositories/project_repository.py"] = append_method(new["repositories/project_repository.py"], "ProjectRepository", """
def delete(self, project_id):
    if not project_id:
        raise ValueError("شناسه پرونده معتبر نیست.")
    with connect() as conn:
        if not conn.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone():
            raise ValueError("پرونده موردنظر پیدا نشد.")
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
        deps = []
        for (name,) in tables:
            if name == "projects":
                continue
            q = '"' + str(name).replace('"', '""') + '"'
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
            if "project_id" in cols:
                n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=?", (project_id,)).fetchone()[0]
                if n:
                    deps.append(f"{name}: {n}")
        if deps:
            raise ValueError("پرونده دارای اطلاعات وابسته است و حذف نمی‌شود: " + "، ".join(deps))
        conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
    return True
""", "repositories/project_repository.py")

    new["repositories/risk_repository.py"] = add_connect(new["repositories/risk_repository.py"])
    new["repositories/risk_repository.py"] = replace_method(new["repositories/risk_repository.py"], "RiskRepository", "delete", """
def delete(self, risk_id):
    if not risk_id:
        raise ValueError("شناسه ریسک معتبر نیست.")
    with connect() as conn:
        row = conn.execute("SELECT id, project_id FROM risks WHERE id=?", (risk_id,)).fetchone()
        if not row:
            raise ValueError("ریسک موردنظر پیدا نشد.")
        pid = row[1]
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
        deps = []
        for (name,) in tables:
            if name == "risks":
                continue
            q = '"' + str(name).replace('"', '""') + '"'
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
            if {"project_id", "risk_id"}.issubset(cols):
                n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND risk_id=?", (pid, risk_id)).fetchone()[0]
                if n:
                    deps.append(f"{name}: {n}")
        if deps:
            raise ValueError("این ریسک دارای ارجاع وابسته است و حذف نمی‌شود: " + "، ".join(deps))
        conn.execute("DELETE FROM risks WHERE id=? AND project_id=?", (risk_id, pid))
    return True
""", "repositories/risk_repository.py")

    new["repositories/workpaper_repository.py"] = append_method(new["repositories/workpaper_repository.py"], "WorkpaperRepository", """
def delete(self, project_id, workpaper_id):
    if not project_id or not workpaper_id:
        raise ValueError("پرونده و شناسه کاربرگ باید مشخص باشند.")
    with connect() as conn:
        row = conn.execute("SELECT status FROM workpapers WHERE id=? AND project_id=?", (workpaper_id, project_id)).fetchone()
        if not row:
            raise ValueError("کاربرگ موردنظر در این پرونده پیدا نشد.")
        if row[0] != self.STATUS_DRAFT:
            raise ValueError("فقط کاربرگ پیش‌نویس قابل حذف است؛ سایر وضعیت‌ها باید در سوابق باقی بمانند.")
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
        deps = []
        for (name,) in tables:
            if name == "workpapers":
                continue
            q = '"' + str(name).replace('"', '""') + '"'
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
            if {"project_id", "workpaper_id"}.issubset(cols):
                n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND workpaper_id=?", (project_id, workpaper_id)).fetchone()[0]
                if n:
                    deps.append(f"{name}: {n}")
        if deps:
            raise ValueError("این کاربرگ دارای ارتباط یا سابقه ثبت‌شده است و حذف نمی‌شود: " + "، ".join(deps))
        conn.execute("DELETE FROM workpapers WHERE id=? AND project_id=?", (workpaper_id, project_id))
    return True
""", "repositories/workpaper_repository.py")

    new["repositories/finding_repository.py"] = append_method(new["repositories/finding_repository.py"], "FindingRepository", """
def delete(self, project_id, finding_id):
    if not project_id or not finding_id:
        raise ValueError("پرونده و شناسه یافته باید مشخص باشند.")
    with connect() as conn:
        row = conn.execute("SELECT status FROM findings WHERE id=? AND project_id=?", (finding_id, project_id)).fetchone()
        if not row:
            raise ValueError("یافته موردنظر در این پرونده پیدا نشد.")
        if row[0] != "باز":
            raise ValueError("فقط یافته باز قابل حذف است؛ یافته رفع‌شده باید در سوابق باقی بماند.")
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
        deps = []
        for (name,) in tables:
            if name == "findings":
                continue
            q = '"' + str(name).replace('"', '""') + '"'
            cols = {r[1] for r in conn.execute(f"PRAGMA table_info({q})").fetchall()}
            if {"project_id", "finding_id"}.issubset(cols):
                n = conn.execute(f"SELECT COUNT(*) FROM {q} WHERE project_id=? AND finding_id=?", (project_id, finding_id)).fetchone()[0]
                if n:
                    deps.append(f"{name}: {n}")
        if deps:
            raise ValueError("این یافته دارای مستند یا ارجاع وابسته است و حذف نمی‌شود: " + "، ".join(deps))
        conn.execute("DELETE FROM findings WHERE id=? AND project_id=?", (finding_id, project_id))
    return True
""", "repositories/finding_repository.py")

    nav = new["ui/views/record_navigation.py"]
    nav = once(nav, 'def add_record_navigation(self, parent, tree, *, on_edit=None, label="رکورد"):',
               'def add_record_navigation(self, parent, tree, *, on_edit=None, on_delete=None, label="رکورد"):', "ui/views/record_navigation.py")
    nav = once(nav,
        '        if on_edit:\n            ttk.Button(bar, text="ویرایش رکورد انتخاب‌شده", command=on_edit).pack(side="left", padx=2)\n',
        '        if on_edit:\n            ttk.Button(bar, text="ویرایش رکورد انتخاب‌شده", command=on_edit).pack(side="left", padx=2)\n        if on_delete:\n            ttk.Button(bar, text="حذف رکورد انتخاب‌شده", command=on_delete).pack(side="left", padx=2)\n',
        "ui/views/record_navigation.py")
    new["ui/views/record_navigation.py"] = nav

    p = "ui/views/project_view.py"
    new[p] = once(new[p],
        'self.add_record_navigation(tab, self.tree_projects, on_edit=self.edit_selected_project, label="پرونده")',
        'self.add_record_navigation(tab, self.tree_projects, on_edit=self.edit_selected_project, on_delete=self.delete_selected_project, label="پرونده")', p)
    new[p] = append_method(new[p], "ProjectViewMixin", """
def delete_selected_project(self):
    selected = self.tree_projects.selection()
    if not selected:
        messagebox.showinfo("انتخاب پرونده", "ابتدا یک پرونده را انتخاب کنید.")
        return
    project_id = int(self.tree_projects.item(selected[0], "values")[0])
    if not messagebox.askyesno("تأیید حذف پرونده", "فقط پرونده‌ای که هیچ اطلاعات وابسته‌ای ندارد حذف می‌شود. آیا ادامه می‌دهید؟"):
        return
    try:
        self.services.projects.delete(project_id)
        self.refresh_project_list()
        self.load_projects()
        messagebox.showinfo("حذف پرونده", "پرونده خالی با موفقیت حذف شد.")
    except ValueError as exc:
        messagebox.showwarning("حذف پرونده ممکن نیست", str(exc))
    except Exception as exc:
        messagebox.showerror("خطا در حذف پرونده", str(exc))
""", p)

    p = "ui/views/workpaper_view.py"
    new[p] = once(new[p],
        'self.add_record_navigation(self.tab_workpapers, self.tree_wps, on_edit=self.edit_selected_workpaper, label="کاربرگ")',
        'self.add_record_navigation(self.tab_workpapers, self.tree_wps, on_edit=self.edit_selected_workpaper, on_delete=self.delete_selected_workpaper, label="کاربرگ")', p)
    new[p] = append_method(new[p], "WorkpaperViewMixin", """
def delete_selected_workpaper(self):
    selected = self.tree_wps.selection()
    if not selected:
        messagebox.showinfo("انتخاب کاربرگ", "ابتدا یک کاربرگ را انتخاب کنید.")
        return
    vals = self.tree_wps.item(selected[0], "values")
    pid = self.get_current_project_id()
    if not pid:
        return
    if not messagebox.askyesno("تأیید حذف کاربرگ", "فقط کاربرگ پیش‌نویسِ بدون سابقه و ارتباط قابل حذف است. آیا ادامه می‌دهید؟"):
        return
    try:
        self.services.workpapers.delete(pid, int(vals[0]))
        self.refresh_workpapers()
        if hasattr(self, "refresh_dashboard"):
            self.refresh_dashboard()
        messagebox.showinfo("حذف کاربرگ", "کاربرگ پیش‌نویس حذف شد.")
    except ValueError as exc:
        messagebox.showwarning("حذف کاربرگ ممکن نیست", str(exc))
    except Exception as exc:
        messagebox.showerror("خطا در حذف کاربرگ", str(exc))
""", p)

    p = "ui/views/finding_view.py"
    new[p] = once(new[p],
        'self.add_record_navigation(self.tab_findings, self.tree_finds, on_edit=self.edit_selected_finding, label="یافته")',
        'self.add_record_navigation(self.tab_findings, self.tree_finds, on_edit=self.edit_selected_finding, on_delete=self.delete_selected_finding, label="یافته")', p)
    new[p] = append_method(new[p], "FindingViewMixin", """
def delete_selected_finding(self):
    selected = self.tree_finds.selection()
    if not selected:
        messagebox.showinfo("انتخاب یافته", "ابتدا یک یافته را انتخاب کنید.")
        return
    vals = self.tree_finds.item(selected[0], "values")
    pid = self.get_current_project_id()
    if not pid:
        return
    if not messagebox.askyesno("تأیید حذف یافته", "فقط یافته باز و فاقد مستندات یا ارجاعات قابل حذف است. آیا ادامه می‌دهید؟"):
        return
    try:
        self.services.findings.delete(pid, int(vals[0]))
        self.refresh_findings()
        if hasattr(self, "refresh_dashboard"):
            self.refresh_dashboard()
        messagebox.showinfo("حذف یافته", "یافته باز حذف شد.")
    except ValueError as exc:
        messagebox.showwarning("حذف یافته ممکن نیست", str(exc))
    except Exception as exc:
        messagebox.showerror("خطا در حذف یافته", str(exc))
""", p)

    for rel, src in new.items():
        validate(src, rel)

    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = ROOT / "backups" / f"phase16_safe_delete_{stamp}"
    backup.mkdir(parents=True, exist_ok=False)
    for rel in FILES:
        dest = backup / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / rel, dest)

    changed = []
    try:
        for rel in FILES:
            target = ROOT / rel
            temp = target.with_suffix(target.suffix + ".safe_delete_tmp")
            temp.write_text(new[rel], encoding="utf-8", newline="\n")
            temp.replace(target)
            changed.append(rel)
        for rel in FILES:
            validate(read(rel), rel)
    except Exception:
        for rel in changed:
            shutil.copy2(backup / rel, ROOT / rel)
        raise

    print("نصب اصلاحات حذف ایمن فاز ۱۶ با موفقیت انجام شد.")
    print(f"فایل‌های اصلاح‌شده: {len(FILES)}")
    print(f"پشتیبان فایل‌های قبلی: {backup}")
    print("پایگاه داده باز یا تغییر داده نشده است.")
    print("اعتبار نحوی فایل‌های اصلاح‌شده بررسی شد.")
    print("توجه: آزمون عملی عملیات حذف روی کپی پایگاه داده هنوز انجام نشده است.")

if __name__ == "__main__":
    try:
        install()
    except Exception as exc:
        print("نصب متوقف شد؛ فایل‌های اصلی در صورت بروز خطا بازیابی شده‌اند.")
        print(f"علت: {exc}")
        sys.exit(1)
