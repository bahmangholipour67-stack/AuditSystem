# Phase 32 — Executive Command Center (foundation)

## Goal
Provide a read-only, schema-tolerant executive snapshot for institute-level monitoring.

## Included in this phase
- Counts for engagement/project, risk, workpaper, finding, test, document, document-request, internal-control and misstatement records.
- Status buckets (open / closed / other) for tables with a supported status column.
- Engagement-scoped metrics when `project_id` is supplied; aggregate metrics otherwise.
- Safe handling of absent optional tables and columns.
- Timestamped snapshot and scope notice.

## Data integrity
This service performs only SELECT queries. No schema migration or changes to engagement records occur.

## Integration note
The service is provided as a tested foundation for the Executive Command Center. The desktop dashboard widget/layout integration and Windows UI smoke test remain a subsequent implementation step; this phase does not claim the command center is already visible in the application.
