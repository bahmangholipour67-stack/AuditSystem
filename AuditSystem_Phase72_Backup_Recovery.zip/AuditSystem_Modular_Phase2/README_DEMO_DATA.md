# AuditSystem Demo Dataset

This is an isolated sample dataset for demonstrating AuditSystem. It is fictional and is marked `[DEMO]`.


## Start the demo

1. Extract the ZIP package to a folder.
2. Run `run_demo.bat` (Windows; Python launcher `py` required).
3. The launcher sets `AUDITSYSTEM_DB_PATH` to the included `demo_audit_system.db`, seeds the demo project if missing, and launches `main.py`.


## Included sample records

- 1 demo engagement: `[DEMO] شرکت تولیدی پارس‌صنعت`
- 4 demo team members with role assignments
- 5 audit risks
- 8 workpapers
- 4 findings
- 14 trial-balance accounts
- 4 audit programs and 4 tests
- 7 test samples
- Project materiality values


## Safety

The demo database is separate from the application's regular database. The launcher points only to `demo_audit_system.db`. To recreate the sample project, run:


```bat
py demo_seed.py --db demo_audit_system.db --reset-demo
```

Reset deletes only the clearly named `[DEMO]` engagement and its project-linked sample records from the selected demo database. Never run it against a production database.
