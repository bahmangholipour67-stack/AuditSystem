# Phase 60 — Professional Approval Inbox

## Purpose
Operationalize the existing version-bound, three-stage approval workflow without creating a parallel approval engine or changing its database schema.

## Delivered
- Added a project-scoped `ApprovalWorkflowService.inbox(project_id, member_id)` query.
- Inbox items are limited to the active member's assigned stage: supervisor, audit manager, or quality control.
- Only active team members in the selected project can access their inbox.
- Inbox rows include the request, document type, document title, current stage, and submission time.
- Added a compact "active member action cards" section to the existing approval center.
- Double-clicking an inbox item selects the matching request in the full approval list.
- The active member selector now refreshes the approval center and preselects that member in the action actor field.
- Existing approval validation, version hash checks, append-only history, and three-stage transitions remain the source of truth.

## Compatibility and safety
- No schema migration or data rewrite was introduced.
- Existing approval requests and history are preserved.
- Existing unified navigation and Phase 59 team workspace are preserved.
- The inbox is a work queue, not an authentication mechanism; service-level role, assignment, project, and stage validation remains authoritative.

## Verification
Run from the project root:

```bash
set PYTHONPATH=.
python -m pytest -q
```

Windows GUI visual verification is still required on the user's computer.
