"""Generate Word, Excel and PDF audit-file quality reports."""

from pathlib import Path
from xml.sax.saxutils import escape


class AuditReportGenerator:
    METRIC_LABELS = {
        "projects": "پرونده", "risks": "ریسک", "audit_programs": "برنامه حسابرسی",
        "workpapers": "کاربرگ", "findings": "یافته", "audit_tests": "آزمون حسابرسی",
        "samples": "نمونه", "evidence": "مستند", "accounts": "حساب تراز آزمایشی",
        "workpapers_approved": "کاربرگ تأییدشده", "tests_approved": "آزمون تأییدشده",
        "open_findings": "یافته باز",
        "trial_balance_flagged_accounts": "حساب‌های پرچم‌دار تراز",
        "trial_balance_difference": "اختلاف جمع بدهکار و بستانکار",
    }

    @staticmethod
    def _safe_excel(value):
        if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")):
            return "'" + value
        return value

    @staticmethod
    def _rtl(value):
        text = str(value or "")
        try:
            import arabic_reshaper
            from bidi.algorithm import get_display
            return get_display(arabic_reshaper.reshape(text))
        except ImportError:
            return text

    @staticmethod
    def _project_title(data):
        project = data.get("project", {})
        return f"{project.get('name', 'پرونده حسابرسی')} - {project.get('period', '')}".strip(" -")

    def export_excel(self, data, path):
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter

        wb = Workbook()
        ws = wb.active
        ws.title = "خلاصه کنترل کیفیت"
        ws.append(["گزارش کنترل کیفیت پرونده حسابرسی"])
        ws.append(["پرونده", self._project_title(data)])
        ws.append(["تاریخ تهیه", data.get("generated_at", "")])
        ws.append([])
        ws.append(["شاخص", "تعداد"])
        for key, label in self.METRIC_LABELS.items():
            ws.append([label, data["metrics"].get(key, 0)])
        ws.append([])
        ws.append(["تعداد موارد نیازمند پیگیری", data["summary"]["issue_count"]])
        ws.append(["موارد بحرانی", data["summary"]["critical_count"]])
        ws.append(["موارد بااهمیت", data["summary"]["high_count"]])
        ws.append(["موارد متوسط", data["summary"]["medium_count"]])
        ws.append(["کنترل‌های بدون مغایرت", data["summary"]["passed_checks"]])

        checks_ws = wb.create_sheet("نتایج کنترل‌ها")
        checks_ws.append(["کد", "عنوان کنترل", "شدت", "تعداد", "اقدام پیشنهادی"])
        for check in data["checks"]:
            checks_ws.append([check["code"], check["title"], check["severity"], check["count"], check["recommendation"]])

        details_ws = wb.create_sheet("جزئیات موارد")
        details_ws.append(["کد کنترل", "شدت", "شناسه", "عنوان", "شرح"])
        for check in data["checks"]:
            for item in check["items"]:
                details_ws.append([check["code"], check["severity"], item.get("id"), item.get("title"), item.get("detail")])

        for sheet in wb.worksheets:
            sheet.sheet_view.rightToLeft = True
            sheet.freeze_panes = "A2"
            for row in sheet.iter_rows():
                for cell in row:
                    cell.value = self._safe_excel(cell.value)
                    cell.alignment = Alignment(horizontal="right", vertical="center", wrap_text=True)
            for cell in sheet[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F4E78")
            for column in sheet.columns:
                letter = get_column_letter(column[0].column)
                max_length = max((len(str(cell.value or "")) for cell in column), default=10)
                sheet.column_dimensions[letter].width = min(max(max_length + 3, 14), 55)
        wb.save(path)
        return str(path)

    def export_word(self, data, path):
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Cm, Pt

        doc = Document()
        section = doc.sections[0]
        section.top_margin = Cm(1.7)
        section.bottom_margin = Cm(1.7)
        title = doc.add_heading("گزارش کنترل کیفیت پرونده حسابرسی", 0)
        title.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p = doc.add_paragraph(f"پرونده: {self._project_title(data)} ـ تاریخ تهیه: {data.get('generated_at', '')}")
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        doc.add_heading("خلاصه مدیریتی", level=1)
        summary = data["summary"]
        for label, key in (("کل موارد نیازمند پیگیری", "issue_count"), ("بحرانی", "critical_count"), ("بااهمیت", "high_count"), ("متوسط", "medium_count"), ("کنترل‌های بدون مغایرت", "passed_checks")):
            p = doc.add_paragraph(f"{label}: {summary[key]}")
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        doc.add_heading("شاخص‌های پرونده", level=1)
        table = doc.add_table(rows=1, cols=2)
        table.style = "Table Grid"
        table.rows[0].cells[0].text = "شاخص"
        table.rows[0].cells[1].text = "تعداد"
        for key, label in self.METRIC_LABELS.items():
            cells = table.add_row().cells
            cells[0].text = label
            cells[1].text = str(data["metrics"].get(key, 0))
        doc.add_heading("نتایج کنترل‌های کیفیت", level=1)
        for check in data["checks"]:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            run = p.add_run(f"{check['severity']} ـ {check['title']} ـ تعداد: {check['count']}")
            run.bold = True
            p = doc.add_paragraph(f"اقدام پیشنهادی: {check['recommendation']}")
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            if check["items"]:
                table = doc.add_table(rows=1, cols=3)
                table.style = "Table Grid"
                for cell, label in zip(table.rows[0].cells, ("شناسه", "عنوان", "شرح")):
                    cell.text = label
                for item in check["items"]:
                    cells = table.add_row().cells
                    cells[0].text = str(item.get("id", ""))
                    cells[1].text = str(item.get("title", ""))
                    cells[2].text = str(item.get("detail", ""))
        for paragraph in doc.paragraphs:
            paragraph.paragraph_format.space_after = Pt(5)
        doc.save(path)
        return str(path)

    def export_pdf(self, data, path):
        """Render a Persian RTL PDF using Pillow's RAQM text layout engine."""
        from io import BytesIO
        from PIL import Image, ImageDraw, ImageFont, features
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.utils import ImageReader

        if not features.check("raqm"):
            raise RuntimeError(
                "قابلیت پردازش راست‌به‌چپ فونت در Pillow فعال نیست. "
                "نسخه به‌روز Pillow را نصب کنید."
            )

        width, height = 1240, 1754
        margin = 82
        body_size = 27
        heading_size = 34
        title_size = 43
        candidates = [
            ("C:/Windows/Fonts/tahoma.ttf", "C:/Windows/Fonts/tahomabd.ttf"),
            ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
            ("/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf", "/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf"),
            ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        ]
        regular_path = bold_path = None
        for regular, bold in candidates:
            if Path(regular).exists():
                regular_path = regular
                bold_path = bold if Path(bold).exists() else regular
                break
        if not regular_path:
            raise RuntimeError("فونت فارسی/عربی مناسب برای ساخت PDF پیدا نشد.")

        body_font = ImageFont.truetype(regular_path, body_size)
        heading_font = ImageFont.truetype(bold_path, heading_size)
        title_font = ImageFont.truetype(bold_path, title_size)
        pages = []
        page = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(page)
        y = 95

        def new_page():
            nonlocal page, draw, y
            pages.append(page)
            page = Image.new("RGB", (width, height), "white")
            draw = ImageDraw.Draw(page)
            y = 95

        def wrap_text(text, font, max_width):
            words = str(text or "").split()
            if not words:
                return [""]
            lines, current = [], ""
            for word in words:
                candidate = f"{current} {word}".strip()
                if current and draw.textlength(candidate, font=font, direction="rtl") > max_width:
                    lines.append(current)
                    current = word
                else:
                    current = candidate
            if current:
                lines.append(current)
            return lines

        def write(text, font=None, gap=12, color=(35, 35, 35), centered=False):
            nonlocal y
            font = font or body_font
            for line in wrap_text(text, font, width - 2 * margin):
                line_height = font.getbbox("آب")[3] - font.getbbox("آب")[1] + gap
                if y + line_height > height - 105:
                    new_page()
                if centered:
                    draw.text((width // 2, y), line, font=font, fill=color,
                              anchor="ma", direction="rtl")
                else:
                    draw.text((width - margin, y), line, font=font, fill=color,
                              anchor="ra", direction="rtl")
                y += line_height

        write("گزارش کنترل کیفیت پرونده حسابرسی", title_font, gap=20,
              color=(31, 78, 121), centered=True)
        write(f"پرونده: {self._project_title(data)} ـ تاریخ تهیه: {data.get('generated_at', '')}", body_font, gap=18)
        y += 10
        write("خلاصه مدیریتی", heading_font, gap=16, color=(31, 78, 121))
        summary = data["summary"]
        for label, key in (("کل موارد نیازمند پیگیری", "issue_count"),
                           ("موارد بحرانی", "critical_count"),
                           ("موارد بااهمیت", "high_count"),
                           ("موارد متوسط", "medium_count"),
                           ("کنترل‌های بدون مغایرت", "passed_checks")):
            write(f"{label}: {summary[key]}")
        y += 8
        write("شاخص‌های پرونده", heading_font, gap=16, color=(31, 78, 121))
        for key, label in self.METRIC_LABELS.items():
            write(f"{label}: {data['metrics'].get(key, 0)}")
        y += 8
        write("نتایج کنترل‌های کیفیت", heading_font, gap=16, color=(31, 78, 121))
        for check in data["checks"]:
            write(f"{check['severity']} ـ {check['title']} ـ تعداد: {check['count']}", heading_font, gap=13)
            write(f"اقدام پیشنهادی: {check['recommendation']}", body_font, gap=11)
            for item in check["items"]:
                write(f"شناسه: {item.get('id', '')} | عنوان: {item.get('title', '')}", body_font, gap=9)
                write(f"شرح: {item.get('detail', '')}", body_font, gap=13)
            y += 7
        pages.append(page)

        pdf = canvas.Canvas(str(path), pagesize=A4)
        page_width, page_height = A4
        for page_number, page_image in enumerate(pages, start=1):
            buffer = BytesIO()
            page_image.save(buffer, format="PNG", optimize=True)
            buffer.seek(0)
            pdf.drawImage(ImageReader(buffer), 0, 0, width=page_width, height=page_height)
            pdf.setFont("Helvetica", 8)
            pdf.setFillColorRGB(0.35, 0.35, 0.35)
            pdf.drawCentredString(page_width / 2, 7 * 5, str(page_number))
            pdf.showPage()
        pdf.save()
        return str(path)

    def export(self, data, path, file_format):
        file_format = file_format.lower().lstrip(".")
        if file_format in {"xlsx", "excel"}:
            return self.export_excel(data, path)
        if file_format in {"docx", "word"}:
            return self.export_word(data, path)
        if file_format == "pdf":
            return self.export_pdf(data, path)
        raise ValueError(f"قالب گزارش پشتیبانی نمی‌شود: {file_format}")
