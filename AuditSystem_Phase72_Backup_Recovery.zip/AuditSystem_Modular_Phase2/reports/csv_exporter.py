import csv
from services.number_utils import safe_csv_text

def write_rows(path, header, rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(header)
        for row in rows: w.writerow([safe_csv_text(v) for v in row])
