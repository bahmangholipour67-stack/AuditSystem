"""Deterministic, evidence-linked audit report draft generator (Phase 66).

This module creates wording from recorded engagement data only; it does not form an audit opinion.
"""
from services.integrated_report_service import IntegratedReportService


class IntelligentReportDraftService:
    SEVERITY_ORDER = {"بحرانی": 0, "زیاد": 1, "بالا": 1, "متوسط": 2, "کم": 3}


    def __init__(self, db_path):
        self.integrated = IntegratedReportService(db_path)

    @staticmethod
    def _text(value):
        return str(value or "").strip()
    @staticmethod
    def _norm(value):
        return str(value or "").replace("ي", "ی").replace("ك", "ک").strip().lower()
    @classmethod
    def _is_closed(cls, status):
        return cls._norm(status) in {"بسته", "مختومه", "رفع شده", "تکمیل شده", "completed", "closed", "done", "تأیید نهایی مدیر"}
    @staticmethod
    def _fmt_amount(value):
        try:
            return f"{float(value):,.2f}"
        except (ValueError, TypeError):
            return "0"

    def build(self, project_id):
        snapshot = self.integrated.build(project_id)
        sections = snapshot["sections"]
        risks = sections.get("risks", [])
        findings = sections.get("findings", [])
        open_findings = [f for f in findings if not self._is_closed(f.get("status"))]
        high_risks = [r for r in risks if IntegratedReportService._is_high_risk(r.get("score"))]
        misstatements = [m for m in sections.get("audit_misstatements", []) if not m.get("archived_at") and m.get("status") in ("اصلاح‌نشده", "مورد اختلاف")]
        corrective = sections.get("corrective_actions", [])
        open_actions = [a for a in corrective if self._norm(a.get("status")) not in {"تأییدشده", "لغو شده", "cancelled", "closed"}]
        # Risk and finding lists are descriptive; do not imply an opinion or severity judgement.
        risk_lines = [f"- {self._text(r.get('title')) or 'ریسک بدون عنوان'} (امتیاز ثبت‌شده: {self._text(r.get('score')) or 'نامشخص'})" for r in high_risks]
        finding_lines = []
        for f in sorted(open_findings, key=lambda item: self.SEVERITY_ORDER.get(self._text(item.get("severity")), 99)):
            title = self._text(f.get("title")) or "یافته بدون عنوان"
            sev = self._text(f.get("severity")) or "درجه ثبت‌نشده"
            owner = self._text(f.get("owner"))
            status = self._text(f.get("status")) or "وضعیت ثبت‌نشده"
            line = f"- {title} | اهمیت ثبت‌شده: {sev} | وضعیت: {status}"
            if owner: line += f" | مسئول: {owner}"
            finding_lines.append(line)
        misstatement_lines = [f"- {self._text(m.get('title')) or 'تحریف بدون عنوان'} | حساب: {self._text(m.get('account_name')) or 'نامشخص'} | مبلغ ثبت‌شده: {self._fmt_amount(m.get('amount'))} | وضعیت: {self._text(m.get('status')) or 'نامشخص'}" for m in misstatements]
        checklist = sections.get("coso_checklist_responses", [])
        unanswered = [x for x in checklist if self._text(x.get("answer")) in ("", "پاسخ‌داده‌نشده")]
        weaknesses = [x for x in checklist if self._text(x.get("answer")) in ("خیر", "تاحدی")]
        summary = snapshot.get("summary", {})
        completeness = []
        if not findings: completeness.append("هیچ یافته‌ای در پرونده ثبت نشده است؛ این موضوع به معنی نبود یافته نیست.")
        if not risks: completeness.append("فهرست ریسک‌ها خالی است یا داده‌ای در دسترس نیست.")
        if unanswered: completeness.append(f"{len(unanswered)} پاسخ چک‌لیست COSO بدون پاسخ ثبت‌شده است.")
        if snapshot.get("unavailable_sections"): completeness.append("برخی بخش‌های داده به علت نبود جدول در پایگاه داده قابل تهیه نبودند.")
        if not misstatements: completeness.append("تحریف اصلاح‌نشده/مورد اختلافی در داده‌های فعال یافت نشد؛ این نتیجه به معنی عدم وجود تحریف نیست.")
        sections_text = {
            "خلاصه مدیریتی (پیش‌نویس)": [f"در پرونده «{self._text(snapshot['project'].get('name'))}»، تعداد {len(risks)} ریسک، {len(findings)} یافته و {len(open_findings)} یافته باز ثبت شده است.", f"تعداد ریسک‌های با امتیاز ۱۶ یا بیشتر: {len(high_risks)} (بر اساس قاعده سامانه؛ نیازمند تأیید حرفه‌ای).", f"تحریف‌های فعال اصلاح‌نشده/مورد اختلاف: {len(misstatements)} مورد؛ جمع ناخالص مبالغ ثبت‌شده: {self._fmt_amount(sum(float(m.get('amount') or 0) for m in misstatements))}.", f"اقدامات اصلاحی باز: {len(open_actions)} مورد."],
            "ریسک‌های برجسته": risk_lines or ["ریسک برجسته‌ای بر اساس آستانه سامانه شناسایی نشد؛ بررسی کامل ریسک‌ها لازم است."],
            "یافته‌های باز": finding_lines or ["یافته باز در داده‌های موجود شناسایی نشد؛ کامل بودن ثبت یافته‌ها باید تأیید شود."],
            "تحریف‌های فعال": misstatement_lines or ["تحریف فعال اصلاح‌نشده/مورد اختلاف در داده‌های موجود ثبت نشده است."],
            "ملاحظات کنترل داخلی": [f"تعداد کنترل‌های ثبت‌شده: {summary.get('internal_control_count', 0)}؛ تعداد آزمون‌های کنترل: {summary.get('control_test_count', 0)}؛ یافته‌های کنترل داخلی: {summary.get('internal_control_finding_count', 0)}؛ موارد چک‌لیست با پاسخ خیر/تاحدی: {len(weaknesses)}."],
            "موارد نیازمند تکمیل قبل از صدور": completeness or ["بر اساس کنترل‌های مقدماتی، مورد خودکار برای تکمیل شناسایی نشد؛ بازبینی انسانی نهایی الزامی است."],
        }
        return {"project_id": snapshot["project_id"], "project": snapshot["project"], "generated_at": snapshot["generated_at"], "draft_only": True, "sections": sections_text, "limitations": ["این خروجی پیش‌نویس ماشینی بر اساس داده‌های ثبت‌شده است و نتیجه‌گیری یا اظهارنظر حسابرس نیست.", "آستانه ریسک و وضعیت‌ها صرفاً از قواعد/مقادیر سامانه استفاده می‌کنند؛ قضاوت حرفه‌ای، بررسی شواهد و تأیید مسئول گزارش ضروری است.", "عدم نمایش مورد به معنی عدم وجود آن نیست؛ کامل بودن داده‌ها باید توسط تیم حسابرسی کنترل شود."]}


def export_draft_docx(draft, output_path, organization_name="مؤسسه حسابرسی", report_number=""):
    """Export the intelligent draft through the approved Phase 65 official template."""
    from reporting.official_report_template import build_official_docx

    rows = []
    for heading, lines in (draft.get("sections") or {}).items():
        for line in lines:
            rows.append({"بخش": heading, "متن پیش‌نویس": str(line)})
    report = {
        "report": {"title": "پیش‌نویس هوشمند گزارش حسابرسی", "category": "پیش‌نویس حسابرسی"},
        "project": draft.get("project") or {},
        "project_id": draft.get("project_id", ""),
        "generated_at": draft.get("generated_at", ""),
        "row_count": len(rows),
        "columns": ["بخش", "متن پیش‌نویس"],
        "rows": rows,
        "limitations": list(draft.get("limitations") or []) + [
            "این سند صرفاً پیش‌نویس است و بدون بررسی شواهد و تأیید حسابرس مسئول قابل صدور نیست."
        ],
    }
    return build_official_docx(
        report, output_path, organization_name=organization_name,
        report_number=report_number,
    )
