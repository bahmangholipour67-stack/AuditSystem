"""Curated, permission-conscious catalogue of standard engagement reports."""

REPORT_CATALOG = (
    {"id": "executive_summary", "category": "مدیریتی", "title": "خلاصه مدیریتی پرونده", "description": "نمای کلی ریسک‌ها، کاربرگ‌ها، یافته‌ها، آزمون‌ها و وضعیت اجرای حسابرسی.", "source": "summary"},
    {"id": "risk_register", "category": "ریسک و کنترل", "title": "دفتر ثبت ریسک‌ها", "description": "فهرست ریسک‌های ثبت‌شده در پرونده و امتیازهای ارزیابی.", "source": "risks"},
    {"id": "workpaper_status", "category": "اجرای حسابرسی", "title": "وضعیت کاربرگ‌ها", "description": "فهرست کاربرگ‌ها، روش اجرا، نتیجه و وضعیت رسیدگی.", "source": "workpapers"},
    {"id": "audit_programs", "category": "اجرای حسابرسی", "title": "برنامه‌های حسابرسی", "description": "برنامه‌ها، حوزه رسیدگی، مسئول اجرا، مهلت و وضعیت.", "source": "audit_programs"},
    {"id": "audit_tests", "category": "اجرای حسابرسی", "title": "آزمون‌های حسابرسی", "description": "آزمون‌ها، نوع آزمون، نتیجه و نتیجه‌گیری ثبت‌شده.", "source": "audit_tests"},
    {"id": "findings", "category": "یافته‌ها و تحریفات", "title": "یافته‌ها و اقدامات اصلاحی", "description": "یافته‌ها، شدت، مسئول پیگیری و وضعیت اقدام اصلاحی.", "source": "findings"},
    {"id": "management_letter", "category": "یافته‌ها و تحریفات", "title": "گزارش یافته‌ها و نامه مدیریت", "description": "گزارش ساختاریافته وضعیت، معیار، علت، پیامد، پیشنهاد اصلاحی، مسئول، مهلت، وضعیت پیگیری و مستندات هر یافته؛ صرفاً بر پایه اطلاعات ثبت‌شده پرونده.", "source": "management_letter"},
    {"id": "misstatements", "category": "یافته‌ها و تحریفات", "title": "تحریفات حسابرسی", "description": "تحریفات فعال و وضعیت اصلاح یا اختلاف.", "source": "audit_misstatements"},
    {"id": "document_requests", "category": "اسناد و شواهد", "title": "درخواست‌های مدارک", "description": "درخواست‌های مدارک، مسئول، مهلت و وضعیت تکمیل.", "source": "document_requests"},
    {"id": "evidence", "category": "اسناد و شواهد", "title": "مستندات یافته‌ها", "description": "فهرست مستندات پیوست‌شده به یافته‌های حسابرسی.", "source": "finding_evidence"},
    {"id": "trial_balance", "category": "اطلاعات مالی", "title": "تراز آزمایشی", "description": "اقلام تراز آزمایشی و اطلاعات بدهکار، بستانکار و خالص.", "source": "trial_balance"},
    {"id": "internal_controls", "category": "ریسک و کنترل", "title": "کنترل‌های داخلی", "description": "کنترل‌های ثبت‌شده، مالک کنترل و مشخصات طراحی کنترل.", "source": "internal_controls"},
    {"id": "control_tests", "category": "ریسک و کنترل", "title": "آزمون کنترل‌ها", "description": "نتایج آزمون کنترل‌ها، حجم نمونه و استثناهای ثبت‌شده.", "source": "control_tests"},
    {"id": "coso_assessment", "category": "استانداردها و انطباق", "title": "ارزیابی چارچوب COSO", "description": "خلاصه ارزیابی، تکمیل پرسش‌ها و خلأهای شواهد در صورت وجود داده.", "source": "coso"},
    {"id": "misstatement_history", "category": "سوابق و ردیابی", "title": "سوابق تغییر وضعیت تحریفات", "description": "تاریخچه تغییرات ثبت‌شده برای تحریفات پرونده.", "source": "misstatement_history"},
)


def get_report_definition(report_id):
    for item in REPORT_CATALOG:
        if item["id"] == report_id:
            return dict(item)
    raise ValueError("گزارش انتخاب‌شده در فهرست گزارشات تعریف نشده است.")
