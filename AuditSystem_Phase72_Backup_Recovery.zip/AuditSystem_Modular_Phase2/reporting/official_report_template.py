"""Official Persian Word report template for AuditSystem standard reports."""
from datetime import datetime

# python-docx is an optional export dependency. Keep it lazy so a missing
# Word package never prevents the desktop application from starting.
def _load_docx_dependencies():
    global WD_ALIGN_PARAGRAPH, WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
    global OxmlElement, qn, Pt, Cm, RGBColor
    try:
        from docx import Document
        from docx.shared import Pt, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
        from docx.oxml import OxmlElement
        from docx.oxml.ns import qn
        globals().update({"WD_ALIGN_PARAGRAPH": WD_ALIGN_PARAGRAPH, "WD_TABLE_ALIGNMENT": WD_TABLE_ALIGNMENT,
                         "WD_CELL_VERTICAL_ALIGNMENT": WD_CELL_VERTICAL_ALIGNMENT, "OxmlElement": OxmlElement,
                         "qn": qn, "Pt": Pt, "Cm": Cm, "RGBColor": RGBColor})
        return Document, Pt, Cm, RGBColor, WD_ALIGN_PARAGRAPH, WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT, OxmlElement, qn
    except ImportError as exc:
        raise RuntimeError(
            "برای خروجی Word، کتابخانه python-docx نصب نیست. "
            "در پوشه اصلی برنامه فایل INSTALL_DEPENDENCIES.bat را اجرا کنید."
        ) from exc

NAVY = '14283F'
BLUE = '2563EB'


def _rtl(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    ppr = paragraph._p.get_or_add_pPr()
    bidi = OxmlElement('w:bidi')
    ppr.append(bidi)
    for run in paragraph.runs:
        rpr = run._element.get_or_add_rPr()
        rtl = OxmlElement('w:rtl')
        rpr.append(rtl)
        run.font.name = 'Tahoma'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Tahoma')


def _shade(cell, color):
    tcpr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), color)
    tcpr.append(shd)


def _cell_text(cell, text, bold=False, color=None, size=9):
    cell.text = str(text)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for p in cell.paragraphs:
        _rtl(p)
        for r in p.runs:
            r.bold = bold
            r.font.size = Pt(size)
            r.font.name = 'Tahoma'
            if color:
                r.font.color.rgb = RGBColor.from_string(color)


def build_official_docx(report, output_path, organization_name='مؤسسه حسابرسی', report_number='', logo_path=None):
    (Document, Pt, Cm, RGBColor, WD_ALIGN_PARAGRAPH, WD_TABLE_ALIGNMENT,
     WD_CELL_VERTICAL_ALIGNMENT, OxmlElement, qn) = _load_docx_dependencies()
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Cm(2.1); section.bottom_margin = Cm(2); section.left_margin = Cm(2); section.right_margin = Cm(2)
    normal = doc.styles['Normal']; normal.font.name = 'Tahoma'; normal.font.size = Pt(10)
    normal._element.rPr.rFonts.set(qn('w:eastAsia'), 'Tahoma')

    # Cover / letterhead
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if logo_path:
        try: p.add_run().add_picture(logo_path, width=Cm(2.2))
        except Exception: pass
    r=p.add_run(organization_name); r.bold=True; r.font.size=Pt(16); r.font.color.rgb=RGBColor.from_string(NAVY)
    _rtl(p)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('گزارش رسمی حسابرسی / گزارش اطلاعات پرونده'); r.bold=True; r.font.size=Pt(20); r.font.color.rgb=RGBColor.from_string(BLUE); _rtl(p)
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(report.get('report',{}).get('title','گزارش')).bold=True; _rtl(p)
    project=report.get('project') or {}
    for label,value in [('نام پرونده',project.get('name','')),('شماره گزارش',report_number or '—'),('شناسه پرونده',report.get('project_id','')),('تاریخ تهیه',report.get('generated_at',''))]:
        p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run(f'{label}: {value}'); _rtl(p)
    doc.add_page_break()

    p=doc.add_paragraph(); p.add_run('۱. مشخصات گزارش').bold=True; _rtl(p)
    meta=[('عنوان گزارش',report.get('report',{}).get('title','')),('حوزه',report.get('report',{}).get('category','')),('تعداد ردیف اطلاعات',report.get('row_count',0))]
    t=doc.add_table(rows=0,cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'
    for a,b in meta:
        cells=t.add_row().cells; _cell_text(cells[0],a,True); _shade(cells[0],'DCE8F8'); _cell_text(cells[1],b)
    p=doc.add_paragraph(); p.add_run('۲. اطلاعات گزارش').bold=True; _rtl(p)
    columns=report.get('columns') or ['پیام']; rows=report.get('rows') or []
    table=doc.add_table(rows=1,cols=max(1,len(columns))); table.style='Table Grid'; table.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,col in enumerate(columns): _cell_text(table.rows[0].cells[i],col,True,'FFFFFF',9); _shade(table.rows[0].cells[i],NAVY)
    for row in rows:
        cells=table.add_row().cells
        for i,col in enumerate(columns): _cell_text(cells[i],row.get(col,''),size=8)
    p=doc.add_paragraph(); p.add_run('۳. یادداشت‌های تهیه و استفاده از گزارش').bold=True; _rtl(p)
    for note in report.get('report_notes',[]) or ['یادداشت اختصاصی برای این گزارش ثبت نشده است.']:
        p=doc.add_paragraph(); p.add_run(str(note)); _rtl(p)
    p=doc.add_paragraph(); p.add_run('۴. ملاحظات و محدودیت‌ها').bold=True; _rtl(p)
    for note in report.get('limitations',[]) or ['محدودیتی ثبت نشده است.']:
        p=doc.add_paragraph(); p.add_run(str(note)); _rtl(p)
    p=doc.add_paragraph(); p.add_run('۵. تأیید و امضا').bold=True; _rtl(p)
    sig=doc.add_table(rows=2,cols=3); sig.style='Table Grid'; sig.alignment=WD_TABLE_ALIGNMENT.CENTER
    roles=['تهیه‌کننده گزارش','سرپرست حسابرسی','مدیر / شریک']
    for i,role in enumerate(roles): _cell_text(sig.rows[0].cells[i],role,True); _shade(sig.rows[0].cells[i],'DCE8F8'); _cell_text(sig.rows[1].cells[i],'نام و امضا:\n\nتاریخ:')
    footer=section.footer.paragraphs[0]; footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run(f'{organization_name}  |  گزارش تولیدشده توسط AuditSystem  |  ')
    _rtl(footer)
    doc.save(output_path)
    return output_path
