"""Read-only report catalogue and execution over existing AuditSystem services."""

from datetime import datetime
from services.integrated_report_service import IntegratedReportService
from reporting.report_catalog import REPORT_CATALOG, get_report_definition


class ReportCenterService:
    """Build standard reports from the existing integrated engagement snapshot."""

    def __init__(self, db_path):
        self.integrated = IntegratedReportService(db_path)

    @staticmethod
    def catalogue():
        return [dict(item) for item in REPORT_CATALOG]

    def build(self, project_id, report_id):
        definition = get_report_definition(report_id)
        snapshot = self.integrated.build(project_id)
        source = definition["source"]
        if source == "summary":
            rows = [{"شاخص": key, "مقدار": value}
                    for key, value in snapshot["summary"].items()]
        elif source == "management_letter":
            findings = snapshot["sections"].get("findings", [])
            actions = snapshot["sections"].get("corrective_actions", [])
            evidence = snapshot["sections"].get("finding_evidence", [])
            actions_by_finding = {}
            for action in actions:
                actions_by_finding.setdefault(action.get("finding_id"), []).append(action)
            evidence_counts = {}
            for item in evidence:
                evidence_counts[item.get("finding_id")] = evidence_counts.get(item.get("finding_id"), 0) + 1
            rows = []
            for finding in findings:
                linked_actions = actions_by_finding.get(finding.get("id"), [])
                action_texts = []
                for action in linked_actions:
                    details = " | ".join(str(action.get(key) or "") for key in
                        ("title", "owner", "due_date", "status", "progress_note", "followup_result") if action.get(key))
                    if details:
                        action_texts.append(details)
                rows.append({
                    "شناسه یافته": finding.get("id", ""),
                    "نوع یافته": finding.get("finding_type") or "عمومی",
                    "عنوان یافته": finding.get("title", ""),
                    "وضعیت": finding.get("status", ""),
                    "درجه اهمیت": finding.get("severity", ""),
                    "وضعیت موجود": finding.get("condition_text", ""),
                    "معیار": finding.get("criteria_text", ""),
                    "علت": finding.get("cause_text", ""),
                    "پیامد": finding.get("effect_text", ""),
                    "اقدام پیشنهادی ثبت‌شده": finding.get("action_text", ""),
                    "اقدامات اصلاحی و پیگیری": " ؛ ".join(action_texts),
                    "مسئول پیگیری": finding.get("owner", ""),
                    "تعداد مستندات پیوست": evidence_counts.get(finding.get("id"), 0),
                    "شناسه کاربرگ": finding.get("workpaper_id", ""),
                    "شناسه ریسک": finding.get("risk_id", ""),
                })
            if not rows:
                rows = [{"پیام": "برای این پرونده هنوز یافته‌ای ثبت نشده است."}]
        elif source == "coso":
            coso = snapshot.get("coso_assessment_report")
            rows = []
            if coso:
                rows.append({"شاخص": "وضعیت کلی", "مقدار": coso.get("summary", {}).get("overall_status", "")})
                rows.extend({"شاخص": key, "مقدار": value}
                            for key, value in coso.get("summary", {}).items())
                rows.extend({"مؤلفه": item.get("component", ""),
                             "تعداد پرسش": item.get("question_count", 0),
                             "درصد تکمیل": item.get("completion_percent", 0),
                             "وضعیت": item.get("assessment_status", "")}
                            for item in coso.get("components", []))
        else:
            rows = snapshot["sections"].get(source, [])
        project = snapshot["project"]
        return {
            "report": definition,
            "project": project,
            "project_id": snapshot["project_id"],
            "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "row_count": (len(snapshot["sections"].get("findings", []))
                          if source == "management_letter" else len(rows)),
            "columns": list(rows[0].keys()) if rows else [],
            "rows": rows,
            "unavailable_sections": snapshot.get("unavailable_sections", []),
            "limitations": snapshot.get("limitations", []),
            "report_notes": ([
                "این گزارش نامه مدیریتِ مبتنی بر یافته‌های ثبت‌شده در سامانه است و پیش‌نویس قابل بازبینی محسوب می‌شود.",
                "فیلدهای خالی به معنی نبود اطلاعات ثبت‌شده هستند و نباید به‌عنوان نبود مشکل یا نبود اثر تفسیر شوند.",
                "درج معیار، وضعیت، علت، پیامد و اقدام اصلاحی فقط در صورت ثبت در پرونده انجام می‌شود؛ متن یا نتیجه‌ای به‌صورت خودکار ساخته نشده است.",
                "این گزارش به‌تنهایی جایگزین ارزیابی اهمیت، کفایت شواهد، پاسخ مدیریت یا قضاوت حرفه‌ای حسابرس نیست.",
            ] if source == "management_letter" else []),
        }
