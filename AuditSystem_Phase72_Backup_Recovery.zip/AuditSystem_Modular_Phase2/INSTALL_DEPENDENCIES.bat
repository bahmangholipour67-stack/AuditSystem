@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_CMD=py -3.12"
echo Checking Python 3.12...
%PYTHON_CMD% --version
if errorlevel 1 goto no_python

echo.
echo Installing optional report-export dependencies for Python 3.12...
echo pip will NOT be upgraded.
%PYTHON_CMD% -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Verifying Word export dependency...
%PYTHON_CMD% -c "from docx import Document; print('python-docx is ready')"
if errorlevel 1 goto failed

echo.
echo Optional report dependencies installed successfully.
pause
exit /b 0
:no_python
echo.
echo Python 3.12 was not found. Install/use Python 3.12 (64-bit).
pause
exit /b 2
:failed
echo.
echo Dependency installation failed. The main application can still be tested if its core dependencies are present.
echo Check network access to pypi.org and files.pythonhosted.org.
pause
exit /b 1
