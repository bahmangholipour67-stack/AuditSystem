# Phase 41 — Risk Intelligence Engine

This phase adds a deterministic, read-only risk classification and management-alert service.

## Risk score bands (initial configurable-methodology proposal)
- 1–4: Low
- 5–9: Medium
- 10–15: High
- 16–25: Critical

## Alert sources
- High and critical risk scores
- Open high-severity findings
- Findings with no linked evidence (as supplied by caller)
- Audit tests awaiting supervisor review
- Workpapers/findings/tests/programs with missing links (as supplied by caller)

## Data safety
- The service is read-only and does not alter database rows.
- Invalid risk-score rows are skipped in classification; direct score validation raises `ValueError`.
- Risk bands are suggested starting thresholds and should be reviewed/adjusted by the audit firm's methodology. They do not replace professional judgment or ISA risk assessment.

## Scope
The service and unit tests are added in this phase. The service is not yet wired to the live dashboard UI; that is a planned integration step.
