# Phase 48 — Navigation Scrolling Refinement

## Scope
- Adds a horizontal scrollbar to the right-side navigation canvas alongside the existing vertical scrollbar.
- Keeps navigation content at its requested width when labels require extra space; long labels are no longer forced to fit the viewport.
- Adds mouse-wheel navigation: vertical wheel scrolls the menu vertically; Shift+wheel scrolls horizontally.
- Wheel handling is attached to the canvas, menu content, and navigation buttons so scrolling remains usable while the pointer is over menu items.
- Maintains Phase 47 unified navigation and all existing modules/data workflows.


## Validation
- Python compile check for `legacy/audit_app.py` passed.
- Full automated test suite: 257 passed, 131 subtests passed.
- GUI behavior still requires visual confirmation on Windows.
