"""Centralized, short-lived SQLite connections for AuditSystem.

All application connections use a bounded lock wait and explicitly enable
foreign-key enforcement. The context manager owns the transaction and always
closes the connection, including when application code raises an exception.
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from config.settings import DATABASE_PATH

DEFAULT_TIMEOUT_SECONDS = 15
DEFAULT_BUSY_TIMEOUT_MS = 15000


def open_connection(db_path=DATABASE_PATH, timeout=DEFAULT_TIMEOUT_SECONDS):
    """Return a configured SQLite connection; caller is responsible for closing it."""
    conn = sqlite3.connect(str(db_path), timeout=float(timeout))
    try:
        conn.execute(f"PRAGMA busy_timeout = {DEFAULT_BUSY_TIMEOUT_MS}")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    except Exception:
        conn.close()
        raise


def open_readonly_connection(db_path=DATABASE_PATH, timeout=DEFAULT_TIMEOUT_SECONDS):
    """Open an existing database in SQLite read-only mode."""
    path = Path(db_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Database file does not exist: {path}")
    conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=float(timeout))
    try:
        conn.execute(f"PRAGMA busy_timeout = {DEFAULT_BUSY_TIMEOUT_MS}")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    except Exception:
        conn.close()
        raise


@contextmanager
def connect(db_path=DATABASE_PATH, timeout=DEFAULT_TIMEOUT_SECONDS):
    """Open a transaction-safe connection and always commit/rollback and close."""
    conn = open_connection(db_path=db_path, timeout=timeout)
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()
