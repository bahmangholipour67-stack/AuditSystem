
"""Safe, non-destructive database migrations."""

from database.connection import connect
from config.settings import DATABASE_PATH
from database.schema import initialize


PROJECT_COLUMNS = {
    "audit_type": "TEXT NOT NULL DEFAULT 'مستقل'",
    "manager": "TEXT NOT NULL DEFAULT ''",
    "start_date": "TEXT NOT NULL DEFAULT ''",
    "end_date": "TEXT NOT NULL DEFAULT ''",
    "status": "TEXT NOT NULL DEFAULT 'جدید'",
    "description": "TEXT NOT NULL DEFAULT ''",
    "updated_at": "TEXT",
}

WORKPAPER_COLUMNS = {
    "assigned_member_id": "INTEGER",
    "reviewer_member_id": "INTEGER",
    "approved_by_member_id": "INTEGER",
    "reviewed_at": "TEXT",
    "approved_at": "TEXT",
}

FINDING_COLUMNS = {
    "risk_id": "INTEGER",
}


def add_missing_columns(conn, table_name, columns):
    existing = {
        row[1]
        for row in conn.execute(
            f"PRAGMA table_info({table_name})"
        ).fetchall()
    }

    for column, definition in columns.items():
        if column not in existing:
            conn.execute(
                f"ALTER TABLE {table_name} "
                f"ADD COLUMN {column} {definition}"
            )


def migrate_projects(conn):
    add_missing_columns(conn, "projects", PROJECT_COLUMNS)

    conn.execute("""
        UPDATE projects
        SET updated_at = COALESCE(updated_at, created_at)
        WHERE updated_at IS NULL
    """)


def migrate_workpapers(conn):
    add_missing_columns(conn, "workpapers", WORKPAPER_COLUMNS)


def migrate_findings(conn):
    """Add direct risk linkage while preserving legacy workpaper links."""
    add_missing_columns(conn, "findings", FINDING_COLUMNS)
    conn.execute("""
        UPDATE findings
        SET risk_id = (
            SELECT w.risk_id FROM workpapers w
            WHERE w.id = findings.workpaper_id
              AND w.project_id = findings.project_id
        )
        WHERE risk_id IS NULL AND workpaper_id IS NOT NULL
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_findings_project_risk "
        "ON findings(project_id, risk_id)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_findings_project_workpaper "
        "ON findings(project_id, workpaper_id)"
    )
    conn.execute("""
        CREATE TABLE IF NOT EXISTS finding_evidence (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            finding_id INTEGER NOT NULL,
            file_path TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            added_by_member_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_finding_evidence_finding "
        "ON finding_evidence(project_id, finding_id)"
    )


def create_team_tables(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS team_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'حسابرس',
            phone TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_team_members_project
        ON team_members(project_id)
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS workpaper_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            workpaper_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            previous_status TEXT,
            new_status TEXT,
            actor_member_id INTEGER,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_workpaper_history_workpaper
        ON workpaper_history(workpaper_id)
    """)



def create_team_communication_tables(conn):
    """Create append-only, project-scoped workpaper communication records."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS team_communications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            workpaper_id INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            author_member_id INTEGER NOT NULL,
            recipient_member_id INTEGER,
            body TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_team_communications_inbox ON team_communications(project_id, recipient_member_id, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_team_communications_thread ON team_communications(project_id, workpaper_id, id)")
    conn.execute("CREATE TRIGGER IF NOT EXISTS team_communications_no_update BEFORE UPDATE ON team_communications BEGIN SELECT RAISE(ABORT, 'team communications are append-only'); END")
    conn.execute("CREATE TRIGGER IF NOT EXISTS team_communications_no_delete BEFORE DELETE ON team_communications BEGIN SELECT RAISE(ABORT, 'team communications are append-only'); END")


AUDIT_TEST_COLUMNS = {
    "workpaper_id": "INTEGER",
    "finding_id": "INTEGER",
    "submitted_by_member_id": "INTEGER",
    "submitted_at": "TEXT",
    "supervisor_decision": "TEXT",
    "supervisor_member_id": "INTEGER",
    "supervisor_reviewed_at": "TEXT",
    "supervisor_comment": "TEXT",
    "manager_member_id": "INTEGER",
    "manager_approved_at": "TEXT",
    "manager_comment": "TEXT",
    "template_id": "TEXT NOT NULL DEFAULT ''",
    "template_objective": "TEXT NOT NULL DEFAULT ''",
    "template_assertions": "TEXT NOT NULL DEFAULT '[]'",
    "expected_evidence": "TEXT NOT NULL DEFAULT ''",
}

SAMPLE_COLUMNS = {
    "document_ref": "TEXT NOT NULL DEFAULT ''",
    "description": "TEXT NOT NULL DEFAULT ''",
    "amount": "REAL",
    "misstatement_amount": "REAL",
    "exception_description": "TEXT NOT NULL DEFAULT ''",
    "evidence_path": "TEXT NOT NULL DEFAULT ''",
    "tested_by_member_id": "INTEGER",
    "tested_at": "TEXT",
}

def create_audit_test_tables(conn):
    """Create audit-test tables and safely upgrade older installations."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_programs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL, title TEXT NOT NULL,
            audit_area TEXT NOT NULL DEFAULT '', objective TEXT NOT NULL DEFAULT '',
            risk_id INTEGER, workpaper_id INTEGER, assigned_member_id INTEGER,
            start_date TEXT NOT NULL DEFAULT '', due_date TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'برنامه‌ریزی‌شده',
            notes TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            program_id INTEGER NOT NULL, title TEXT NOT NULL,
            test_type TEXT NOT NULL DEFAULT 'ماهوی', procedure TEXT NOT NULL DEFAULT '',
            population_description TEXT NOT NULL DEFAULT '',
            population_size INTEGER NOT NULL DEFAULT 0, sample_size INTEGER NOT NULL DEFAULT 0,
            sampling_method TEXT NOT NULL DEFAULT 'تصادفی ساده', random_seed INTEGER,
            assigned_member_id INTEGER, status TEXT NOT NULL DEFAULT 'جدید',
            conclusion TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT, workpaper_id INTEGER, finding_id INTEGER,
            submitted_by_member_id INTEGER, submitted_at TEXT, supervisor_decision TEXT,
            supervisor_member_id INTEGER, supervisor_reviewed_at TEXT,
            supervisor_comment TEXT, manager_member_id INTEGER,
            manager_approved_at TEXT, manager_comment TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_test_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            test_id INTEGER NOT NULL, sample_no INTEGER NOT NULL, population_row INTEGER,
            document_ref TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
            amount REAL, result TEXT NOT NULL DEFAULT 'رسیدگی‌نشده',
            exception_description TEXT NOT NULL DEFAULT '', evidence_path TEXT NOT NULL DEFAULT '',
            tested_by_member_id INTEGER, tested_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(test_id, sample_no)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_test_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            test_id INTEGER NOT NULL, sample_id INTEGER, action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '', actor_member_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    add_missing_columns(conn, "audit_tests", AUDIT_TEST_COLUMNS)
    add_missing_columns(conn, "audit_test_samples", SAMPLE_COLUMNS)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_programs_project ON audit_programs(project_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_tests_program ON audit_tests(program_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_samples_test ON audit_test_samples(test_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_history_test ON audit_test_history(test_id)")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_sample_findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            test_id INTEGER NOT NULL, sample_id INTEGER NOT NULL, finding_id INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(sample_id, finding_id)
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_sample_findings_test ON audit_sample_findings(test_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_sample_findings_finding ON audit_sample_findings(finding_id)")



PROJECT_ARCHIVE_COLUMNS = {
    "archived_at": "TEXT",
    "archive_reason": "TEXT NOT NULL DEFAULT ''",
    "archived_by_member_id": "INTEGER",
    "archived_previous_status": "TEXT NOT NULL DEFAULT ''",
}


def migrate_project_archive(conn):
    """Add reversible, auditable soft-archive support for audit projects."""
    add_missing_columns(conn, "projects", PROJECT_ARCHIVE_COLUMNS)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS project_archive_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            event_type TEXT NOT NULL CHECK(event_type IN ('ARCHIVE', 'RESTORE')),
            reason TEXT NOT NULL DEFAULT '',
            actor_member_id INTEGER,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_project_archive_history_project "
        "ON project_archive_history(project_id, id)"
    )
    # Backward compatibility: projects already marked as archived are retained
    # and receive archive metadata without changing their status.
    conn.execute("""
        UPDATE projects
        SET archived_at = COALESCE(archived_at, updated_at, created_at),
            archived_previous_status = CASE
                WHEN archived_previous_status = '' THEN 'تکمیل‌شده'
                ELSE archived_previous_status END,
            archive_reason = CASE
                WHEN archive_reason = '' THEN 'بایگانی‌شده در نسخه پیشین سامانه'
                ELSE archive_reason END
        WHERE status = 'بایگانی' AND archived_at IS NULL
    """)
    conn.execute("""
        INSERT INTO project_archive_history (project_id, event_type, reason, created_at)
        SELECT p.id, 'ARCHIVE', p.archive_reason, p.archived_at
        FROM projects p
        WHERE p.archived_at IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM project_archive_history h
              WHERE h.project_id = p.id AND h.event_type = 'ARCHIVE'
          )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_projects_archived_at "
        "ON projects(archived_at, id)"
    )

def migrate_document_repository(conn):
    """Create shared project-scoped document and request tables safely."""
    conn.execute("""CREATE TABLE IF NOT EXISTS engagement_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'عمومی',
        file_path TEXT NOT NULL,
        file_name TEXT NOT NULL DEFAULT '',
        size_bytes INTEGER NOT NULL DEFAULT 0,
        sha256 TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        uploaded_by_member_id INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        archived_at TEXT,
        archive_reason TEXT NOT NULL DEFAULT '',
        archived_by_member_id INTEGER
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS document_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        document_id INTEGER NOT NULL,
        relation_type TEXT NOT NULL,
        relation_id INTEGER NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(project_id, document_id, relation_type, relation_id)
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS document_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        document_id INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        details TEXT NOT NULL DEFAULT '',
        actor_member_id INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS document_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        requested_from TEXT NOT NULL DEFAULT '',
        assigned_member_id INTEGER,
        due_date TEXT NOT NULL DEFAULT '',
        priority TEXT NOT NULL DEFAULT 'عادی',
        status TEXT NOT NULL DEFAULT 'جدید',
        created_by_member_id INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT,
        completed_at TEXT,
        archived_at TEXT,
        archive_reason TEXT NOT NULL DEFAULT '',
        archived_by_member_id INTEGER
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS document_request_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        request_id INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        old_status TEXT,
        new_status TEXT,
        actor_member_id INTEGER,
        details TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_engagement_documents_project ON engagement_documents(project_id, archived_at, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_document_links_target ON document_links(project_id, relation_type, relation_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_document_requests_project ON document_requests(project_id, archived_at, status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_document_request_history ON document_request_history(project_id, request_id, id)")



def migrate_misstatement_evaluation(conn):
    """Add project materiality settings and auditable misstatement register."""
    conn.execute("""CREATE TABLE IF NOT EXISTS project_materiality (
        project_id INTEGER PRIMARY KEY, overall_materiality REAL NOT NULL,
        performance_materiality REAL NOT NULL, clearly_trivial REAL NOT NULL,
        basis TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS project_materiality_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        event_type TEXT NOT NULL, previous_values TEXT NOT NULL DEFAULT '',
        new_values TEXT NOT NULL DEFAULT '', actor_member_id INTEGER,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_misstatements (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        title TEXT NOT NULL, misstatement_type TEXT NOT NULL,
        account_name TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT '', amount REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'اصلاح‌نشده', finding_id INTEGER,
        workpaper_id INTEGER, audit_test_id INTEGER, tax_effect REAL,
        created_by_member_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT, archived_at TEXT, archive_reason TEXT NOT NULL DEFAULT '',
        archived_by_member_id INTEGER
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS misstatement_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        misstatement_id INTEGER NOT NULL, event_type TEXT NOT NULL,
        old_status TEXT, new_status TEXT, details TEXT NOT NULL DEFAULT '',
        actor_member_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_materiality_history_project ON project_materiality_history(project_id, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_misstatements_project ON audit_misstatements(project_id, archived_at, status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_misstatement_history ON misstatement_history(project_id, misstatement_id, id)")


def migrate_approval_workflow(conn):
    """Create version-bound, append-only multi-stage approval records."""
    conn.execute("""CREATE TABLE IF NOT EXISTS approval_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
        snapshot_hash TEXT NOT NULL, submitted_by_member_id INTEGER NOT NULL,
        supervisor_member_id INTEGER NOT NULL, manager_member_id INTEGER NOT NULL,
        quality_member_id INTEGER NOT NULL, current_stage TEXT NOT NULL,
        status TEXT NOT NULL, submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        completed_at TEXT, archived_at TEXT,
        UNIQUE(project_id, entity_type, entity_id)
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS approval_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        request_id INTEGER NOT NULL, event_type TEXT NOT NULL, stage TEXT NOT NULL,
        actor_member_id INTEGER NOT NULL, actor_role TEXT NOT NULL,
        comment TEXT NOT NULL DEFAULT '', snapshot_hash TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_approval_requests_project ON approval_requests(project_id, status, id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_approval_history_request ON approval_history(project_id, request_id, id)")
    conn.execute("CREATE TRIGGER IF NOT EXISTS approval_history_no_update BEFORE UPDATE ON approval_history BEGIN SELECT RAISE(ABORT, 'approval history is append-only'); END")
    conn.execute("CREATE TRIGGER IF NOT EXISTS approval_history_no_delete BEFORE DELETE ON approval_history BEGIN SELECT RAISE(ABORT, 'approval history is append-only'); END")



def migrate_internal_control_engine(conn):
    """Add internal-control records while extending the shared findings model."""
    add_missing_columns(conn, "findings", {
        "finding_type": "TEXT NOT NULL DEFAULT 'عمومی'",
        "condition_text": "TEXT NOT NULL DEFAULT ''",
        "criteria_text": "TEXT NOT NULL DEFAULT ''",
        "cause_text": "TEXT NOT NULL DEFAULT ''",
        "effect_text": "TEXT NOT NULL DEFAULT ''",
        "likelihood": "INTEGER NOT NULL DEFAULT 3",
        "impact": "INTEGER NOT NULL DEFAULT 3",
        "control_id": "INTEGER",
    })
    conn.execute("""CREATE TABLE IF NOT EXISTS internal_controls (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        title TEXT NOT NULL, objective TEXT NOT NULL DEFAULT '', risk_id INTEGER,
        owner TEXT NOT NULL DEFAULT '', frequency TEXT NOT NULL DEFAULT '',
        control_type TEXT NOT NULL, method TEXT NOT NULL, criteria TEXT NOT NULL DEFAULT '',
        archived_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_internal_controls_project ON internal_controls(project_id,archived_at,id)")
    conn.execute("""CREATE TABLE IF NOT EXISTS control_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, control_id INTEGER NOT NULL,
        test_stage TEXT NOT NULL, result TEXT NOT NULL, sample_size INTEGER NOT NULL DEFAULT 0,
        exceptions INTEGER NOT NULL DEFAULT 0, evidence TEXT NOT NULL DEFAULT '', tester TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_control_tests_project_control ON control_tests(project_id,control_id,id)")
    conn.execute("""CREATE TABLE IF NOT EXISTS corrective_actions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, finding_id INTEGER NOT NULL,
        title TEXT NOT NULL, owner TEXT NOT NULL, due_date TEXT NOT NULL, milestones TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'باز', progress_note TEXT NOT NULL DEFAULT '',
        closure_evidence TEXT NOT NULL DEFAULT '', followup_result TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_corrective_actions_project_finding ON corrective_actions(project_id,finding_id,id)")
    conn.execute("CREATE VIEW IF NOT EXISTS internal_control_findings AS SELECT * FROM findings WHERE finding_type='کنترل داخلی'")
    conn.execute("""CREATE TABLE IF NOT EXISTS internal_control_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL, event_type TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_internal_control_history_entity ON internal_control_history(project_id,entity_type,entity_id,id)")
    conn.execute("CREATE TRIGGER IF NOT EXISTS internal_control_history_no_update BEFORE UPDATE ON internal_control_history BEGIN SELECT RAISE(ABORT,'internal control history is append-only'); END")
    conn.execute("CREATE TRIGGER IF NOT EXISTS internal_control_history_no_delete BEFORE DELETE ON internal_control_history BEGIN SELECT RAISE(ABORT,'internal control history is append-only'); END")


def migrate_coso_framework(conn):
    """Install COSO's five components and 17 principles, plus project-scoped mappings."""
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_principles (
        code TEXT PRIMARY KEY, component_no INTEGER NOT NULL, component TEXT NOT NULL,
        principle_no INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '')""")
    principles = [
        ("P01",1,"محیط کنترلی",1,"تعهد به درستکاری و ارزش‌های اخلاقی"),("P02",1,"محیط کنترلی",2,"اعمال مسئولیت نظارتی"),("P03",1,"محیط کنترلی",3,"تعیین ساختار، اختیار و مسئولیت"),("P04",1,"محیط کنترلی",4,"تعهد به شایستگی"),("P05",1,"محیط کنترلی",5,"پاسخگویی نسبت به مسئولیت‌ها"),
        ("P06",2,"ارزیابی ریسک",6,"تعیین اهداف روشن"),("P07",2,"ارزیابی ریسک",7,"شناسایی و تحلیل ریسک"),("P08",2,"ارزیابی ریسک",8,"ارزیابی ریسک تقلب"),("P09",2,"ارزیابی ریسک",9,"شناسایی و ارزیابی تغییرات مهم"),
        ("P10",3,"فعالیت‌های کنترلی",10,"انتخاب و توسعه فعالیت‌های کنترلی"),("P11",3,"فعالیت‌های کنترلی",11,"کنترل‌های عمومی فناوری"),("P12",3,"فعالیت‌های کنترلی",12,"استقرار کنترل از طریق سیاست‌ها و رویه‌ها"),
        ("P13",4,"اطلاعات و ارتباطات",13,"استفاده از اطلاعات مرتبط و باکیفیت"),("P14",4,"اطلاعات و ارتباطات",14,"ارتباطات داخلی"),("P15",4,"اطلاعات و ارتباطات",15,"ارتباطات با طرف‌های برون‌سازمانی"),
        ("P16",5,"فعالیت‌های نظارتی",16,"ارزیابی‌های مستمر و مستقل"),("P17",5,"فعالیت‌های نظارتی",17,"ارزیابی و گزارش نارسایی‌ها")]
    conn.executemany("INSERT OR IGNORE INTO coso_principles(code,component_no,component,principle_no,title) VALUES(?,?,?,?,?)", principles)
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_control_mappings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, control_id INTEGER NOT NULL,
        principle_code TEXT NOT NULL, risk_id INTEGER, rationale TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(project_id,control_id,principle_code))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_coso_mapping_project_principle ON coso_control_mappings(project_id,principle_code)")
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_principle_assessments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, principle_code TEXT NOT NULL,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), evidence TEXT NOT NULL,
        conclusion TEXT NOT NULL DEFAULT '', assessor TEXT NOT NULL DEFAULT '',
        assessed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(project_id,principle_code))""")
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL, event_type TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_coso_history_entity ON coso_history(project_id,entity_type,entity_id,id)")
    conn.execute("CREATE TRIGGER IF NOT EXISTS coso_history_no_update BEFORE UPDATE ON coso_history BEGIN SELECT RAISE(ABORT,'COSO history is append-only'); END")
    conn.execute("CREATE TRIGGER IF NOT EXISTS coso_history_no_delete BEFORE DELETE ON coso_history BEGIN SELECT RAISE(ABORT,'COSO history is append-only'); END")
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_checklist_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, principle_code TEXT NOT NULL,
        question_no INTEGER NOT NULL, question_text TEXT NOT NULL,
        guidance TEXT NOT NULL DEFAULT '', expected_evidence TEXT NOT NULL DEFAULT '',
        UNIQUE(principle_code,question_no))""")
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_checklist_responses (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL, answer TEXT NOT NULL DEFAULT 'پاسخ‌داده‌نشده'
            CHECK(answer IN ('بله','خیر','تاحدی','قابل‌اعمال نیست','پاسخ‌داده‌نشده')),
        explanation TEXT NOT NULL DEFAULT '', evidence_ref TEXT NOT NULL DEFAULT '',
        weakness TEXT NOT NULL DEFAULT '', corrective_action TEXT NOT NULL DEFAULT '',
        owner TEXT NOT NULL DEFAULT '', due_date TEXT NOT NULL DEFAULT '',
        assessor TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(project_id,question_id))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_coso_checklist_project ON coso_checklist_responses(project_id,question_id)")
    conn.execute("""CREATE TABLE IF NOT EXISTS coso_checklist_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
        question_id INTEGER NOT NULL, response_id INTEGER, event_type TEXT NOT NULL,
        detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_coso_checklist_history ON coso_checklist_history(project_id,question_id,id)")
    conn.execute("CREATE TRIGGER IF NOT EXISTS coso_checklist_history_no_update BEFORE UPDATE ON coso_checklist_history BEGIN SELECT RAISE(ABORT,'COSO checklist history is append-only'); END")
    conn.execute("CREATE TRIGGER IF NOT EXISTS coso_checklist_history_no_delete BEFORE DELETE ON coso_checklist_history BEGIN SELECT RAISE(ABORT,'COSO checklist history is append-only'); END")
    # Five practical, evidence-oriented assessment prompts for each of the 17 principles.
    checklist = {
      'P01': ['مدیریت ارشد الگوی رفتاری روشن و قابل مشاهده‌ای از درستکاری و اخلاق حرفه‌ای ارائه می‌کند؟','آیین‌نامه اخلاقی و تعارض منافع تدوین، ابلاغ و به کارکنان آموزش داده شده است؟','سازوکار محرمانه و قابل اتکایی برای گزارش تخلف و حمایت از گزارش‌دهنده وجود دارد؟','موارد نقض اخلاقی به‌موقع بررسی و اقدامات انضباطی متناسب و مستند اعمال می‌شود؟','رعایت ارزش‌های اخلاقی به‌طور دوره‌ای ارزیابی و نتایج آن به ارکان نظارتی گزارش می‌شود؟'],
      'P02': ['هیئت‌مدیره یا رکن نظارتی مستقل، مسئولیت نظارت بر طراحی و عملکرد کنترل داخلی را پذیرفته است؟','ترکیب اعضا از تخصص و استقلال کافی برای نظارت برخوردار است؟','جلسات نظارتی منظم برگزار و صورت‌جلسات و تصمیم‌ها مستند می‌شوند؟','گزارش‌های ریسک، تخلف، کنترل داخلی و حسابرسی به‌موقع به رکن نظارتی می‌رسد؟','پیگیری اجرای مصوبات و رفع نواقص تا حصول نتیجه انجام می‌شود؟'],
      'P03': ['ساختار سازمانی متناسب با اهداف و ریسک‌های شرکت طراحی و تصویب شده است؟','حدود اختیار، مسئولیت و خطوط گزارش‌دهی واحدها و اشخاص روشن و مستند است؟','تفکیک وظایف ناسازگار در فرایندهای حساس رعایت می‌شود؟','تغییرات ساختار و اختیارات با ارزیابی آثار کنترلی تصویب و ابلاغ می‌شود؟','ساختار واقعی فعالیت‌ها با ساختار مصوب تطبیق داده و انحراف‌ها اصلاح می‌شوند؟'],
      'P04': ['شایستگی‌های لازم برای نقش‌های کلیدی و حساس تعریف شده‌اند؟','فرایند جذب، انتصاب و ارتقای کارکنان بر مبنای صلاحیت و تجربه مرتبط انجام می‌شود؟','نیازهای آموزشی کارکنان در حوزه کنترل داخلی و وظایف تخصصی شناسایی می‌شود؟','آموزش‌ها و ارزیابی اثربخشی آن‌ها مستند و قابل ردیابی است؟','برای کمبود مهارت یا وابستگی به افراد کلیدی برنامه جانشین‌پروری وجود دارد؟'],
      'P05': ['انتظارات عملکردی و مسئولیت هر فرد در قبال کنترل‌های داخلی ابلاغ شده است؟','شاخص‌های ارزیابی عملکرد، رعایت کنترل‌ها و کیفیت انجام وظایف را نیز پوشش می‌دهند؟','عملکرد مسئولان کنترل به‌صورت دوره‌ای ارزیابی و مستند می‌شود؟','برای عدم انجام مسئولیت‌ها یا دور زدن کنترل‌ها پاسخگویی متناسب اعمال می‌شود؟','پاداش‌ها و مشوق‌ها رفتار پرریسک یا گزارشگری نادرست را ترغیب نمی‌کنند؟'],
      'P06': ['اهداف عملیاتی، گزارشگری و رعایت قوانین به‌صورت روشن و قابل سنجش تعیین شده‌اند؟','اهداف در سطوح شرکت، واحدها و فرایندها با یکدیگر همسو هستند؟','اهداف گزارشگری مالی و غیرمالی از نظر دقت، زمان‌بندی و قابلیت اتکا مشخص‌اند؟','ریسک‌های دستیابی به اهداف در زمان تعیین اهداف مورد توجه قرار می‌گیرند؟','اهداف و شاخص‌ها به مسئولان مربوط ابلاغ و در صورت تغییر شرایط بازنگری می‌شوند؟'],
      'P07': ['فرایند رسمی و مستندی برای شناسایی ریسک در سطح شرکت و فرایندها وجود دارد؟','ریسک‌ها با توجه به احتمال وقوع و آثار مالی، عملیاتی و قانونی تحلیل می‌شوند؟','ریسک ذاتی و ریسک باقیمانده از یکدیگر تفکیک و مستند می‌شوند؟','مالک ریسک، پاسخ ریسک و کنترل‌های مرتبط برای ریسک‌های مهم تعیین شده‌اند؟','فهرست ریسک‌ها با تغییرات فعالیت و نتایج پایش به‌روزرسانی می‌شود؟'],
      'P08': ['سناریوهای تقلب متناسب با فعالیت، دارایی‌ها و فرایندهای شرکت شناسایی شده‌اند؟','ریسک دستکاری گزارشگری، سوءاستفاده از دارایی و فساد بررسی می‌شود؟','عوامل فشار، فرصت و توجیه تقلب در ارزیابی ریسک لحاظ می‌شوند؟','کنترل‌های پیشگیرانه و کشف‌کننده تقلب و مسیر گزارش موارد مشکوک تعریف شده‌اند؟','نشانه‌ها و ادعاهای تقلب بررسی، مستند و به مرجع مناسب ارجاع می‌شوند؟'],
      'P09': ['فرایندی برای شناسایی تغییرات داخلی و بیرونی اثرگذار بر کنترل داخلی وجود دارد؟','تغییرات فناوری، قوانین، مدیران، مدل کسب‌وکار و ساختار ارزیابی می‌شوند؟','پیش از اجرای تغییرات بااهمیت، آثار آن‌ها بر ریسک و کنترل بررسی می‌شود؟','کنترل‌ها و مستندات پس از تغییرات مهم به‌روزرسانی می‌شوند؟','مسئول پایش تغییرات و گزارش پیامدهای آن مشخص است؟'],
      'P10': ['کنترل‌ها بر مبنای ریسک‌های ارزیابی‌شده و سطح قابل قبول ریسک انتخاب شده‌اند؟','ترکیبی متناسب از کنترل‌های پیشگیرانه، کشف‌کننده و اصلاحی طراحی شده است؟','کنترل‌های کلیدی، مالک، تناوب، شواهد اجرا و معیار موفقیت مشخص دارند؟','کنترل‌های جبرانی در موارد محدودیت تفکیک وظایف طراحی و مستند شده‌اند؟','طراحی کنترل‌ها از نظر تناسب هزینه، پوشش ریسک و امکان اجرا بازبینی می‌شود؟'],
      'P11': ['دسترسی کاربران به سامانه‌ها بر اساس نقش و اصل حداقل دسترسی تخصیص می‌یابد؟','ایجاد، تغییر و لغو دسترسی‌ها تأیید و به‌موقع انجام می‌شود؟','تغییرات برنامه‌ها، تنظیمات و زیرساخت فناوری کنترل و ثبت می‌شوند؟','پشتیبان‌گیری، بازیابی، تداوم کسب‌وکار و امنیت اطلاعات آزمون می‌شوند؟','گزارش رخدادهای فناوری و دسترسی‌های ممتاز به‌صورت دوره‌ای بازبینی می‌شود؟'],
      'P12': ['سیاست‌ها و رویه‌های کنترل داخلی برای فرایندهای کلیدی تدوین و تصویب شده‌اند؟','مسئول اجرا، زمان اجرا و شواهد مورد انتظار هر رویه مشخص است؟','رویه‌ها به کارکنان مرتبط ابلاغ و دسترسی به نسخه معتبر فراهم شده است؟','اجرای واقعی رویه‌ها با نمونه‌گیری یا نظارت بررسی می‌شود؟','عدم رعایت رویه‌ها ثبت، تحلیل و با اقدام اصلاحی پیگیری می‌شود؟'],
      'P13': ['اطلاعات موردنیاز برای اجرای کنترل‌ها از منابع معتبر و به‌موقع تهیه می‌شود؟','کامل بودن، صحت، اعتبار، دسترس‌پذیری و محرمانگی اطلاعات ارزیابی می‌شود؟','منابع داده و مالک اطلاعات برای گزارش‌های کلیدی مشخص هستند؟','کنترل‌های ورود، پردازش، انتقال و گزارش‌گیری داده‌ها برقرارند؟','کیفیت اطلاعات مورد استفاده مدیریت و حسابرسان به‌صورت دوره‌ای ارزیابی می‌شود؟'],
      'P14': ['مسیرهای ارتباطی رسمی برای انتقال مسئولیت‌ها و انتظارات کنترل داخلی وجود دارد؟','کارکنان می‌دانند تخلف، نقص کنترل یا ریسک جدید را چگونه گزارش کنند؟','اطلاعات مرتبط با تغییر سیاست‌ها و رویه‌ها به‌موقع به افراد ذی‌ربط می‌رسد؟','ارتباط میان واحدها برای کنترل فرایندهای بین‌بخشی برقرار و مستند است؟','اثربخشی ارتباطات داخلی و رفع موانع گزارش‌دهی ارزیابی می‌شود؟'],
      'P15': ['الزامات ارتباط با سهامداران، نهادهای ناظر، حسابرسان و سایر ذی‌نفعان مشخص است؟','اطلاعات برون‌سازمانی کامل، دقیق، مجاز و در موعد مقرر منتشر می‌شود؟','کانال دریافت شکایت، گزارش تخلف و بازخورد طرف‌های بیرونی وجود دارد؟','محدودیت‌های محرمانگی و مجوز انتشار اطلاعات رعایت می‌شوند؟','بازخوردهای بیرونی تحلیل و در صورت لزوم به اصلاح کنترل‌ها منجر می‌شوند؟'],
      'P16': ['ارزیابی‌های مستمر در جریان عملیات برای بررسی عملکرد کنترل‌ها انجام می‌شود؟','ارزیابی‌های مستقل با دامنه، تناوب و صلاحیت مناسب برنامه‌ریزی می‌شوند؟','روش‌ها و معیارهای ارزیابی کنترل‌ها مستند و قابل تکرار هستند؟','نتایج ارزیابی‌ها با شواهد کافی پشتیبانی و به مسئولان ذی‌ربط گزارش می‌شوند؟','دامنه و تناوب پایش با سطح ریسک و تغییرات محیط کنترل متناسب است؟'],
      'P17': ['نواقص کنترل داخلی بر اساس معیار مشخص شناسایی و طبقه‌بندی می‌شوند؟','شدت، علت ریشه‌ای، آثار و دامنه انتشار هر نقص ارزیابی می‌شود؟','نواقص مهم بدون تأخیر به مدیریت ارشد و رکن نظارتی گزارش می‌شوند؟','برای هر نقص، مسئول، مهلت و اقدام اصلاحی قابل سنجش تعیین می‌شود؟','اجرای اقدام اصلاحی با شواهد و آزمون پیگیری تأیید و وضعیت نقص به‌روز می‌شود؟']
    }
    guidance = 'پاسخ را بر اساس شواهد قابل اتکا ثبت کنید؛ در صورت پاسخ «قابل‌اعمال نیست» توجیه مستند ارائه شود.'
    evidence = 'سیاست/دستورالعمل، صورت‌جلسه، گزارش، نمونه تراکنش، لاگ سامانه، مصاحبه یا مشاهده مستقیم حسب موضوع'
    for code, questions in checklist.items():
        for qno, question in enumerate(questions, 1):
            conn.execute("INSERT OR IGNORE INTO coso_checklist_questions(principle_code,question_no,question_text,guidance,expected_evidence) VALUES(?,?,?,?,?)", (code,qno,question,guidance,evidence))

def ensure_schema(db_path=None):
    """Initialize and migrate the selected database; defaults to app database."""
    with connect(db_path or DATABASE_PATH) as conn:
        initialize(conn)
        migrate_projects(conn)
        migrate_project_archive(conn)
        migrate_workpapers(conn)
        migrate_findings(conn)
        create_team_tables(conn)
        create_team_communication_tables(conn)
        create_audit_test_tables(conn)
        migrate_document_repository(conn)
        migrate_misstatement_evaluation(conn)
        migrate_approval_workflow(conn)
        migrate_internal_control_engine(conn)
        migrate_coso_framework(conn)
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_template_library (
            template_id TEXT PRIMARY KEY, content_json TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_project_template_overrides (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            template_id TEXT NOT NULL, content_json TEXT NOT NULL,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(project_id, template_id))""")
        conn.execute("""CREATE TABLE IF NOT EXISTS audit_template_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL,
            project_id INTEGER, template_id TEXT NOT NULL, content_json TEXT NOT NULL,
            action TEXT NOT NULL DEFAULT '', actor_member_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_audit_template_history ON audit_template_history(template_id, id)")
