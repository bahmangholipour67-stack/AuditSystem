
"""Safe, non-destructive database migrations."""

from database.connection import connect
from database.schema import initialize


PROJECT_COLUMNS = {
    "audit_type": "TEXT NOT NULL DEFAULT 'مستقل'",
    "manager": "TEXT NOT NULL DEFAULT ''",
    "start_date": "TEXT NOT NULL DEFAULT ''",
    "end_date": "TEXT NOT NULL DEFAULT ''",
    "status": "TEXT NOT NULL DEFAULT 'جدید'",
    "description": "TEXT NOT NULL DEFAULT ''",
    "updated_at": "TEXT",
}

WORKPAPER_COLUMNS = {
    "assigned_member_id": "INTEGER",
    "reviewer_member_id": "INTEGER",
    "approved_by_member_id": "INTEGER",
    "reviewed_at": "TEXT",
    "approved_at": "TEXT",
}


def add_missing_columns(conn, table_name, columns):
    existing = {
        row[1]
        for row in conn.execute(
            f"PRAGMA table_info({table_name})"
        ).fetchall()
    }

    for column, definition in columns.items():
        if column not in existing:
            conn.execute(
                f"ALTER TABLE {table_name} "
                f"ADD COLUMN {column} {definition}"
            )


def migrate_projects(conn):
    add_missing_columns(conn, "projects", PROJECT_COLUMNS)

    conn.execute("""
        UPDATE projects
        SET updated_at = COALESCE(updated_at, created_at)
        WHERE updated_at IS NULL
    """)


def migrate_workpapers(conn):
    add_missing_columns(conn, "workpapers", WORKPAPER_COLUMNS)


def create_team_tables(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS team_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'حسابرس',
            phone TEXT NOT NULL DEFAULT '',
            email TEXT NOT NULL DEFAULT '',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_team_members_project
        ON team_members(project_id)
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS workpaper_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            workpaper_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            previous_status TEXT,
            new_status TEXT,
            actor_member_id INTEGER,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_workpaper_history_workpaper
        ON workpaper_history(workpaper_id)
    """)


def ensure_schema():
    with connect() as conn:
        initialize(conn)
        migrate_projects(conn)
        migrate_workpapers(conn)
        create_team_tables(conn)
