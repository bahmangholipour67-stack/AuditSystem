"""Read-only SQLite health diagnostics for an AuditSystem database."""
from database.connection import open_readonly_connection


def inspect_database(db_path):
    """Return integrity, FK, journal, and size diagnostics without mutations."""
    conn = open_readonly_connection(db_path)
    try:
        integrity_rows = conn.execute("PRAGMA integrity_check").fetchall()
        foreign_key_issues = conn.execute("PRAGMA foreign_key_check").fetchall()
        page_count = conn.execute("PRAGMA page_count").fetchone()[0]
        page_size = conn.execute("PRAGMA page_size").fetchone()[0]
        journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        integrity = [row[0] for row in integrity_rows]
        return {
            "ok": integrity == ["ok"] and not foreign_key_issues,
            "integrity_check": integrity,
            "foreign_key_issues": [tuple(row) for row in foreign_key_issues],
            "journal_mode": journal_mode,
            "page_count": page_count,
            "page_size": page_size,
            "database_size_bytes": page_count * page_size,
        }
    finally:
        conn.close()
