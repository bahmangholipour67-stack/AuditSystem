"""Verified SQLite backup and guarded restore utilities for AuditSystem."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from config.settings import DATABASE_PATH


class DatabaseBackupError(RuntimeError):
    """Raised when a backup or restore cannot be completed safely."""


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _open_readonly(path: Path) -> sqlite3.Connection:
    if not path.is_file():
        raise FileNotFoundError(f"فایل پایگاه داده پیدا نشد: {path}")
    uri = path.as_uri() + "?mode=ro"
    return sqlite3.connect(uri, uri=True, timeout=15)


def validate_database(path) -> dict:
    """Validate SQLite integrity and foreign keys without modifying the file."""
    db_path = Path(path).expanduser().resolve()
    conn = _open_readonly(db_path)
    try:
        integrity = [row[0] for row in conn.execute("PRAGMA integrity_check").fetchall()]
        fk_issues = [tuple(row) for row in conn.execute("PRAGMA foreign_key_check").fetchall()]
        return {
            "ok": integrity == ["ok"] and not fk_issues,
            "integrity_check": integrity,
            "foreign_key_issues": fk_issues,
            "size_bytes": db_path.stat().st_size,
        }
    finally:
        conn.close()


def create_backup(db_path=DATABASE_PATH, backup_dir=None, keep=10) -> dict:
    """Create a consistent SQLite online backup, verify it, and rotate old backups."""
    source = Path(db_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"فایل پایگاه داده پیدا نشد: {source}")
    destination_dir = Path(backup_dir).expanduser().resolve() if backup_dir else source.parent / "backups" / "automatic"
    destination_dir.mkdir(parents=True, exist_ok=True)
    stamp = _utc_stamp()
    backup_path = destination_dir / f"audit_system_{stamp}.db"
    manifest_path = backup_path.with_suffix(".json")

    src = _open_readonly(source)
    dst = None
    try:
        dst = sqlite3.connect(str(backup_path), timeout=15)
        src.backup(dst, pages=256, sleep=0.05)
        dst.commit()
    except Exception as exc:
        if backup_path.exists():
            backup_path.unlink()
        raise DatabaseBackupError(f"تهیه نسخه پشتیبان ناموفق بود: {exc}") from exc
    finally:
        if dst is not None:
            dst.close()
        src.close()

    check = validate_database(backup_path)
    if not check["ok"]:
        backup_path.unlink(missing_ok=True)
        raise DatabaseBackupError("نسخه پشتیبان پس از ایجاد، آزمون سلامت را نگذرانده است.")

    manifest = {
        "format_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_database": str(source),
        "backup_file": backup_path.name,
        "size_bytes": backup_path.stat().st_size,
        "sha256": _sha256(backup_path),
        "integrity_check": check["integrity_check"],
        "foreign_key_issues": check["foreign_key_issues"],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    removed = []
    if keep is not None and int(keep) > 0:
        backups = sorted(destination_dir.glob("audit_system_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in backups[int(keep):]:
            old_manifest = old.with_suffix(".json")
            old.unlink(missing_ok=True)
            old_manifest.unlink(missing_ok=True)
            removed.append(old.name)

    return {"backup_path": str(backup_path), "manifest_path": str(manifest_path),
            "sha256": manifest["sha256"], "size_bytes": manifest["size_bytes"],
            "integrity": check, "rotated_files": removed}


def _verify_backup(backup_path: Path) -> dict:
    result = validate_database(backup_path)
    if not result["ok"]:
        raise DatabaseBackupError("فایل پشتیبان خراب است یا ناسازگاری ارجاعی دارد؛ بازیابی متوقف شد.")
    manifest_path = backup_path.with_suffix(".json")
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise DatabaseBackupError("فایل مشخصات نسخه پشتیبان قابل خواندن نیست.") from exc
        expected = manifest.get("sha256")
        if expected and expected != _sha256(backup_path):
            raise DatabaseBackupError("اثر انگشت فایل پشتیبان با مشخصات آن مطابقت ندارد.")
    return result


def restore_backup(backup_path, target_path=DATABASE_PATH, pre_restore_dir=None) -> dict:
    """Restore a verified backup, first creating a verified pre-restore backup."""
    backup = Path(backup_path).expanduser().resolve()
    target = Path(target_path).expanduser().resolve()
    if not backup.is_file():
        raise FileNotFoundError(f"فایل پشتیبان پیدا نشد: {backup}")
    if backup == target:
        raise DatabaseBackupError("فایل پشتیبان و پایگاه داده مقصد نمی‌توانند یکسان باشند.")
    _verify_backup(backup)
    target.parent.mkdir(parents=True, exist_ok=True)

    # Build and validate a temporary replacement in the target directory first.
    fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".restore.tmp", dir=target.parent)
    os.close(fd)
    staged = Path(temp_name)
    src = _open_readonly(backup)
    dst = None
    try:
        dst = sqlite3.connect(str(staged), timeout=15)
        src.backup(dst, pages=256, sleep=0.05)
        dst.commit()
    except Exception as exc:
        raise DatabaseBackupError(f"آماده‌سازی بازیابی ناموفق بود: {exc}") from exc
    finally:
        if dst is not None:
            dst.close()
        src.close()

    try:
        staged_check = validate_database(staged)
        if not staged_check["ok"]:
            raise DatabaseBackupError("نسخه آماده‌شده برای بازیابی سالم نیست.")

        pre_restore = None
        if target.exists():
            # Checkpoint WAL before taking the safety snapshot or replacing the file.
            live = sqlite3.connect(str(target), timeout=15)
            try:
                checkpoint = live.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                if checkpoint and checkpoint[0] != 0:
                    raise DatabaseBackupError("پایگاه داده در حال استفاده است؛ برنامه را ببندید و دوباره تلاش کنید.")
            except sqlite3.DatabaseError as exc:
                raise DatabaseBackupError(f"پایگاه داده مقصد در دسترس امن نیست: {exc}") from exc
            finally:
                live.close()
            safety_dir = Path(pre_restore_dir).resolve() if pre_restore_dir else target.parent / "backups" / "pre_restore"
            pre_restore = create_backup(target, safety_dir, keep=20)["backup_path"]
            # Remove only stale sidecars after a successful checkpoint and closed connection.
            for suffix in ("-wal", "-shm"):
                Path(str(target) + suffix).unlink(missing_ok=True)

        os.replace(staged, target)
        final_check = validate_database(target)
        if not final_check["ok"]:
            raise DatabaseBackupError("پس از جایگزینی، آزمون سلامت پایگاه داده مقصد ناموفق بود.")
        return {"restored_from": str(backup), "target_path": str(target),
                "pre_restore_backup": pre_restore, "integrity": final_check}
    finally:
        staged.unlink(missing_ok=True)
