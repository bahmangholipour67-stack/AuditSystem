# Phase 44 — Risk-to-Audit Planning Engine


Adds a deterministic, read-only advisory service that turns an existing risk title, score, and optional description into a risk tier, audit-area category, relevant assertions, suggested audit procedures, and extent guidance.


## Covered risk themes
- Cash and bank
- Inventory
- Revenue and sales
- Receivables
- Payables and unrecorded liabilities
- Fixed assets
- Payroll
- Fraud
- Information technology
- General/unknown risks

## Safety and limitations
- No database writes or automatic creation of audit tests/workpapers.
- Does not infer missing risk score or control effectiveness.
- Recommendations are generic; auditor must tailor them to engagement facts, assertions, materiality, applicable standards and professional judgment.
- Does not invent sample sizes.
- Not yet integrated into a GUI workflow.

## API
`AuditPlanningService.plan_for_risk({"title": ..., "score": ..., "control_desc": ...})`
`AuditPlanningService.plan_for_risks(iterable)`
