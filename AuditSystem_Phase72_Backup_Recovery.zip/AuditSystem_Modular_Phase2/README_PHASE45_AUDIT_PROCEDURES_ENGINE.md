# Phase 45 — Audit Procedures Engine

This phase adds a deterministic, advisory service that maps a risk category from the existing risk-to-planning engine to relevant templates in the AuditSystem audit-test catalog.


## Features
- Procedure candidates selected from the existing catalog; no invented templates.
- Relevance ranking by audit cycle/category, title and relevant assertions.
- Stable candidate key (`risk identity::template id`) to support later persistence and duplicate prevention.
- Candidate records include template ID, title, cycle, type, assertions, objective, relevance score and proposed status.
- Batch processing sorts risks by score descending.
- Unknown categories do not receive unrelated catalog templates.
- Read-only; does not create database rows or change existing engagements.

## Limitation
This service is not yet connected to the GUI or engagement database. A reviewer must approve/adjust procedure candidates before they are adopted. It does not decide sample size, materiality or audit sufficiency.
