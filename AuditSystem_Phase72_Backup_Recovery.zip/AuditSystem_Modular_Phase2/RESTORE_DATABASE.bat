@echo off
setlocal
cd /d "%~dp0"
echo Enter the full path to the backup .db file.
set /p BACKUP_FILE=Backup file: 
if "%BACKUP_FILE%"=="" goto :cancel
py -3.12 scripts\restore_database.py "%BACKUP_FILE%"
if errorlevel 1 echo Restore was cancelled or failed. Review the message above.
echo.
pause
endlocal
goto :eof
:cancel
echo No file selected. Nothing was changed.
pause
endlocal
