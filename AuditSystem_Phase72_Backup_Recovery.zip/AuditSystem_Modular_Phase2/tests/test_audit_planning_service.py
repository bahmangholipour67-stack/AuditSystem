import pytest
from services.audit_planning_service import AuditPlanningService as Service


def test_risk_level_bands_and_validation():
    assert Service.risk_level(4) == "کم"
    assert Service.risk_level(5) == "متوسط"
    assert Service.risk_level(9) == "متوسط"
    assert Service.risk_level(10) == "زیاد"
    assert Service.risk_level(15) == "زیاد"
    assert Service.risk_level(16) == "بحرانی"
    for value in (0, 26, None, "x"):
        with pytest.raises(ValueError):
            Service.risk_level(value)


def test_cash_bank_risk_returns_specific_procedures():
    plan = Service.plan_for_risk({"title": "ریسک مغایرت بانکی", "score": 18})
    assert plan["category"] == "نقد و بانک"
    assert plan["risk_level"] == "بحرانی"
    assert any("مغایرت بانکی" in p for p in plan["recommended_procedures"])
    assert plan["risk_score"] == 18


def test_inventory_risk_is_classified_and_suggestions_are_advisory():
    plan = Service.plan_for_risk({"title": "ریسک ارزش‌گذاری موجودی کالا", "score": 12})
    assert plan["category"] == "موجودی کالا"
    assert "ارزش‌گذاری" in plan["relevant_assertions"]
    assert "تیم حسابرسی" in plan["advisory"]


def test_unknown_risk_uses_general_procedures_without_inventing_category():
    plan = Service.plan_for_risk({"title": "ریسک فرایند ناشناخته", "score": 6})
    assert plan["category"] == "ریسک عمومی"
    assert len(plan["recommended_procedures"]) >= 3


def test_missing_title_or_invalid_input_rejected():
    for risk in ({"score": 5}, {"title": "عنوان", "score": 30}, None):
        with pytest.raises(ValueError):
            Service.plan_for_risk(risk)


def test_batch_plans_sort_by_score_descending_and_title():
    risks = [
        {"title": "ب", "score": 9},
        {"title": "ج", "score": 20},
        {"title": "الف", "score": 20},
    ]
    plans = Service.plan_for_risks(risks)
    assert [(p["risk_score"], p["risk_title"]) for p in plans] == [(20, "الف"), (20, "ج"), (9, "ب")]
