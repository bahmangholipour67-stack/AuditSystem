from pathlib import Path

from legacy.audit_app import AuditApp


def test_workspace_header_has_breadcrumb_and_context_labels():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert 'self.workspace_breadcrumb = ttk.Label(' in source
    assert 'self.workspace_context = ttk.Label(' in source
    assert 'self.workspace_breadcrumb.config(text=f"سامانه  ‹  {group}  ‹  {title}")' in source


def test_workspace_group_mapping_covers_all_navigation_groups():
    app = AuditApp.__new__(AuditApp)
    assert app._workspace_group_for_title("داشبورد") == "نمای کلی"
    assert app._workspace_group_for_title("کاربرگ‌ها") == "برنامه‌ریزی و اجرا"
    assert app._workspace_group_for_title("مرکز ریسک") == "ریسک و کنترل داخلی"
    assert app._workspace_group_for_title("مرکز تأییدها") == "نظارت و کیفیت"
    assert app._workspace_group_for_title("تحلیل بنفورد") == "ابزارهای تحلیلی"
    assert app._workspace_group_for_title("عنوان ناشناخته") == "فضای کاری"


def test_sidebar_active_state_uses_exact_current_module_identity():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert 'self.current_workspace_title = title' in source
    assert 'is_active = title == getattr(self, "current_workspace_title", None)' in source
    assert 'button_title in self.workspace_title.cget("text")' not in source
