import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from database.migrations import ensure_schema
from database.connection import connect as real_connect
from repositories.project_repository import ProjectRepository


class ProjectArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "archive_test.db"
        ensure_schema(self.db_path)
        self.repo = ProjectRepository()
        self.base_connect_patch = patch(
            "repositories.base_repository.connect",
            side_effect=lambda: real_connect(self.db_path),
        )
        self.repo_connect_patch = patch(
            "repositories.project_repository.connect",
            side_effect=lambda: real_connect(self.db_path),
        )
        self.base_connect_patch.start()
        self.repo_connect_patch.start()
        self.project_id = self.repo.create(
            "شرکت آزمایشی", "1405", "مستقل", "مدیر آزمون",
            "1405/01/01", "1405/12/29", "در حال انجام", "پرونده تست"
        )
        with real_connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO risks(project_id,title,score) VALUES(?,?,?)",
                (self.project_id, "ریسک نقدینگی", 12),
            )

    def tearDown(self):
        self.repo_connect_patch.stop()
        self.base_connect_patch.stop()
        self.temp_dir.cleanup()

    def test_archive_hides_project_from_active_but_preserves_data(self):
        self.repo.archive(self.project_id, "اتمام عملیات", 7)

        self.assertEqual(self.repo.active(), [])
        archived = self.repo.archived()
        self.assertEqual(len(archived), 1)
        self.assertEqual(archived[0][0], self.project_id)
        self.assertEqual(archived[0][12], "اتمام عملیات")

        with real_connect(self.db_path) as conn:
            risk_count = conn.execute(
                "SELECT COUNT(*) FROM risks WHERE project_id=?",
                (self.project_id,),
            ).fetchone()[0]
            status = conn.execute(
                "SELECT status FROM projects WHERE id=?", (self.project_id,)
            ).fetchone()[0]
        self.assertEqual(risk_count, 1)
        self.assertEqual(status, "بایگانی")

    def test_restore_returns_original_status_and_logs_both_events(self):
        self.repo.archive(self.project_id, "اتمام عملیات", 7)
        self.repo.restore(self.project_id, 9)

        active = self.repo.active()
        self.assertEqual(len(active), 1)
        self.assertEqual(active[0][8], "در حال انجام")
        self.assertEqual(self.repo.archived(), [])

        history = self.repo.archive_history(self.project_id)
        self.assertEqual([row[1] for row in reversed(history)], ["ARCHIVE", "RESTORE"])
        self.assertEqual(history[0][3], 9)

    def test_archive_requires_reason_and_rejects_duplicate_archive(self):
        with self.assertRaisesRegex(ValueError, "علت بایگانی"):
            self.repo.archive(self.project_id, "   ")
        self.repo.archive(self.project_id, "علت معتبر")
        with self.assertRaisesRegex(ValueError, "قبلاً بایگانی"):
            self.repo.archive(self.project_id, "دوباره")

    def test_restore_rejects_non_archived_project(self):
        with self.assertRaisesRegex(ValueError, "در وضعیت بایگانی"):
            self.repo.restore(self.project_id)

    def test_legacy_archived_status_is_migrated_without_losing_project(self):
        with real_connect(self.db_path) as conn:
            conn.execute(
                "UPDATE projects SET status='بایگانی' WHERE id=?",
                (self.project_id,),
            )
        ensure_schema(self.db_path)
        archived = self.repo.archived()
        self.assertEqual(len(archived), 1)
        self.assertEqual(archived[0][0], self.project_id)
        self.assertEqual(self.repo.active(), [])
        self.assertTrue(self.repo.archive_history(self.project_id))


if __name__ == "__main__":
    unittest.main()
