import hashlib
import sqlite3
import tempfile
import unittest
from pathlib import Path

from services.audit_file_quality_service import AuditFileQualityService
from reports.audit_report_generator import AuditReportGenerator


class AuditFileQualityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp.name) / "quality.db"
        self.conn = sqlite3.connect(self.db_path)
        self.conn.executescript("""
            CREATE TABLE projects (id INTEGER PRIMARY KEY, name TEXT, period TEXT);
            CREATE TABLE risks (id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, score INTEGER, control_desc TEXT);
            CREATE TABLE workpapers (id INTEGER PRIMARY KEY, project_id INTEGER, risk_id INTEGER, title TEXT, procedure TEXT, result TEXT, status TEXT, assigned_member_id INTEGER);
            CREATE TABLE findings (id INTEGER PRIMARY KEY, project_id INTEGER, workpaper_id INTEGER, title TEXT, severity TEXT, action_text TEXT, owner TEXT, status TEXT);
            CREATE TABLE audit_programs (id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, risk_id INTEGER, workpaper_id INTEGER, status TEXT);
            CREATE TABLE audit_tests (id INTEGER PRIMARY KEY, project_id INTEGER, program_id INTEGER, title TEXT, status TEXT, sample_size INTEGER, workpaper_id INTEGER);
            CREATE TABLE audit_test_samples (id INTEGER PRIMARY KEY, project_id INTEGER, test_id INTEGER, sample_no INTEGER, result TEXT);
            CREATE TABLE finding_evidence (id INTEGER PRIMARY KEY, project_id INTEGER, finding_id INTEGER, file_path TEXT, description TEXT);
            CREATE TABLE trial_balance (id INTEGER PRIMARY KEY, project_id INTEGER, account_code TEXT, account_name TEXT, debit REAL, credit REAL, net REAL, flags TEXT);
            INSERT INTO projects VALUES (1, 'پرونده آزمایشی', '۱۴۰۵');
            INSERT INTO risks VALUES (1, 1, 'ریسک بااهمیت', 20, '');
            INSERT INTO workpapers VALUES (1, 1, 1, 'کاربرگ تأییدشده', '', '', 'تأیید نهایی مدیر', 1);
            INSERT INTO workpapers VALUES (2, 1, NULL, 'کاربرگ بدون ریسک', '', '', 'پیش‌نویس', NULL);
            INSERT INTO findings VALUES (1, 1, 2, 'یافته فاقد مستند', 'اساسی', '', '', 'باز');
            INSERT INTO audit_programs VALUES (1, 1, 'برنامه بدون ریسک', NULL, NULL, 'جدید');
            INSERT INTO audit_tests VALUES (1, 1, 1, 'آزمون ناتمام', 'در حال اجرا', 2, NULL);
            INSERT INTO audit_test_samples VALUES (1, 1, 1, 1, 'رسیدگی‌نشده');
            INSERT INTO trial_balance VALUES (1, 1, '100', 'بانک', 100, 50, 50, 'کد تکراری');
        """)
        self.conn.commit()
        self.conn.close()
        self.service = AuditFileQualityService(self.db_path)

    def tearDown(self):
        self.temp.cleanup()

    def test_detects_expected_completeness_issues(self):
        result = self.service.run(1)
        checks = {item['code']: item for item in result['checks']}
        self.assertEqual(checks['WP_NO_RISK']['count'], 1)
        self.assertEqual(checks['WP_UNASSIGNED']['count'], 1)
        self.assertEqual(checks['FINDING_NO_EVIDENCE']['count'], 1)
        self.assertEqual(checks['PROGRAM_NO_RISK']['count'], 1)
        self.assertEqual(checks['TEST_INCOMPLETE']['count'], 1)
        self.assertEqual(checks['SAMPLE_UNTESTED']['count'], 1)
        self.assertEqual(checks['HIGH_RISK_NO_WP']['count'], 0)
        self.assertEqual(checks['RISK_NO_WORKPAPER']['count'], 0)
        self.assertEqual(checks['TEST_NO_WORKPAPER']['count'], 1)
        self.assertEqual(checks['TRIAL_BALANCE_FLAGS']['count'], 1)
        self.assertEqual(checks['TRIAL_BALANCE_UNBALANCED']['count'], 1)
        self.assertEqual(result['metrics']['findings'], 1)

    def test_rejects_missing_or_unknown_project(self):
        with self.assertRaises(ValueError):
            self.service.run(None)
        with self.assertRaises(ValueError):
            self.service.run(999)

    def test_non_numeric_risk_score_is_reported(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("INSERT INTO risks VALUES (2, 1, 'ریسک با امتیاز نامعتبر', 'نامعتبر', '')")
            conn.commit()
        finally:
            conn.close()
        result = self.service.run(1)
        check = next(x for x in result['checks'] if x['code'] == 'RISK_SCORE_INVALID')
        self.assertEqual(check['count'], 1)

    def test_detects_missing_evidence_file(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("INSERT INTO finding_evidence VALUES (1,1,1,?, '')", (str(self.db_path.parent / 'absent.pdf'),))
            conn.commit()
        finally:
            conn.close()
        result = self.service.run(1)
        check = next(x for x in result['checks'] if x['code'] == 'EVIDENCE_FILE_MISSING')
        self.assertEqual(check['count'], 1)

    def test_reports_can_be_generated_and_reopened_in_all_formats(self):
        from docx import Document
        from openpyxl import load_workbook

        data = self.service.run(1)
        generator = AuditReportGenerator()
        for ext in ('xlsx', 'docx', 'pdf'):
            path = self.db_path.parent / f'report.{ext}'
            generator.export(data, path, ext)
            self.assertTrue(path.exists())
            self.assertGreater(path.stat().st_size, 500)
            if ext == 'xlsx':
                book = load_workbook(path, read_only=True, data_only=True)
                self.assertIn('نتایج کنترل‌ها', book.sheetnames)
                book.close()
            elif ext == 'docx':
                document = Document(path)
                self.assertGreater(len(document.paragraphs), 2)
            else:
                self.assertEqual(path.read_bytes()[:4], b'%PDF')

    def test_quality_review_does_not_modify_database(self):
        before = hashlib.sha256(self.db_path.read_bytes()).hexdigest()
        self.service.run(1)
        after = hashlib.sha256(self.db_path.read_bytes()).hexdigest()
        self.assertEqual(before, after)

    def test_export_rejects_unsupported_format(self):
        with self.assertRaises(ValueError):
            AuditReportGenerator().export({}, self.db_path.parent / 'x.foo', 'foo')


if __name__ == '__main__':
    unittest.main()
