import json
import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

from database.backup import (DatabaseBackupError, create_backup, restore_backup,
                             validate_database)


@contextmanager
def managed_connection(path):
    conn = sqlite3.connect(path)
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


class DatabaseBackupRestoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / "audit.sqlite"
        with managed_connection(self.db) as conn:
            conn.execute("CREATE TABLE records (id INTEGER PRIMARY KEY, value TEXT NOT NULL)")
            conn.execute("INSERT INTO records(value) VALUES ('original')")

    def tearDown(self):
        self.temp.cleanup()

    def test_backup_is_created_and_verified(self):
        result = create_backup(self.db, self.root / "backups")
        backup = Path(result["backup_path"])
        self.assertTrue(backup.is_file())
        self.assertTrue(backup.with_suffix(".json").is_file())
        self.assertTrue(validate_database(backup)["ok"])

    def test_backup_manifest_contains_hash(self):
        result = create_backup(self.db, self.root / "backups")
        manifest = json.loads(Path(result["manifest_path"]).read_text(encoding="utf-8"))
        self.assertEqual(manifest["sha256"], result["sha256"])

    def test_backup_rotation_keeps_requested_count(self):
        folder = self.root / "rotated"
        for _ in range(3):
            create_backup(self.db, folder, keep=2)
        self.assertEqual(len(list(folder.glob("audit_system_*.db"))), 2)
        self.assertEqual(len(list(folder.glob("audit_system_*.json"))), 2)

    def test_restore_preserves_pre_restore_backup(self):
        backup = create_backup(self.db, self.root / "backups")["backup_path"]
        with managed_connection(self.db) as conn:
            conn.execute("UPDATE records SET value='changed'")
        result = restore_backup(backup, self.db)
        with managed_connection(self.db) as conn:
            self.assertEqual(conn.execute("SELECT value FROM records").fetchone()[0], "original")
        self.assertTrue(Path(result["pre_restore_backup"]).is_file())
        self.assertTrue(result["integrity"]["ok"])

    def test_restore_rejects_corrupted_backup(self):
        backup = Path(create_backup(self.db, self.root / "backups")["backup_path"])
        with backup.open("ab") as stream:
            stream.write(b"corruption")
        with self.assertRaises(DatabaseBackupError):
            restore_backup(backup, self.root / "target.sqlite")

    def test_restore_rejects_manifest_hash_mismatch(self):
        backup = Path(create_backup(self.db, self.root / "backups")["backup_path"])
        manifest_path = backup.with_suffix(".json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["sha256"] = "0" * 64
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaises(DatabaseBackupError):
            restore_backup(backup, self.root / "target.sqlite")

    def test_restore_rejects_same_source_and_target(self):
        with self.assertRaises(DatabaseBackupError):
            restore_backup(self.db, self.db)

    def test_missing_source_does_not_create_backup_directory(self):
        folder = self.root / "not-created"
        with self.assertRaises(FileNotFoundError):
            create_backup(self.root / "missing.sqlite", folder)
        self.assertFalse(folder.exists())

    def test_restore_to_new_target(self):
        backup = create_backup(self.db, self.root / "backups")["backup_path"]
        target = self.root / "new" / "restored.sqlite"
        result = restore_backup(backup, target)
        self.assertIsNone(result["pre_restore_backup"])
        self.assertTrue(validate_database(target)["ok"])

    def test_backup_does_not_modify_source_data(self):
        create_backup(self.db, self.root / "backups")
        with managed_connection(self.db) as conn:
            self.assertEqual(conn.execute("SELECT value FROM records").fetchone()[0], "original")


if __name__ == "__main__":
    unittest.main()
