import unittest
from unittest.mock import Mock

from services.audit_test_service import AuditTestService
from services.audit_test_catalog import (
    get_template,
    list_cycles,
    list_templates,
    list_test_types,
    list_industries,
)


class AuditTestCatalogTests(unittest.TestCase):
    def test_catalog_contains_unique_stable_ids_and_titles(self):
        rows = list_templates()
        ids = [row["id"] for row in rows]
        titles = [row["title"] for row in rows]
        self.assertGreaterEqual(len(rows), 20)
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len(titles), len(set(titles)))

    def test_every_template_has_required_professional_content(self):
        for row in list_templates():
            with self.subTest(template=row["id"]):
                for field in (
                    "title", "cycle", "test_type", "objective",
                    "population_description", "procedure", "evidence",
                ):
                    self.assertTrue(str(row[field]).strip(), field)
                self.assertIn(row["test_type"], list_test_types())
                self.assertTrue(row["assertions"])

    def test_filtering_by_cycle_and_type(self):
        rows = list_templates(cycle="وجوه نقد و بانک", test_type="ماهوی")
        self.assertTrue(rows)
        self.assertTrue(all(row["cycle"] == "وجوه نقد و بانک" for row in rows))
        self.assertTrue(all(row["test_type"] == "ماهوی" for row in rows))

    def test_search_finds_templates_by_title_and_assertion(self):
        self.assertTrue(list_templates(query="تأییدیه"))
        self.assertTrue(list_templates(query="ارزش‌گذاری"))

    def test_get_template_returns_copy_and_unknown_returns_none(self):
        original = get_template("cash-bank-confirmation")
        self.assertIsNotNone(original)
        original["assertions"].append("تغییر آزمایشی")
        original["title"] = "عنوان تغییر یافته"

        fresh = get_template("cash-bank-confirmation")
        self.assertNotIn("تغییر آزمایشی", fresh["assertions"])
        self.assertNotEqual(fresh["title"], "عنوان تغییر یافته")
        self.assertIsNone(get_template("not-a-template"))


    def test_specialized_industry_templates_are_available_and_filterable(self):
        self.assertTrue({"تولیدی", "بازرگانی", "خدماتی", "بورسی"}.issubset(set(list_industries())))
        for industry in ("تولیدی", "بازرگانی", "خدماتی", "بورسی"):
            rows = list_templates(industry=industry)
            self.assertTrue(rows, industry)
            self.assertTrue(all(row.get("industry") == industry for row in rows))

    def test_specialized_templates_have_stable_ids_and_complete_procedures(self):
        rows = [row for row in list_templates() if row.get("industry") in {"تولیدی", "بازرگانی", "خدماتی", "بورسی"}]
        self.assertGreaterEqual(len(rows), 8)
        for row in rows:
            with self.subTest(template=row["id"]):
                self.assertTrue(row["procedure"].count("\n") >= 3)
                self.assertTrue(row["evidence"].strip())
                self.assertTrue(row["assertions"])


    def test_phase13_advanced_templates_are_available_and_complete(self):
        expected = {
            "journal-entry-risk-testing",
            "payroll-expense-testing",
            "fixed-assets-additions-disposals",
            "impairment-indicators-assessment",
            "accounting-estimates-provisions",
            "related-party-completeness",
            "subsequent-events-review",
            "going-concern-assessment",
            "income-tax-provision-reconciliation",
        }
        rows = list_templates(industry="عمومی")
        by_id = {row["id"]: row for row in rows}
        self.assertTrue(expected.issubset(by_id))
        for template_id in expected:
            with self.subTest(template=template_id):
                row = by_id[template_id]
                self.assertGreaterEqual(len(row["procedure"].splitlines()), 5)
                self.assertGreaterEqual(len(row["assertions"]), 3)
                self.assertTrue(row["objective"].strip())
                self.assertTrue(row["population_description"].strip())
                self.assertTrue(row["evidence"].strip())

    def test_phase13_templates_are_compatible_with_planning_service(self):
        from services.audit_test_planning import AuditTestPlanningService
        service = AuditTestPlanningService()
        template_ids = (
            "journal-entry-risk-testing", "payroll-expense-testing",
            "fixed-assets-additions-disposals", "impairment-indicators-assessment",
            "accounting-estimates-provisions", "related-party-completeness",
            "subsequent-events-review", "going-concern-assessment",
            "income-tax-provision-reconciliation",
        )
        for template_id in template_ids:
            with self.subTest(template=template_id):
                plan = service.build_execution_plan(template_id, risk_score=18)
                self.assertEqual(plan["risk_level"], "بالا")
                self.assertTrue(plan["procedure_steps"])
                self.assertTrue(plan["evidence_checklist"])
                self.assertTrue(plan["completion_checks"])

    def test_cycles_are_unique_and_sorted(self):
        cycles = list_cycles()
        self.assertEqual(cycles, sorted(set(cycles)))

    def test_template_content_can_be_saved_through_audit_test_service(self):
        repository = Mock()
        repository.create_test.return_value = 41
        service = AuditTestService(repository=repository)
        template = get_template("cash-bank-confirmation")

        result = service.create_test(
            project_id=7,
            program_id=9,
            title=template["title"],
            population_size=120,
            sample_size=25,
            test_type=template["test_type"],
            procedure=template["procedure"],
            population_description=template["population_description"],
        )

        self.assertEqual(result, 41)
        kwargs = repository.create_test.call_args.kwargs
        self.assertEqual(kwargs["procedure"], template["procedure"])
        self.assertEqual(
            kwargs["population_description"], template["population_description"]
        )
        self.assertEqual(kwargs["test_type"], "ماهوی")


if __name__ == "__main__":
    unittest.main()
