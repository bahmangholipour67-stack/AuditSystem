import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from database.migrations import ensure_schema
from repositories.base_repository import BaseRepository
from repositories.risk_repository import RiskRepository
from repositories.workpaper_repository import WorkpaperRepository
from repositories.finding_repository import FindingRepository
from repositories.audit_test_repository import AuditTestRepository
from ui.views.dashboard_view import DashboardViewMixin


class TestAuditRelationships(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "relationships.db"
        ensure_schema(self.db_path)
        setup_conn = sqlite3.connect(self.db_path)
        try:
            setup_conn.execute(
                "INSERT INTO projects(id,name,period) VALUES(1,'پرونده اول','1405')"
            )
            setup_conn.execute(
                "INSERT INTO projects(id,name,period) VALUES(2,'پرونده دوم','1405')"
            )
            setup_conn.execute(
                "INSERT INTO team_members(project_id,full_name,role,is_active) VALUES(1,'حسابرس','حسابرس',1)"
            )
            setup_conn.execute(
                "INSERT INTO team_members(project_id,full_name,role,is_active) VALUES(2,'عضو پرونده دوم','حسابرس',1)"
            )
            setup_conn.commit()
        finally:
            setup_conn.close()

        self.patches = [
            patch("repositories.base_repository.connect", self._connect),
            patch("repositories.risk_repository.connect", self._connect),
            patch("repositories.workpaper_repository.connect", self._connect),
            patch("repositories.finding_repository.connect", self._connect),
            patch("repositories.audit_test_repository.connect", self._connect),
        ]
        for item in self.patches:
            item.start()

        self.risks = RiskRepository()
        self.workpapers = WorkpaperRepository()
        self.findings = FindingRepository()
        self.audit_tests = AuditTestRepository()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.temp_dir.cleanup()

    @contextmanager
    def _connect(self, *args, **kwargs):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = None
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def test_risk_workpaper_finding_chain_is_saved_and_queryable(self):
        risk_id = self.risks.create(1, "ریسک شناسایی درآمد", 22, "کنترل تأیید فروش")
        workpaper_id = self.workpapers.create(
            1, "کاربرگ آزمون فروش", "نمونه‌گیری اسناد", "", risk_id=risk_id
        )
        finding_id = self.findings.create(
            1, "ثبت زودهنگام درآمد", "بااهمیت", "اصلاح ثبت حسابداری",
            "مدیر مالی", workpaper_id=workpaper_id,
        )

        wp_rows = self.workpapers.for_project_detailed(1)
        self.assertEqual(wp_rows[0][12], risk_id)
        self.assertEqual(wp_rows[0][13], "ریسک شناسایی درآمد")

        finding = self.findings.for_project(1)[0]
        self.assertEqual(finding[0], finding_id)
        self.assertEqual(finding[6], workpaper_id)
        self.assertEqual(finding[8], risk_id)
        self.assertEqual(finding[9], "ریسک شناسایی درآمد")

        summary = self.findings.linkage_summary(1)
        self.assertEqual(summary, {"total": 1, "linked_workpaper": 1, "linked_risk": 1})

    def test_unlinked_risk_can_be_deleted(self):
        risk_id = self.risks.create(1, "ریسک قابل حذف", 10)
        self.risks.delete(risk_id)
        self.assertIsNone(self.risks.get(1, risk_id))

    def test_risk_with_workpaper_cannot_be_deleted(self):
        risk_id = self.risks.create(1, "ریسک متصل", 10)
        self.workpapers.create(1, "کاربرگ مرتبط", risk_id=risk_id)
        with self.assertRaisesRegex(ValueError, "کاربرگ"):
            self.risks.delete(risk_id)
        self.assertIsNotNone(self.risks.get(1, risk_id))

    def test_risk_with_direct_finding_cannot_be_deleted(self):
        risk_id = self.risks.create(1, "ریسک یافته", 10)
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO findings(project_id,title,risk_id) VALUES(1,'یافته مستقیم',?)",
                (risk_id,),
            )
        with self.assertRaisesRegex(ValueError, "یافته"):
            self.risks.delete(risk_id)

    def test_risk_can_be_edited_without_breaking_relationships(self):
        risk_id = self.risks.create(1, "ریسک اولیه", 10, "کنترل اولیه")
        workpaper_id = self.workpapers.create(1, "کاربرگ مرتبط", risk_id=risk_id)
        self.risks.update(1, risk_id, "ریسک اصلاح‌شده", 18, "کنترل اصلاح‌شده")
        self.assertEqual(self.risks.get(1, risk_id)[2:], ("ریسک اصلاح‌شده", 18, "کنترل اصلاح‌شده"))
        self.assertEqual(self.workpapers.for_project_detailed(1)[0][12], risk_id)

    def test_workpaper_content_can_be_edited_only_before_review(self):
        workpaper_id = self.workpapers.create(1, "کاربرگ اولیه", "روش اول", "نتیجه اول")
        self.workpapers.update_content(1, workpaper_id, "کاربرگ اصلاحی", "روش دوم", "نتیجه دوم")
        row = self.workpapers.for_project(1)[0]
        self.assertEqual(row[1:4], ("کاربرگ اصلاحی", "روش دوم", "نتیجه دوم"))

    def test_open_finding_can_be_edited_but_closed_finding_cannot(self):
        finding_id = self.findings.create(1, "یافته اولیه", "کم", "اقدام اول", "مسئول اول")
        self.findings.update(1, finding_id, "یافته اصلاحی", "اساسی", "اقدام دوم", "مسئول دوم")
        row = self.findings.for_project(1)[0]
        self.assertEqual(row[1:5], ("یافته اصلاحی", "اساسی", "اقدام دوم", "مسئول دوم"))
        self.findings.close(1, finding_id)
        with self.assertRaisesRegex(ValueError, "یافته‌های باز"):
            self.findings.update(1, finding_id, "ویرایش ممنوع")

    def test_cross_project_risk_cannot_be_attached_to_workpaper(self):
        risk_id = self.risks.create(2, "ریسک پرونده دوم", 10)
        with self.assertRaisesRegex(ValueError, "متعلق به این پرونده نیست"):
            self.workpapers.create(1, "کاربرگ نامعتبر", risk_id=risk_id)

    def test_cross_project_workpaper_cannot_be_attached_to_finding(self):
        workpaper_id = self.workpapers.create(2, "کاربرگ پرونده دوم")
        with self.assertRaisesRegex(ValueError, "متعلق به این پرونده نیست"):
            self.findings.create(1, "یافته نامعتبر", workpaper_id=workpaper_id)

    def test_finding_relink_updates_derived_risk(self):
        risk_id = self.risks.create(1, "ریسک اول", 8)
        workpaper_id = self.workpapers.create(1, "کاربرگ اول", risk_id=risk_id)
        finding_id = self.findings.create(1, "یافته مستقل")
        self.findings.link_workpaper(1, finding_id, workpaper_id)
        row = self.findings.for_project(1)[0]
        self.assertEqual(row[6], workpaper_id)
        self.assertEqual(row[8], risk_id)


    def _create_test_with_workpaper(self, workpaper_id, finding_id=None):
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO audit_programs(project_id,title) VALUES(1,'برنامه آزمون')"
            )
            program_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            cur = conn.execute(
                """INSERT INTO audit_tests(
                       project_id, program_id, title, workpaper_id, finding_id
                   ) VALUES(1,?,'آزمون ارتباطی',?,?)""",
                (program_id, workpaper_id, finding_id),
            )
            return cur.lastrowid

    def test_audit_test_cannot_link_finding_from_another_workpaper(self):
        wp_one = self.workpapers.create(1, "کاربرگ یک")
        wp_two = self.workpapers.create(1, "کاربرگ دو")
        finding_id = self.findings.create(1, "یافته مرتبط با کاربرگ دو", workpaper_id=wp_two)
        test_id = self._create_test_with_workpaper(wp_one)
        with self.assertRaisesRegex(ValueError, "کاربرگی متفاوت"):
            self.audit_tests.link_test_finding(1, test_id, finding_id)

    def test_audit_test_cannot_change_workpaper_away_from_linked_finding(self):
        wp_one = self.workpapers.create(1, "کاربرگ یک")
        wp_two = self.workpapers.create(1, "کاربرگ دو")
        finding_id = self.findings.create(1, "یافته مرتبط با کاربرگ دو", workpaper_id=wp_two)
        test_id = self._create_test_with_workpaper(wp_one, finding_id)
        with self.assertRaisesRegex(ValueError, "یکسان نیست"):
            self.audit_tests.link_test_workpaper(1, test_id, wp_one)

    def test_audit_test_and_finding_can_share_the_same_workpaper(self):
        workpaper_id = self.workpapers.create(1, "کاربرگ مشترک")
        finding_id = self.findings.create(1, "یافته مشترک", workpaper_id=workpaper_id)
        test_id = self._create_test_with_workpaper(workpaper_id)
        self.assertTrue(self.audit_tests.link_test_finding(1, test_id, finding_id))
        links = self.audit_tests.test_links(1, test_id)
        self.assertEqual(links["workpaper_id"], workpaper_id)
        self.assertEqual(links["finding_id"], finding_id)

    def test_sample_finding_must_match_test_workpaper(self):
        wp_one = self.workpapers.create(1, "کاربرگ آزمون")
        wp_two = self.workpapers.create(1, "کاربرگ دیگر")
        finding_id = self.findings.create(1, "یافته خارج از کاربرگ", workpaper_id=wp_two)
        test_id = self._create_test_with_workpaper(wp_one)
        with self._connect() as conn:
            cur = conn.execute(
                """INSERT INTO audit_test_samples(
                       project_id,test_id,sample_no,population_row
                   ) VALUES(1,?,1,1)""",
                (test_id,),
            )
            sample_id = cur.lastrowid
        with self.assertRaisesRegex(ValueError, "کاربرگی متفاوت"):
            self.audit_tests.link_sample_finding(1, test_id, sample_id, finding_id)

    def test_unlinking_test_workpaper_is_blocked_when_finding_requires_it(self):
        workpaper_id = self.workpapers.create(1, "کاربرگ لازم")
        finding_id = self.findings.create(1, "یافته متصل", workpaper_id=workpaper_id)
        test_id = self._create_test_with_workpaper(workpaper_id, finding_id)
        with self.assertRaisesRegex(ValueError, "یکسان نیست"):
            self.audit_tests.link_test_workpaper(1, test_id, None)

    def test_finding_cannot_be_relinked_away_from_test_workpaper(self):
        wp_one = self.workpapers.create(1, "کاربرگ آزمون")
        wp_two = self.workpapers.create(1, "کاربرگ جدید")
        finding_id = self.findings.create(1, "یافته", workpaper_id=wp_one)
        self._create_test_with_workpaper(wp_one, finding_id)
        with self.assertRaisesRegex(ValueError, "آزمون‌های این یافته"):
            self.findings.link_workpaper(1, finding_id, wp_two)

    def test_workpaper_risk_change_updates_linked_program_risk(self):
        risk_one = self.risks.create(1, "ریسک اول", 8)
        risk_two = self.risks.create(1, "ریسک دوم", 12)
        workpaper_id = self.workpapers.create(1, "کاربرگ", risk_id=risk_one)
        program_id = self.audit_tests.create_program(
            1, "برنامه مرتبط", workpaper_id=workpaper_id
        )
        self.workpapers.link_risk(1, workpaper_id, risk_two)
        self.assertEqual(self.audit_tests.get_program(program_id)["risk_id"], risk_two)

    def test_risk_score_must_be_between_one_and_twenty_five(self):
        with self.assertRaises(ValueError):
            self.risks.create(1, "ریسک نامعتبر", 26)

    def test_workpaper_risk_relink_keeps_finding_risk_in_sync(self):
        risk_one = self.risks.create(1, "ریسک اول", 8)
        risk_two = self.risks.create(1, "ریسک دوم", 12)
        workpaper_id = self.workpapers.create(1, "کاربرگ", risk_id=risk_one)
        finding_id = self.findings.create(1, "یافته", workpaper_id=workpaper_id)
        self.workpapers.link_risk(1, workpaper_id, risk_two)
        row = self.findings.for_project(1)[0]
        self.assertEqual(row[0], finding_id)
        self.assertEqual(row[8], risk_two)

    def test_audit_program_is_linked_to_project_risk(self):
        risk_id = self.risks.create(1, "ریسک برنامه", 18)
        program_id = self.audit_tests.create_program(
            1, "برنامه مرتبط", risk_id=risk_id
        )
        program = self.audit_tests.get_program(program_id)
        self.assertEqual(program["risk_id"], risk_id)

    def test_audit_program_rejects_risk_from_another_project(self):
        foreign_risk_id = self.risks.create(2, "ریسک خارجی", 12)
        with self.assertRaisesRegex(ValueError, "متعلق به این پرونده نیست"):
            self.audit_tests.create_program(1, "برنامه نامعتبر", risk_id=foreign_risk_id)

    def test_audit_program_derives_risk_from_linked_workpaper(self):
        risk_id = self.risks.create(1, "ریسک کاربرگ", 17)
        workpaper_id = self.workpapers.create(1, "کاربرگ دارای ریسک", risk_id=risk_id)
        program_id = self.audit_tests.create_program(
            1, "برنامه با کاربرگ", workpaper_id=workpaper_id
        )
        self.assertEqual(self.audit_tests.get_program(program_id)["risk_id"], risk_id)

    def test_finding_evidence_is_saved_with_actor_and_listed(self):
        import tempfile
        from pathlib import Path
        finding_id = self.findings.create(1, "یافته مستنددار")
        with tempfile.TemporaryDirectory() as folder:
            evidence_file = Path(folder) / "evidence.txt"
            evidence_file.write_text("audit evidence", encoding="utf-8")
            evidence_id = self.findings.add_evidence(
                1, finding_id, str(evidence_file), "مدرک پشتیبان", added_by_member_id=1
            )
            rows = self.findings.evidence_for_finding(1, finding_id)
            self.assertEqual(rows[0][0], evidence_id)
            self.assertEqual(rows[0][2], "مدرک پشتیبان")
            self.assertEqual(rows[0][3], "حسابرس")
            self.assertEqual(Path(rows[0][1]).read_text(encoding="utf-8"), "audit evidence")

    def test_finding_evidence_rejects_member_from_another_project(self):
        finding_id = self.findings.create(1, "یافته")
        with tempfile.TemporaryDirectory() as folder:
            evidence_file = Path(folder) / "evidence.txt"
            evidence_file.write_text("x", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "عضو ثبت‌کننده فعال نیست"):
                self.findings.add_evidence(
                    1, finding_id, str(evidence_file), added_by_member_id=2
                )

    def test_dashboard_reports_linkage_and_test_counts(self):
        risk_id = self.risks.create(1, "ریسک داشبورد", 20)
        workpaper_id = self.workpapers.create(1, "کاربرگ داشبورد", risk_id=risk_id)
        finding_id = self.findings.create(1, "یافته داشبورد", workpaper_id=workpaper_id)
        with tempfile.TemporaryDirectory() as folder:
            evidence_file = Path(folder) / "evidence.txt"
            evidence_file.write_text("x", encoding="utf-8")
            self.findings.add_evidence(1, finding_id, str(evidence_file))
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO audit_programs(project_id,title,risk_id) VALUES(1,'برنامه آزمون',?)",
                (risk_id,),
            )
            program_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT INTO audit_tests(project_id,program_id,title) VALUES(1,?,'آزمون داشبورد')",
                (program_id,),
            )

        view = object.__new__(DashboardViewMixin)
        view.get_current_project_id = lambda: 1
        view.get_conn = self._connect
        data = view._get_dashboard_data()
        self.assertEqual(data["risks"], 1)
        self.assertEqual(data["workpapers"], 1)
        self.assertEqual(data["findings"], 1)
        self.assertEqual(data["audit_tests"], 1)
        self.assertEqual(data["linked_workpapers"], 1)
        self.assertEqual(data["linked_findings"], 1)
        self.assertEqual(data["linked_programs"], 1)
        self.assertEqual(data["finding_evidence"], 1)
        self.assertEqual(len(data["finding_evidence_rows"]), 1)
        self.assertEqual(data["finding_evidence_rows"][0][1], finding_id)
        self.assertEqual(len(data["unlinked_test_rows"]), 1)
        self.assertEqual(len(data["workpaper_detail_rows"]), 1)
        self.assertEqual(data["finding_detail_rows"][0][0], finding_id)
        self.assertEqual(len(data["test_detail_rows"]), 1)


    def test_dashboard_can_aggregate_all_projects(self):
        risk_id = self.risks.create(2, "ریسک پرونده دوم", 13)
        self.workpapers.create(2, "کاربرگ پرونده دوم", risk_id=risk_id)
        view = object.__new__(DashboardViewMixin)
        view.get_current_project_id = lambda: None
        view.get_conn = self._connect
        data = view._get_dashboard_data()
        self.assertEqual(data["projects"], 2)
        self.assertEqual(data["risks"], 1)
        self.assertEqual(data["linked_workpapers"], 1)
        self.assertEqual(data["linked_programs"], 0)



if __name__ == "__main__":
    unittest.main()
