import sqlite3
import tempfile
import unittest

from pathlib import Path
from contextlib import contextmanager
from unittest.mock import patch

from repositories.audit_test_repository import AuditTestRepository
from services.audit_test_service import AuditTestService


class TestAuditApprovalWorkflow(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "workflow_test.db"

        self._create_database()

        self.patcher = patch(
            "repositories.audit_test_repository.connect",
            self._connect
        )
        self.patcher.start()

        self.repository = AuditTestRepository()
        self.service = AuditTestService(self.repository)

        self._insert_test_data()

    def tearDown(self):
        self.patcher.stop()
        self.temp_dir.cleanup()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row

        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _create_database(self):
        conn = sqlite3.connect(str(self.db_path))

        conn.executescript("""
            CREATE TABLE team_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL,
                phone TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE audit_tests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                program_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                test_type TEXT DEFAULT 'ماهوی',
                procedure TEXT DEFAULT '',
                population_description TEXT DEFAULT '',
                population_size INTEGER DEFAULT 0,
                sample_size INTEGER DEFAULT 0,
                sampling_method TEXT DEFAULT 'تصادفی ساده',
                random_seed INTEGER,
                assigned_member_id INTEGER,
                status TEXT DEFAULT 'جدید',
                conclusion TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT,
                workpaper_id INTEGER,
                finding_id INTEGER,
                submitted_by_member_id INTEGER,
                submitted_at TEXT,
                supervisor_decision TEXT,
                supervisor_member_id INTEGER,
                supervisor_reviewed_at TEXT,
                supervisor_comment TEXT,
                manager_member_id INTEGER,
                manager_approved_at TEXT,
                manager_comment TEXT
            );

            CREATE TABLE audit_test_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                test_id INTEGER NOT NULL,
                sample_no INTEGER NOT NULL,
                population_row INTEGER,
                document_ref TEXT DEFAULT '',
                description TEXT DEFAULT '',
                amount REAL,
                result TEXT DEFAULT 'رسیدگی‌نشده',
                exception_description TEXT DEFAULT '',
                evidence_path TEXT DEFAULT '',
                tested_by_member_id INTEGER,
                tested_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(test_id, sample_no)
            );

            CREATE TABLE audit_test_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                test_id INTEGER NOT NULL,
                sample_id INTEGER,
                action TEXT NOT NULL,
                details TEXT DEFAULT '',
                actor_member_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        """)

        conn.commit()
        conn.close()

    def _insert_test_data(self):
        conn = sqlite3.connect(str(self.db_path))

        members = [
            (1, 1, "مدیر", "مدیر حسابرسی", 1),
            (2, 1, "سرپرست", "سرپرست حسابرسی", 1),
            (3, 1, "حسابرس", "حسابرس", 1),
            (4, 1, "کارآموز", "کارآموز حسابرسی", 1),
            (5, 1, "سرپرست غیرفعال", "سرپرست حسابرسی", 0),
            (6, 2, "سرپرست پروژه دیگر", "سرپرست حسابرسی", 1),
            (7, 1, "مدیر غیرفعال", "مدیر حسابرسی", 0),
            (8, 2, "مدیر پروژه دیگر", "مدیر حسابرسی", 1),
        ]

        conn.executemany("""
            INSERT INTO team_members
            (id, project_id, full_name, role, is_active)
            VALUES (?, ?, ?, ?, ?)
        """, members)

        conn.execute("""
            INSERT INTO audit_tests (
                id, project_id, program_id, title,
                population_size, sample_size,
                status, conclusion
            )
            VALUES (
                1, 1, 1, 'آزمون آزمایشی',
                10, 1, 'در حال اجرا',
                'نتیجه آزمون قابل قبول است'
            )
        """)

        conn.execute("""
            INSERT INTO audit_test_samples (
                project_id, test_id, sample_no, result
            )
            VALUES (1, 1, 1, 'تأیید')
        """)

        conn.commit()
        conn.close()

    def _read_database(self, sql, params=()):
        conn = sqlite3.connect(str(self.db_path))
        try:
            return conn.execute(sql, params).fetchall()
        finally:
            conn.close()

    def _complete_workflow(self):
        self.service.submit_test(1, 1, 3, 2)
        self.service.supervisor_review(
            1, 1, 2, "approve", "بررسی انجام شد"
        )
        self.service.manager_approve(
            1, 1, 1, "تأیید نهایی"
        )

    def test_complete_approval_workflow(self):
        self._complete_workflow()

        status = self._read_database(
            "SELECT status FROM audit_tests WHERE id=1"
        )[0][0]

        self.assertEqual(status, "تأیید نهایی مدیر")

        history_count = self._read_database(
            "SELECT COUNT(*) FROM audit_test_history"
        )[0][0]

        self.assertEqual(history_count, 3)

    def test_manager_cannot_approve_before_supervisor(self):
        with self.assertRaises(ValueError):
            self.service.manager_approve(
                1, 1, 1, "تأیید زودهنگام"
            )

    def test_wrong_role_cannot_submit(self):
        with self.assertRaises(ValueError):
            self.service.submit_test(1, 1, 2, 2)

    def test_supervisor_can_return_test_for_correction(self):
        self.service.submit_test(1, 1, 3, 2)

        self.service.supervisor_review(
            1, 1, 2, "return", "مدارک تکمیلی لازم است"
        )

        row = self._read_database("""
            SELECT status, supervisor_comment
            FROM audit_tests WHERE id=1
        """)[0]

        self.assertEqual(row[0], "نیازمند اصلاح")
        self.assertEqual(row[1], "مدارک تکمیلی لازم است")

    def test_corrected_test_can_be_resubmitted(self):
        self.service.submit_test(1, 1, 3, 2)

        self.service.supervisor_review(
            1, 1, 2, "return", "اصلاح لازم است"
        )

        self.service.submit_test(1, 1, 3, 2)

        row = self._read_database("""
            SELECT status, supervisor_decision,
                   supervisor_member_id, supervisor_comment
            FROM audit_tests WHERE id=1
        """)[0]

        self.assertEqual(row[0], "آماده بررسی سرپرست")
        self.assertIsNone(row[1])
        self.assertEqual(row[2], 2)
        self.assertIsNone(row[3])

    def test_final_approved_test_cannot_be_modified(self):
        self._complete_workflow()

        sample_id = self._read_database(
            "SELECT id FROM audit_test_samples WHERE test_id=1"
        )[0][0]

        with self.assertRaises(ValueError):
            self.service.record_sample_result(
                sample_id, "مغایرت"
            )

    def test_auditor_can_save_conclusion_and_history_records_actor(self):
        self.service.save_conclusion(1, 1, 3, "نتیجه‌گیری اصلاح‌شده")

        conclusion = self._read_database(
            "SELECT conclusion FROM audit_tests WHERE id=1"
        )[0][0]
        self.assertEqual(conclusion, "نتیجه‌گیری اصلاح‌شده")

        history = self._read_database(
            "SELECT action, actor_member_id FROM audit_test_history ORDER BY id DESC LIMIT 1"
        )[0]
        self.assertEqual(history[0], "ثبت نتیجه‌گیری حسابرسی")
        self.assertEqual(history[1], 3)

    def test_sample_result_requires_auditor_identity(self):
        sample_id = self._read_database(
            "SELECT id FROM audit_test_samples WHERE test_id=1"
        )[0][0]
        with self.assertRaisesRegex(ValueError, "شناسه حسابرس"):
            self.service.record_sample_result(sample_id, "مغایرت")

    def test_sample_result_rejects_wrong_role(self):
        sample_id = self._read_database(
            "SELECT id FROM audit_test_samples WHERE test_id=1"
        )[0][0]
        with self.assertRaises(ValueError):
            self.service.record_sample_result(
                sample_id, "مغایرت", actor_member_id=4
            )

    def test_history_includes_actor_name(self):
        self.service.save_conclusion(1, 1, 3, "نتیجه")
        rows = self.repository.history_for_test(1)
        self.assertEqual(rows[0]["actor_name"], "حسابرس")
        self.assertEqual(rows[0]["actor_role"], "حسابرس")

    def test_wrong_role_cannot_save_conclusion(self):
        with self.assertRaises(ValueError):
            self.service.save_conclusion(1, 1, 4, "نتیجه")

    def test_inactive_or_foreign_supervisor_cannot_be_selected(self):
        with self.assertRaises(ValueError):
            self.service.submit_test(1, 1, 3, 5)

        with self.assertRaises(ValueError):
            self.service.submit_test(1, 1, 3, 6)

    def test_inactive_or_foreign_manager_cannot_approve(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.execute(
            "UPDATE audit_tests SET status=? WHERE id=1",
            ("تأیید سرپرست",)
        )
        conn.commit()
        conn.close()

        with self.assertRaises(ValueError):
            self.service.manager_approve(1, 1, 7, "تأیید")

        with self.assertRaises(ValueError):
            self.service.manager_approve(1, 1, 8, "تأیید")


if __name__ == "__main__":
    unittest.main()
