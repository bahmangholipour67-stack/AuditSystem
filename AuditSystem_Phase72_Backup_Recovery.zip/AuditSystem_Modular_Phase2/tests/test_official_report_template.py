import os
import tempfile
import unittest
from reporting.official_report_template import build_official_docx

class OfficialReportTemplateTests(unittest.TestCase):
    def test_creates_docx_with_report_sections(self):
        payload = {
            'report': {'title': 'گزارش نمونه', 'category': 'مدیریتی'},
            'project': {'name': 'پرونده آزمایشی'}, 'project_id': 7,
            'generated_at': '2026-11-22T09:00:00', 'row_count': 1,
            'columns': ['عنوان', 'مقدار'], 'rows': [{'عنوان': 'ریسک', 'مقدار': 'زیاد'}],
            'limitations': ['محدودیت آزمایشی']
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'report.docx')
            build_official_docx(payload, path)
            self.assertTrue(os.path.isfile(path))
            self.assertGreater(os.path.getsize(path), 1000)

if __name__ == '__main__':
    unittest.main()
