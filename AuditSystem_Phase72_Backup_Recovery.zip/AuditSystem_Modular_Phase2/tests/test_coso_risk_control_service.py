import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path
from database.migrations import ensure_schema
from services.internal_control_service import InternalControlService
from services.coso_risk_control_service import CosoRiskControlService
from services.integrated_report_service import IntegratedReportService

class CosoRiskControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'coso.db'
        ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO projects(id,name,period) VALUES(1,'الف','1405')")
            c.execute("INSERT INTO projects(id,name,period) VALUES(2,'ب','1405')")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(11,1,'ریسک فروش',16)")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(22,2,'ریسک خرید',9)")
        self.controls=InternalControlService(self.db); self.coso=CosoRiskControlService(self.db)
        self.control=self.controls.create_control(1,'کنترل تأیید فروش',risk_id=11)

    def tearDown(self): self.tmp.cleanup()

    def test_seeds_five_components_and_17_principles(self):
        ps=self.coso.principles()
        self.assertEqual(len(ps),17)
        self.assertEqual(len({p['component_no'] for p in ps}),5)

    def test_project_scoped_control_mapping(self):
        mapping=self.coso.map_control(1,self.control,'P07',11,'ریسک فروش')
        self.assertGreater(mapping,0)
        with self.assertRaises(ValueError): self.coso.map_control(1,self.control,'P07',22)
        with self.assertRaises(ValueError): self.coso.map_control(2,self.control,'P07')
        self.assertEqual(self.coso.build_report(1)['summary']['mapped_count'],1)
        self.assertEqual(self.coso.build_report(2)['summary']['mapped_count'],0)

    def test_assessment_requires_evidence_and_valid_rating(self):
        with self.assertRaises(ValueError): self.coso.assess_principle(1,'P01',4,'')
        with self.assertRaises(ValueError): self.coso.assess_principle(1,'P01',6,'سند')
        self.coso.assess_principle(1,'P01',2,'سند کنترل','ضعف مشاهده شد','ارزیاب')
        report=self.coso.build_report(1)
        p=next(x for x in report['principles'] if x['code']=='P01')
        self.assertEqual(p['rating'],2)
        self.assertTrue(any(g['code']=='P01' for g in report['gaps']))

    def test_report_identifies_unmapped_and_unassessed_principles(self):
        report=self.coso.build_report(1)
        self.assertEqual(report['summary']['principle_count'],17)
        self.assertEqual(report['summary']['assessed_count'],0)
        self.assertEqual(report['summary']['mapped_count'],0)
        self.assertEqual(report['summary']['gap_count'],34)

    def test_coso_records_are_included_in_integrated_project_report(self):
        self.coso.map_control(1,self.control,'P07',11,'ارتباط با ریسک فروش')
        self.coso.assess_principle(1,'P07',4,'برنامه آزمون کنترل و مستندات','ارزیابی قابل قبول','حسابرس')
        report=IntegratedReportService(self.db).build(1)
        self.assertEqual(report['summary']['coso_control_mapping_count'],1)
        self.assertEqual(report['summary']['coso_principle_assessment_count'],1)
        self.assertEqual(report['sections']['coso_principle_assessments'][0]['principle_code'],'P07')

    def test_history_is_append_only_and_migration_idempotent(self):
        self.coso.map_control(1,self.control,'P01')
        with sqlite_connection(self.db) as c:
            with self.assertRaises(sqlite3.IntegrityError):
                c.execute("UPDATE coso_history SET detail='tamper'")
        ensure_schema(self.db); ensure_schema(self.db)
        self.assertEqual(len(self.coso.principles()),17)

if __name__=='__main__': unittest.main()
