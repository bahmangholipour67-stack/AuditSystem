import unittest
from services.unified_audit_execution_service import UnifiedAuditExecutionService


class FakeRepository:
    def __init__(self, data):
        self.data = data
    def for_project(self, project_id):
        if project_id != self.data["project_id"]:
            return {"project_id": project_id, "risks": [], "programs": [], "tests": [], "samples": [], "findings": [], "finding_evidence": []}
        return self.data


class UnifiedAuditExecutionServiceTests(unittest.TestCase):
    def setUp(self):
        self.data = {
            "project_id": 7,
            "risks": [{"id": 1, "title": "ریسک خرید", "score": 20}],
            "programs": [{"id": 2, "title": "برنامه خرید", "risk_id": 1}],
            "tests": [{"id": 3, "program_id": 2, "title": "آزمون مجوز خرید", "workpaper_id": 4,
                       "template_objective": "کنترل مجوز قبل از سفارش", "template_assertions": '["وقوع"]',
                       "conclusion": "کنترل در نمونه‌ها اجرا شده است."}],
            "samples": [{"id": 5, "test_id": 3, "result": "تأیید", "evidence_path": "evidence/a.pdf"}],
            "findings": [], "finding_evidence": [],
        }

    def test_combined_mode_uses_both_methodologies(self):
        report = UnifiedAuditExecutionService(FakeRepository(self.data)).for_project(7, "combined")
        self.assertEqual(report["risk_coverage_percent"], 100.0)
        self.assertEqual(report["summary"]["open_gaps"], 0)
        self.assertEqual(report["mode_label"], "حسابرسی تلفیقی")

    def test_financial_mode_requires_assertions_but_not_internal_objective(self):
        self.data["tests"][0]["template_assertions"] = "[]"
        self.data["tests"][0]["template_objective"] = ""
        report = UnifiedAuditExecutionService().build_report(self.data, "financial")
        issues = [g["issue"] for g in report["gaps"]]
        self.assertTrue(any("ادعاهای مرتبط صورت‌های مالی" in x for x in issues))
        self.assertFalse(any("هدف یا معیار کنترلی" in x for x in issues))

    def test_internal_mode_requires_control_objective_not_fs_assertions(self):
        self.data["tests"][0]["template_assertions"] = "[]"
        self.data["tests"][0]["template_objective"] = ""
        report = UnifiedAuditExecutionService().build_report(self.data, "internal")
        issues = [g["issue"] for g in report["gaps"]]
        self.assertTrue(any("هدف یا معیار کنترلی" in x for x in issues))
        self.assertFalse(any("ادعاهای مرتبط صورت‌های مالی" in x for x in issues))

    def test_missing_sample_evidence_and_unlinked_exception_are_reported(self):
        self.data["samples"][0].update(result="مغایرت", evidence_path="")
        report = UnifiedAuditExecutionService().build_report(self.data, "combined")
        issues = [g["issue"] for g in report["gaps"]]
        self.assertTrue(any("استثنا ثبت شده" in x for x in issues))
        self.assertTrue(any("مسیر شواهد" in x for x in issues))

    def test_invalid_mode_and_project_are_rejected(self):
        with self.assertRaises(ValueError):
            UnifiedAuditExecutionService().build_report(self.data, "unknown")
        with self.assertRaises(ValueError):
            UnifiedAuditExecutionService().for_project(None)

    def test_cross_project_repository_scope(self):
        report = UnifiedAuditExecutionService(FakeRepository(self.data)).for_project(99)
        self.assertEqual(report["summary"]["risks"], 0)
        self.assertEqual(report["project_id"], 99)


if __name__ == "__main__":
    unittest.main()
