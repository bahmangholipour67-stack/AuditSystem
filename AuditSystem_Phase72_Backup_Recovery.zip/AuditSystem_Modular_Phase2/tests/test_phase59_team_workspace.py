from pathlib import Path


def test_team_communications_workspace_is_registered_in_main_navigation():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert "TeamWorkspaceViewMixin" in source
    assert "self.tab_team_workspace = ttk.Frame(self.workspace_host)" in source
    assert '(self.tab_team_workspace, "مرکز ارتباطات تیم")' in source
    assert "self.setup_team_workspace_tab()" in source


def test_team_workspace_exposes_inbox_thread_and_review_request_actions():
    source = Path("ui/views/team_workspace_view.py").read_text(encoding="utf-8")
    assert "صندوق ورودی و ارجاعات" in source
    assert "گفت‌وگوی کاربرگ" in source
    assert "درخواست بررسی" in source
    assert "request_review" in source
    assert "add_comment" in source


def test_team_workspace_uses_active_member_and_project_scoped_services():
    source = Path("ui/views/team_workspace_view.py").read_text(encoding="utf-8")
    assert "get_current_project_id()" in source
    assert "get_active_member()" in source
    assert "team_communications.inbox" in source
    assert "team_communications.thread" in source


def test_team_workspace_supports_workpaper_routing_through_existing_workflow_service():
    source = Path("ui/views/team_workspace_view.py").read_text(encoding="utf-8")
    assert "route_team_workspace_workpaper" in source
    assert "team_workspace_assignee" in source
    assert "team_workspace_reviewer" in source
    assert "team_communications.route_workpaper" in source
