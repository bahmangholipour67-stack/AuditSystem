import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from repositories.misstatement_repository import MisstatementRepository
from services.engagement_assessment_service import EngagementAssessmentService


class EngagementAssessmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Path(self.temp.name) / "audit.db"
        ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO projects(id,name,period,status) VALUES(1,'پرونده الف','1405','در جریان')")
            c.execute("INSERT INTO projects(id,name,period,status) VALUES(2,'پرونده ب','1405','در جریان')")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(1,1,'ریسک فروش',20)")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(2,2,'ریسک خرید',10)")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(3,1,'ریسک موجودی',18)")
            c.execute("INSERT INTO workpapers(id,project_id,risk_id,title,status) VALUES(10,1,1,'کاربرگ فروش','پیش‌نویس')")
            c.execute("INSERT INTO findings(id,project_id,title,severity,status,risk_id,workpaper_id) VALUES(20,1,'یافته فروش','زیاد','باز',1,10)")
            c.execute("INSERT INTO audit_programs(id,project_id,title) VALUES(30,1,'برنامه فروش')")
            c.execute("INSERT INTO audit_tests(id,project_id,program_id,title,status) VALUES(40,1,30,'آزمون فروش','در حال اجرا')")
            c.execute("INSERT INTO audit_test_samples(id,project_id,test_id,sample_no,result,exception_description,evidence_path) VALUES(50,1,40,1,'مغایرت','فاکتور ناقص','')")
            c.execute("INSERT INTO document_requests(id,project_id,title,status) VALUES(60,1,'تأییدیه دریافتنی','ارسال‌شده')")
        self.repo = MisstatementRepository(self.db)
        self.engine = EngagementAssessmentService(self.db)

    def tearDown(self):
        self.temp.cleanup()

    def test_missing_materiality_and_incomplete_work(self):
        result = self.engine.build(1)
        codes = {x['code'] for x in result['issues']}
        self.assertIn('MATERIALITY_NOT_SET', codes)
        self.assertIn('RISKS_WITHOUT_WORKPAPERS', codes)
        self.assertIn('WORKPAPERS_NOT_FINAL', codes)
        self.assertIn('TESTS_NOT_FINAL', codes)
        self.assertIn('OPEN_FINDINGS', codes)
        self.assertIn('SAMPLE_EXCEPTIONS_WITHOUT_EVIDENCE', codes)
        self.assertIn('OPEN_DOCUMENT_REQUESTS', codes)
        self.assertEqual(result['readiness'], 'نیازمند رسیدگی فوری')

    def test_materiality_and_uncorrected_misstatement_rules(self):
        self.repo.set_materiality(1, 1000, 700, 50)
        self.repo.create(1, 'تحریف فروش', 'واقعی', 800)
        self.repo.create(1, 'تحریف موجودی', 'قضاوتی', 250)
        self.repo.create(1, 'تحریف اصلاح‌شده', 'برآوردی', 900, status='اصلاح‌شده')
        result = self.engine.build(1)
        self.assertEqual(result['misstatement_summary']['uncorrected_gross_total'], '1050.00')
        codes = {x['code'] for x in result['issues']}
        self.assertIn('MISSTATEMENTS_OVERALL_MATERIALITY', codes)
        self.assertIn('TRIVIAL_THRESHOLD_ITEMS', codes)
        self.assertEqual(result['counts']['corrected_misstatements'], 1)

    def test_project_isolation(self):
        result = self.engine.build(2)
        self.assertEqual(result['counts']['risks'], 1)
        self.assertEqual(result['counts']['workpapers'], 0)
        self.assertEqual(result['counts']['findings'], 0)
        self.assertEqual(result['counts']['misstatements'], 0)

    def test_read_only_does_not_mutate_records(self):
        with sqlite_connection(self.db) as conn:
            before = conn.execute('SELECT status FROM workpapers WHERE id=10').fetchone()[0]
        self.engine.build(1)
        with sqlite_connection(self.db) as conn:
            after = conn.execute('SELECT status FROM workpapers WHERE id=10').fetchone()[0]
        self.assertEqual(before, after)

    def test_invalid_project_rejected(self):
        with self.assertRaises(ValueError):
            self.engine.build(999)

    def test_report_contains_traceable_references_and_limits(self):
        result = self.engine.build(1)
        issue = next(x for x in result['issues'] if x['code'] == 'SAMPLE_EXCEPTIONS_WITHOUT_EVIDENCE')
        self.assertEqual(issue['references'], [50])
        self.assertTrue(any('اظهارنظر' in x for x in result['limitations']))


if __name__ == '__main__':
    unittest.main()
