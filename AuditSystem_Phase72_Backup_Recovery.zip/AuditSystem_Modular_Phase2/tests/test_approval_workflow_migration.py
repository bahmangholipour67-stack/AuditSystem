import sqlite3
import unittest
from database.migrations import migrate_approval_workflow


class TestApprovalWorkflowMigration(unittest.TestCase):
    def test_migration_is_idempotent_and_preserves_existing_tables(self):
        conn = sqlite3.connect(':memory:')
        conn.execute('CREATE TABLE projects(id INTEGER PRIMARY KEY, name TEXT)')
        conn.execute("INSERT INTO projects VALUES(1, 'پرونده موجود')")
        migrate_approval_workflow(conn)
        migrate_approval_workflow(conn)
        self.assertEqual(conn.execute('SELECT name FROM projects WHERE id=1').fetchone()[0], 'پرونده موجود')
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({'approval_requests', 'approval_history'}.issubset(names))
        triggers = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
        self.assertTrue({'approval_history_no_update', 'approval_history_no_delete'}.issubset(triggers))
        conn.close()


if __name__ == '__main__':
    unittest.main()
