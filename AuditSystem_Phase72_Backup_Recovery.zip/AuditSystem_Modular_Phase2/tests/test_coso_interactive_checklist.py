import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path
from database.migrations import ensure_schema
from services.coso_risk_control_service import CosoRiskControlService
from services.integrated_report_service import IntegratedReportService

class CosoInteractiveChecklistTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'coso_checklist.db'
        ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده الف','1405')")
            c.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده ب','1405')")
        self.s=CosoRiskControlService(self.db)
    def tearDown(self): self.tmp.cleanup()
    def test_seeds_85_questions_for_17_principles(self):
        rows=self.s.checklist(1)
        self.assertEqual(len(rows),85)
        self.assertEqual(len({r['principle_code'] for r in rows}),17)
        self.assertEqual(len(self.s.checklist(1,'P01')),5)
    def test_save_response_requires_explanation_or_evidence(self):
        q=self.s.checklist(1,'P01')[0]
        with self.assertRaises(ValueError): self.s.save_checklist_response(1,q['question_id'],'بله')
        with self.assertRaises(ValueError): self.s.save_checklist_response(1,q['question_id'],'قابل‌اعمال نیست')
        rid=self.s.save_checklist_response(1,q['question_id'],'بله',explanation='کنترل مستند است')
        self.assertGreater(rid,0)
    def test_response_is_project_scoped(self):
        q=self.s.checklist(1,'P03')[0]
        self.s.save_checklist_response(1,q['question_id'],'خیر',evidence_ref='سند شماره ۲')
        self.assertEqual(self.s.checklist(2,'P03')[0]['answer'],'پاسخ‌داده‌نشده')
    def test_report_calculates_completion_and_weaknesses(self):
        rows=self.s.checklist(1,'P07')
        self.s.save_checklist_response(1,rows[0]['question_id'],'بله',evidence_ref='سند ۱')
        self.s.save_checklist_response(1,rows[1]['question_id'],'خیر',explanation='رویه وجود ندارد',weakness='نبود رویه')
        self.s.save_checklist_response(1,rows[2]['question_id'],'قابل‌اعمال نیست',explanation='این فرایند وجود ندارد')
        report=self.s.checklist_report(1)
        self.assertEqual(report['summary']['question_count'],85)
        self.assertEqual(report['summary']['answered_count'],3)
        self.assertEqual(report['summary']['completion_percent'],3.5)
        self.assertEqual(report['summary']['weakness_count'],1)
    def test_checklist_answers_are_in_integrated_report(self):
        q=self.s.checklist(1,'P12')[0]
        self.s.save_checklist_response(1,q['question_id'],'بله',evidence_ref='دستورالعمل شماره ۵')
        report=IntegratedReportService(self.db).build(1)
        self.assertEqual(report['summary']['coso_checklist_question_count'],85)
        self.assertEqual(report['summary']['coso_checklist_answered_count'],1)
        self.assertEqual(report['sections']['coso_checklist_responses'][55]['answer'],'بله')

    def test_answer_validation_and_unknown_question(self):
        q=self.s.checklist(1)[0]
        with self.assertRaises(ValueError): self.s.save_checklist_response(1,q['question_id'],'شاید',explanation='x')
        with self.assertRaises(ValueError): self.s.save_checklist_response(1,99999,'بله',explanation='x')
    def test_checklist_history_is_append_only_and_migration_idempotent(self):
        q=self.s.checklist(1)[0]
        self.s.save_checklist_response(1,q['question_id'],'تاحدی',explanation='بخشی اجرا می‌شود')
        with sqlite_connection(self.db) as c:
            with self.assertRaises(sqlite3.IntegrityError): c.execute("UPDATE coso_checklist_history SET detail='tamper'")
        ensure_schema(self.db); ensure_schema(self.db)
        self.assertEqual(len(self.s.checklist(1)),85)

if __name__=='__main__': unittest.main()
