﻿import sqlite3
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema


class DatabaseMigrationTests(unittest.TestCase):
    def test_fresh_database_gets_all_audit_test_tables_and_columns(self):
        with tempfile.TemporaryDirectory() as folder:
            db_path = Path(folder) / "fresh.db"
            ensure_schema(db_path)
            ensure_schema(db_path)  # migrations must be repeatable

            conn = sqlite3.connect(str(db_path))
            try:
                tables = {row[0] for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )}
                expected_tables = {
                    "projects", "team_members", "audit_programs",
                    "audit_tests", "audit_test_samples",
                    "audit_test_history", "audit_sample_findings",
                    "finding_evidence", "engagement_documents", "document_links",
                    "document_history", "document_requests", "document_request_history"
                }
                self.assertTrue(expected_tables.issubset(tables))

                columns = {row[1] for row in conn.execute(
                    "PRAGMA table_info(audit_tests)"
                )}
                expected_columns = {
                    "conclusion", "submitted_by_member_id", "submitted_at",
                    "supervisor_member_id", "supervisor_decision",
                    "manager_member_id", "manager_approved_at",
                    "workpaper_id", "finding_id"
                }
                self.assertTrue(expected_columns.issubset(columns))

                sample_columns = {row[1] for row in conn.execute(
                    "PRAGMA table_info(audit_test_samples)"
                )}
                self.assertIn("misstatement_amount", sample_columns)

                finding_columns = {
                    row[1] for row in conn.execute("PRAGMA table_info(findings)")
                }
                self.assertIn("risk_id", finding_columns)
                self.assertEqual(
                    conn.execute("PRAGMA integrity_check").fetchone()[0], "ok"
                )
            finally:
                conn.close()

    def test_finding_risk_link_is_backfilled_from_legacy_workpaper(self):
        with tempfile.TemporaryDirectory() as folder:
            db_path = Path(folder) / "legacy_links.db"
            ensure_schema(db_path)
            conn = sqlite3.connect(str(db_path))
            try:
                conn.execute("INSERT INTO projects(name,period) VALUES('پرونده','1405')")
                project_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.execute(
                    "INSERT INTO risks(project_id,title,score) VALUES(?,?,?)",
                    (project_id, "ریسک قدیمی", 15),
                )
                risk_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.execute(
                    "INSERT INTO workpapers(project_id,risk_id,title) VALUES(?,?,?)",
                    (project_id, risk_id, "کاربرگ قدیمی"),
                )
                workpaper_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.execute(
                    "INSERT INTO findings(project_id,workpaper_id,title) VALUES(?,?,?)",
                    (project_id, workpaper_id, "یافته قدیمی"),
                )
                conn.commit()
                conn.execute("UPDATE findings SET risk_id=NULL")
                conn.commit()
            finally:
                conn.close()

            ensure_schema(db_path)
            conn = sqlite3.connect(str(db_path))
            try:
                risk_link = conn.execute(
                    "SELECT risk_id FROM findings WHERE title='یافته قدیمی'"
                ).fetchone()[0]
                self.assertEqual(risk_link, risk_id)
            finally:
                conn.close()



if __name__ == "__main__":
    unittest.main()
