from pathlib import Path

from services.notification_center_service import NotificationCenterService


def _snapshot():
    return {"tasks": [
        {"id": 1, "category": "اقدام اصلاحی", "title": "اقدام عقب‌افتاده",
         "status": "باز", "owner": "علی", "due_date": "2026-11-19", "overdue": True},
        {"id": 2, "category": "درخواست مدرک", "title": "قرارداد",
         "status": "در انتظار", "owner": "حقوقی", "due_date": "2026-11-23", "overdue": False},
        {"id": 3, "category": "تأییدیه", "title": "تأیید کاربرگ",
         "status": "در انتظار سرپرست", "owner": "سرپرست", "due_date": "", "overdue": False},
        {"id": 4, "category": "اقدام اصلاحی", "title": "اقدام با مهلت دور",
         "status": "باز", "owner": "رضا", "due_date": "2026-12-20", "overdue": False},
    ]}


def test_notification_center_classifies_overdue_due_soon_and_pending_actions():
    result = NotificationCenterService.build(_snapshot(), today="2026-11-21", days_ahead=3)
    assert result["total"] == 3
    assert result["overdue"] == 1
    assert result["due_soon"] == 1
    assert result["action_required"] == 1
    assert result["notifications"][0]["title"] == "اقدام عقب‌افتاده"


def test_notification_window_is_configurable_and_bounded():
    snapshot = _snapshot()
    narrow = NotificationCenterService.build(snapshot, today="2026-11-21", days_ahead=1)
    wide = NotificationCenterService.build(snapshot, today="2026-11-21", days_ahead=5)
    assert narrow["due_soon"] == 0
    assert wide["due_soon"] == 1
    assert NotificationCenterService.build(snapshot, today="2026-11-21", days_ahead=999)["days_ahead"] == 90


def test_closed_or_unrelated_tasks_do_not_create_action_notifications():
    snapshot = {"tasks": [
        {"category": "کاربرگ", "title": "کاربرگ بسته", "status": "بسته", "due_date": "",
         "overdue": False},
        {"category": "ریسک", "title": "ریسک عادی", "status": "باز", "due_date": "",
         "overdue": False},
    ]}
    assert NotificationCenterService.build(snapshot, today="2026-11-21")["total"] == 0


def test_dashboard_integrates_notification_center_without_database_mutations():
    root = Path(__file__).resolve().parents[1]
    view = (root / "ui" / "views" / "dashboard_view.py").read_text(encoding="utf-8")
    service = (root / "services" / "notification_center_service.py").read_text(encoding="utf-8")
    assert "NotificationCenterService.build" in view
    assert "مرکز اعلان‌ها و یادآوری‌های حسابرسی" in view
    assert "CREATE TABLE" not in service
    assert "INSERT INTO" not in service
    assert "UPDATE " not in service
