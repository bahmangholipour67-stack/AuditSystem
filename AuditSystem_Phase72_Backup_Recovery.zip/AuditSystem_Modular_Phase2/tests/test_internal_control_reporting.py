import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path
from database.migrations import ensure_schema
from services.internal_control_service import InternalControlService
from services.integrated_report_service import IntegratedReportService

class InternalControlReportingTests(unittest.TestCase):
    def test_internal_control_data_appears_in_integrated_report(self):
        with tempfile.TemporaryDirectory() as td:
            db=Path(td)/'audit.db'; ensure_schema(db)
            with sqlite_connection(db) as c:
                c.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده','1405')")
                c.execute("INSERT INTO risks(id,project_id,title) VALUES(1,1,'ریسک')")
            service=InternalControlService(db)
            control=service.create_control(1,'کنترل',risk_id=1)
            service.record_control_test(1,control,'طراحی','موثر',0,0,'شرح شواهد')
            finding=service.create_control_finding(1,control,'ضعف','شرط','معیار')
            service.create_action(1,finding,'اقدام','مسئول','1405/12/29')
            report=IntegratedReportService(db).build(1)
            self.assertEqual(report['summary']['internal_control_count'],1)
            self.assertEqual(report['summary']['control_test_count'],1)
            self.assertEqual(report['summary']['internal_control_finding_count'],1)
            self.assertEqual(report['summary']['open_corrective_action_count'],1)
            self.assertEqual(report['sections']['internal_control_findings'][0]['id'],finding)

if __name__=='__main__': unittest.main()
