from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DASHBOARD = ROOT / "ui" / "views" / "dashboard_view.py"


def test_executive_kpi_strip_is_setup_and_refreshed():
    source = DASHBOARD.read_text(encoding="utf-8")
    assert "_setup_executive_kpi_strip(container)" in source
    assert "_update_executive_kpi_strip(data)" in source
    assert "AuditExecutiveDashboardService.snapshot(" in source


def test_executive_kpi_strip_has_expected_indicators():
    source = DASHBOARD.read_text(encoding="utf-8")
    for key in (
        "project_count",
        "audit_test_count",
        "high_risk_count",
        "workpaper_completion_percent",
        "open_finding_count",
        "pending_review_count",
    ):
        assert key in source


def test_project_status_is_not_assumed_by_dashboard_integration():
    source = DASHBOARD.read_text(encoding="utf-8")
    assert '"نامشخص"' in source
    assert "do not infer status" in source
