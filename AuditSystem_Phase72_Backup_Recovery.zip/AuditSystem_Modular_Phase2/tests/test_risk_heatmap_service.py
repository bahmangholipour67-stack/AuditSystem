from services.risk_heatmap_service import RiskHeatmapService as Service

def test_score_validates_1_to_5_and_multiplies():
    assert Service.score(5, 4) == 20
    for pair in ((0, 3), (6, 3), (2, None), ("x", 2)):
        try:
            Service.score(*pair)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected validation error for {pair}")

def test_level_boundaries():
    assert Service.level(4) == "کم"
    assert Service.level(5) == "متوسط"
    assert Service.level(9) == "متوسط"
    assert Service.level(10) == "زیاد"
    assert Service.level(15) == "زیاد"
    assert Service.level(16) == "بحرانی"

def test_matrix_counts_cells_and_ignores_invalid_records():
    data = [{"title": "A", "likelihood": 5, "impact": 4},
            {"title": "B", "likelihood": 5, "impact": 4},
            {"title": "bad", "likelihood": 0, "impact": 2}]
    result = Service.matrix(data)
    assert result["total"] == 2
    assert result["cells"][(5, 4)] == 2
    assert result["risks"][0]["level"] == "بحرانی"

def test_filter_cell_returns_only_matching_risks():
    data = [{"title": "A", "likelihood": 3, "impact": 4},
            {"title": "B", "likelihood": 3, "impact": 4},
            {"title": "C", "likelihood": 4, "impact": 4}]
    assert [r["title"] for r in Service.filter_cell(data, 3, 4)] == ["A", "B"]

def test_inherent_residual_requires_explicit_values_and_sorts_by_residual():
    data = [{"title": "A", "inherent_likelihood": 5, "inherent_impact": 5,
             "residual_likelihood": 2, "residual_impact": 3},
            {"title": "B", "inherent_likelihood": 4, "inherent_impact": 4,
             "residual_likelihood": 4, "residual_impact": 4},
            {"title": "missing", "inherent_likelihood": 4, "inherent_impact": 4}]
    result = Service.compare_inherent_residual(data)
    assert len(result) == 2
    assert result[0]["title"] == "B"
    assert result[1]["inherent_score"] == 25
    assert result[1]["residual_score"] == 6
    assert result[1]["score_difference"] == 19
