import unittest

from services.audit_test_evaluation_service import AuditTestEvaluationService


class AuditTestEvaluationServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = AuditTestEvaluationService()

    def test_counts_and_completion(self):
        result = self.service.evaluate([
            {"sample_no": 1, "result": "تأیید"},
            {"sample_no": 2, "result": "مغایرت", "amount": 120},
            {"sample_no": 3, "result": "عدم انطباق", "amount": 80},
        ], allowed_exception_rate=70)
        self.assertEqual(result["tested_samples"], 3)
        self.assertEqual(result["exception_samples"], 2)
        self.assertEqual(result["exception_amount"], 200)
        self.assertEqual(result["assessment"], "احراز معیار")

    def test_unresolved_samples_block_final_assessment(self):
        result = self.service.evaluate([
            {"result": "تأیید"},
            {"result": "نیازمند بررسی"},
        ], allowed_exception_rate=100)
        self.assertEqual(result["assessment"], "نیازمند تکمیل رسیدگی")
        self.assertFalse(result["is_complete"])

    def test_untested_samples_are_not_in_rate_denominator(self):
        result = self.service.evaluate([
            {"result": "تأیید"},
            {"result": "مغایرت"},
            {"result": "رسیدگی‌نشده"},
        ], allowed_exception_rate=50, require_complete=False)
        self.assertEqual(result["exception_rate_percent"], 50.0)

    def test_exceeding_threshold_fails(self):
        result = self.service.evaluate([
            {"result": "تأیید"},
            {"result": "مغایرت"},
        ], allowed_exception_rate=49.9)
        self.assertEqual(result["assessment"], "عدم احراز معیار")

    def test_zero_tested_samples_has_no_result(self):
        result = self.service.evaluate([
            {"result": "رسیدگی‌نشده"},
        ])
        self.assertEqual(result["assessment"], "فاقد نتیجه")

    def test_invalid_result_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.evaluate([{"result": "نامعتبر"}])

    def test_invalid_threshold_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.evaluate([{"result": "تأیید"}], allowed_exception_rate=101)

    def test_bad_amount_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.evaluate([{"result": "مغایرت", "amount": "abc"}])

    def test_input_samples_are_not_mutated(self):
        samples = [{"sample_no": 1, "result": "تأیید"}]
        original = [dict(row) for row in samples]
        self.service.evaluate(samples)
        self.assertEqual(samples, original)


if __name__ == "__main__":
    unittest.main()
