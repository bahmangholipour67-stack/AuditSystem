from pathlib import Path


def test_active_application_has_no_ttk_notebook_or_global_tab_strip():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert "ttk.Notebook(" not in source
    assert "self.workspace_host = ttk.Frame(workspace_area)" in source
    assert "frame.grid(row=0, column=0, sticky=\"nsew\")" in source
    assert "frame.tkraise()" in source


def test_dashboard_does_not_duplicate_global_module_navigation():
    source = Path("ui/views/dashboard_view.py").read_text(encoding="utf-8")
    assert "دسترسی سریع:" not in source
    assert "_open_workspace_title(target)" not in source
