from ui.table_interactions import _sort_value, attach_table_interactions


class FakeMenu:
    def __init__(self, *args, **kwargs):
        self.commands = []

    def add_command(self, **kwargs):
        self.commands.append(kwargs)

    def tk_popup(self, *args):
        pass

    def grab_release(self):
        pass


class FakeOwner:
    def __init__(self):
        self.clipboard = ""

    def clipboard_clear(self):
        self.clipboard = ""

    def clipboard_append(self, value):
        self.clipboard = value


class FakeTree:
    def __init__(self):
        self.columns = ("id", "name")
        self.rows = {
            "r1": {"id": "۱۰", "name": "بتا"},
            "r2": {"id": "۲", "name": "آلفا"},
        }
        self.order = ["r1", "r2"]
        self.selected = ("r1", "r2")
        self.bindings = {}
        self.titles = {"id": "شناسه", "name": "عنوان"}
        self.commands = {}

    def __getitem__(self, key):
        assert key == "columns"
        return self.columns

    def heading(self, column, option=None, **kwargs):
        if kwargs:
            self.titles[column] = kwargs.get("text", self.titles[column])
            if "command" in kwargs:
                self.commands[column] = kwargs["command"]
            return
        if option == "text":
            return self.titles[column]
        return self.titles[column]

    def bind(self, sequence, callback, add=None):
        self.bindings[sequence] = callback

    def get_children(self, item=""):
        return tuple(self.order)

    def set(self, item, column):
        return self.rows[item][column]

    def move(self, item, parent, index):
        self.order.remove(item)
        self.order.insert(index, item)

    def selection(self):
        return self.selected

    def selection_set(self, items):
        self.selected = tuple(items) if not isinstance(items, str) else (items,)

    def item(self, item, option):
        return {"values": tuple(self.rows[item][key] for key in self.columns)}[option]

    def identify_row(self, y):
        return "r1"



def test_sort_value_handles_persian_digits_and_numeric_values():
    assert _sort_value("۱۰") < _sort_value("۲۵")
    assert _sort_value("۲") < _sort_value("۱۰")
    assert _sort_value("پرونده") > _sort_value("۱۲")


def test_table_interactions_sort_copy_and_select_all(monkeypatch):
    monkeypatch.setattr("ui.table_interactions.tk.Menu", FakeMenu)
    tree = FakeTree()
    owner = FakeOwner()
    attach_table_interactions(tree, owner)

    # Numeric sorting is ascending on first click and descending on second.
    tree.commands["id"]()
    assert tree.order == ["r2", "r1"]
    tree.commands["id"]()
    assert tree.order == ["r1", "r2"]

    tree.bindings["<Control-a>"](None)
    assert tree.selection() == ("r1", "r2")
    tree._audit_table_copy()
    assert owner.clipboard == "۱۰\tبتا\n۲\tآلفا"

    # Re-attachment is idempotent and does not replace existing state.
    state = tree._audit_table_sort_state
    attach_table_interactions(tree, owner)
    assert tree._audit_table_sort_state is state


def test_make_tree_installs_shared_interactions_for_all_table_views():
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / "legacy" / "audit_app.py").read_text(encoding="utf-8")
    assert "from ui.table_interactions import attach_table_interactions" in source
    assert "attach_table_interactions(tree, self.root)" in source
