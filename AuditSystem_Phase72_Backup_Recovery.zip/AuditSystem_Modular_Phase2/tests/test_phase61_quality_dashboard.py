import unittest
from datetime import datetime
from services.quality_dashboard_service import QualityDashboardService

class QualityDashboardTests(unittest.TestCase):
    def test_counts_overdue_returned_approved_and_average_duration(self):
        now = datetime(2026, 11, 22, 12)
        rows = [
            (1, "pending_supervisor", "supervisor", "2026-11-10 10:00:00", None, 7),
            (2, "returned", "supervisor", "2026-11-01 10:00:00", "2026-11-03 10:00:00", 7),
            (3, "approved", "complete", "2026-11-01 10:00:00", "2026-11-05 10:00:00", 8),
        ]
        result = QualityDashboardService.build_snapshot(rows, now=now)
        self.assertEqual(result["pending_requests"], 1)
        self.assertEqual(result["overdue_requests"], 1)
        self.assertEqual(result["returned_requests"], 1)
        self.assertEqual(result["approved_requests"], 1)
        self.assertEqual(result["average_review_days"], 3.0)
        self.assertEqual(result["completion_percent"], 33)

    def test_empty_data_and_invalid_threshold(self):
        result = QualityDashboardService.build_snapshot([])
        self.assertEqual(result["total_requests"], 0)
        self.assertIsNone(result["average_review_days"])
        with self.assertRaises(ValueError):
            QualityDashboardService.build_snapshot([], overdue_days="x")

    def test_supervisor_history_aggregated(self):
        history = [(5, "سرپرست الف", "supervisor", "returned", "2026-11-01 10:00:00"),
                   (5, "سرپرست الف", "supervisor", "stage_approved", "2026-11-02 10:00:00")]
        result = QualityDashboardService.build_snapshot([], history)
        self.assertEqual(result["supervisors"][5]["reviewed"], 2)
        self.assertEqual(result["supervisors"][5]["returned"], 1)

if __name__ == "__main__":
    unittest.main()
