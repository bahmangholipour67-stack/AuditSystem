from pathlib import Path


def test_dashboard_exposes_advanced_workspace_filters():
    source = (Path(__file__).resolve().parents[1] / "ui" / "views" / "dashboard_view.py").read_text(encoding="utf-8")
    for token in ("workspace_filter_vars", "refresh_workspace_filter_options", "responsible", "period", "filters=filters", "project_options", "همه پرونده‌ها"):
        assert token in source


def test_advanced_search_remains_read_only_and_schema_adaptive():
    source = (Path(__file__).resolve().parents[1] / "services" / "phase31_workspace_service.py").read_text(encoding="utf-8")
    assert "PRAGMA table_info" in source
    assert "def filter_options" in source
    assert "def search" in source
    assert "CREATE TABLE" not in source
