import ast
from pathlib import Path
import unittest


class PersianNavigationOrderTests(unittest.TestCase):
    def setUp(self):
        self.source = Path(__file__).parents[1] / "legacy" / "audit_app.py"
        self.text = self.source.read_text(encoding="utf-8")
        self.tree = ast.parse(self.text)

    def test_custom_menu_buttons_are_packed_from_right(self):
        method = next(n for n in ast.walk(self.tree)
                      if isinstance(n, ast.FunctionDef)
                      and n.name == "_build_classic_application_menu")
        code = ast.get_source_segment(self.text, method)
        self.assertIn('button.pack(side="right"', code)
        self.assertIn('system_button.pack(side="right"', code)
        self.assertIn("for group in menu_order", code)
        self.assertNotIn("for group in reversed(menu_order)", code)

    def test_native_menubar_is_disabled(self):
        self.assertIn('self.root.configure(menu="")', self.text)
        self.assertIn("self.classic_menu_bar", self.text)

    def test_dropdowns_align_to_right_edge(self):
        method = next(n for n in ast.walk(self.tree)
                      if isinstance(n, ast.FunctionDef)
                      and n.name == "_popup_rtl_application_menu")
        code = ast.get_source_segment(self.text, method)
        self.assertIn("button.winfo_rootx() + button.winfo_width() - menu_width", code)

    def test_tabs_render_newest_at_right_edge(self):
        self.assertIn("for title in reversed(self._opened_workspace_titles)", self.text)
        self.assertIn('anchor="ne"', self.text)
        self.assertIn("self.workspace_tabs_canvas.xview_moveto(1.0)", self.text)
        self.assertIn('btn.pack(side="right"', self.text)


if __name__ == "__main__":
    unittest.main()
