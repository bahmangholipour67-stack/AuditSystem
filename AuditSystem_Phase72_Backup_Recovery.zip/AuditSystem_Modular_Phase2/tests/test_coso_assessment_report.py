import json
import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from services.coso_risk_control_service import CosoRiskControlService
from services.coso_assessment_report_service import CosoAssessmentReportService


class CosoAssessmentReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "coso_report.db"
        ensure_schema(self.db)
        with sqlite_connection(self.db) as conn:
            conn.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده گزارش','1405')")
            conn.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده دیگر','1405')")
        self.checklist = CosoRiskControlService(self.db)
        self.service = CosoAssessmentReportService(self.db)

    def tearDown(self):
        self.tmp.cleanup()

    def test_report_classifies_incomplete_weakness_and_evidence_separately(self):
        rows = self.checklist.checklist(1, "P01")
        self.checklist.save_checklist_response(1, rows[0]["question_id"], "بله", explanation="شرح پاسخ بدون شماره مدرک")
        self.checklist.save_checklist_response(1, rows[1]["question_id"], "خیر", evidence_ref="سند ۱۲", weakness="نبود کنترل")
        self.checklist.save_checklist_response(1, rows[2]["question_id"], "قابل‌اعمال نیست", explanation="فرایند مربوط در شرکت وجود ندارد")
        report = self.service.build(1)
        self.assertEqual(report["summary"]["question_count"], 85)
        self.assertEqual(report["summary"]["answered_count"], 3)
        self.assertEqual(report["summary"]["weakness_count"], 1)
        self.assertEqual(report["summary"]["evidence_gap_count"], 1)
        self.assertEqual(report["summary"]["unanswered_count"], 82)
        self.assertIn("ناقص", report["summary"]["overall_status"])
        self.assertEqual(report["summary"]["na_without_rationale_count"], 0)

    def test_project_data_isolation(self):
        row = self.checklist.checklist(1, "P02")[0]
        self.checklist.save_checklist_response(1, row["question_id"], "خیر", explanation="ضعف پرونده یک")
        report_b = self.service.build(2)
        self.assertEqual(report_b["summary"]["answered_count"], 0)
        self.assertEqual(report_b["summary"]["weakness_count"], 0)

    def test_principle_component_control_test_and_finding_cross_reference(self):
        with sqlite_connection(self.db) as conn:
            cur = conn.execute("INSERT INTO internal_controls(project_id,title,control_type,method) VALUES(1,'کنترل نمونه','پیشگیرانه','دستی')")
            control_id = cur.lastrowid
            conn.execute("INSERT INTO control_tests(project_id,control_id,test_stage,result) VALUES(1,?,'اثربخشی عملیاتی','قبول')", (control_id,))
            conn.execute("INSERT INTO findings(project_id,title,finding_type,control_id,status) VALUES(1,'یافته کنترل','کنترل داخلی',?,'باز')", (control_id,))
            conn.execute("INSERT INTO coso_control_mappings(project_id,control_id,principle_code,rationale) VALUES(1,?,'P01','ارتباط با اصل')", (control_id,))
        report = self.service.build(1)
        p01 = next(p for p in report["principles"] if p["code"] == "P01")
        self.assertEqual(p01["mapped_controls"], 1)
        self.assertEqual(p01["tested_controls"], 1)
        self.assertEqual(p01["linked_findings"], 1)

    def test_export_excel_and_word(self):
        report = self.service.build(1)
        xlsx = Path(self.tmp.name) / "coso.xlsx"
        docx = Path(self.tmp.name) / "coso.docx"
        self.service.export_excel(report, xlsx)
        self.service.export_word(report, docx)
        self.assertGreater(xlsx.stat().st_size, 1000)
        self.assertGreater(docx.stat().st_size, 1000)

    def test_invalid_or_unknown_project_rejected(self):
        with self.assertRaises(ValueError):
            self.service.build("abc")
        with self.assertRaises(ValueError):
            self.service.build(999)


if __name__ == "__main__":
    unittest.main()
