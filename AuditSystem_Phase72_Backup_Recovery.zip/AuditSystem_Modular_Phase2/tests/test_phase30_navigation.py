from pathlib import Path


def test_phase30_uses_right_side_workspace_navigation():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert 'sidebar.grid(row=0, column=1, sticky="ns")' in source
    assert 'self.workspace_host = ttk.Frame(workspace_area)' in source
    assert 'frame.tkraise()' in source
    assert 'ttk.Notebook(' not in source
    assert 'def show_workspace(self, frame, title=None):' in source
    assert 'def filter_navigation(self, *_):' in source


def test_phase30_keeps_all_existing_module_setup_calls():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    required = [
        "setup_project_tab", "setup_archive_tab", "setup_dashboard_tab",
        "setup_risk_tab", "setup_workpaper_tab", "setup_finding_tab",
        "setup_benford_tab", "setup_ratio_tab", "setup_sampling_tab",
        "setup_trial_balance_tab", "setup_team_tab", "setup_audit_test_tab",
        "setup_audit_file_tab", "setup_audit_traceability_tab",
        "setup_document_center_tab", "setup_misstatement_tab",
        "setup_engagement_assessment_tab", "setup_approval_center_tab",
        "setup_unified_audit_execution_tab", "setup_internal_control_tab",
        "setup_coso_framework_tab",
    ]
    for method in required:
        assert f"self.{method}()" in source


def test_phase30_does_not_replace_existing_database_or_service_layer():
    root = Path(".")
    assert (root / "database" / "schema.py").exists()
    assert (root / "database" / "migrations.py").exists()
    assert (root / "services" / "application_services.py").exists()
    assert (root / "repositories" / "project_repository.py").exists()
