"""Test-only SQLite context manager that commits/rolls back and closes."""
import sqlite3
from contextlib import contextmanager


@contextmanager
def sqlite_connection(path):
    connection = sqlite3.connect(path)
    try:
        with connection:
            yield connection
    finally:
        connection.close()
