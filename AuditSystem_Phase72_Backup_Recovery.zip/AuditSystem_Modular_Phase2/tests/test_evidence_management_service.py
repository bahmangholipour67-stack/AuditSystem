import tempfile
from pathlib import Path
import pytest
from services.evidence_management_service import EvidenceManagementService as Service


BASE = {"title": "Bank confirmation", "source": "Bank", "received_by": "auditor-1", "received_date": "2026-11-20"}


def test_metadata_required_fields_and_default_status():
    assert Service.validate_metadata(BASE)["status"] == "دریافت‌شده"
    with pytest.raises(ValueError):
        Service.validate_metadata({"title": "missing source"})
    with pytest.raises(ValueError):
        Service.validate_metadata({**BASE, "status": "unknown"})


def test_status_transition_rules():
    assert Service.transition_status("دریافت‌شده", "در حال بررسی") == "در حال بررسی"
    assert Service.transition_status("در حال بررسی", "تأییدشده") == "تأییدشده"
    with pytest.raises(ValueError):
        Service.transition_status("دریافت‌شده", "تأییدشده")
    with pytest.raises(ValueError):
        Service.transition_status("بایگانی‌شده", "دریافت‌شده")


def test_link_validation_and_duplicate_removal():
    links = [{"entity_type": "risk", "entity_id": "R-1"},
             {"entity_type": "risk", "entity_id": "R-1"},
             {"entity_type": "workpaper", "entity_id": "WP-1"}]
    assert Service.validate_links(links) == links[:1] + links[2:]
    with pytest.raises(ValueError):
        Service.validate_links([{"entity_type": "invalid", "entity_id": "1"}])
    with pytest.raises(ValueError):
        Service.validate_links([{"entity_type": "risk", "entity_id": ""}])


def test_sha256_and_duplicate_lookup():
    with tempfile.TemporaryDirectory() as td:
        file_path = Path(td) / "sample.txt"
        file_path.write_bytes(b"evidence bytes")
        digest = Service.sha256_file(file_path)
        assert len(digest) == 64
        records = [{"evidence_id": "E-1", "sha256": digest}, {"evidence_id": "E-2", "sha256": "other"}]
        assert Service.find_duplicate_hash(records, digest) == records[:1]
        with pytest.raises(FileNotFoundError):
            Service.sha256_file(Path(td) / "missing")
