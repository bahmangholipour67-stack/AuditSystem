import json
import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from database.migrations import ensure_schema
from repositories.audit_traceability_repository import AuditTraceabilityRepository
from services.audit_traceability_service import AuditTraceabilityService


class AuditTraceabilityServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = AuditTraceabilityService()

    def test_reports_missing_chain_and_prioritizes_high_risk(self):
        report = self.service.build_report({
            "project_id": 1,
            "risks": [{"id": 1, "title": "ریسک درآمد", "score": 22}],
            "programs": [], "tests": [], "samples": [], "findings": [],
            "finding_evidence": [],
        })
        self.assertEqual(report["summary"]["risk_test_coverage_percent"], 0.0)
        self.assertEqual(report["issues"][0]["priority"], "بالا")
        self.assertIn("برنامه حسابرسی", report["issues"][0]["problem"])

    def test_detects_assertion_evidence_and_exception_without_finding(self):
        report = self.service.build_report({
            "project_id": 1,
            "risks": [{"id": 1, "title": "ریسک", "score": 20}],
            "programs": [{"id": 10, "title": "برنامه", "risk_id": 1}],
            "tests": [{
                "id": 20, "program_id": 10, "title": "آزمون فروش", "status": "در حال اجرا",
                "workpaper_id": 30, "program_risk_id": 1, "workpaper_risk_id": 1,
                "template_assertions": "[]", "expected_evidence": "فاکتور و قرارداد",
                "conclusion": "", "finding_id": None,
            }],
            "samples": [{"id": 40, "test_id": 20, "result": "مغایرت", "evidence_path": ""}],
            "findings": [], "finding_evidence": [],
        })
        problems = [item["problem"] for item in report["issues"]]
        self.assertTrue(any("ادعاهای صورت‌های مالی" in value for value in problems))
        self.assertTrue(any("مسیر شواهد" in value for value in problems))
        self.assertTrue(any("مورد استثنا" in value for value in problems))
        self.assertEqual(report["summary"]["risk_test_coverage_percent"], 100.0)

    def test_does_not_flag_complete_linkage_and_evidence(self):
        report = self.service.build_report({
            "project_id": 1,
            "risks": [{"id": 1, "title": "ریسک", "score": 12}],
            "programs": [{"id": 10, "title": "برنامه", "risk_id": 1}],
            "tests": [{
                "id": 20, "program_id": 10, "title": "آزمون", "status": "در حال اجرا",
                "workpaper_id": 30, "program_risk_id": 1, "workpaper_risk_id": 1,
                "template_assertions": json.dumps(["وقوع", "دقت"]),
                "expected_evidence": "فاکتور", "conclusion": "نتیجه مستند", "finding_id": None,
            }],
            "samples": [{"id": 40, "test_id": 20, "result": "تأیید", "evidence_path": "evidence/invoice.pdf"}],
            "findings": [], "finding_evidence": [],
        })
        self.assertEqual(report["issues"], [])
        self.assertEqual(report["summary"]["risk_test_coverage_percent"], 100.0)
        self.assertEqual(report["summary"]["distinct_assertion_count"], 2)
        self.assertEqual(report["risk_matrix"][0]["assertions"], ["وقوع", "دقت"])

    def test_sample_level_finding_link_prevents_duplicate_unlinked_exception_warning(self):
        report = self.service.build_report({
            "project_id": 1,
            "risks": [{"id": 1, "title": "ریسک", "score": 20}],
            "programs": [{"id": 10, "title": "برنامه", "risk_id": 1}],
            "tests": [{"id": 20, "program_id": 10, "title": "آزمون", "status": "در حال اجرا",
                       "workpaper_id": 30, "program_risk_id": 1, "workpaper_risk_id": 1,
                       "template_assertions": '["وقوع"]', "expected_evidence": "فاکتور"}],
            "samples": [{"id": 40, "test_id": 20, "result": "مغایرت",
                          "evidence_path": "invoice.pdf", "finding_id": 50}],
            "findings": [], "finding_evidence": [],
        })
        self.assertFalse(any("مورد استثنا" in item["problem"] for item in report["issues"]))

    def test_rejects_invalid_threshold(self):
        for threshold in (0, 26, "x"):
            with self.subTest(threshold=threshold), self.assertRaises(ValueError):
                self.service.build_report({}, high_risk_threshold=threshold)


class AuditTraceabilityRepositoryTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "traceability.db"
        ensure_schema(self.db_path)
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده','1405')")
            conn.execute("INSERT INTO risks(id,project_id,title,score) VALUES(1,1,'ریسک فروش',21)")
            conn.execute("INSERT INTO workpapers(id,project_id,risk_id,title,status) VALUES(1,1,1,'کاربرگ فروش','پیش‌نویس')")
            conn.execute("INSERT INTO audit_programs(id,project_id,title,risk_id) VALUES(1,1,'برنامه فروش',1)")
            conn.execute("""INSERT INTO audit_tests(
                id,project_id,program_id,title,workpaper_id,template_assertions,expected_evidence
            ) VALUES(1,1,1,'آزمون فروش',1,'[\"وقوع\"]','فاکتور')""")
            conn.execute("""INSERT INTO audit_test_samples(
                id,project_id,test_id,sample_no,result,evidence_path
            ) VALUES(1,1,1,1,'تأیید','docs/invoice.pdf')""")
            conn.commit()
        finally:
            conn.close()

        self.patch = patch("repositories.audit_traceability_repository.connect", self._connect)
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp_dir.cleanup()

    @contextmanager
    def _connect(self, *args, **kwargs):
        conn = sqlite3.connect(str(self.db_path))
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def test_reads_real_project_chain_without_mutating_database(self):
        repository = AuditTraceabilityRepository()
        data = repository.for_project(1)
        report = AuditTraceabilityService().build_report(data)
        self.assertEqual(len(data["risks"]), 1)
        self.assertEqual(len(data["tests"]), 1)
        self.assertEqual(report["summary"]["risk_test_coverage_percent"], 100.0)
        self.assertEqual(report["issues"], [])


if __name__ == "__main__":
    unittest.main()
