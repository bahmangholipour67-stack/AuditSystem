import sqlite3

from services.phase31_workspace_service import Phase31WorkspaceService


def make_db():
    conn = sqlite3.connect(":memory:")
    conn.executescript("""
        CREATE TABLE projects(id INTEGER PRIMARY KEY, name TEXT, period TEXT, created_at TEXT);
        CREATE TABLE risks(id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, control_desc TEXT,
            status TEXT, assigned_to TEXT, period TEXT);
        CREATE TABLE workpaper_history(id INTEGER PRIMARY KEY, project_id INTEGER, workpaper_id INTEGER,
            action TEXT, notes TEXT, created_at TEXT);
        INSERT INTO projects VALUES(1, 'شرکت نمونه', '1405', '2026-01-01');
        INSERT INTO risks VALUES(1, 1, 'ریسک موجودی کالا', 'شمارش و انبار', 'در انتظار بررسی', 'حسابرس الف', '1405');
        INSERT INTO risks VALUES(2, 2, 'ریسک فروش', 'کنترل فروش', 'تأییدشده', 'حسابرس ب', '1404');
        INSERT INTO workpaper_history VALUES(1, 1, 10, 'ارسال برای بررسی', 'کاربرگ موجودی', '2026-02-01 10:00:00');
    """)
    return conn


def test_global_search_respects_project_scope():
    conn = make_db()
    service = Phase31WorkspaceService()
    rows = service.search(conn, 'ریسک', project_id=1)
    assert len(rows) == 1
    assert rows[0]['title'] == 'ریسک موجودی کالا'
    assert rows[0]['module'] == 'ریسک‌ها'


def test_global_search_returns_no_results_for_short_query():
    conn = make_db()
    assert Phase31WorkspaceService().search(conn, 'ر', project_id=1) == []


def test_recent_activity_reads_append_only_history():
    conn = make_db()
    rows = Phase31WorkspaceService().recent_activity(conn, project_id=1)
    assert rows
    assert rows[0]['type'] == 'کاربرگ'
    assert rows[0]['event'] == 'ارسال برای بررسی'
    assert rows[0]['detail'] == 'کاربرگ موجودی'


def test_recent_activity_is_project_scoped():
    conn = make_db()
    rows = Phase31WorkspaceService().recent_activity(conn, project_id=2)
    assert rows == []


def test_global_search_supports_module_status_responsible_and_period_filters():
    conn = make_db()
    service = Phase31WorkspaceService()
    rows = service.search(conn, "ریسک", project_id=1, filters={
        "module": "ریسک‌ها", "status": "در انتظار بررسی",
        "responsible": "حسابرس الف", "period": "1405",
    })
    assert len(rows) == 1
    assert rows[0]["title"] == "ریسک موجودی کالا"
    assert service.search(conn, "ریسک", project_id=1, filters={"status": "تأییدشده"}) == []


def test_filter_options_are_discovered_from_existing_schema():
    conn = make_db()
    options = Phase31WorkspaceService.filter_options(conn, project_id=1)
    assert options["status"] == ["در انتظار بررسی"]
    assert options["responsible"] == ["حسابرس الف"]
    assert options["period"] == ["1405"]


def test_project_options_expose_engagements_for_cross_project_search():
    conn = make_db()
    options = Phase31WorkspaceService.project_options(conn)
    assert options == [{"id": 1, "name": "شرکت نمونه"}]
