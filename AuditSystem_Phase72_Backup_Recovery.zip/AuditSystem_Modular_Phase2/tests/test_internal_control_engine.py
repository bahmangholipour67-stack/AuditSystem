import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from services.internal_control_service import InternalControlService


class InternalControlEngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / 'audit.db'
        ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده الف','1405')")
            c.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده ب','1405')")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(10,1,'ریسک فروش',15)")
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(20,2,'ریسک خرید',12)")
        self.s = InternalControlService(self.db)

    def tearDown(self): self.tmp.cleanup()

    def test_control_and_test_lifecycle_is_project_scoped(self):
        control = self.s.create_control(1, 'کنترل تأیید فروش', 'تأیید مدیر فروش', 10,
            'مدیر فروش', 'روزانه', 'پیشگیرانه', 'دستی', 'دستورالعمل فروش')
        self.assertEqual(len(self.s.list_controls(1)), 1)
        self.assertEqual(self.s.list_controls(2), [])
        with self.assertRaises(ValueError): self.s.create_control(1, 'کنترل نامعتبر', risk_id=20)
        with self.assertRaises(ValueError): self.s.record_control_test(1, control, 'اثربخشی عملیاتی', 'موثر', 0, 0)
        test = self.s.record_control_test(1, control, 'اثربخشی عملیاتی', 'دارای نقص', 25, 3, 'نمونه‌های آزمون', 'حسابرس')
        self.assertGreater(test, 0)
        with sqlite_connection(self.db) as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM control_tests WHERE project_id=2').fetchone()[0], 0)

    def test_finding_action_and_evidence_required_for_closure(self):
        control = self.s.create_control(1, 'کنترل تطبیق بانک', risk_id=10)
        finding = self.s.create_control_finding(1, control, 'عدم انجام تطبیق', 'تطبیق ماهانه انجام نشده',
            'آیین‌نامه مالی', 'نبود مسئول مشخص', 'مانده بانک نامطمئن', 'زیاد', 4, 5, 'مدیر مالی')
        with self.assertRaises(ValueError): self.s.close_finding(1, finding)
        action = self.s.create_action(1, finding, 'اجرای تطبیق‌های معوق', 'مدیر مالی', '1405/12/29', 'ماه اول؛ ماه دوم')
        with self.assertRaises(ValueError): self.s.update_action(1, action, 'تأییدشده')
        with self.assertRaises(ValueError): self.s.update_action(1, action, 'تأییدشده', evidence='گزارش', followup_result='ناموفق')
        self.s.update_action(1, action, 'تأییدشده', 'تطبیق انجام شد', 'گزارش تطبیق امضاشده', 'موفق')
        self.assertTrue(self.s.close_finding(1, finding, 'بازبین کیفیت', 'شواهد و آزمون پیگیری بررسی شد'))
        self.assertEqual(self.s.list_findings(1)[0]['status'], 'رفع‌شده')
        self.assertEqual(self.s.list_findings(2), [])

    def test_history_is_append_only_and_legacy_findings_remain_general(self):
        control = self.s.create_control(1, 'کنترل ثبت سفارش')
        finding = self.s.create_control_finding(1, control, 'ضعف کنترل', 'شرط', 'معیار')
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO findings(project_id,title) VALUES(1,'یافته قدیمی')")
            self.assertEqual(c.execute("SELECT finding_type FROM findings WHERE title='یافته قدیمی'").fetchone()[0], 'عمومی')
            with self.assertRaises(sqlite3.IntegrityError):
                c.execute("UPDATE internal_control_history SET detail='تغییر' WHERE entity_id=?", (finding,))
            self.assertGreater(c.execute('SELECT COUNT(*) FROM internal_control_history').fetchone()[0], 0)

    def test_control_archive_and_restore_preserve_history(self):
        control = self.s.create_control(1, 'کنترل بایگانی‌پذیر')
        self.assertTrue(self.s.archive_control(1, control, 'کنترل جایگزین شد'))
        self.assertEqual(self.s.list_controls(1), [])
        self.assertEqual(len(self.s.list_controls(1, include_archived=True)), 1)
        with self.assertRaises(ValueError):
            self.s.create_control_finding(1, control, 'یافته', 'شرط', 'معیار')
        self.assertTrue(self.s.restore_control(1, control, 'نیاز به بررسی مجدد'))
        self.assertEqual(len(self.s.list_controls(1)), 1)
        with sqlite_connection(self.db) as c:
            events = [r[0] for r in c.execute("SELECT event_type FROM internal_control_history WHERE entity_id=? ORDER BY id", (control,))]
        self.assertEqual(events, ['CREATED', 'ARCHIVED', 'RESTORED'])

    def test_migration_is_idempotent(self):
        ensure_schema(self.db)
        ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            names = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({'internal_controls','control_tests','corrective_actions','internal_control_history'} <= names)


if __name__ == '__main__': unittest.main()
