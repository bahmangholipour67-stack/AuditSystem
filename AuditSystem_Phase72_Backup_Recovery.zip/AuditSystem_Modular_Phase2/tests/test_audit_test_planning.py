import unittest

from services.audit_test_planning import AuditTestPlanningService


class AuditTestPlanningServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = AuditTestPlanningService()

    def test_builds_complete_execution_plan_for_catalog_template(self):
        plan = self.service.build_execution_plan("cash-bank-confirmation")
        self.assertEqual(plan["template"]["id"], "cash-bank-confirmation")
        self.assertTrue(plan["procedure_steps"])
        self.assertTrue(plan["evidence_checklist"])
        self.assertTrue(plan["assertion_focus"])
        self.assertEqual(plan["risk_level"], "تعیین‌نشده")
        self.assertTrue(plan["completion_checks"])
        self.assertTrue(plan["escalation_triggers"])

    def test_risk_score_maps_to_three_levels(self):
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=5)["risk_level"], "پایین")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=12)["risk_level"], "متوسط")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=20)["risk_level"], "بالا")

    def test_risk_score_boundaries(self):
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=1)["risk_level"], "پایین")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=8)["risk_level"], "پایین")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=9)["risk_level"], "متوسط")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=15)["risk_level"], "متوسط")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=16)["risk_level"], "بالا")
        self.assertEqual(self.service.build_execution_plan("cash-count", risk_score=25)["risk_level"], "بالا")

    def test_rejects_invalid_risk_scores(self):
        for value in (0, 26, -1, 1.5, "abc", True):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    self.service.build_execution_plan("cash-count", risk_score=value)

    def test_unknown_template_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "کتابخانه"):
            self.service.build_execution_plan("not-real")

    def test_control_template_has_control_specific_checks(self):
        plan = self.service.build_execution_plan("control-purchase-approval")
        self.assertTrue(any("کنترل" in item for item in plan["type_specific_checks"]))

    def test_substantive_template_has_misstatement_checks(self):
        plan = self.service.build_execution_plan("revenue-vouching")
        self.assertTrue(any("تحریف" in item for item in plan["type_specific_checks"]))

    def test_analytical_template_has_expectation_checks(self):
        plan = self.service.build_execution_plan("analytical-gross-margin")
        self.assertTrue(any("انتظار مستقل" in item for item in plan["type_specific_checks"]))

    def test_plan_does_not_mutate_catalog_template(self):
        plan = self.service.build_execution_plan("cash-bank-confirmation")
        plan["template"]["assertions"].append("دستکاری")
        fresh = self.service.build_execution_plan("cash-bank-confirmation")
        self.assertNotIn("دستکاری", fresh["template"]["assertions"])

    def test_every_catalog_template_produces_a_valid_plan(self):
        from services.audit_test_catalog import list_templates
        for template in list_templates():
            with self.subTest(template=template["id"]):
                plan = self.service.build_execution_plan(template["id"], risk_score=17)
                self.assertEqual(plan["template"]["test_type"], template["test_type"])
                self.assertEqual(plan["risk_level"], "بالا")
                self.assertGreaterEqual(len(plan["procedure_steps"]), 1)


if __name__ == "__main__":
    unittest.main()
