import sqlite3
import tempfile
import unittest
from pathlib import Path

from database.connection import connect, open_connection, open_readonly_connection
from database.health import inspect_database


class DatabaseConnectionReliabilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Path(self.temp.name) / "reliability.sqlite"

    def tearDown(self):
        self.temp.cleanup()

    def test_shared_connection_sets_busy_timeout(self):
        conn = open_connection(self.db)
        try:
            self.assertEqual(conn.execute("PRAGMA busy_timeout").fetchone()[0], 15000)
        finally:
            conn.close()

    def test_shared_connection_enables_foreign_keys(self):
        conn = open_connection(self.db)
        try:
            self.assertEqual(conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
        finally:
            conn.close()

    def test_context_manager_commits_on_success(self):
        with connect(self.db) as conn:
            conn.execute("CREATE TABLE sample (value TEXT)")
            conn.execute("INSERT INTO sample VALUES ('saved')")
        check = sqlite3.connect(self.db)
        try:
            self.assertEqual(check.execute("SELECT value FROM sample").fetchone()[0], "saved")
        finally:
            check.close()

    def test_context_manager_rolls_back_on_error(self):
        setup = sqlite3.connect(self.db)
        try:
            setup.execute("CREATE TABLE sample (value TEXT)")
            setup.commit()
        finally:
            setup.close()
        with self.assertRaises(RuntimeError):
            with connect(self.db) as conn:
                conn.execute("INSERT INTO sample VALUES ('discarded')")
                raise RuntimeError("forced failure")
        check = sqlite3.connect(self.db)
        try:
            self.assertEqual(check.execute("SELECT COUNT(*) FROM sample").fetchone()[0], 0)
        finally:
            check.close()

    def test_context_manager_closes_connection(self):
        holder = {}
        with connect(self.db) as conn:
            holder['conn'] = conn
        with self.assertRaises(sqlite3.ProgrammingError):
            holder['conn'].execute("SELECT 1")

    def test_readonly_connection_rejects_writes(self):
        with connect(self.db) as conn:
            conn.execute("CREATE TABLE sample (id INTEGER PRIMARY KEY)")
        conn = open_readonly_connection(self.db)
        try:
            with self.assertRaises(sqlite3.OperationalError):
                conn.execute("INSERT INTO sample VALUES (1)")
        finally:
            conn.close()

    def test_health_check_does_not_create_missing_database(self):
        missing = Path(self.temp.name) / "missing.sqlite"
        with self.assertRaises(FileNotFoundError):
            inspect_database(missing)
        self.assertFalse(missing.exists())

    def test_health_check_is_read_only_and_reports_integrity(self):
        with connect(self.db) as conn:
            conn.execute("CREATE TABLE sample (id INTEGER PRIMARY KEY)")
            conn.execute("INSERT INTO sample VALUES (1)")
        result = inspect_database(self.db)
        self.assertTrue(result['ok'])
        self.assertEqual(result['integrity_check'], ['ok'])
        self.assertEqual(result['foreign_key_issues'], [])
        self.assertGreater(result['database_size_bytes'], 0)


if __name__ == '__main__':
    unittest.main()
