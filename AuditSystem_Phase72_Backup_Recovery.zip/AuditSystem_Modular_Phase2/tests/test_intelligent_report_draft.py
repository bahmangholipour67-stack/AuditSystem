import tempfile
import sqlite3
from db_test_utils import sqlite_connection
import unittest
from pathlib import Path
from database.migrations import ensure_schema
from reporting.intelligent_report_draft import IntelligentReportDraftService


class IntelligentReportDraftTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/"db.sqlite"; ensure_schema(self.db)
        with sqlite_connection(self.db) as c:
            c.execute("INSERT INTO projects(id,name,period,audit_type,manager,status) VALUES(1,?,?,?,?,?)",("نمونه", "1405", "مستقل", "مدیر", "جاری"))
            c.execute("INSERT INTO risks(id,project_id,title,score) VALUES(1,1,'ریسک نقدینگی',20)")
            c.execute("INSERT INTO findings(id,project_id,title,severity,status,owner) VALUES(1,1,'ضعف کنترل', 'زیاد','باز','مسئول مالی')")
    def tearDown(self): self.tmp.cleanup()
    def test_generates_draft_and_highlights_open_finding(self):
        draft=IntelligentReportDraftService(self.db).build(1)
        self.assertTrue(draft['draft_only'])
        self.assertIn('ریسک نقدینگی', '\n'.join(draft['sections']['ریسک‌های برجسته']))
        self.assertIn('ضعف کنترل', '\n'.join(draft['sections']['یافته‌های باز']))
        self.assertTrue(draft['limitations'])
    def test_empty_data_does_not_claim_absence(self):
        with sqlite_connection(self.db) as c: c.execute('DELETE FROM findings WHERE project_id=1')
        draft=IntelligentReportDraftService(self.db).build(1)
        self.assertIn('به معنی نبود یافته نیست', '\n'.join(draft['sections']['موارد نیازمند تکمیل قبل از صدور']))
if __name__=='__main__': unittest.main()

class IntelligentDraftOfficialExportTests(unittest.TestCase):
    def test_export_uses_official_phase65_template(self):
        import zipfile
        from reporting.intelligent_report_draft import export_draft_docx
        draft = {
            "project_id": 9, "project": {"name": "[DEMO] پرونده نمونه"},
            "generated_at": "1405/08/01", "draft_only": True,
            "sections": {"یافته‌های باز": ["مغایرت آزمایشی"]},
            "limitations": ["نیازمند بازبینی حرفه‌ای"],
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "official_draft.docx"
            export_draft_docx(draft, path, organization_name="مؤسسه نمونه", report_number="D-001")
            self.assertTrue(path.exists())
            with zipfile.ZipFile(path) as archive:
                self.assertIsNone(archive.testzip())
                xml = archive.read("word/document.xml").decode("utf-8")
                self.assertIn("گزارش رسمی حسابرسی", xml)
                self.assertIn("مغایرت آزمایشی", xml)
                self.assertIn("D-001", xml)
                self.assertIn("تأیید و امضا", xml)
