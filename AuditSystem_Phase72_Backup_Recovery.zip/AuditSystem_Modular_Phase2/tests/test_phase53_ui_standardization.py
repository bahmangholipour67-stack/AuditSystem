from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_financial_enterprise_styles_cover_common_controls_and_forms():
    source = (ROOT / "legacy" / "audit_app.py").read_text(encoding="utf-8")
    for token in (
        'style.configure("Secondary.TButton"',
        'style.configure("Danger.TButton"',
        'style.configure("TLabelframe"',
        'style.configure("FormHint.TLabel"',
        'style.configure("FormRequired.TLabel"',
        'style.configure("Treeview"',
        'style.configure("TScrollbar"',
    ):
        assert token in source


def test_dialog_styling_is_presentation_only_and_shared():
    source = (ROOT / "legacy" / "audit_app.py").read_text(encoding="utf-8")
    assert "def _style_dialog(self, window):" in source
    assert 'window.configure(background=PALETTE["ivory"])' in source
    assert "does not change modality" in source

    dialog_modules = (
        "project_view.py", "workpaper_view.py", "coso_framework_view.py",
        "approval_center_view.py", "audit_test_view.py", "finding_view.py", "risk_view.py",
    )
    for filename in dialog_modules:
        text = (ROOT / "ui" / "views" / filename).read_text(encoding="utf-8")
        assert "self._style_dialog(" in text, filename


def test_unified_navigation_remains_structural_after_visual_refinement():
    source = (ROOT / "legacy" / "audit_app.py").read_text(encoding="utf-8")
    assert "ttk.Notebook(" not in source
    assert "self.workspace_host = ttk.Frame(workspace_area)" in source
    assert "frame.tkraise()" in source
