import unittest
from services.number_utils import parse_amount,safe_csv_text
from services.benford_service import analyze
from services.sampling_service import select_sample
from services.trial_balance_service import add_flags

class ServiceTests(unittest.TestCase):
 def test_persian_amount(self): self.assertEqual(parse_amount('۱۲۳٬۴۵۶٫۷'),123456.7)
 def test_parentheses_negative(self): self.assertEqual(parse_amount('(250)'),-250)
 def test_csv_formula_guard(self): self.assertEqual(safe_csv_text('=1+1'),"'=1+1")
 def test_sample_reproducible(self): self.assertEqual(select_sample(100,10,seed=42),select_sample(100,10,seed=42))
 def test_benford_minimum(self):
  with self.assertRaises(ValueError): analyze([1,2,3])
 def test_trial_balance_flags(self):
  rows=[{'code':'1','name':'a','debit':-1,'credit':0,'net':-1,'flags':''},{'code':'1','name':'b','debit':1,'credit':2,'net':-1,'flags':''}]
  add_flags(rows); self.assertIn('بدهکار منفی',rows[0]['flags']); self.assertIn('کد تکراری',rows[0]['flags'])
if __name__=='__main__': unittest.main()
