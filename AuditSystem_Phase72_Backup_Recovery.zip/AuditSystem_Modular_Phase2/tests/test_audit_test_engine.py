import unittest

from services.audit_test_engine import AuditTestEngine


class TestAuditTestEngine(unittest.TestCase):
    def setUp(self):
        self.engine = AuditTestEngine()

    def test_random_selection_is_reproducible_and_unique(self):
        population = list(range(1, 101))
        first = self.engine.select_random(population, 12, seed=123)
        second = self.engine.select_random(population, 12, seed=123)
        self.assertEqual(first, second)
        self.assertEqual(len(first["selected"]), 12)
        self.assertEqual(len(set(first["selected"])), 12)

    def test_selection_supports_dictionary_population_records(self):
        population = [{"id": 1, "amount": 100}, {"id": 2, "amount": 200}, {"id": 3, "amount": 300}]
        result = self.engine.select_random(population, 2, seed=5)
        self.assertEqual(len(result["selected"]), 2)
        self.assertTrue(all(isinstance(item, dict) for item in result["selected"]))

    def test_systematic_selection_returns_expected_population_positions(self):
        population = list("ABCDEFGHIJ")
        result = self.engine.select_systematic(population, 4, seed=1, start=0)
        self.assertEqual(result["positions"], [1, 3, 6, 8])
        self.assertEqual(result["selected"], ["A", "C", "F", "H"])

    def test_stratified_allocation_is_proportional_and_complete(self):
        strata = {"A": list(range(1, 51)), "B": list(range(51, 81)), "C": list(range(81, 101))}
        result = self.engine.select_stratified(strata, 20, seed=10)
        self.assertEqual(result["allocation"], {"A": 10, "B": 6, "C": 4})
        self.assertEqual(result["selected_total"], 20)
        self.assertEqual(len(set(x for values in result["selected"].values() for x in values)), 20)

    def test_control_test_calculates_observed_deviation_rate(self):
        result = self.engine.evaluate_control_test(
            [{"deviation": False}, {"deviation": True}, {"deviation": False}],
            tolerable_deviation_rate=20,
        )
        self.assertEqual(result["observed_deviation_rate_percent"], 33.3333)
        self.assertTrue(result["assessment"].startswith("نرخ انحراف مشاهده‌شده بیش از"))
        self.assertEqual(len(result["limitations"]), 3)

    def test_control_test_requires_completion_by_default(self):
        result = self.engine.evaluate_control_test(
            [{"deviation": False}, {"deviation": None}], 100
        )
        self.assertEqual(result["assessment"], "نیازمند تکمیل رسیدگی")
        self.assertFalse(result["is_complete"])

    def test_substantive_test_sums_identified_misstatements_without_projection(self):
        result = self.engine.evaluate_substantive_test(
            [{"misstatement": 120}, {"misstatement": 80}, {"misstatement": 0}],
            performance_materiality=150,
        )
        self.assertEqual(result["identified_misstatement"], 200)
        self.assertEqual(result["items_with_misstatement"], 2)
        self.assertIn("بیش از اهمیت عملکردی", result["assessment"])
        self.assertTrue(any("تعمیم" in item for item in result["limitations"]))

    def test_substantive_test_blocks_incomplete_results(self):
        result = self.engine.evaluate_substantive_test(
            [{"misstatement": 10}, {"misstatement": None}], 100
        )
        self.assertEqual(result["assessment"], "نیازمند تکمیل رسیدگی")

    def test_analytical_test_detects_amount_threshold_breach(self):
        result = self.engine.evaluate_analytical_procedure(
            1250, 1000, tolerable_difference_amount=200
        )
        self.assertEqual(result["variance"], 250)
        self.assertTrue(result["threshold_exceeded"])

    def test_analytical_test_detects_percentage_threshold_breach(self):
        result = self.engine.evaluate_analytical_procedure(
            1100, 1000, tolerable_difference_percent=9
        )
        self.assertEqual(result["variance_percent"], 10)
        self.assertTrue(result["threshold_exceeded"])

    def test_analytical_test_rejects_ambiguous_thresholds(self):
        with self.assertRaises(ValueError):
            self.engine.evaluate_analytical_procedure(10, 9)
        with self.assertRaises(ValueError):
            self.engine.evaluate_analytical_procedure(
                10, 9, tolerable_difference_amount=1, tolerable_difference_percent=10
            )

    def test_seed_must_fit_sqlite_integer_range(self):
        with self.assertRaises(ValueError):
            self.engine.select_random([1, 2, 3], 1, seed=2**63)
        with self.assertRaises(ValueError):
            self.engine.select_random([1, 2, 3], 1, seed=-1)

    def test_invalid_population_and_sample_size_are_rejected(self):
        with self.assertRaises(ValueError):
            self.engine.select_random([], 1, seed=1)
        with self.assertRaises(ValueError):
            self.engine.select_systematic([1, 2], 3, seed=1)
        with self.assertRaises(ValueError):
            self.engine.select_stratified({"A": [1, 2], "B": [2, 3]}, 2, seed=1)


if __name__ == "__main__":
    unittest.main()
