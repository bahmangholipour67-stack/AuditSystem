import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from services.approval_workflow_service import ApprovalWorkflowService


class TestApprovalWorkflowService(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'approval.db'
        conn = sqlite3.connect(self.path)
        conn.executescript('''
            CREATE TABLE team_members(id INTEGER PRIMARY KEY, project_id INTEGER, full_name TEXT, role TEXT, is_active INTEGER);
            CREATE TABLE workpapers(id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, procedure TEXT, result TEXT, status TEXT, risk_id INTEGER);
            CREATE TABLE audit_tests(id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, procedure TEXT, conclusion TEXT, status TEXT, program_id INTEGER, workpaper_id INTEGER);
            CREATE TABLE approval_requests(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL, snapshot_hash TEXT NOT NULL, submitted_by_member_id INTEGER NOT NULL, supervisor_member_id INTEGER NOT NULL, manager_member_id INTEGER NOT NULL, quality_member_id INTEGER NOT NULL, current_stage TEXT NOT NULL, status TEXT NOT NULL, submitted_at TEXT DEFAULT CURRENT_TIMESTAMP, completed_at TEXT, archived_at TEXT, UNIQUE(project_id,entity_type,entity_id));
            CREATE TABLE approval_history(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL, request_id INTEGER NOT NULL, event_type TEXT NOT NULL, stage TEXT NOT NULL, actor_member_id INTEGER NOT NULL, actor_role TEXT NOT NULL, comment TEXT DEFAULT '', snapshot_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TRIGGER approval_history_no_update BEFORE UPDATE ON approval_history BEGIN SELECT RAISE(ABORT, 'approval history is append-only'); END;
            CREATE TRIGGER approval_history_no_delete BEFORE DELETE ON approval_history BEGIN SELECT RAISE(ABORT, 'approval history is append-only'); END;
        ''')
        conn.executemany('INSERT INTO team_members VALUES(?,?,?,?,?)', [
            (1,1,'حسابرس','حسابرس',1),(2,1,'سرپرست','سرپرست حسابرسی',1),
            (3,1,'مدیر','مدیر حسابرسی',1),(4,1,'کنترل کیفیت','مسئول کنترل کیفیت',1),
            (5,1,'عضو نامعتبر','حسابرس',1),(6,2,'سرپرست دیگر','سرپرست حسابرسی',1)])
        conn.execute("INSERT INTO workpapers VALUES(10,1,'کاربرگ','روش','نتیجه','پیش‌نویس',NULL)")
        conn.execute("INSERT INTO workpapers VALUES(20,2,'کاربرگ دیگر','روش','نتیجه','پیش‌نویس',NULL)")
        conn.commit(); conn.close()
        self.patcher = patch('services.approval_workflow_service.connect', self._connect)
        self.patcher.start()
        self.service = ApprovalWorkflowService()

    def tearDown(self):
        self.patcher.stop(); self.tmp.cleanup()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.path)
        try:
            yield conn; conn.commit()
        except Exception:
            conn.rollback(); raise
        finally:
            conn.close()

    def _submit(self):
        return self.service.submit(1, 'workpaper', 10, 1, 2, 3, 4)

    def test_inbox_only_returns_items_for_current_stage_assignee(self):
        rid = self._submit()
        supervisor_items = self.service.inbox(1, 2)
        self.assertEqual([item[0] for item in supervisor_items], [rid])
        self.assertEqual(supervisor_items[0][7], "کاربرگ")
        self.assertEqual(self.service.inbox(1, 3), [])
        self.service.decide(1, rid, 2, "approve", "بررسی شد")
        self.assertEqual(self.service.inbox(1, 2), [])
        self.assertEqual([item[0] for item in self.service.inbox(1, 3)], [rid])

    def test_inbox_is_project_scoped_and_requires_active_member(self):
        rid = self._submit()
        with self.assertRaises(ValueError):
            self.service.inbox(2, 2)
        with self.assertRaises(ValueError):
            self.service.inbox(1, 99)
        self.assertEqual([item[0] for item in self.service.inbox(1, 2)], [rid])

    def test_three_stage_approval_flow(self):
        rid = self._submit()
        self.service.decide(1, rid, 2, 'approve', 'بررسی سرپرست')
        self.service.decide(1, rid, 3, 'approve', 'تأیید مدیر')
        self.service.decide(1, rid, 4, 'approve', 'کنترل کیفیت')
        self.assertEqual(self.service.for_project(1)[0][3], 'approved')
        self.assertEqual(len(self.service.history(1, rid)), 4)

    def test_submitter_cannot_be_reviewer_or_self_approve(self):
        with self.assertRaises(ValueError): self.service.submit(1,'workpaper',10,1,1,3,4)
        rid=self._submit()
        with self.assertRaises(ValueError): self.service.decide(1,rid,1,'approve')

    def test_wrong_role_and_wrong_assignee_are_blocked(self):
        rid=self._submit()
        with self.assertRaises(ValueError): self.service.decide(1,rid,5,'approve')
        with self.assertRaises(ValueError): self.service.decide(1,rid,6,'approve')

    def test_cross_project_isolation(self):
        rid=self._submit()
        with self.assertRaises(ValueError): self.service.decide(2,rid,2,'approve')
        self.assertEqual(self.service.for_project(2), [])

    def test_invalid_transition_and_return_requires_comment(self):
        rid=self._submit()
        with self.assertRaises(ValueError): self.service.decide(1,rid,2,'approve') if False else self.service.decide(1,rid,3,'approve')
        with self.assertRaises(ValueError): self.service.decide(1,rid,2,'return','')
        self.service.decide(1,rid,2,'return','اصلاح شود')
        with self.assertRaises(ValueError): self.service.decide(1,rid,2,'approve')

    def test_resubmit_preserves_history_and_refreshes_version(self):
        rid=self._submit(); self.service.decide(1,rid,2,'return','اصلاح متن')
        with self._connect() as conn: conn.execute("UPDATE workpapers SET result='نتیجه اصلاح‌شده' WHERE id=10 AND project_id=1")
        self.service.resubmit(1,rid,1)
        self.assertEqual(len(self.service.history(1,rid)),3)
        self.service.decide(1,rid,2,'approve')

    def test_old_version_cannot_be_approved(self):
        rid=self._submit()
        with self._connect() as conn: conn.execute("UPDATE workpapers SET result='تغییر خارج از گردش' WHERE id=10")
        with self.assertRaises(ValueError): self.service.decide(1,rid,2,'approve')

    def test_history_is_immutable(self):
        rid=self._submit()
        with self._connect() as conn:
            with self.assertRaises(sqlite3.IntegrityError): conn.execute("UPDATE approval_history SET comment='دستکاری' WHERE request_id=?",(rid,))
            with self.assertRaises(sqlite3.IntegrityError): conn.execute("DELETE FROM approval_history WHERE request_id=?",(rid,))

    def test_archive_filter_does_not_leak_archived_request(self):
        rid=self._submit()
        with self._connect() as conn: conn.execute("UPDATE approval_requests SET archived_at=CURRENT_TIMESTAMP WHERE id=?",(rid,))
        self.assertEqual(self.service.for_project(1), [])


if __name__ == '__main__': unittest.main()
