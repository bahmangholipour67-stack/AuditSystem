import os
import tempfile
import unittest
from unittest.mock import patch

from database.migrations import ensure_schema
from database.connection import connect
from repositories.audit_test_repository import AuditTestRepository
from repositories.audit_template_repository import AuditTemplateRepository
from services.audit_template_service import AuditTemplateService
from services.audit_test_catalog import get_template


class AuditTemplateEditingTests(unittest.TestCase):
    def setUp(self):
        handle, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(handle)
        ensure_schema(self.db_path)
        self.service = AuditTemplateService(AuditTemplateRepository(self.db_path))
        self.base = get_template("cash-bank-confirmation")

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def edited(self, title):
        result = dict(self.base)
        result["title"] = title
        result["procedure"] = "روش اجرای ویرایش‌شده"
        return result

    def test_library_edit_is_used_by_all_projects(self):
        self.service.save_to_library(self.base["id"], self.edited("عنوان کتابخانه"))
        self.assertEqual(self.service.get_template(self.base["id"], 10)["title"], "عنوان کتابخانه")
        self.assertEqual(self.service.get_template(self.base["id"], 20)["title"], "عنوان کتابخانه")

    def test_project_edit_does_not_change_library_or_other_projects(self):
        self.service.save_to_library(self.base["id"], self.edited("نسخه اصلی"))
        self.service.save_to_project(10, self.base["id"], self.edited("نسخه پرونده ده"))
        self.assertEqual(self.service.get_template(self.base["id"], 10)["title"], "نسخه پرونده ده")
        self.assertEqual(self.service.get_template(self.base["id"], 20)["title"], "نسخه اصلی")
        self.assertEqual(self.service.get_template(self.base["id"])["title"], "نسخه اصلی")

    def test_project_override_can_be_updated_without_mutating_base_catalog(self):
        self.service.save_to_project(10, self.base["id"], self.edited("نسخه اول"))
        self.service.save_to_project(10, self.base["id"], self.edited("نسخه دوم"))
        self.assertEqual(self.service.get_template(self.base["id"], 10)["title"], "نسخه دوم")
        self.assertEqual(get_template(self.base["id"])["title"], self.base["title"])

    def test_history_records_global_and_project_edits(self):
        self.service.save_to_library(self.base["id"], self.edited("اصلی"))
        self.service.save_to_project(10, self.base["id"], self.edited("اختصاصی"))
        history = self.service.history(self.base["id"], 10)
        self.assertEqual(len(history), 2)
        self.assertEqual({row["scope"] for row in history}, {"library", "project"})

    def test_previous_version_can_be_restored_and_restore_is_logged(self):
        self.service.save_to_library(self.base["id"], self.edited("نسخه اول"))
        first = self.service.history(self.base["id"])[0]
        self.service.save_to_library(self.base["id"], self.edited("نسخه دوم"))
        self.service.restore_history(first["id"])
        self.assertEqual(self.service.get_template(self.base["id"])["title"], "نسخه اول")
        self.assertEqual(len(self.service.history(self.base["id"])), 3)

    def test_invalid_template_is_rejected(self):
        bad = self.edited("")
        with self.assertRaises(ValueError):
            self.service.save_to_library(self.base["id"], bad)

    def test_applied_template_snapshot_is_saved_with_created_audit_test(self):
        with connect(self.db_path) as conn:
            project_id = conn.execute(
                "INSERT INTO projects(name, period) VALUES(?, ?)", ("شرکت آزمایشی", "1405")
            ).lastrowid
            program_id = conn.execute(
                "INSERT INTO audit_programs(project_id, title) VALUES(?, ?)", (project_id, "برنامه آزمون")
            ).lastrowid
        import repositories.audit_test_repository as repository_module
        with patch.object(repository_module, "connect", lambda: connect(self.db_path)):
            test_id = AuditTestRepository().create_test(
                project_id, program_id, "آزمون سفارشی", test_type="ماهوی",
                procedure="روش سفارشی", population_description="جامعه سفارشی",
                population_size=10, sample_size=3, template_id=self.base["id"],
                template_objective="هدف سفارشی", template_assertions='["وجود"]',
                expected_evidence="شواهد سفارشی",
            )
        with connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT template_id,template_objective,template_assertions,expected_evidence,procedure "
                "FROM audit_tests WHERE id=?", (test_id,)
            ).fetchone()
        self.assertEqual(tuple(row), (self.base["id"], "هدف سفارشی", '["وجود"]', "شواهد سفارشی", "روش سفارشی"))

    def test_project_save_requires_project_id(self):
        with self.assertRaises(ValueError):
            self.service.save_to_project(None, self.base["id"], self.edited("عنوان"))


if __name__ == "__main__":
    unittest.main()
