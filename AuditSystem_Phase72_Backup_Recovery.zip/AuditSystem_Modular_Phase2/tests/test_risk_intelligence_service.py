from services.risk_intelligence_service import RiskIntelligenceService as Service


def test_risk_matrix_classification_boundaries():
    assert Service.risk_level(1) == "کم"
    assert Service.risk_level(4) == "کم"
    assert Service.risk_level(5) == "متوسط"
    assert Service.risk_level(9) == "متوسط"
    assert Service.risk_level(10) == "زیاد"
    assert Service.risk_level(15) == "زیاد"
    assert Service.risk_level(16) == "بحرانی"
    assert Service.risk_level(25) == "بحرانی"


def test_invalid_risk_scores_raise_value_error():
    for score in (0, 26, "abc", None):
        try:
            Service.risk_level(score)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected invalid score to raise: {score!r}")


def test_risks_are_sorted_and_invalid_rows_ignored():
    rows = Service.classify_risks([("کم", 3), ("بحرانی", 22), ("نامعتبر", "x")])
    assert rows == [
        {"title": "بحرانی", "score": 22, "level": "بحرانی"},
        {"title": "کم", "score": 3, "level": "کم"},
    ]


def test_alerts_prioritize_critical_open_findings_and_missing_evidence():
    alerts = Service.build_alerts(
        risks=[("ریسک بحرانی", 20), ("ریسک زیاد", 12), ("ریسک کم", 3)],
        findings=[(1, "یافته اساسی باز", "اساسی", "باز"), (2, "یافته بسته", "بااهمیت", "مختومه")],
        findings_without_evidence=[(1, "یافته فاقد سند")],
        pending_tests=[(7, "آزمون منتظر", "آماده بررسی سرپرست")],
        unlinked_workpapers=[(9, "کاربرگ بی‌ارتباط")],
    )
    assert alerts[0]["priority"] == "P1"
    assert alerts[0]["category"] in {"یافته", "شواهد", "ریسک"}
    assert any(a["subject"] == "یافته بسته" for a in alerts) is False
    assert any(a["category"] == "بازبینی" and a["priority"] == "P2" for a in alerts)
    assert any(a["category"] == "کاربرگ" and a["priority"] == "P3" for a in alerts)


def test_empty_alerts_returns_empty_list():
    assert Service.build_alerts() == []
