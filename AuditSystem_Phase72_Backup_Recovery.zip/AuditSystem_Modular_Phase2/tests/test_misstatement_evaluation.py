import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from repositories.misstatement_repository import MisstatementRepository
from services.integrated_report_service import IntegratedReportService


class MisstatementEvaluationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Path(self.temp.name) / "audit.db"
        ensure_schema(self.db)
        with sqlite_connection(self.db) as conn:
            conn.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده الف','1405')")
            conn.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده ب','1404')")
            conn.execute("INSERT INTO workpapers(id,project_id,title) VALUES(10,1,'کاربرگ فروش')")
            conn.execute("INSERT INTO workpapers(id,project_id,title) VALUES(20,2,'کاربرگ دیگر')")
            conn.execute("INSERT INTO findings(id,project_id,title) VALUES(30,1,'یافته فروش')")
            conn.execute("INSERT INTO audit_programs(id,project_id,title) VALUES(40,1,'برنامه فروش')")
            conn.execute("INSERT INTO audit_tests(id,project_id,program_id,title) VALUES(50,1,40,'آزمون فروش')")
        self.repo = MisstatementRepository(self.db)

    def tearDown(self):
        self.temp.cleanup()

    def test_materiality_validation_and_upsert(self):
        saved = self.repo.set_materiality(1, 1000, 700, 50, "سود قبل از مالیات")
        self.assertEqual(saved["overall_materiality"], 1000)
        self.repo.set_materiality(1, 1200, 800, 60, "درآمد")
        self.assertEqual(self.repo.get_materiality(1)["overall_materiality"], 1200)
        with self.assertRaises(ValueError): self.repo.set_materiality(1, 500, 600, 10)
        with self.assertRaises(ValueError): self.repo.set_materiality(1, 500, 400, 450)

    def test_create_validate_types_and_project_links(self):
        item = self.repo.create(1, "کم‌نمایی فروش", "واقعی", 300, "فروش", "شرح", "آزمون", workpaper_id=10, finding_id=30, audit_test_id=50)
        self.assertEqual(len(self.repo.list_for_project(1)), 1)
        self.assertEqual(self.repo.list_for_project(2), [])
        with self.assertRaises(ValueError): self.repo.create(1, "تحریف", "نامعتبر", 10)
        with self.assertRaises(ValueError): self.repo.create(1, "تحریف", "واقعی", 10, workpaper_id=20)
        with self.assertRaises(ValueError): self.repo.create(1, "تحریف", "واقعی", -1)
        self.assertGreater(item, 0)

    def test_evaluation_gross_total_and_corrected_exclusion(self):
        self.repo.set_materiality(1, 1000, 700, 50)
        self.repo.create(1, "تحریف واقعی", "واقعی", 600)
        self.repo.create(1, "تحریف قضاوتی", "قضاوتی", 500)
        corrected = self.repo.create(1, "اصلاح‌شده", "برآوردی", 900, status="اصلاح‌شده")
        self.repo.create(1, "مورد اختلاف", "برآوردی", 100, status="مورد اختلاف")
        result = self.repo.evaluate(1)
        self.assertEqual(result["uncorrected_total"], 1200)
        self.assertEqual(result["corrected_count"], 1)
        self.assertTrue(result["overall_materiality_exceeded"])
        self.assertEqual(result["uncorrected_by_type"]["واقعی"], 600)
        self.assertEqual(result["uncorrected_by_type"]["قضاوتی"], 500)
        self.assertEqual(result["uncorrected_by_type"]["برآوردی"], 100)

    def test_status_history_and_archive_preserve_record(self):
        item = self.repo.create(1, "تحریف", "واقعی", 100)
        self.assertTrue(self.repo.update_status(1, item, "اصلاح‌شده", note="ثبت سند اصلاحی"))
        self.assertFalse(self.repo.update_status(1, item, "اصلاح‌شده"))
        self.repo.archive(1, item, "ثبت تکراری")
        self.assertEqual(self.repo.list_for_project(1), [])
        self.assertEqual(len(self.repo.list_for_project(1, include_archived=True)), 1)
        with sqlite_connection(self.db) as conn:
            history = conn.execute("SELECT event_type FROM misstatement_history WHERE misstatement_id=? ORDER BY id", (item,)).fetchall()
        self.assertEqual([r[0] for r in history], ["CREATED", "STATUS_CHANGED", "ARCHIVED"])

    def test_integrated_report_contains_misstatements(self):
        self.repo.create(1, "تحریف", "واقعی", 250)
        report = IntegratedReportService(self.db).build(1)
        self.assertEqual(report["summary"]["misstatement_count"], 1)
        self.assertEqual(report["summary"]["uncorrected_misstatement_total"], 250)
        self.assertEqual(len(report["sections"]["audit_misstatements"]), 1)


if __name__ == "__main__":
    unittest.main()
