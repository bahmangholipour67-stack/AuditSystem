import sqlite3
from pathlib import Path

from services.task_center_service import TaskCenterService


def _database():
    conn = sqlite3.connect(":memory:")
    conn.executescript("""
        CREATE TABLE corrective_actions (
            id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, owner TEXT,
            due_date TEXT, status TEXT);
        CREATE TABLE document_requests (
            id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT,
            requested_from TEXT, due_date TEXT, status TEXT);
        CREATE TABLE approval_requests (
            id INTEGER PRIMARY KEY, project_id INTEGER, entity_type TEXT,
            entity_id INTEGER, status TEXT, current_stage TEXT);
        CREATE TABLE workpapers (
            id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT, status TEXT,
            assigned_member_id INTEGER);
        INSERT INTO corrective_actions VALUES (1, 10, 'اصلاح کنترل خرید', 'علی', '2026-11-01', 'باز');
        INSERT INTO corrective_actions VALUES (2, 20, 'اقدام پرونده دیگر', 'رضا', '2026-11-01', 'باز');
        INSERT INTO document_requests VALUES (3, 10, 'دریافت قرارداد', 'واحد حقوقی', '2026-11-30', 'در انتظار');
        INSERT INTO approval_requests VALUES (4, 10, 'workpaper', 7, 'pending_supervisor', 'supervisor');
        INSERT INTO workpapers VALUES (7, 10, 'کاربرگ موجودی', 'آماده بررسی سرپرست', 5);
    """)
    return conn


def test_task_center_aggregates_existing_records_and_marks_overdue():
    conn = _database()
    try:
        result = TaskCenterService.snapshot(conn, project_id=10, today="2026-11-21")
    finally:
        conn.close()
    assert result["total"] == 4
    assert result["overdue"] == 1
    assert result["tasks"][0]["title"] == "اصلاح کنترل خرید"
    assert result["tasks"][0]["priority"] == "متأخر"
    assert {task["category"] for task in result["tasks"]} == {
        "اقدام اصلاحی", "درخواست مدرک", "تأییدیه", "کاربرگ"
    }


def test_task_center_can_scope_to_all_projects_and_is_read_only():
    conn = _database()
    try:
        before = conn.execute("SELECT COUNT(*) FROM corrective_actions").fetchone()[0]
        all_rows = TaskCenterService.snapshot(conn, today="2026-11-21")
        scoped = TaskCenterService.snapshot(conn, project_id=10, today="2026-11-21")
        after = conn.execute("SELECT COUNT(*) FROM corrective_actions").fetchone()[0]
    finally:
        conn.close()
    assert all_rows["total"] == 5
    assert scoped["total"] == 4
    assert before == after == 2


def test_dashboard_integrates_task_center_without_schema_mutations():
    root = Path(__file__).resolve().parents[1]
    view = (root / "ui" / "views" / "dashboard_view.py").read_text(encoding="utf-8")
    service = (root / "services" / "task_center_service.py").read_text(encoding="utf-8")
    assert "TaskCenterService.snapshot" in view
    assert "مرکز مدیریت کارها و پیگیری اقدامات حسابرسی" in view
    assert "CREATE TABLE" not in service
    assert "def _refresh_task_center" in view
