from pathlib import Path

from ui.views.approval_center_view import ApprovalCenterViewMixin


def test_approval_center_exposes_submit_decide_history_and_refresh():
    assert callable(ApprovalCenterViewMixin.setup_approval_center_tab)
    assert callable(ApprovalCenterViewMixin.submit_approval_request)
    assert callable(ApprovalCenterViewMixin.decide_approval)
    assert callable(ApprovalCenterViewMixin.show_approval_history)
    assert callable(ApprovalCenterViewMixin.refresh_approval_center)


def test_approval_center_is_integrated_as_tab_and_refreshed():
    source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
    assert "ApprovalCenterViewMixin" in source
    assert "self.tab_approval_center = ttk.Frame(self.workspace_host)" in source
    assert '(self.tab_approval_center, "۱۵. مرکز تأییدها")' in source
    assert "self.setup_approval_center_tab()" in source
    assert "self.refresh_approval_center()" in source


def test_approval_center_exposes_member_specific_inbox():
    assert callable(ApprovalCenterViewMixin.refresh_approval_inbox)
    assert callable(ApprovalCenterViewMixin.open_approval_inbox_item)
    source = Path("ui/views/approval_center_view.py").read_text(encoding="utf-8")
    assert "self.approval_service.inbox(project_id, member_id)" in source
    assert "کارت‌های اقدام عضو فعال" in source
