
import unittest
import tempfile
import sqlite3
from pathlib import Path

from repositories.audit_test_repository import AuditTestRepository
from services.audit_test_service import AuditTestService


class TestAuditTestService(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_audit.db"

        self.conn = sqlite3.connect(self.db_path)
        self.conn.executescript("""
        CREATE TABLE audit_programs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            audit_area TEXT,
            objective TEXT,
            risk_id INTEGER,
            workpaper_id INTEGER,
            assigned_member_id INTEGER,
            start_date TEXT,
            due_date TEXT,
            status TEXT,
            notes TEXT,
            created_at TEXT,
            updated_at TEXT
        );

        CREATE TABLE audit_tests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            program_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            test_type TEXT,
            procedure TEXT,
            population_description TEXT,
            population_size INTEGER,
            sample_size INTEGER,
            sampling_method TEXT,
            random_seed INTEGER,
            assigned_member_id INTEGER,
            status TEXT,
            conclusion TEXT,
            created_at TEXT,
            updated_at TEXT
        );

        CREATE TABLE audit_test_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            test_id INTEGER NOT NULL,
            sample_no INTEGER NOT NULL,
            population_row INTEGER NOT NULL,
            document_ref TEXT,
            description TEXT,
            amount REAL,
            misstatement_amount REAL,
            result TEXT DEFAULT 'رسیدگی‌نشده',
            exception_description TEXT,
            evidence_path TEXT,
            tested_by_member_id INTEGER,
            tested_at TEXT,
            created_at TEXT,
            UNIQUE(test_id, sample_no)
        );

        CREATE TABLE audit_test_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            test_id INTEGER NOT NULL,
            sample_id INTEGER,
            action TEXT,
            details TEXT,
            actor_member_id INTEGER,
            created_at TEXT
        );
        """)
        self.conn.close()

        class TestRepository(AuditTestRepository):
            def __init__(repo_self, db_path):
                repo_self.db_path = db_path

            def _connect(repo_self):
                return sqlite3.connect(repo_self.db_path)

        # Override repository operations to use the temporary database.
        self.repository = AuditTestRepositoryForTest(self.db_path)
        self.service = AuditTestService(self.repository)

        self.program_id = self.service.create_program(
            1, "برنامه آزمون مطالبات", audit_area="مطالبات"
        )

        self.test_id = self.service.create_test(
            1,
            self.program_id,
            "آزمون نمونه مطالبات",
            100,
            10
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_invalid_audit_test_type_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.create_test(
                1, self.program_id, "آزمون نامعتبر", 10, 2,
                test_type="نوع ناشناخته",
            )

    def test_population_validation(self):
        self.assertEqual(
            self.service.validate_population(100, 20),
            (100, 20)
        )

        with self.assertRaises(ValueError):
            self.service.validate_population(0, 5)

        with self.assertRaises(ValueError):
            self.service.validate_population(10, 20)

    def test_random_sample_generation(self):
        result = self.service.generate_samples(
            1, self.test_id, seed=12345
        )

        self.assertEqual(result["count"], 10)
        self.assertEqual(len(result["selected"]), 10)
        self.assertEqual(len(set(result["selected"])), 10)

        result2 = sorted(result["selected"])
        self.assertEqual(result2, sorted(result["selected"]))

    def test_duplicate_sample_generation_is_blocked(self):
        self.service.generate_samples(1, self.test_id, seed=123)

        with self.assertRaises(ValueError):
            self.service.generate_samples(1, self.test_id, seed=456)

    def test_systematic_sample_generation_uses_requested_method(self):
        result = self.service.generate_samples(
            1, self.test_id, seed=123, method="سیستماتیک"
        )
        self.assertEqual(result["method"], "سیستماتیک")
        self.assertEqual(result["count"], 10)
        self.assertEqual(len(result["selected"]), 10)
        self.assertEqual(len(set(result["selected"])), 10)
        saved_test = self.repository.get_test(self.test_id)
        self.assertEqual(saved_test["sampling_method"], "سیستماتیک")
        self.assertEqual(saved_test["random_seed"], 123)

    def test_unsupported_sampling_method_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.generate_samples(
                1, self.test_id, seed=123, method="روش نامعتبر"
            )

    def test_follow_up_recommendations_are_exposed_by_application_service(self):
        result = self.service.build_follow_up_recommendations(
            {"assessment": "عدم احراز معیار", "is_complete": True,
             "exception_samples": 1, "exception_amount": 250},
            risk_score=18, materiality=200,
        )
        self.assertEqual(result["risk_level"], "بالا")
        self.assertTrue(result["finding_review_recommended"])
        self.assertIn("MATERIALITY_REVIEW", {item["code"] for item in result["actions"]})

    def test_specialized_evaluators_are_exposed_by_application_service(self):
        control = self.service.evaluate_control_test(
            [{"deviation": False}, {"deviation": True}], 50
        )
        substantive = self.service.evaluate_substantive_test(
            [{"misstatement": 25}], 100
        )
        analytical = self.service.evaluate_analytical_procedure(
            105, 100, tolerable_difference_amount=10
        )
        self.assertEqual(control["deviation_samples"], 1)
        self.assertEqual(substantive["identified_misstatement"], 25)
        self.assertFalse(analytical["threshold_exceeded"])


    def test_integrated_substantive_evaluation_uses_recorded_misstatement_amounts(self):
        self.service.generate_samples(1, self.test_id, seed=321)
        samples = self.service.list_samples(self.test_id)
        self.service.record_sample_result(
            samples[0]["id"], "مغایرت",
            exception_description="اختلاف فاکتور",
            misstatement_amount=125
        )
        for sample in samples[1:]:
            self.service.record_sample_result(sample["id"], "تأیید")

        result = self.service.evaluate_test_for_conclusion(
            self.test_id, performance_materiality=100
        )
        self.assertEqual(result["identified_misstatement"], 125)
        self.assertTrue(result["assessment"].startswith("مبلغ مغایرت شناسایی‌شده بیش از"))

    def test_integrated_control_evaluation_maps_sample_results(self):
        control_test_id = self.service.create_test(
            1, self.program_id, "آزمون کنترل خرید", 10, 2, test_type="کنترلی"
        )
        self.service.generate_samples(1, control_test_id, seed=654)
        samples = self.service.list_samples(control_test_id)
        self.service.record_sample_result(samples[0]["id"], "عدم انطباق")
        self.service.record_sample_result(samples[1]["id"], "تأیید")

        result = self.service.evaluate_test_for_conclusion(
            control_test_id, tolerable_deviation_rate=25
        )
        self.assertEqual(result["deviation_samples"], 1)
        self.assertEqual(result["observed_deviation_rate_percent"], 50.0)

    def test_integrated_analytical_evaluation_uses_explicit_threshold(self):
        analytical_test_id = self.service.create_test(
            1, self.program_id, "تحلیل هزینه اداری", 1, 1, test_type="تحلیلی"
        )
        result = self.service.evaluate_test_for_conclusion(
            analytical_test_id,
            actual=1250,
            expected=1000,
            tolerable_difference_amount=200,
        )
        self.assertTrue(result["threshold_exceeded"])
        self.assertEqual(result["variance"], 250)

    def test_substantive_evaluation_does_not_treat_sample_book_value_as_misstatement(self):
        self.service.generate_samples(1, self.test_id, seed=777)
        samples = self.service.list_samples(self.test_id)
        self.service.record_sample_result(
            samples[0]["id"], "مغایرت", amount=5000,
            exception_description="مغایرت با مبلغ دفتری"
        )
        for sample in samples[1:]:
            self.service.record_sample_result(sample["id"], "تأیید")
        result = self.service.evaluate_test_for_conclusion(
            self.test_id, performance_materiality=1000
        )
        self.assertEqual(result["identified_misstatement"], 0)

    def test_progress_and_untested_samples(self):
        self.service.generate_samples(1, self.test_id, seed=100)

        samples = self.service.list_samples(self.test_id)
        self.assertEqual(len(samples), 10)

        self.service.record_sample_result(
            samples[0]["id"], "تأیید"
        )

        progress = self.service.progress(self.test_id)

        self.assertEqual(progress["total_samples"], 10)
        self.assertEqual(progress["tested_samples"], 1)
        self.assertEqual(progress["untested_samples"], 9)
        self.assertEqual(progress["completion_percent"], 10.0)

        self.assertEqual(
            len(self.service.untested_samples(self.test_id)),
            9
        )

    def test_exception_reporting(self):
        self.service.generate_samples(1, self.test_id, seed=200)

        sample = self.service.list_samples(self.test_id)[0]

        self.service.record_sample_result(
            sample["id"],
            "مغایرت",
            exception_description="اختلاف در مبلغ سند"
        )

        exceptions = self.service.exceptions(self.test_id)

        self.assertEqual(len(exceptions), 1)
        self.assertEqual(exceptions[0]["result"], "مغایرت")


class AuditTestRepositoryForTest(AuditTestRepository):
    """Repository using an isolated temporary SQLite database."""

    def __init__(self, db_path):
        self.db_path = db_path

    def _run(self, sql, params=(), fetch=None):
        conn = sqlite3.connect(self.db_path)
        try:
            cur = conn.execute(sql, params)
            if fetch == "one":
                result = cur.fetchone()
            elif fetch == "all":
                columns = [x[0] for x in cur.description]
                result = [
                    dict(zip(columns, row))
                    for row in cur.fetchall()
                ]
            else:
                result = cur.lastrowid
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def for_project(self, project_id):
        return self._run(
            "SELECT * FROM audit_programs WHERE project_id=? ORDER BY id DESC",
            (project_id,), "all"
        )

    def create_program(self, project_id, title, **kwargs):
        fields = {
            "project_id": project_id,
            "title": title,
            **kwargs
        }
        columns = list(fields)
        placeholders = ",".join("?" for _ in columns)
        return self._run(
            f"INSERT INTO audit_programs ({','.join(columns)},created_at,updated_at) "
            f"VALUES ({placeholders},CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)",
            tuple(fields[x] for x in columns)
        )

    def get_test(self, test_id):
        return self._run(
            "SELECT * FROM audit_tests WHERE id=?",
            (test_id,), "one"
        ) and self._test_dict(test_id)

    def _test_dict(self, test_id):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                "SELECT * FROM audit_tests WHERE id=?", (test_id,)
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def create_test(self, project_id, program_id, title, **kwargs):
        fields = {
            "project_id": project_id,
            "program_id": program_id,
            "title": title,
            **kwargs
        }
        columns = list(fields)
        placeholders = ",".join("?" for _ in columns)
        return self._run(
            f"INSERT INTO audit_tests ({','.join(columns)},created_at,updated_at) "
            f"VALUES ({placeholders},CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)",
            tuple(fields[x] for x in columns)
        )

    def create_samples(self, project_id, test_id, selected_rows, sampling_method=None, random_seed=None):
        conn = sqlite3.connect(self.db_path)
        try:
            test = conn.execute(
                "SELECT population_size,sample_size FROM audit_tests WHERE id=? AND project_id=?",
                (test_id, project_id)
            ).fetchone()

            if not test:
                raise ValueError("آزمون موردنظر پیدا نشد.")

            population_size, sample_size = test

            if len(selected_rows) != sample_size:
                raise ValueError("تعداد نمونه‌ها صحیح نیست.")

            if any(x < 1 or x > population_size for x in selected_rows):
                raise ValueError("شماره نمونه خارج از محدوده است.")

            existing = conn.execute(
                "SELECT COUNT(*) FROM audit_test_samples WHERE test_id=?",
                (test_id,)
            ).fetchone()[0]

            if existing:
                raise ValueError("نمونه قبلاً ثبت شده است.")

            for number, population_row in enumerate(sorted(selected_rows), 1):
                conn.execute(
                    """
                    INSERT INTO audit_test_samples (
                        project_id,test_id,sample_no,population_row,
                        result,created_at
                    )
                    VALUES (?,?,?,?, 'رسیدگی‌نشده',CURRENT_TIMESTAMP)
                    """,
                    (project_id, test_id, number, population_row)
                )

            conn.execute(
                """UPDATE audit_tests
                   SET status='در حال اجرا', sampling_method=COALESCE(?, sampling_method),
                       random_seed=? WHERE id=? AND project_id=?""",
                (sampling_method, random_seed, test_id, project_id)
            )
            conn.commit()
            return len(selected_rows)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def samples_for_test(self, test_id):
        return self._run(
            "SELECT * FROM audit_test_samples WHERE test_id=? ORDER BY sample_no",
            (test_id,), "all"
        )

    def update_sample_result(self, sample_id, result, **kwargs):
        conn = sqlite3.connect(self.db_path)
        try:
            sample = conn.execute(
                "SELECT test_id,project_id FROM audit_test_samples WHERE id=?",
                (sample_id,)
            ).fetchone()

            if not sample:
                raise ValueError("نمونه پیدا نشد.")

            test_id, project_id = sample

            conn.execute(
                """
                UPDATE audit_test_samples
                SET result=?,exception_description=?,document_ref=?,
                    description=?,amount=?,misstatement_amount=?,evidence_path=?,
                    tested_by_member_id=?,tested_at=CURRENT_TIMESTAMP
                WHERE id=?
                """,
                (
                    result,
                    kwargs.get("exception_description", ""),
                    kwargs.get("document_ref", ""),
                    kwargs.get("description", ""),
                    kwargs.get("amount"),
                    kwargs.get("misstatement_amount"),
                    kwargs.get("evidence_path", ""),
                    kwargs.get("tested_by_member_id"),
                    sample_id
                )
            )

            conn.execute(
                """
                INSERT INTO audit_test_history (
                    project_id,test_id,sample_id,action,details,
                    actor_member_id,created_at
                )
                VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP)
                """,
                (
                    project_id, test_id, sample_id,
                    "ثبت نتیجه نمونه",
                    f"نتیجه: {result}",
                    kwargs.get("actor_member_id")
                )
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def test_progress(self, test_id):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total_samples,
                    SUM(CASE WHEN result <> 'رسیدگی‌نشده' THEN 1 ELSE 0 END) AS tested_samples,
                    SUM(CASE WHEN result = 'رسیدگی‌نشده' THEN 1 ELSE 0 END) AS untested_samples,
                    SUM(CASE WHEN result IN ('مغایرت','عدم انطباق') THEN 1 ELSE 0 END) AS exception_samples
                FROM audit_test_samples WHERE test_id=?
                """,
                (test_id,)
            ).fetchone()
            result = dict(row)
            total = result["total_samples"] or 0
            result["completion_percent"] = (
                round((result["tested_samples"] or 0) * 100 / total, 2)
                if total else 0
            )
            return result
        finally:
            conn.close()

    def exceptions_for_test(self, test_id):
        return self._run(
            """
            SELECT * FROM audit_test_samples
            WHERE test_id=? AND result IN ('مغایرت','عدم انطباق')
            ORDER BY sample_no
            """,
            (test_id,), "all"
        )

    def history_for_test(self, test_id):
        return self._run(
            "SELECT * FROM audit_test_history WHERE test_id=? ORDER BY id DESC",
            (test_id,), "all"
        )


if __name__ == "__main__":
    unittest.main()
