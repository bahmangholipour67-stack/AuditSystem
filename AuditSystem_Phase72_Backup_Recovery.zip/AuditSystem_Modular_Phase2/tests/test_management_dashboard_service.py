import unittest

from services.management_dashboard_service import ManagementDashboardService


class ManagementDashboardServiceTests(unittest.TestCase):
    def test_builds_priority_queue_from_realistic_audit_rows(self):
        result = ManagementDashboardService.build_snapshot(
            risk_rows=[("ریسک با امتیاز بالا", 22), ("ریسک عادی", 8)],
            workpaper_rows=[(1, "کاربرگ تکمیل", "نهایی و تأیید"),
                            (2, "کاربرگ باز", "پیش‌نویس")],
            finding_rows=[(10, "یافته اساسی", "اساسی", "باز", "حسابرس"),
                          (11, "یافته بسته", "اساسی", "بسته", "")],
            test_rows=[(20, "آزمون در انتظار", "آماده بررسی سرپرست"),
                       (21, "آزمون برگشتی", "نیازمند اصلاح"),
                       (22, "آزمون تأیید", "تأیید نهایی مدیر")],
            findings_without_evidence=[(10, "یافته اساسی")],
            unlinked_workpapers=[(2, "کاربرگ بدون ریسک")],
            risk_threshold=15,
        )
        self.assertEqual(result["high_risk_count"], 1)
        self.assertEqual(result["pending_test_reviews"], 1)
        self.assertEqual(result["returned_tests"], 1)
        self.assertEqual(result["manager_approved_tests"], 1)
        self.assertEqual(result["critical_open_findings"], 1)
        self.assertEqual(result["workpaper_completion_percent"], 50)
        self.assertEqual(result["actions"][0]["priority"], "فوری")
        self.assertEqual(result["actions"][0]["category"], "شواهد")

    def test_summary_is_read_only_and_deterministic(self):
        kwargs = dict(risk_rows=[("R", 20)], risk_threshold=15)
        first = ManagementDashboardService.build_snapshot(**kwargs)
        second = ManagementDashboardService.build_snapshot(**kwargs)
        self.assertEqual(first, second)
        self.assertEqual(kwargs["risk_rows"], [("R", 20)])

    def test_rejects_invalid_risk_threshold(self):
        for value in (0, 26, "bad"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                ManagementDashboardService.build_snapshot(risk_threshold=value)

    def test_persian_status_variants_are_normalized(self):
        self.assertTrue(ManagementDashboardService.is_closed("نهایی و تأیید"))
        self.assertTrue(ManagementDashboardService.is_closed("بسته"))
        self.assertFalse(ManagementDashboardService.is_closed("در انتظار بررسی مدیر"))


if __name__ == "__main__":
    unittest.main()
