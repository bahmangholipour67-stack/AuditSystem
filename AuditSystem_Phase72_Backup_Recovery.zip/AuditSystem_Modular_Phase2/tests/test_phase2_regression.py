import sqlite3, tempfile, unittest, shutil
from pathlib import Path
from services.number_utils import parse_amount, safe_csv_text
from services.sampling_service import select_sample
from services.benford_service import analyze
from services.trial_balance_service import add_flags
class Phase2RegressionTests(unittest.TestCase):
 def test_number_parsing(self): self.assertEqual(parse_amount('۱۲۳٬۴۵۶٫۷'),123456.7); self.assertEqual(parse_amount('(250)'),-250)
 def test_csv_guard(self): self.assertEqual(safe_csv_text('=1+1'),"'=1+1")
 def test_sampling_seed(self): self.assertEqual(select_sample(100,10,42),select_sample(100,10,42))
 def test_benford_minimum(self):
  with self.assertRaises(ValueError): analyze([1,2,3])
 def test_trial_balance_flags(self):
  rows=[{'code':'1','name':'a','debit':-1,'credit':0,'net':-1,'flags':''},{'code':'1','name':'b','debit':1,'credit':2,'net':-1,'flags':''}]
  add_flags(rows); self.assertIn('بدهکار منفی',rows[0]['flags']); self.assertIn('کد تکراری',rows[0]['flags'])
 def test_database_backup_matches_source(self):
  p=Path(__file__).resolve().parents[1]/'backups'/'audit_system_original_backup.db'
  c=sqlite3.connect(p); self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
  counts={r[0]:c.execute('SELECT COUNT(*) FROM "'+r[0]+'"').fetchone()[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
  self.assertEqual(counts.get('projects'),1); self.assertEqual(counts.get('risks'),2); self.assertEqual(counts.get('workpapers'),0); self.assertEqual(counts.get('findings'),0); c.close()
if __name__=='__main__': unittest.main()
