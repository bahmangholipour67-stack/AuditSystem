import sqlite3
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from repositories.workpaper_repository import WorkpaperRepository


class TestWorkpaperWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "workpaper.db"
        self._create_database()
        self.patcher = patch("repositories.workpaper_repository.connect", self._connect)
        self.patcher.start()
        self.repo = WorkpaperRepository()

    def tearDown(self):
        self.patcher.stop()
        self.temp_dir.cleanup()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path))
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _create_database(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.executescript("""
            CREATE TABLE team_members (
                id INTEGER PRIMARY KEY, project_id INTEGER, full_name TEXT,
                role TEXT, is_active INTEGER
            );
            CREATE TABLE workpapers (
                id INTEGER PRIMARY KEY, project_id INTEGER, risk_id INTEGER,
                title TEXT, procedure TEXT, result TEXT, status TEXT,
                assigned_member_id INTEGER, reviewer_member_id INTEGER,
                approved_by_member_id INTEGER, reviewed_at TEXT, approved_at TEXT
            );
            CREATE TABLE workpaper_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER,
                workpaper_id INTEGER, action TEXT, previous_status TEXT,
                new_status TEXT, actor_member_id INTEGER, notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        """)
        conn.executemany("""
            INSERT INTO team_members (id, project_id, full_name, role, is_active)
            VALUES (?, ?, ?, ?, ?)
        """, [
            (1, 1, "حسابرس", "حسابرس", 1),
            (2, 1, "سرپرست", "سرپرست حسابرسی", 1),
            (3, 1, "مدیر", "مدیر حسابرسی", 1),
            (4, 1, "کارآموز", "کارآموز حسابرسی", 1),
            (5, 1, "سرپرست غیرفعال", "سرپرست حسابرسی", 0),
            (6, 2, "سرپرست پروژه دیگر", "سرپرست حسابرسی", 1),
        ])
        conn.execute("""
            INSERT INTO workpapers (
                id, project_id, title, status, assigned_member_id, reviewer_member_id
            ) VALUES (1, 1, 'کاربرگ آزمون', 'پیش‌نویس', 1, 2)
        """)
        conn.commit()
        conn.close()

    def _status(self):
        with self._connect() as conn:
            return conn.execute("SELECT status FROM workpapers WHERE id=1").fetchone()[0]

    def test_complete_workflow(self):
        self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 1)
        self.assertEqual(self._status(), "در انتظار بررسی مدیر")
        self.repo.update_workflow(1, 1, "تأیید سرپرست", 2, "بررسی شد")
        self.assertEqual(self._status(), "تأیید سرپرست")
        self.repo.update_workflow(1, 1, "نهایی و تأیید", 3, "تأیید نهایی")
        self.assertEqual(self._status(), "نهایی و تأیید")
        with self._connect() as conn:
            approved_by = conn.execute(
                "SELECT approved_by_member_id FROM workpapers WHERE id=1"
            ).fetchone()[0]
            history_count = conn.execute(
                "SELECT COUNT(*) FROM workpaper_history WHERE workpaper_id=1"
            ).fetchone()[0]
        self.assertEqual(approved_by, 3)
        self.assertEqual(history_count, 3)

    def test_wrong_role_cannot_submit(self):
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 4)

    def test_only_assigned_auditor_can_submit(self):
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 2)

    def test_only_selected_supervisor_can_review(self):
        self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 1)
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "تأیید سرپرست", 6)
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "تأیید سرپرست", 5)

    def test_manager_cannot_approve_before_supervisor(self):
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "نهایی و تأیید", 3)

    def test_return_requires_comment_and_can_be_resubmitted(self):
        self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 1)
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "نیازمند اصلاح", 2)
        self.repo.update_workflow(1, 1, "نیازمند اصلاح", 2, "اصلاح مستندات")
        self.assertEqual(self._status(), "نیازمند اصلاح")
        self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 1)
        self.assertEqual(self._status(), "در انتظار بررسی مدیر")

    def test_assignment_validates_member_roles(self):
        with self.assertRaises(ValueError):
            self.repo.update_assignment(1, 1, 4, 2)
        with self.assertRaises(ValueError):
            self.repo.update_assignment(1, 1, 1, 3)

    def test_final_approval_is_locked(self):
        self.repo.update_workflow(1, 1, "در انتظار بررسی مدیر", 1)
        self.repo.update_workflow(1, 1, "تأیید سرپرست", 2)
        self.repo.update_workflow(1, 1, "نهایی و تأیید", 3)
        with self.assertRaises(ValueError):
            self.repo.update_workflow(1, 1, "نیازمند اصلاح", 2, "اصلاح")


if __name__ == "__main__":
    unittest.main()
