import unittest

from services.audit_test_followup import AuditTestFollowUpService


class AuditTestFollowUpServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = AuditTestFollowUpService()

    def test_incomplete_test_gets_urgent_completion_action(self):
        result = self.service.build_follow_up({
            "assessment": "نیازمند تکمیل رسیدگی", "is_complete": False,
        })
        self.assertEqual(result["follow_up_priority"], "فوری")
        self.assertEqual(result["actions"][0]["code"], "COMPLETE_TEST")

    def test_high_risk_and_failed_assessment_generate_actions(self):
        result = self.service.build_follow_up({
            "assessment": "عدم احراز معیار", "is_complete": True,
            "exception_samples": 2, "exception_amount": 150,
        }, risk_score=20, materiality=100)
        codes = {item["code"] for item in result["actions"]}
        self.assertIn("INVESTIGATE_EXCEPTIONS", codes)
        self.assertIn("REASSESS_HIGH_RISK", codes)
        self.assertIn("MATERIALITY_REVIEW", codes)
        self.assertTrue(result["finding_review_recommended"])

    def test_insufficient_or_conflicting_evidence_is_urgent(self):
        result = self.service.build_follow_up(
            {"assessment": "احراز معیار", "is_complete": True},
            evidence_sufficient=False, contradictory_evidence=True,
        )
        codes = {item["code"] for item in result["actions"]}
        self.assertEqual(result["follow_up_priority"], "فوری")
        self.assertTrue({"OBTAIN_EVIDENCE", "RESOLVE_CONFLICT"}.issubset(codes))
        self.assertTrue(result["finding_review_recommended"])

    def test_successful_low_risk_test_gets_documentation_action(self):
        result = self.service.build_follow_up(
            {"assessment": "احراز معیار", "is_complete": True}, risk_score=5
        )
        self.assertEqual(result["risk_level"], "پایین")
        self.assertEqual(result["actions"][0]["code"], "DOCUMENT_CONCLUSION")
        self.assertFalse(result["finding_review_recommended"])

    def test_invalid_risk_and_materiality_are_rejected(self):
        for value in (0, 26, 1.5, True, "bad"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.service.build_follow_up({"assessment": "احراز معیار"}, risk_score=value)
        with self.assertRaises(ValueError):
            self.service.build_follow_up({"assessment": "احراز معیار"}, materiality=-1)

    def test_does_not_mutate_evaluation(self):
        evaluation = {"assessment": "عدم احراز معیار", "exception_samples": 1}
        original = dict(evaluation)
        self.service.build_follow_up(evaluation, risk_score=18)
        self.assertEqual(evaluation, original)

    def test_rejects_non_boolean_evidence_flags(self):
        with self.assertRaises(ValueError):
            self.service.build_follow_up(
                {"assessment": "احراز معیار"}, evidence_sufficient="yes"
            )


if __name__ == "__main__":
    unittest.main()
