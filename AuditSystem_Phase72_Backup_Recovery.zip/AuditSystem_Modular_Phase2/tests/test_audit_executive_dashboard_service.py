from services.audit_executive_dashboard_service import AuditExecutiveDashboardService as Service



def test_dashboard_snapshot_calculates_kpis():
    result = Service.snapshot(
        projects=[(1, "پرونده باز", "فعال"), (2, "پرونده بسته", "مختومه")],
        risks=[("ریسک بالا", 20), ("ریسک عادی", 8), ("امتیاز نامعتبر", "x")],
        workpapers=[(1, "تکمیل", "نهایی و تأیید"), (2, "باز", "پیش‌نویس")],
        findings=[(1, "یافته اساسی", "اساسی", "باز"), (2, "یافته بسته", "کم", "بسته")],
        tests=[(1, "آزمون", "آماده بررسی سرپرست"), (2, "تأیید شده", "تأیید نهایی مدیر")],
    )
    assert result["project_count"] == 2
    assert result["active_project_count"] == 1
    assert result["high_risk_count"] == 1
    assert result["completed_workpaper_count"] == 1
    assert result["workpaper_completion_percent"] == 50
    assert result["open_finding_count"] == 1
    assert result["critical_open_finding_count"] == 1
    assert result["pending_review_count"] == 1



def test_dashboard_empty_data_returns_zeroes():
    result = Service.snapshot()
    assert result["project_count"] == 0
    assert result["workpaper_completion_percent"] == 0
    assert result["pending_review_count"] == 0



def test_persian_status_normalization():
    assert Service.is_closed("نهایی و تأیید")
    assert Service.is_closed("مختومه")
    assert not Service.is_closed("در انتظار بررسی")
