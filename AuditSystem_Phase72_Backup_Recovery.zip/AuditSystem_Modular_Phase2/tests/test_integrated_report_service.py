import json
import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from services.integrated_report_service import IntegratedReportService
from ui.views.report_view import ReportViewMixin


class IntegratedReportServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "integrated_report.db"
        ensure_schema(self.db_path)
        with sqlite_connection(self.db_path) as conn:
            conn.execute("INSERT INTO projects(id,name,period,audit_type,manager,status) VALUES(1,?,?,?,?,?)",
                         ("پرونده آزمایشی", "1405", "مستقل", "مدیر الف", "در جریان"))
            conn.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده دیگر','1404')")
            conn.execute("INSERT INTO risks(id,project_id,title,score) VALUES(1,1,'ریسک فروش',20)")
            conn.execute("INSERT INTO risks(id,project_id,title,score) VALUES(2,2,'ریسک محرمانه پرونده دیگر',25)")
            conn.execute("INSERT INTO workpapers(id,project_id,risk_id,title,status) VALUES(1,1,1,'کاربرگ فروش','پیش‌نویس')")
            conn.execute("INSERT INTO findings(id,project_id,workpaper_id,risk_id,title,severity,status) VALUES(1,1,1,1,'مغایرت فروش','بااهمیت','باز')")
            conn.execute("INSERT INTO audit_programs(id,project_id,title,risk_id,status) VALUES(1,1,'برنامه فروش',1,'در حال اجرا')")
            conn.execute("INSERT INTO audit_tests(id,project_id,program_id,title,status) VALUES(1,1,1,'آزمون فروش','در حال اجرا')")
            conn.execute("""INSERT INTO audit_test_samples(
                id,project_id,test_id,sample_no,amount,result,misstatement_amount,exception_description
            ) VALUES(1,1,1,1,1000,'مغایرت',120,'اختلاف مبلغ')""")
            conn.execute("INSERT INTO finding_evidence(project_id,finding_id,file_path,description) VALUES(1,1,'evidence.pdf','فاکتور')")
            conn.execute("INSERT INTO trial_balance(project_id,account_code,account_name,debit,credit,net) VALUES(1,'101','بانک',1000,800,200)")
        self.service = IntegratedReportService(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_builds_project_scoped_integrated_snapshot(self):
        report = self.service.build(1)
        self.assertEqual(report["project"]["name"], "پرونده آزمایشی")
        self.assertEqual(report["summary"]["risk_count"], 1)
        self.assertEqual(report["summary"]["high_risk_count"], 1)
        self.assertEqual(report["summary"]["workpaper_count"], 1)
        self.assertEqual(report["summary"]["program_count"], 1)
        self.assertEqual(report["summary"]["test_count"], 1)
        self.assertEqual(report["summary"]["sample_exception_count"], 1)
        self.assertEqual(report["summary"]["open_finding_count"], 1)
        self.assertEqual(report["summary"]["evidence_count"], 1)
        self.assertEqual(report["summary"]["trial_balance_difference"], 200)
        self.assertEqual(report["summary"]["recorded_misstatement_total"], 120)
        self.assertNotIn("ریسک محرمانه پرونده دیگر", str(report))

    def test_rejects_unknown_project_and_invalid_ids(self):
        for value in (None, "bad", 0, 999):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.service.build(value)

    def test_exporter_writes_integrated_csv_sections(self):
        report = self.service.build(1)
        path = self.db_path.parent / "report.csv"
        ReportViewMixin._write_integrated_csv(report, path)
        content = path.read_text(encoding="utf-8-sig")
        self.assertIn("گزارش یکپارچه پرونده حسابرسی", content)
        self.assertIn("ریسک فروش", content)
        self.assertIn("آزمون فروش", content)
        self.assertIn("مبلغ تحریف ثبت‌شده", content)


if __name__ == "__main__":
    unittest.main()
