import pytest
from services.audit_procedures_engine import AuditProceduresEngine as Engine


def test_cash_risk_suggests_bank_templates_and_stable_keys():
    result = Engine.build_for_risk({"id": "R-12", "title": "ریسک مغایرت بانکی", "score": 18})
    assert result["count"] > 0
    assert any("بانک" in p["cycle"] or "نقد" in p["cycle"] for p in result["procedure_candidates"])
    assert all(p["procedure_key"].startswith("R-12::") for p in result["procedure_candidates"])
    assert all(p["status"] == "پیشنهادی" for p in result["procedure_candidates"])


def test_unknown_risk_returns_no_unrelated_catalog_templates():
    result = Engine.build_for_risk({"title": "ریسک نامرتبط", "score": 5})
    assert result["risk_plan"]["category"] == "ریسک عمومی"
    assert result["procedure_candidates"] == []


def test_candidate_limit_and_validation():
    result = Engine.build_for_risk({"title": "ریسک فروش", "score": 10}, max_templates=1)
    assert result["count"] <= 1
    for invalid in (0, 26, True, "3"):
        with pytest.raises(ValueError):
            Engine.build_for_risk({"title": "ریسک فروش", "score": 10}, max_templates=invalid)
    with pytest.raises(ValueError):
        Engine.build_for_risk({"score": 10})
    with pytest.raises(ValueError):
        Engine.build_for_risk("not a dict")


def test_batch_orders_risks_by_score_descending():
    items = Engine.build_for_risks([
        {"title": "ریسک فروش", "score": 7},
        {"title": "ریسک نقد", "score": 20},
    ])
    assert items[0]["risk_plan"]["risk_score"] == 20
