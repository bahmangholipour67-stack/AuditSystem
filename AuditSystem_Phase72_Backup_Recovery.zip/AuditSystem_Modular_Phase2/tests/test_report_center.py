import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from reporting.report_center_service import ReportCenterService
from reporting.report_catalog import get_report_definition


class ReportCenterServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "report_center.db"
        ensure_schema(self.db_path)
        with sqlite_connection(self.db_path) as conn:
            conn.execute(
                "INSERT INTO projects(id,name,period,audit_type,manager,status) VALUES(1,?,?,?,?,?)",
                ("پرونده نمونه", "1405", "مستقل", "مدیر پرونده", "در جریان"),
            )
            conn.execute("INSERT INTO risks(id,project_id,title,score) VALUES(1,1,'ریسک موجودی',18)")
            conn.execute("INSERT INTO workpapers(id,project_id,risk_id,title,status) VALUES(1,1,1,'کاربرگ موجودی','در حال بررسی')")
        self.service = ReportCenterService(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_catalogue_has_unique_ids_and_categories(self):
        catalogue = self.service.catalogue()
        ids = [item["id"] for item in catalogue]
        self.assertGreaterEqual(len(catalogue), 10)
        self.assertEqual(len(ids), len(set(ids)))
        self.assertTrue(all(item["title"] and item["description"] and item["category"] for item in catalogue))

    def test_builds_project_scoped_risk_and_workpaper_reports(self):
        risk_report = self.service.build(1, "risk_register")
        self.assertEqual(risk_report["project"]["name"], "پرونده نمونه")
        self.assertEqual(risk_report["row_count"], 1)
        self.assertIn("ریسک موجودی", str(risk_report["rows"]))
        workpaper_report = self.service.build(1, "workpaper_status")
        self.assertEqual(workpaper_report["row_count"], 1)
        self.assertIn("کاربرگ موجودی", str(workpaper_report["rows"]))

    def test_rejects_unknown_report_and_invalid_project(self):
        with self.assertRaises(ValueError):
            get_report_definition("not-a-report")
        with self.assertRaises(ValueError):
            self.service.build(0, "risk_register")

    def test_management_letter_uses_recorded_finding_actions_and_evidence(self):
        with sqlite_connection(self.db_path) as conn:
            conn.execute(
                "INSERT INTO findings(project_id,workpaper_id,risk_id,title,severity,action_text,owner,status,finding_type,condition_text,criteria_text,cause_text,effect_text) "
                "VALUES(1,1,1,?,?,?,?,?,?,?,?,?,?)",
                ("مغایرت موجودی", "بااهمیت", "اصلاح مغایرت و بازبینی شمارش", "مسئول مالی", "باز",
                 "عمومی", "شمارش مستند نشده", "دستورالعمل انبار", "ضعف نظارت", "احتمال تحریف موجودی"),
            )
            finding_id = conn.execute("SELECT MAX(id) FROM findings").fetchone()[0]
            conn.execute(
                "INSERT INTO corrective_actions(project_id,finding_id,title,owner,due_date,status,progress_note) VALUES(1,?,?,?,?,?,?)",
                (finding_id, "بازشماری موجودی", "مدیر مالی", "1405/09/30", "در حال انجام", "هماهنگی با انبار"),
            )
            conn.execute(
                "INSERT INTO finding_evidence(project_id,finding_id,file_path,description) VALUES(1,?,?,?)",
                (finding_id, "evidence/count.pdf", "صورتجلسه شمارش"),
            )
        report = self.service.build(1, "management_letter")
        row = next(row for row in report["rows"] if row.get("عنوان یافته") == "مغایرت موجودی")
        self.assertEqual(row["وضعیت موجود"], "شمارش مستند نشده")
        self.assertEqual(row["معیار"], "دستورالعمل انبار")
        self.assertIn("بازشماری موجودی", row["اقدامات اصلاحی و پیگیری"])
        self.assertEqual(row["تعداد مستندات پیوست"], 1)
        self.assertTrue(report["report_notes"])

    def test_management_letter_does_not_invent_findings(self):
        report = self.service.build(1, "management_letter")
        self.assertEqual(report["row_count"], 0)
        self.assertIn("هنوز یافته‌ای ثبت نشده", report["rows"][0]["پیام"])
        self.assertTrue(any("پیش‌نویس" in note for note in report["report_notes"]))


class ReportCenterIntegrationTests(unittest.TestCase):
    def test_report_center_is_registered_in_unified_navigation(self):
        source = Path("legacy/audit_app.py").read_text(encoding="utf-8")
        self.assertIn("ReportCenterViewMixin", source)
        self.assertIn('self.tab_report_center = ttk.Frame(self.workspace_host)', source)
        self.assertIn('(self.tab_report_center, "مرکز جامع گزارشات")', source)
        self.assertIn('self.setup_report_center_tab()', source)
        self.assertIn('"مرکز جامع گزارشات": "گزارشات و تحلیل"', source)


if __name__ == "__main__":
    unittest.main()
