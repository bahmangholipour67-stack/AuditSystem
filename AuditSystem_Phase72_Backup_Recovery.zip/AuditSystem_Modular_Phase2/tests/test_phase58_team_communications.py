import sqlite3
from contextlib import contextmanager

import pytest

from services import team_communication_service as communication_module
from services.team_communication_service import TeamCommunicationService


@pytest.fixture
def communication_db(tmp_path, monkeypatch):
    db_path = tmp_path / "phase58.sqlite"
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        CREATE TABLE team_members (
            id INTEGER PRIMARY KEY, project_id INTEGER, full_name TEXT,
            role TEXT, is_active INTEGER DEFAULT 1
        );
        CREATE TABLE workpapers (
            id INTEGER PRIMARY KEY, project_id INTEGER, title TEXT
        );
        CREATE TABLE team_communications (
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            workpaper_id INTEGER NOT NULL, event_type TEXT NOT NULL,
            author_member_id INTEGER NOT NULL, recipient_member_id INTEGER,
            body TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TRIGGER team_communications_no_update BEFORE UPDATE ON team_communications
        BEGIN SELECT RAISE(ABORT, 'append-only'); END;
        CREATE TRIGGER team_communications_no_delete BEFORE DELETE ON team_communications
        BEGIN SELECT RAISE(ABORT, 'append-only'); END;
        INSERT INTO team_members VALUES (1, 10, 'حسابرس الف', 'حسابرس', 1);
        INSERT INTO team_members VALUES (2, 10, 'سرپرست ب', 'سرپرست حسابرسی', 1);
        INSERT INTO team_members VALUES (3, 10, 'عضو غیرفعال', 'حسابرس', 0);
        INSERT INTO team_members VALUES (4, 11, 'عضو پرونده دیگر', 'حسابرس', 1);
        INSERT INTO workpapers VALUES (100, 10, 'کاربرگ موجودی کالا');
    """)
    conn.commit()
    conn.close()

    @contextmanager
    def test_connect():
        db = sqlite3.connect(db_path)
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    monkeypatch.setattr(communication_module, "connect", test_connect)
    return db_path


def test_comment_thread_and_inbox_are_project_scoped(communication_db):
    message_id = TeamCommunicationService.add_comment(10, 100, 1, "لطفاً سند پشتیبان بررسی شود.", 2)
    assert message_id == 1
    thread = TeamCommunicationService.thread(10, 100)
    assert len(thread) == 1
    assert thread[0]["author"] == "حسابرس الف"
    assert thread[0]["recipient"] == "سرپرست ب"
    inbox = TeamCommunicationService.inbox(10, 2)
    assert len(inbox) == 1
    assert inbox[0]["workpaper_title"] == "کاربرگ موجودی کالا"
    assert TeamCommunicationService.inbox(10, 1) == []


def test_review_request_requires_active_supervisor_in_same_project(communication_db):
    TeamCommunicationService.request_review(10, 100, 1, 2, "آماده بررسی است")
    with pytest.raises(ValueError):
        TeamCommunicationService.request_review(10, 100, 1, 3)
    with pytest.raises(ValueError):
        TeamCommunicationService.request_review(10, 100, 1, 4)


def test_empty_comment_and_cross_project_workpaper_are_rejected(communication_db):
    with pytest.raises(ValueError):
        TeamCommunicationService.add_comment(10, 100, 1, "   ")
    with pytest.raises(ValueError):
        TeamCommunicationService.add_comment(11, 100, 4, "متن")


def test_communication_records_are_append_only(communication_db):
    TeamCommunicationService.add_comment(10, 100, 1, "نظر ثبت‌شده")
    db = sqlite3.connect(communication_db)
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("UPDATE team_communications SET body='تغییر' WHERE id=1")
    with pytest.raises(sqlite3.IntegrityError):
        db.execute("DELETE FROM team_communications WHERE id=1")
    db.close()


def test_communication_migration_is_idempotent_and_creates_immutable_history(tmp_path):
    from database.migrations import create_team_communication_tables
    db = sqlite3.connect(tmp_path / "migration.sqlite")
    create_team_communication_tables(db)
    create_team_communication_tables(db)
    names = {row[0] for row in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    )}
    assert "team_communications" in names
    trigger_names = {row[0] for row in db.execute(
        "SELECT name FROM sqlite_master WHERE type='trigger'"
    )}
    assert "team_communications_no_update" in trigger_names
    assert "team_communications_no_delete" in trigger_names
    db.close()
