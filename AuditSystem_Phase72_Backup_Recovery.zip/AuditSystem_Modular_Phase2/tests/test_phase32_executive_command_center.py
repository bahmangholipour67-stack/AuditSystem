import sqlite3
import unittest
from services.executive_command_center_service import ExecutiveCommandCenterService


class ExecutiveCommandCenterTests(unittest.TestCase):
    def setUp(self):
        self.conn = sqlite3.connect(':memory:')
        self.conn.execute('CREATE TABLE projects (id INTEGER PRIMARY KEY, name TEXT)')
        self.conn.execute('CREATE TABLE risks (id INTEGER, project_id INTEGER, title TEXT, status TEXT)')
        self.conn.execute('CREATE TABLE findings (id INTEGER, project_id INTEGER, title TEXT, status TEXT)')
        self.conn.executemany('INSERT INTO projects VALUES (?,?)', [(1,'Alpha'),(2,'Beta')])
        self.conn.executemany('INSERT INTO risks VALUES (?,?,?,?)', [(1,1,'R1','باز'),(2,1,'R2','بسته'),(3,2,'R3','باز')])
        self.conn.executemany('INSERT INTO findings VALUES (?,?,?,?)', [(1,1,'F1','در جریان'),(2,2,'F2','مختومه')])
    def tearDown(self): self.conn.close()
    def test_project_scope_counts(self):
        s = ExecutiveCommandCenterService.snapshot(self.conn, 1)
        self.assertEqual(s['counts']['risks'], 2)
        self.assertEqual(s['counts']['findings'], 1)
        self.assertEqual(s['statuses']['risks']['open'], 1)
        self.assertEqual(s['statuses']['risks']['closed'], 1)
    def test_all_engagements_aggregation(self):
        s = ExecutiveCommandCenterService.snapshot(self.conn)
        self.assertEqual(s['counts']['risks'], 3)
        self.assertEqual(s['counts']['projects'], 2)
        self.assertEqual(s['total_records'], sum(s['counts'].values()))
    def test_missing_optional_tables_are_safe(self):
        c = sqlite3.connect(':memory:')
        s = ExecutiveCommandCenterService.snapshot(c)
        self.assertEqual(s['total_records'], 0)
        c.close()
    def test_read_only_behavior(self):
        before = self.conn.execute('SELECT COUNT(*) FROM risks').fetchone()[0]
        ExecutiveCommandCenterService.snapshot(self.conn, 1)
        after = self.conn.execute('SELECT COUNT(*) FROM risks').fetchone()[0]
        self.assertEqual(before, after)
if __name__ == '__main__': unittest.main()
