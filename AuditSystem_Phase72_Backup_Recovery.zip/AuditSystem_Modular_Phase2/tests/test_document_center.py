import sqlite3
from db_test_utils import sqlite_connection
import tempfile
import unittest
from pathlib import Path

from database.migrations import ensure_schema
from repositories.document_repository import DocumentRepository
from repositories.document_request_repository import DocumentRequestRepository


class DocumentCenterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / "audit.db"
        ensure_schema(self.db)
        with sqlite_connection(self.db) as conn:
            conn.execute("INSERT INTO projects(id,name,period) VALUES(1,'پرونده یک','1405')")
            conn.execute("INSERT INTO projects(id,name,period) VALUES(2,'پرونده دو','1404')")
            conn.execute("INSERT INTO workpapers(id,project_id,title) VALUES(11,1,'کاربرگ فروش')")
            conn.execute("INSERT INTO workpapers(id,project_id,title) VALUES(22,2,'کاربرگ دیگر')")
        self.docs = DocumentRepository(self.db)
        self.requests = DocumentRequestRepository(self.db)
        self.sample_file = self.root / "invoice.txt"
        self.sample_file.write_text("invoice evidence", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_register_and_link_document_with_project_scope(self):
        doc_id = self.docs.register(1, "فاکتور فروش", self.sample_file, "فروش", "نمونه مستند")
        self.assertTrue(self.docs.link(1, doc_id, "workpaper", 11))
        self.assertFalse(self.docs.link(1, doc_id, "workpaper", 11))
        with self.assertRaises(ValueError):
            self.docs.link(1, doc_id, "workpaper", 22)
        rows = self.docs.list_for_project(1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["sha256"], __import__("hashlib").sha256(b"invoice evidence").hexdigest())
        self.assertEqual(self.docs.list_for_project(2), [])

    def test_missing_file_and_invalid_project_rejected(self):
        with self.assertRaises(ValueError):
            self.docs.register(1, "سند", self.root / "missing.pdf")
        with self.assertRaises(ValueError):
            self.docs.register(999, "سند", self.sample_file)

    def test_document_archive_restore_preserves_record_and_history(self):
        doc_id = self.docs.register(1, "سند بایگانی", self.sample_file)
        self.docs.archive(1, doc_id, "پایان رسیدگی")
        self.assertEqual(self.docs.list_for_project(1), [])
        self.assertEqual(len(self.docs.list_for_project(1, include_archived=True)), 1)
        self.docs.restore(1, doc_id)
        self.assertEqual(len(self.docs.list_for_project(1)), 1)
        with sqlite_connection(self.db) as conn:
            events = [r[0] for r in conn.execute("SELECT event_type FROM document_history WHERE document_id=? ORDER BY id", (doc_id,))]
        self.assertEqual(events, ["ARCHIVE", "RESTORE"])

    def test_request_lifecycle_and_history(self):
        request_id = self.requests.create(1, "صورت‌حساب بانک", "سه ماهه", "واحد مالی", due_date="1405/09/30", priority="فوری")
        self.assertTrue(self.requests.update_status(1, request_id, "ارسال‌شده", note="ارسال ایمیل"))
        self.assertTrue(self.requests.update_status(1, request_id, "دریافت‌شده"))
        self.assertTrue(self.requests.update_status(1, request_id, "تکمیل‌شده"))
        self.assertFalse(self.requests.update_status(1, request_id, "تکمیل‌شده"))
        history = self.requests.history(1, request_id)
        self.assertEqual([x["event_type"] for x in history], ["CREATED", "STATUS_CHANGED", "STATUS_CHANGED", "STATUS_CHANGED"])
        self.assertEqual(self.requests.list_for_project(2), [])
        with self.assertRaises(ValueError):
            self.requests.update_status(2, request_id, "لغوشده")

    def test_request_archive_is_soft_delete(self):
        request_id = self.requests.create(1, "قراردادها")
        self.requests.archive(1, request_id, "درخواست تکراری")
        self.assertEqual(self.requests.list_for_project(1), [])
        self.assertEqual(len(self.requests.list_for_project(1, include_archived=True)), 1)
        with sqlite_connection(self.db) as conn:
            count = conn.execute("SELECT COUNT(*) FROM document_request_history WHERE request_id=?", (request_id,)).fetchone()[0]
        self.assertEqual(count, 2)


if __name__ == "__main__":
    unittest.main()
