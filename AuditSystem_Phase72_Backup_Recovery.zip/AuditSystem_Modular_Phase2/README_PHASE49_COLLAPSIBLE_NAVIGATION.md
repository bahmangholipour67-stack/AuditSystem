# Phase 49 — Collapsible Sidebar Navigation

Phase 49 builds on the unified navigation and Phase 48 scrolling refinements.

## Changes
- Adds a collapse/expand control at the top of the single navigation sidebar.
- Collapsed mode uses a compact icon-only sidebar, allowing more central workspace width.
- Tooltips show the full Persian module name while hovering in collapsed mode.
- Expanded mode restores module names, search, and group headings.
- Preserves the active module styling and navigation callbacks.
- Existing vertical/horizontal sidebar scrolling remains available in expanded mode.
- All modules and underlying frames/services remain unchanged.


## Validation
- `python -m compileall -q legacy/audit_app.py` passed.
- `python -m pytest -q`: 257 passed, 131 subtests passed.

- Visual interaction on a Windows desktop has not been independently confirmed in this environment.
