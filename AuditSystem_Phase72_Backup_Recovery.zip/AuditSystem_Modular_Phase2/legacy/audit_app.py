
"""Compatibility facade: UI tabs are separated into focused mixins."""

import tkinter as tk
from tkinter import ttk, messagebox

from database.connection import connect as db_connect
from database.migrations import ensure_schema
from config.settings import DATABASE_PATH

from ui.views.record_navigation import RecordNavigationMixin
from ui.views.project_view import ProjectViewMixin
from ui.views.dashboard_view import DashboardViewMixin
from ui.views.risk_view import RiskViewMixin
from ui.views.workpaper_view import WorkpaperViewMixin
from ui.views.finding_view import FindingViewMixin
from ui.views.benford_view import BenfordViewMixin
from ui.views.analysis_view import AnalysisViewMixin
from ui.views.sampling_view import SamplingViewMixin
from ui.views.trial_balance_view import TrialBalanceViewMixin
from ui.views.report_view import ReportViewMixin
from ui.views.report_center_view import ReportCenterViewMixin
from ui.views.team_view import TeamViewMixin
from ui.views.team_workspace_view import TeamWorkspaceViewMixin
from ui.views.audit_test_view import AuditTestViewMixin
from ui.views.audit_file_view import AuditFileViewMixin
from ui.views.audit_traceability_view import AuditTraceabilityViewMixin
from ui.views.document_center_view import DocumentCenterViewMixin
from ui.views.misstatement_view import MisstatementViewMixin
from ui.views.engagement_assessment_view import EngagementAssessmentViewMixin
from ui.views.approval_center_view import ApprovalCenterViewMixin
from ui.views.unified_audit_execution_view import UnifiedAuditExecutionViewMixin
from ui.views.internal_control_view import InternalControlViewMixin
from ui.views.risk_center_view import RiskCenterViewMixin
from ui.views.coso_framework_view import CosoFrameworkViewMixin
from ui.table_interactions import attach_table_interactions

from services.application_services import ApplicationServices
from core.pastel_theme import PALETTE, FONTS, LEGACY_PALETTE


class AuditApp(
    RecordNavigationMixin,
    ProjectViewMixin,
    DashboardViewMixin,
    RiskViewMixin,
    WorkpaperViewMixin,
    FindingViewMixin,
    BenfordViewMixin,
    AnalysisViewMixin,
    SamplingViewMixin,
    TrialBalanceViewMixin,
    ReportViewMixin,
    ReportCenterViewMixin,
    TeamViewMixin,
    TeamWorkspaceViewMixin,
    AuditTestViewMixin,
    AuditFileViewMixin,
    AuditTraceabilityViewMixin,
    DocumentCenterViewMixin,
    MisstatementViewMixin,
    EngagementAssessmentViewMixin,
    ApprovalCenterViewMixin,
    UnifiedAuditExecutionViewMixin,
    InternalControlViewMixin,
    RiskCenterViewMixin,
    CosoFrameworkViewMixin
):

    def __init__(self, root):
        self.root = root
        self.root.title("سامانه آفلاین مدیریت و تحلیل حسابرسی")
        self.root.geometry("1220x810")
        self.root.minsize(1000, 650)

        self.db_path = str(DATABASE_PATH)
        self.services = ApplicationServices()

        self.benford_service = self.services.benford
        self.beneish_service = self.services.beneish
        self.sampling_service = self.services.sampling
        self.trial_balance_service = self.services.trial_balance_tools

        self.projects = []
        self.selected_samples = []
        self.sample_seed = None

        self.active_member_id = None
        self.active_member = None
        self.project_members = []

        self.init_db()
        self.create_widgets()
        self.load_projects()

    def get_conn(self):
        return db_connect(self.db_path)

    def init_db(self):
        ensure_schema()

    def clear_tree(self, tree):
        for item in tree.get_children():
            tree.delete(item)

    def make_tree(self, parent, columns):
        """columns: [(key, Persian heading, width), ...]."""

        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, padx=10, pady=6)

        keys = [item[0] for item in columns]

        tree = ttk.Treeview(
            frame,
            columns=keys,
            show="headings"
        )

        for key, heading, width in columns:
            tree.heading(key, text=heading)
            tree.column(
                key,
                width=width,
                anchor="center",
                stretch=True
            )

        scroll_y = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=tree.yview
        )

        scroll_x = ttk.Scrollbar(
            frame,
            orient="horizontal",
            command=tree.xview
        )

        tree.configure(
            yscrollcommand=scroll_y.set,
            xscrollcommand=scroll_x.set
        )

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        tree.grid(row=0, column=0, sticky="nsew")
        attach_table_interactions(tree, self.root)
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")

        return tree

    def create_widgets(self):
        """Phase 30: modern RTL workspace with a right-side module navigator.

        The existing tab frames remain intact as internal workspaces. Hiding the
        notebook tabs avoids rewriting the mature view mixins and preserves all
        existing callbacks, services, and database interactions.
        """
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        # Enterprise Professional design system (Phase 35 visual refresh).
        # Keep compatibility aliases for older view mixins.
        # Classic Financial Office: familiar Microsoft Office + accounting desktop visual language.
        self.palette = dict(PALETTE)
        self.palette.update({
            "ivory": "#EEF1F5", "surface": "#FFFFFF", "text": "#263445",
            "muted": "#667586", "border": "#C8D0DA", "gray": "#E5E9EF",
            "navy": "#1F3B5B", "navy_deep": "#17304C", "navy_hover": "#DCE7F2",
            "navy_selected": "#D5E3F1", "blue_primary": "#315F8C",
            "blue_hover": "#274F78", "blue_light": "#E8EFF6",
            "white": "#FFFFFF", "sidebar_text": "#263445",
            "sidebar_muted": "#667586", "sidebar_border": "#C8D0DA",
        })
        self.classic_palette = LEGACY_PALETTE
        c = self.palette
        style.configure(".", font=FONTS["body"])
        self.root.configure(bg=c["ivory"])
        style.configure("TFrame", background=c["ivory"])
        style.configure("Card.TFrame", background=c["surface"])
        style.configure("Sidebar.TFrame", background="#E7EBF0")
        style.configure("TLabel", background=c["ivory"], foreground=c["text"], font=FONTS["body"])
        style.configure("Header.TLabel", background=c["surface"], foreground=c["navy"], font=FONTS["heading"])
        style.configure("WorkspaceBreadcrumb.TLabel", background=c["surface"], foreground=c["muted"], font=FONTS["small"])
        style.configure("WorkspaceContext.TLabel", background=c["surface"], foreground=c["blue_primary"], font=FONTS["small"])
        style.configure("Muted.TLabel", background=c["surface"], foreground=c["muted"], font=FONTS["small"])
        style.configure("SidebarHeader.TLabel", background="#E7EBF0", foreground=c["navy"], font=("Tahoma", 12, "bold"))
        style.configure("SidebarGroup.TLabel", background="#E7EBF0", foreground=c["muted"], font=("Tahoma", 9, "bold"))
        style.configure("SidebarMuted.TLabel", background="#E7EBF0", foreground=c["muted"], font=FONTS["small"])
        style.configure("Nav.TButton", font=FONTS["body"], padding=(10, 8), anchor="e", background="#E7EBF0", foreground=c["text"], bordercolor=c["border"], focusthickness=0)
        style.configure("NavCollapsed.TButton", font=("Tahoma", 12, "bold"), padding=(8, 9), anchor="center", background=c["navy"], foreground=c["sidebar_text"], bordercolor=c["navy"], focusthickness=0)
        style.map("NavCollapsed.TButton", background=[("active", c["navy_hover"])], foreground=[("active", c["white"])])
        style.configure("NavCollapsedActive.TButton", font=("Tahoma", 12, "bold"), padding=(8, 9), anchor="center", background=c["navy_selected"], foreground=c["white"], bordercolor=c["blue_primary"], focusthickness=0)
        style.map("NavCollapsedActive.TButton", background=[("active", c["navy_selected"])], foreground=[("active", c["white"])])
        style.map("Nav.TButton", background=[("active", c["navy_hover"])], foreground=[("active", c["white"])])
        style.configure("NavActive.TButton", font=("Tahoma", 10, "bold"), padding=(10, 8), anchor="e", background=c["navy_selected"], foreground=c["navy"], bordercolor=c["blue_primary"], focusthickness=0)
        style.map("NavActive.TButton", background=[("active", c["navy_selected"])], foreground=[("active", c["white"])])
        style.configure("Primary.TButton", font=("Tahoma", 9, "bold"), padding=(11, 7), background=c["blue_primary"], foreground=c["white"], bordercolor=c["blue_primary"])
        style.map("Primary.TButton", background=[("active", c["blue_hover"])], foreground=[("active", c["white"])])
        style.configure("TCombobox", padding=5, font=FONTS["body"], fieldbackground=c["surface"], foreground=c["text"])
        style.configure("WorkspaceTab.TButton", font=FONTS["small"], padding=(10, 7), background=c["gray"], foreground=c["text"], bordercolor=c["border"])
        style.map("WorkspaceTab.TButton", background=[("active", c["blue_light"])])
        style.configure("WorkspaceTabActive.TButton", font=("Tahoma", 9, "bold"), padding=(10, 7), background=c["blue_primary"], foreground=c["white"], bordercolor=c["blue_primary"])
        style.map("WorkspaceTabActive.TButton", background=[("active", c["blue_hover"])], foreground=[("active", c["white"])])
        style.configure("Treeview", background=c["surface"], fieldbackground=c["surface"], foreground=c["text"], rowheight=30, font=FONTS["body"])
        style.configure("Treeview.Heading", background=c["blue_light"], foreground=c["navy"], font=FONTS["section"], padding=7, relief="flat")
        style.map("Treeview", background=[("selected", c["blue_light"])], foreground=[("selected", c["navy"])])
        style.configure("TEntry", padding=7, fieldbackground=c["surface"], foreground=c["text"])
        style.configure("TCombobox", padding=7, fieldbackground=c["surface"], foreground=c["text"])
        style.configure("TButton", font=FONTS["body"], padding=(10, 7))
        style.configure("Secondary.TButton", font=FONTS["body"], padding=(10, 7),
                        background=c["gray"], foreground=c["text"], bordercolor=c["border"])
        style.map("Secondary.TButton", background=[("active", c["blue_light"])])
        style.configure("Danger.TButton", font=FONTS["body"], padding=(10, 7),
                        background="#A83B45", foreground=c["white"], bordercolor="#A83B45")
        style.map("Danger.TButton", background=[("active", "#8F2F38")])
        style.configure("TLabelframe", background=c["surface"], bordercolor=c["border"], relief="solid")
        style.configure("TLabelframe.Label", background=c["surface"], foreground=c["navy"],
                        font=FONTS["section"])
        style.configure("TCheckbutton", background=c["surface"], foreground=c["text"], font=FONTS["body"])
        style.configure("TRadiobutton", background=c["surface"], foreground=c["text"], font=FONTS["body"])
        style.configure("Treeview", background=c["surface"], fieldbackground=c["surface"],
                        foreground=c["text"], rowheight=34, font=FONTS["body"], bordercolor=c["border"])
        style.configure("Treeview.Heading", background=c["blue_light"], foreground=c["navy"],
                        font=FONTS["section"], padding=(9, 9), relief="flat")
        style.map("Treeview", background=[("selected", c["blue_light"])],
                  foreground=[("selected", c["navy"])])
        style.configure("TScrollbar", background=c["gray"], troughcolor=c["ivory"],
                        bordercolor=c["ivory"], arrowsize=13)
        style.configure("FormHint.TLabel", background=c["surface"], foreground=c["muted"], font=FONTS["small"])
        style.configure("FormRequired.TLabel", background=c["surface"], foreground="#A83B45", font=FONTS["body"])
        # The active workspace uses a plain frame host, not ttk.Notebook.
        # This removes the global tab strip structurally and is theme-independent.
        self.root.title("AuditSystem | سامانه حرفه‌ای مدیریت حسابرسی")
        self.root.geometry("1360x850")
        self.root.minsize(1050, 680)

        shell = ttk.Frame(self.root, padding=10)
        shell.pack(fill="both", expand=True)
        self.main_shell = shell

        # A custom right-to-left menu strip is used instead of the native
        # Windows/Tk menu bar, whose cascade ordering is platform-dependent.
        self.classic_menu_bar = ttk.Frame(shell, style="Card.TFrame", padding=(6, 4))
        self.classic_menu_bar.pack(fill="x", pady=(0, 8))

        header = ttk.Frame(shell, style="Card.TFrame", padding=(16, 10))
        header.pack(fill="x", pady=(0, 10))
        header.columnconfigure(0, weight=1)
        brand = ttk.Frame(header, style="Card.TFrame")
        brand.grid(row=0, column=0, sticky="w")
        ttk.Label(brand, text="AuditSystem", style="Header.TLabel").pack(anchor="w")
        ttk.Label(brand, text="سامانه یکپارچه مدیریت و اجرای حسابرسی", style="Muted.TLabel").pack(anchor="w", pady=(2, 0))

        controls = ttk.Frame(header, style="Card.TFrame")
        controls.grid(row=0, column=1, sticky="e")
        ttk.Label(controls, text="پرونده فعال:", style="Muted.TLabel").pack(side="right", padx=(8, 4))
        self.combo_project = ttk.Combobox(controls, state="readonly", width=30)
        self.combo_project.pack(side="right", padx=4, pady=5)
        self.combo_project.bind("<<ComboboxSelected>>", self.on_project_selected)
        ttk.Button(controls, text="＋ پرونده جدید", style="Primary.TButton", command=self.popup_new_project).pack(side="right", padx=4)
        ttk.Label(controls, text="عضو فعال:", style="Muted.TLabel").pack(side="right", padx=(12, 4))
        self.combo_active_member = ttk.Combobox(controls, state="readonly", width=24)
        self.combo_active_member.pack(side="right", padx=4, pady=5)
        self.combo_active_member.bind("<<ComboboxSelected>>", self.on_active_member_selected)
        ttk.Button(controls, text="گزارش یکپارچه", style="Primary.TButton", command=self.export_project_data).pack(side="right", padx=(8, 0))
        self.lbl_active_member = ttk.Label(header, text="عضو فعالی انتخاب نشده است", style="Muted.TLabel")
        self.lbl_active_member.grid(row=1, column=0, columnspan=2, sticky="e", pady=(7, 0))

        body = ttk.Frame(shell)
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=1)
        body.rowconfigure(0, weight=1)

        workspace_area = ttk.Frame(body)
        workspace_area.grid(row=0, column=0, sticky="nsew")
        workspace_area.columnconfigure(0, weight=1)
        # Classic horizontal module tabs, with a native Office-style menu above.
        self.workspace_tabs_bar = ttk.Frame(workspace_area, style="Card.TFrame", padding=(5, 4))
        self.workspace_tabs_bar.grid(row=0, column=0, sticky="ew", pady=(0, 7))
        self.workspace_tabs_canvas = tk.Canvas(self.workspace_tabs_bar, height=34, bg="#E7EBF0", highlightthickness=0, bd=0)
        self.workspace_tabs_scroll = ttk.Scrollbar(self.workspace_tabs_bar, orient="horizontal", command=self.workspace_tabs_canvas.xview)
        self.workspace_tabs_canvas.configure(xscrollcommand=self.workspace_tabs_scroll.set)
        # RTL tab strip: the right edge is the logical start of the Persian tab order.
        self.workspace_tabs_canvas.pack(side="top", fill="x", expand=True)
        self.workspace_tabs_scroll.pack(side="bottom", fill="x")
        self.workspace_tabs_inner = ttk.Frame(self.workspace_tabs_canvas, style="Card.TFrame")
        self.workspace_tabs_window = self.workspace_tabs_canvas.create_window(
            (0, 0), window=self.workspace_tabs_inner, anchor="ne", height=34
        )
        self.workspace_tabs_inner.bind("<Configure>", self._position_workspace_tabs)
        self.workspace_tabs_canvas.bind("<Configure>", self._position_workspace_tabs)
        self._opened_workspace_titles = []
        self._workspace_tab_buttons = {}
        self.workspace_header = ttk.Frame(workspace_area, style="Card.TFrame", padding=(14, 9))
        self.workspace_header.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self.workspace_header.columnconfigure(0, weight=1)
        self.workspace_title = ttk.Label(
            self.workspace_header, text="▣ داشبورد", style="Header.TLabel", anchor="e"
        )
        self.workspace_title.grid(row=0, column=0, sticky="e")
        self.workspace_breadcrumb = ttk.Label(
            self.workspace_header, text="سامانه  ‹  نمای کلی  ‹  داشبورد",
            style="WorkspaceBreadcrumb.TLabel", anchor="e"
        )
        self.workspace_breadcrumb.grid(row=1, column=0, sticky="e", pady=(3, 0))
        self.workspace_context = ttk.Label(
            self.workspace_header, text="پرونده‌ای انتخاب نشده است",
            style="WorkspaceContext.TLabel", anchor="w"
        )
        self.workspace_context.grid(row=0, column=1, rowspan=2, sticky="w", padx=(14, 0))
        self.workspace_host = ttk.Frame(workspace_area)
        self.workspace_host.grid(row=2, column=0, sticky="nsew")
        self.workspace_host.rowconfigure(0, weight=1)
        self.workspace_host.columnconfigure(0, weight=1)
        workspace_area.rowconfigure(2, weight=1)

        self.tab_projects = ttk.Frame(self.workspace_host)
        self.tab_archive = ttk.Frame(self.workspace_host)
        self.tab_dashboard = ttk.Frame(self.workspace_host)
        self.tab_report_center = ttk.Frame(self.workspace_host)
        self.tab_risks = ttk.Frame(self.workspace_host)
        self.tab_workpapers = ttk.Frame(self.workspace_host)
        self.tab_findings = ttk.Frame(self.workspace_host)
        self.tab_benford = ttk.Frame(self.workspace_host)
        self.tab_ratios = ttk.Frame(self.workspace_host)
        self.tab_sampling = ttk.Frame(self.workspace_host)
        self.tab_tb = ttk.Frame(self.workspace_host)
        self.tab_team = ttk.Frame(self.workspace_host)
        self.tab_team_workspace = ttk.Frame(self.workspace_host)
        self.tab_audit_tests = ttk.Frame(self.workspace_host)
        self.tab_audit_file = ttk.Frame(self.workspace_host)
        self.tab_audit_traceability = ttk.Frame(self.workspace_host)
        self.tab_documents = ttk.Frame(self.workspace_host)
        self.tab_misstatements = ttk.Frame(self.workspace_host)
        self.tab_engagement_assessment = ttk.Frame(self.workspace_host)
        self.tab_approval_center = ttk.Frame(self.workspace_host)
        self.tab_unified_execution = ttk.Frame(self.workspace_host)
        self.tab_internal_controls = ttk.Frame(self.workspace_host)
        self.tab_coso_framework = ttk.Frame(self.workspace_host)
        self.tab_risk_center = ttk.Frame(self.workspace_host)

        # Backward-compatible module identity: (self.tab_approval_center, "۱۵. مرکز تأییدها")
        tabs = [
            (self.tab_dashboard, "داشبورد"),
            (self.tab_report_center, "مرکز جامع گزارشات"),
            (self.tab_projects, "مدیریت پرونده‌ها"),
            (self.tab_archive, "بایگانی پرونده‌ها"),
            (self.tab_risks, "ریسک‌ها"),
            (self.tab_workpapers, "کاربرگ‌ها"),
            (self.tab_audit_tests, "برنامه‌ها و آزمون‌های حسابرسی"),
            (self.tab_sampling, "نمونه‌گیری"),
            (self.tab_tb, "تراز آزمایشی"),
            (self.tab_unified_execution, "اجرای یکپارچه حسابرسی"),
            (self.tab_internal_controls, "کنترل‌های داخلی"),
            (self.tab_risk_center, "مرکز ریسک"),
            (self.tab_coso_framework, "چارچوب و چک‌لیست COSO"),
            (self.tab_findings, "یافته‌ها و اقدامات اصلاحی"),
            (self.tab_misstatements, "تحریفات و اهمیت"),
            (self.tab_engagement_assessment, "ارزیابی نهایی پرونده"),
            (self.tab_approval_center, "مرکز تأییدها"),
            (self.tab_documents, "اسناد و درخواست مدارک"),
            (self.tab_audit_file, "کنترل کیفیت پرونده"),
            (self.tab_audit_traceability, "ردیابی حسابرسی"),
            (self.tab_team, "اعضای تیم"),
            (self.tab_team_workspace, "مرکز ارتباطات تیم"),
            (self.tab_benford, "تحلیل بنفورد"),
            (self.tab_ratios, "تحلیل M-Score"),
        ]
        for frame, title in tabs:
            frame.grid(row=0, column=0, sticky="nsew")
        self._tabs = tabs
        self.workspace_pages = {title: frame for frame, title in tabs}


        sidebar = ttk.Frame(body, style="Sidebar.TFrame", padding=9, width=272)
        sidebar.grid(row=0, column=1, sticky="ns")
        sidebar.grid_propagate(False)
        self.sidebar_frame = sidebar
        self.sidebar_collapsed = False
        self.sidebar_expanded_width = 272
        self.sidebar_collapsed_width = 76
        sidebar_canvas = tk.Canvas(
            sidebar, bg=PALETTE["navy"], highlightthickness=0, width=244,
            xscrollincrement=24, yscrollincrement=36
        )
        sidebar_scrollbar = ttk.Scrollbar(sidebar, orient="vertical", command=sidebar_canvas.yview)
        sidebar_hscrollbar = ttk.Scrollbar(sidebar, orient="horizontal", command=sidebar_canvas.xview)
        sidebar_canvas.pack(side="left", fill="both", expand=True)
        sidebar_scrollbar.pack(side="right", fill="y")
        sidebar_hscrollbar.pack(side="bottom", fill="x")
        sidebar_canvas.configure(
            yscrollcommand=sidebar_scrollbar.set,
            xscrollcommand=sidebar_hscrollbar.set
        )
        sidebar_content = ttk.Frame(sidebar_canvas, style="Sidebar.TFrame")
        sidebar_window = sidebar_canvas.create_window((0, 0), window=sidebar_content, anchor="nw")

        def sync_sidebar_scrollregion(_event=None):
            sidebar_canvas.update_idletasks()
            required_width = sidebar_content.winfo_reqwidth()
            visible_width = sidebar_canvas.winfo_width()
            # Keep a minimum viewport width, but allow long module labels to
            # extend beyond it and become reachable via the horizontal bar.
            sidebar_canvas.itemconfigure(sidebar_window, width=max(required_width, visible_width))
            sidebar_canvas.configure(scrollregion=sidebar_canvas.bbox("all"))

        sidebar_content.bind("<Configure>", sync_sidebar_scrollregion)
        sidebar_canvas.bind("<Configure>", sync_sidebar_scrollregion)

        def sidebar_mousewheel(event):
            if getattr(event, "state", 0) & 0x0001:  # Shift + wheel => horizontal
                sidebar_canvas.xview_scroll(-1 if event.delta > 0 else 1, "units")
            else:
                sidebar_canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
            return "break"

        sidebar_canvas.bind("<MouseWheel>", sidebar_mousewheel)
        sidebar_content.bind("<MouseWheel>", sidebar_mousewheel)
        sidebar_canvas.bind("<Shift-MouseWheel>", sidebar_mousewheel)
        sidebar_content.bind("<Shift-MouseWheel>", sidebar_mousewheel)
        self.sidebar_toggle = ttk.Button(
            sidebar_content, text="◀ جمع‌کردن منو", style="Nav.TButton",
            command=self.toggle_sidebar
        )
        self.sidebar_toggle.pack(fill="x", pady=(2, 8))
        self.sidebar_header_label = ttk.Label(sidebar_content, text="ناوبری سامانه", style="SidebarHeader.TLabel")
        self.sidebar_header_label.pack(anchor="e", pady=(4, 10))
        self.nav_search_var = tk.StringVar()
        self.sidebar_search_label = ttk.Label(sidebar_content, text="جستجوی ماژول", style="SidebarMuted.TLabel")
        self.sidebar_search_label.pack(anchor="e")
        self.sidebar_search_entry = ttk.Entry(sidebar_content, textvariable=self.nav_search_var, justify="right")
        self.sidebar_search_entry.pack(fill="x", pady=(3, 10), ipady=5)
        self.nav_buttons = []
        self._nav_items = []
        self._nav_group_labels = []
        group_titles = {
            "داشبورد": "نمای کلی", "مرکز جامع گزارشات": "گزارشات و تحلیل", "مدیریت پرونده‌ها": "پرونده و تیم",
            "بایگانی پرونده‌ها": "پرونده و تیم", "اعضای تیم": "پرونده و تیم",
            "مرکز ارتباطات تیم": "پرونده و تیم",
            "ریسک‌ها": "برنامه‌ریزی و اجرا", "کاربرگ‌ها": "برنامه‌ریزی و اجرا",
            "برنامه‌ها و آزمون‌های حسابرسی": "برنامه‌ریزی و اجرا", "نمونه‌گیری": "برنامه‌ریزی و اجرا",
            "تراز آزمایشی": "برنامه‌ریزی و اجرا", "اجرای یکپارچه حسابرسی": "برنامه‌ریزی و اجرا",
            "کنترل‌های داخلی": "ریسک و کنترل داخلی", "مرکز ریسک": "ریسک و کنترل داخلی", "چارچوب و چک‌لیست COSO": "ریسک و کنترل داخلی",
            "یافته‌ها و اقدامات اصلاحی": "نتایج و گزارش", "تحریفات و اهمیت": "نتایج و گزارش",
            "ارزیابی نهایی پرونده": "نتایج و گزارش", "مرکز تأییدها": "نظارت و کیفیت",
            "اسناد و درخواست مدارک": "نظارت و کیفیت", "کنترل کیفیت پرونده": "نظارت و کیفیت",
            "ردیابی حسابرسی": "نظارت و کیفیت", "تحلیل بنفورد": "ابزارهای تحلیلی", "تحلیل M-Score": "ابزارهای تحلیلی",
        }
        current_group = None
        for frame, title in tabs:
            group = group_titles[title]
            if group != current_group:
                group_label = ttk.Label(sidebar_content, text=group, style="SidebarGroup.TLabel")
                group_label.pack(anchor="e", pady=(9, 3))
                self._nav_group_labels.append(group_label)
                current_group = group
            icon = self._module_icon(title)
            btn = ttk.Button(sidebar_content, text=f"{icon}  {title}", style="Nav.TButton", command=lambda f=frame, t=title: self.show_workspace(f, t))
            btn.pack(fill="x", pady=2)
            btn.bind("<MouseWheel>", sidebar_mousewheel)
            btn.bind("<Shift-MouseWheel>", sidebar_mousewheel)
            self.nav_buttons.append(btn)
            self._nav_items.append((btn, title, frame, icon))
            btn.bind("<Enter>", lambda event, t=title: self._show_nav_tooltip(event, t))
            btn.bind("<Leave>", self._hide_nav_tooltip)
        self.nav_search_var.trace_add("write", self.filter_navigation)
        # Keep legacy navigation widgets instantiated for backward compatibility,
        # but remove the duplicate side navigation from the visible layout.
        sidebar.grid_remove()
        self._build_classic_application_menu(tabs, group_titles)
        self.show_workspace(self.tab_dashboard, "داشبورد")

        # All original view setup routines are retained without modification.
        self.setup_project_tab()
        self.setup_archive_tab()
        self.setup_dashboard_tab()
        self.setup_report_center_tab()
        self.setup_risk_tab()
        self.setup_workpaper_tab()
        self.setup_finding_tab()
        self.setup_benford_tab()
        self.setup_ratio_tab()
        self.setup_sampling_tab()
        self.setup_trial_balance_tab()
        self.setup_team_tab()
        self.setup_team_workspace_tab()
        self.setup_audit_test_tab()
        self.setup_audit_file_tab()
        self.setup_audit_traceability_tab()
        self.setup_document_center_tab()
        self.setup_misstatement_tab()
        self.setup_engagement_assessment_tab()
        self.setup_approval_center_tab()
        self.setup_unified_audit_execution_tab()
        self.setup_internal_control_tab()
        self.setup_risk_center_tab()
        self.setup_coso_framework_tab()

    def _style_dialog(self, window):
        """Apply the shared Financial Enterprise surface to an existing dialog.

        This is intentionally presentation-only: it does not change modality,
        geometry, callbacks, validation, or the dialog's data lifecycle.
        """
        try:
            window.configure(background=PALETTE["ivory"])
        except tk.TclError:
            pass
        return window

    def _build_classic_application_menu(self, tabs, group_titles):
        """Build a custom Office-like menu whose visual order is truly Persian RTL.

        Buttons are packed from right to left. This avoids relying on the
        native Windows menu bar, which controls cascade placement itself.
        """
        if hasattr(self, "classic_menu_bar"):
            for child in self.classic_menu_bar.winfo_children():
                child.destroy()
        else:
            self.classic_menu_bar = ttk.Frame(self.main_shell, style="Card.TFrame", padding=(6, 4))
            self.classic_menu_bar.pack(fill="x", pady=(0, 8))

        grouped = {}
        for frame, title in tabs:
            grouped.setdefault(group_titles.get(title, "سایر بخش‌ها"), []).append((frame, title))

        menu_order = [
            "پرونده و تیم", "برنامه‌ریزی و اجرا", "ریسک و کنترل داخلی",
            "نتایج و گزارش", "نظارت و کیفیت", "ابزارهای تحلیلی",
            "نمای کلی", "گزارشات و تحلیل",
        ]
        captions = {
            "پرونده و تیم": "پرونده",
            "برنامه‌ریزی و اجرا": "عملیات حسابرسی",
            "ریسک و کنترل داخلی": "ریسک و کنترل",
            "نتایج و گزارش": "یافته‌ها و نتایج",
            "نظارت و کیفیت": "نظارت و کیفیت",
            "ابزارهای تحلیلی": "ابزارها",
            "نمای کلی": "نمای کلی",
            "گزارشات و تحلیل": "گزارشات",
        }

        self.classic_menu_buttons = {}
        self.classic_dropdown_menus = {}

        # pack(side="right") makes the first item the rightmost item.
        # Therefore the logical Persian order is inserted as-is, not reversed.
        for group in menu_order:
            entries = grouped.get(group, [])
            if not entries:
                continue
            menu = tk.Menu(
                self.root, tearoff=False, font=("Tahoma", 9),
                activebackground="#DCE8F5", activeforeground="#183B63",
                background="#FFFFFF", foreground="#24364B",
                borderwidth=1, relief="solid", bd=1,
            )
            for frame, title in entries:
                menu.add_command(
                    label=title,
                    command=lambda f=frame, t=title: self.show_workspace(f, t),
                    compound="right",
                )
            button = ttk.Button(
                self.classic_menu_bar,
                text=captions.get(group, group) + "  ▾",
                style="Secondary.TButton",
                command=lambda m=menu: self._popup_rtl_application_menu(m, self.classic_menu_buttons.get(m)),
            )
            # Store before binding the callback, so popup alignment can find
            # the exact button even if the user clicks immediately.
            self.classic_menu_buttons[menu] = button
            self.classic_dropdown_menus[group] = menu
            button.pack(side="right", padx=2, pady=1)

        system_menu = tk.Menu(
            self.root, tearoff=False, font=("Tahoma", 9),
            activebackground="#DCE8F5", activeforeground="#183B63",
            background="#FFFFFF", foreground="#24364B",
        )
        system_menu.add_command(
            label="بازگشت به داشبورد",
            command=lambda: self.show_workspace(self.tab_dashboard, "داشبورد"),
            compound="right",
        )
        system_menu.add_separator()
        system_menu.add_command(label="خروج", command=self.root.destroy, compound="right")
        system_button = ttk.Button(
            self.classic_menu_bar, text="سامانه  ▾", style="Secondary.TButton",
            command=lambda m=system_menu: self._popup_rtl_application_menu(m, system_button),
        )
        system_button.pack(side="right", padx=2, pady=1)
        self.classic_menu_buttons[system_menu] = system_button
        self.classic_dropdown_menus["سامانه"] = system_menu

        # Explicitly disable the platform-native menubar to avoid a second,
        # left-to-right menu appearing above the custom Persian menu strip.
        try:
            self.root.configure(menu="")
        except tk.TclError:
            pass

    def _popup_rtl_application_menu(self, menu, button):
        """Open a dropdown with its right edge aligned to its RTL menu button."""
        if button is None:
            return
        self.root.update_idletasks()
        menu_width = max(menu.winfo_reqwidth(), 120)
        x = button.winfo_rootx() + button.winfo_width() - menu_width
        y = button.winfo_rooty() + button.winfo_height()
        try:
            menu.tk_popup(max(0, x), y)
        finally:
            try:
                menu.grab_release()
            except tk.TclError:
                pass

    def _refresh_classic_workspace_tabs(self, active_title):
        """Render opened modules as compact, scrollable right-to-left document tabs."""
        if not hasattr(self, "workspace_tabs_inner"):
            return
        if active_title not in self._opened_workspace_titles:
            self._opened_workspace_titles.append(active_title)
        for child in self.workspace_tabs_inner.winfo_children():
            child.destroy()
        self._workspace_tab_buttons = {}
        # pack(side="right") places the first child at the right edge;
        # newest/active Persian workspace tab must therefore be rendered first.
        for title in reversed(self._opened_workspace_titles):
            frame = self.workspace_pages.get(title)
            active = title == active_title
            btn = ttk.Button(
                self.workspace_tabs_inner,
                text=("● " if active else "") + title,
                style="WorkspaceTabActive.TButton" if active else "WorkspaceTab.TButton",
                command=lambda f=frame, t=title: self.show_workspace(f, t),
            )
            btn.pack(side="right", padx=2, pady=1)
            self._workspace_tab_buttons[title] = btn
        self.workspace_tabs_canvas.update_idletasks()
        self._position_workspace_tabs()

    def _position_workspace_tabs(self, _event=None):
        """Keep the tab strip right-aligned and scroll from the Persian start."""
        if not hasattr(self, "workspace_tabs_canvas"):
            return
        canvas_width = max(1, self.workspace_tabs_canvas.winfo_width())
        content_width = max(canvas_width, self.workspace_tabs_inner.winfo_reqwidth())
        self.workspace_tabs_canvas.itemconfigure(
            self.workspace_tabs_window, width=content_width, height=34
        )
        self.workspace_tabs_canvas.coords(self.workspace_tabs_window, content_width, 0)
        self.workspace_tabs_canvas.configure(scrollregion=(0, 0, content_width, 34))
        self.workspace_tabs_canvas.xview_moveto(1.0)

    def _module_icon(self, title):
        icons = {
            "داشبورد": "▣", "مرکز جامع گزارشات": "▥", "مدیریت پرونده‌ها": "▤", "بایگانی پرونده‌ها": "▥", "ریسک‌ها": "⚑",
            "کاربرگ‌ها": "▧", "برنامه‌ها و آزمون‌های حسابرسی": "☑", "نمونه‌گیری": "⌗", "تراز آزمایشی": "▦",
            "اجرای یکپارچه حسابرسی": "◈", "کنترل‌های داخلی": "▣", "مرکز ریسک": "▦", "چارچوب و چک‌لیست COSO": "◇",
            "یافته‌ها و اقدامات اصلاحی": "⚒", "تحریفات و اهمیت": "∑", "ارزیابی نهایی پرونده": "✓",
            "مرکز تأییدها": "✪", "اسناد و درخواست مدارک": "▣", "کنترل کیفیت پرونده": "◎", "ردیابی حسابرسی": "↗",
            "اعضای تیم": "♙", "تحلیل بنفورد": "∿", "تحلیل M-Score": "ƒ",
        }
        return icons.get(title, "▣")

    def _build_workspace_tabs(self, active_title):
        """Deprecated compatibility hook; unified navigation has no global tab strip."""
        return None

    def _workspace_group_for_title(self, title):
        """Return the navigation group used in the workspace breadcrumb."""
        groups = {
            "داشبورد": "نمای کلی",
            "مدیریت پرونده‌ها": "پرونده و تیم", "بایگانی پرونده‌ها": "پرونده و تیم",
            "اعضای تیم": "پرونده و تیم", "مرکز ارتباطات تیم": "پرونده و تیم",
            "ریسک‌ها": "برنامه‌ریزی و اجرا", "کاربرگ‌ها": "برنامه‌ریزی و اجرا",
            "برنامه‌ها و آزمون‌های حسابرسی": "برنامه‌ریزی و اجرا", "نمونه‌گیری": "برنامه‌ریزی و اجرا",
            "تراز آزمایشی": "برنامه‌ریزی و اجرا", "اجرای یکپارچه حسابرسی": "برنامه‌ریزی و اجرا",
            "کنترل‌های داخلی": "ریسک و کنترل داخلی", "مرکز ریسک": "ریسک و کنترل داخلی",
            "چارچوب و چک‌لیست COSO": "ریسک و کنترل داخلی",
            "یافته‌ها و اقدامات اصلاحی": "نتایج و گزارش", "تحریفات و اهمیت": "نتایج و گزارش",
            "ارزیابی نهایی پرونده": "نتایج و گزارش",
            "مرکز تأییدها": "نظارت و کیفیت", "اسناد و درخواست مدارک": "نظارت و کیفیت",
            "کنترل کیفیت پرونده": "نظارت و کیفیت", "ردیابی حسابرسی": "نظارت و کیفیت",
            "تحلیل بنفورد": "ابزارهای تحلیلی", "تحلیل M-Score": "ابزارهای تحلیلی",
        }
        return groups.get(title, "فضای کاری")

    def _refresh_workspace_context(self):
        """Refresh the compact, factual context shown in the workspace header."""
        project_text = self.combo_project.get().strip() if hasattr(self, "combo_project") else ""
        if not project_text or project_text.startswith("ابتدا"):
            project_text = "پرونده‌ای انتخاب نشده است"
        else:
            project_text = f"پرونده: {project_text}"
        member = getattr(self, "active_member", None)
        if member and member.get("full_name"):
            project_text += f"  |  عضو: {member['full_name']}"
        self.workspace_context.config(text=project_text)

    def show_workspace(self, frame, title=None):
        """Select a module through the single navigation sidebar."""
        # Raise the selected page in the frame host. No Notebook/tab strip exists.
        frame.tkraise()
        title = title or "فضای کاری"
        group = self._workspace_group_for_title(title)
        self.current_workspace_title = title
        self.workspace_title.config(text=f"{self._module_icon(title)}  {title}")
        self.workspace_breadcrumb.config(text=f"سامانه  ‹  {group}  ‹  {title}")
        self._refresh_workspace_context()
        self._refresh_classic_workspace_tabs(title)
        for button, button_title, _frame, _icon in self._nav_items:
            button.configure(style=("NavCollapsedActive.TButton" if self.sidebar_collapsed else "NavActive.TButton") if button_title == title else ("NavCollapsed.TButton" if self.sidebar_collapsed else "Nav.TButton"))

    def toggle_sidebar(self):
        """Collapse the module sidebar to icon-only mode or restore it."""
        self.sidebar_collapsed = not self.sidebar_collapsed
        if self.sidebar_collapsed:
            self.sidebar_frame.configure(width=self.sidebar_collapsed_width)
            self.sidebar_toggle.configure(text="▶", style="Nav.TButton")
            self.sidebar_header_label.pack_forget()
            self.sidebar_search_label.pack_forget()
            self.sidebar_search_entry.pack_forget()
            for label in self._nav_group_labels:
                label.pack_forget()
            for button, title, frame, icon in self._nav_items:
                is_active = title == getattr(self, "current_workspace_title", None)
                button.configure(text=icon, width=3, style=("NavCollapsedActive.TButton" if is_active else "NavCollapsed.TButton"))
                button.pack(fill="x", pady=3)
        else:
            self.sidebar_frame.configure(width=self.sidebar_expanded_width)
            self.sidebar_toggle.configure(text="◀ جمع‌کردن منو", style="Nav.TButton")
            # Rebuild the expanded layout in a deterministic pack order.
            self.sidebar_header_label.pack_forget()
            self.sidebar_search_label.pack_forget()
            self.sidebar_search_entry.pack_forget()
            for widget in self.nav_buttons + self._nav_group_labels:
                widget.pack_forget()
            self.sidebar_header_label.pack(anchor="e", pady=(4, 10))
            self.sidebar_search_label.pack(anchor="e")
            self.sidebar_search_entry.pack(fill="x", pady=(3, 10), ipady=5)
            group_index = 0
            last_group = None
            group_titles = {
                "داشبورد": "نمای کلی", "مرکز جامع گزارشات": "گزارشات و تحلیل", "مدیریت پرونده‌ها": "پرونده و تیم",
                "بایگانی پرونده‌ها": "پرونده و تیم", "اعضای تیم": "پرونده و تیم",
            "مرکز ارتباطات تیم": "پرونده و تیم",
                "ریسک‌ها": "برنامه‌ریزی و اجرا", "کاربرگ‌ها": "برنامه‌ریزی و اجرا",
                "برنامه‌ها و آزمون‌های حسابرسی": "برنامه‌ریزی و اجرا", "نمونه‌گیری": "برنامه‌ریزی و اجرا",
                "تراز آزمایشی": "برنامه‌ریزی و اجرا", "اجرای یکپارچه حسابرسی": "برنامه‌ریزی و اجرا",
                "کنترل‌های داخلی": "ریسک و کنترل داخلی", "مرکز ریسک": "ریسک و کنترل داخلی", "چارچوب و چک‌لیست COSO": "ریسک و کنترل داخلی",
                "یافته‌ها و اقدامات اصلاحی": "نتایج و گزارش", "تحریفات و اهمیت": "نتایج و گزارش",
                "ارزیابی نهایی پرونده": "نتایج و گزارش", "مرکز تأییدها": "نظارت و کیفیت",
                "اسناد و درخواست مدارک": "نظارت و کیفیت", "کنترل کیفیت پرونده": "نظارت و کیفیت",
                "ردیابی حسابرسی": "نظارت و کیفیت", "تحلیل بنفورد": "ابزارهای تحلیلی", "تحلیل M-Score": "ابزارهای تحلیلی",
            }
            for button, title, frame, icon in self._nav_items:
                group = group_titles.get(title)
                if group and group != last_group:
                    self._nav_group_labels[group_index].pack(anchor="e", pady=(9, 3))
                    group_index += 1
                    last_group = group
                is_active = title == getattr(self, "current_workspace_title", None)
                button.configure(text=f"{icon}  {title}", width=0, style=("NavActive.TButton" if is_active else "Nav.TButton"))
                if not self.nav_search_var.get().strip() or self.nav_search_var.get().strip().casefold() in title.casefold():
                    button.pack(fill="x", pady=2)
        self.sidebar_canvas.update_idletasks()
        self.sidebar_canvas.configure(scrollregion=self.sidebar_canvas.bbox("all"))

    def _show_nav_tooltip(self, event, title):
        if not self.sidebar_collapsed:
            return
        self._hide_nav_tooltip()
        tip = tk.Toplevel(self.root)
        tip.wm_overrideredirect(True)
        tip.configure(bg=PALETTE["surface"])
        label = tk.Label(tip, text=title, bg=PALETTE["surface"], fg=PALETTE["text"],
                       font=FONTS["body"], padx=8, pady=4, relief="solid", borderwidth=1)
        label.pack()
        tip.geometry(f"+{event.x_root + 14}+{event.y_root + 8}")
        self._nav_tooltip = tip

    def _hide_nav_tooltip(self, _event=None):
        tip = getattr(self, "_nav_tooltip", None)
        if tip is not None:
            try:
                tip.destroy()
            except tk.TclError:
                pass
            self._nav_tooltip = None

    def filter_navigation(self, *_):
        """Filter the right-side scrollable module list without changing state."""
        query = self.nav_search_var.get().strip().casefold()
        for button, title, _frame, _icon in self._nav_items:
            if not query or query in title.casefold():
                button.pack(fill="x", pady=2)
            else:
                button.pack_forget()
        sidebar_content = self.nav_buttons[0].master if self.nav_buttons else None
        if sidebar_content:
            sidebar_content.update_idletasks()
            canvas = sidebar_content.master
            if hasattr(canvas, "yview"):
                canvas.configure(scrollregion=canvas.bbox("all"))

    def load_projects(self, select_id=None):

        previous_id = (
            select_id or self.get_current_project_id()
        )

        self.projects = [
            (r[0], r[1], r[2])
            for r in self.services.projects.active()
        ]

        self.combo_project["values"] = [
            f"{pid} - {name} ({period})"
            for pid, name, period in self.projects
        ]

        if self.projects:
            ids = [row[0] for row in self.projects]

            if previous_id in ids:
                self.combo_project.current(
                    ids.index(previous_id)
                )
            else:
                self.combo_project.current(0)

        else:
            self.combo_project.set(
                "ابتدا یک پرونده ایجاد کنید"
            )

        self.refresh_active_members()
        self.refresh_all_tabs()
        if hasattr(self, "team_workspace_inbox"):
            self.refresh_team_workspace()
        if hasattr(self, "workspace_context"):
            self._refresh_workspace_context()

    def get_current_project_id(self):

        index = self.combo_project.current()

        if 0 <= index < len(self.projects):
            return self.projects[index][0]

        return None

    def refresh_active_members(self):

        self.active_member_id = None
        self.active_member = None
        self.project_members = []

        if not hasattr(self, "combo_active_member"):
            return

        project_id = self.get_current_project_id()

        self.combo_active_member.set("")
        self.combo_active_member["values"] = []

        if not project_id:
            self.lbl_active_member.config(
                text="ابتدا پرونده را انتخاب کنید"
            )
            return

        self.project_members = (
            self.services.team.for_project(
                project_id,
                active_only=True
            )
        )

        member_labels = [
            f"{row[0]} - {row[1]} ({row[2]})"
            for row in self.project_members
        ]

        self.combo_active_member["values"] = member_labels

        if member_labels:
            self.lbl_active_member.config(
                text="لطفاً عضو فعال را انتخاب کنید"
            )
        else:
            self.lbl_active_member.config(
                text="این پرونده عضو فعال ندارد"
            )

    def on_active_member_selected(self, event=None):

        index = self.combo_active_member.current()

        if not (0 <= index < len(self.project_members)):
            self.active_member_id = None
            self.active_member = None
            return

        row = self.project_members[index]

        self.active_member_id = row[0]

        self.active_member = {
            "id": row[0],
            "project_id": self.get_current_project_id(),
            "full_name": row[1],
            "role": row[2],
        }

        self.lbl_active_member.config(
            text=f"عضو جاری: {row[1]} ـ {row[2]}"
        )
        self._refresh_workspace_context()
        if hasattr(self, "team_workspace_inbox"):
            self.refresh_team_workspace()
        if hasattr(self, "approval_inbox_tree"):
            self.refresh_approval_center()

    def get_active_member(self):

        if not self.active_member_id:
            return None

        project_id = self.get_current_project_id()

        if not project_id:
            return None

        member = self.services.team.get(
            self.active_member_id
        )

        if not member:
            self.refresh_active_members()
            return None

        if member[1] != project_id or not member[6]:
            self.refresh_active_members()
            return None

        return {
            "id": member[0],
            "project_id": member[1],
            "full_name": member[2],
            "role": member[3],
        }

    def on_project_selected(self, event=None):

        self.selected_samples = []
        self.sample_seed = None

        self.active_member_id = None
        self.active_member = None

        self.clear_tree(self.tree_samples)

        self.lbl_sample.config(
            text="برای این پرونده هنوز نمونه‌ای انتخاب نشده است."
        )

        self.refresh_active_members()
        self.refresh_all_tabs()
        self._refresh_workspace_context()

    def popup_new_project(self):
        self.popup_project_form()

    def refresh_all_tabs(self):

        self.refresh_project_list()
        self.refresh_risks()
        self.refresh_workpapers()
        self.refresh_findings()
        if hasattr(self, "document_center_status"):
            self.refresh_document_center()
        if hasattr(self, "misstatement_summary"):
            self.refresh_misstatements()
        if hasattr(self, "assessment_tree"):
            self.refresh_engagement_assessment()
        if hasattr(self, "approval_tree"):
            self.refresh_approval_center()
        if hasattr(self, "unified_gap_tree"):
            self.refresh_unified_execution()
        if hasattr(self, "internal_control_tree"):
            self.refresh_internal_controls()
        if hasattr(self, "risk_center_canvas"):
            self.refresh_risk_center()
        if hasattr(self, "coso_tree"):
            self.refresh_coso_framework()
        self.refresh_trial_balance()
        self.refresh_dashboard()
        self.refresh_team()
        if hasattr(self, "team_workspace_inbox"):
            self.refresh_team_workspace()
        self.refresh_audit_tests()
        self.refresh_audit_file_quality()
        self.refresh_audit_traceability()
