"""Compatibility facade: UI tabs are separated into focused mixins."""
import os, sqlite3, tkinter as tk
from tkinter import ttk
from database.connection import connect as db_connect
from config.settings import DATABASE_PATH
from ui.views.risk_view import RiskViewMixin
from ui.views.workpaper_view import WorkpaperViewMixin
from ui.views.finding_view import FindingViewMixin
from ui.views.benford_view import BenfordViewMixin
from ui.views.analysis_view import AnalysisViewMixin
from ui.views.sampling_view import SamplingViewMixin
from ui.views.trial_balance_view import TrialBalanceViewMixin
from ui.views.report_view import ReportViewMixin
from services.application_services import ApplicationServices

class AuditApp(
    RiskViewMixin, WorkpaperViewMixin, FindingViewMixin, BenfordViewMixin,
    AnalysisViewMixin, SamplingViewMixin, TrialBalanceViewMixin, ReportViewMixin
):
    def __init__(self, root):
            self.root = root
            self.root.title("سامانه آفلاین مدیریت و تحلیل حسابرسی")
            self.root.geometry("1220x810")
            self.root.minsize(1000, 650)
    
            self.db_path = str(DATABASE_PATH)
            # Build and inject repositories/services before any UI callback runs.
            self.services = ApplicationServices()
            self.benford_service = self.services.benford
            self.beneish_service = self.services.beneish
            self.sampling_service = self.services.sampling
            self.trial_balance_service = self.services.trial_balance_tools
            self.projects = []
            self.selected_samples = []
            self.sample_seed = None
    
            self.init_db()
            self.create_widgets()
            self.load_projects()
    
    def get_conn(self):
            return db_connect(self.db_path)
    
    def init_db(self):
            # CREATE IF NOT EXISTS preserves existing tables and records.
            with self.get_conn() as conn:
                conn.executescript("""
                    CREATE TABLE IF NOT EXISTS projects (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        period TEXT NOT NULL,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
    
                    CREATE TABLE IF NOT EXISTS risks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        title TEXT NOT NULL,
                        score INTEGER,
                        control_desc TEXT
                    );
    
                    CREATE TABLE IF NOT EXISTS workpapers (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        risk_id INTEGER,
                        title TEXT NOT NULL,
                        procedure TEXT,
                        result TEXT,
                        status TEXT DEFAULT 'پیش‌نویس'
                    );
    
                    CREATE TABLE IF NOT EXISTS findings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        workpaper_id INTEGER,
                        title TEXT NOT NULL,
                        severity TEXT,
                        action_text TEXT,
                        owner TEXT,
                        status TEXT DEFAULT 'باز'
                    );
    
                    CREATE TABLE IF NOT EXISTS trial_balance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        account_code TEXT,
                        account_name TEXT NOT NULL,
                        debit REAL NOT NULL DEFAULT 0,
                        credit REAL NOT NULL DEFAULT 0,
                        net REAL NOT NULL DEFAULT 0,
                        flags TEXT NOT NULL DEFAULT '',
                        imported_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
                """)
    
    def clear_tree(self, tree):
            for item in tree.get_children():
                tree.delete(item)
    
    def make_tree(self, parent, columns):
            """columns: [(key, Persian heading, width), ...]."""
            frame = ttk.Frame(parent)
            frame.pack(fill="both", expand=True, padx=10, pady=6)
    
            keys = [item[0] for item in columns]
            tree = ttk.Treeview(frame, columns=keys, show="headings")
    
            for key, heading, width in columns:
                tree.heading(key, text=heading)
                tree.column(key, width=width, anchor="center", stretch=True)
    
            scroll_y = ttk.Scrollbar(
                frame, orient="vertical", command=tree.yview
            )
            scroll_x = ttk.Scrollbar(
                frame, orient="horizontal", command=tree.xview
            )
            tree.configure(
                yscrollcommand=scroll_y.set,
                xscrollcommand=scroll_x.set,
            )
    
            frame.rowconfigure(0, weight=1)
            frame.columnconfigure(0, weight=1)
            tree.grid(row=0, column=0, sticky="nsew")
            scroll_y.grid(row=0, column=1, sticky="ns")
            scroll_x.grid(row=1, column=0, sticky="ew")
            return tree
    
    def create_widgets(self):
            top = ttk.LabelFrame(self.root, text="پرونده فعال")
            top.pack(fill="x", padx=10, pady=8)
    
            self.combo_project = ttk.Combobox(
                top, state="readonly", width=43
            )
            self.combo_project.pack(side="left", padx=8, pady=8)
            self.combo_project.bind(
                "<<ComboboxSelected>>", self.on_project_selected
            )
    
            ttk.Button(
                top, text="پرونده جدید", command=self.popup_new_project
            ).pack(side="left", padx=4)
    
            ttk.Button(
                top, text="خروجی گزارش CSV",
                command=self.export_project_data,
            ).pack(side="left", padx=4)
    
            self.notebook = ttk.Notebook(self.root)
            self.notebook.pack(fill="both", expand=True, padx=10, pady=5)
    
            self.tab_risks = ttk.Frame(self.notebook)
            self.tab_workpapers = ttk.Frame(self.notebook)
            self.tab_findings = ttk.Frame(self.notebook)
            self.tab_benford = ttk.Frame(self.notebook)
            self.tab_ratios = ttk.Frame(self.notebook)
            self.tab_sampling = ttk.Frame(self.notebook)
            self.tab_tb = ttk.Frame(self.notebook)
    
            tabs = [
                (self.tab_risks, "۱. ریسک‌ها"),
                (self.tab_workpapers, "۲. کاربرگ‌ها"),
                (self.tab_findings, "۳. یافته‌ها"),
                (self.tab_benford, "۴. بنفورد"),
                (self.tab_ratios, "۵. M-Score"),
                (self.tab_sampling, "۶. نمونه‌گیری"),
                (self.tab_tb, "۷. تراز آزمایشی"),
            ]
            for frame, title in tabs:
                self.notebook.add(frame, text=title)
    
            self.setup_risk_tab()
            self.setup_workpaper_tab()
            self.setup_finding_tab()
            self.setup_benford_tab()
            self.setup_ratio_tab()
            self.setup_sampling_tab()
            self.setup_trial_balance_tab()
    
    def load_projects(self, select_id=None):
        previous_id = select_id or self.get_current_project_id()
        self.projects = [(r[0], r[1], r[2]) for r in self.services.projects.all()]
        self.combo_project["values"] = [f"{pid} - {name} ({period})" for pid, name, period in self.projects]
        if self.projects:
            ids = [row[0] for row in self.projects]
            self.combo_project.current(ids.index(previous_id) if previous_id in ids else 0)
        else:
            self.combo_project.set("ابتدا یک پرونده ایجاد کنید")
        self.refresh_all_tabs()
    
    def get_current_project_id(self):
            index = self.combo_project.current()
            if 0 <= index < len(self.projects):
                return self.projects[index][0]
            return None
    
    def on_project_selected(self, event=None):
            self.selected_samples = []
            self.sample_seed = None
            self.clear_tree(self.tree_samples)
            self.lbl_sample.config(text="برای این پرونده هنوز نمونه‌ای انتخاب نشده است.")
            self.refresh_all_tabs()
    
    def popup_new_project(self):
            win = tk.Toplevel(self.root)
            win.title("پرونده جدید")
            win.geometry("390x200")
            win.transient(self.root)
            win.grab_set()
    
            ttk.Label(win, text="نام پرونده:").pack(anchor="e", padx=15, pady=5)
            entry_name = ttk.Entry(win, width=42)
            entry_name.pack(padx=15)
    
            ttk.Label(win, text="دوره مالی:").pack(anchor="e", padx=15, pady=5)
            entry_period = ttk.Entry(win, width=42)
            entry_period.pack(padx=15)
    
            def save():
                name = entry_name.get().strip()
                period = entry_period.get().strip()
    
                if not name or not period:
                    messagebox.showwarning(
                        "اطلاعات ناقص",
                        "نام پرونده و دوره مالی را وارد کنید.",
                        parent=win,
                    )
                    return
    
                with self.get_conn() as conn:
                    cursor = conn.execute(
                        "INSERT INTO projects (name, period) VALUES (?, ?)",
                        (name, period),
                    )
                    new_id = cursor.lastrowid
    
                win.destroy()
                self.load_projects(select_id=new_id)
    
            ttk.Button(win, text="ذخیره", command=save).pack(pady=14)
    
    def refresh_all_tabs(self):
            self.refresh_risks()
            self.refresh_workpapers()
            self.refresh_findings()
            self.refresh_trial_balance()

