# Phase 33 — Classic UI & Smart Navigation

## Scope
- Apply a permanent classic visual palette (navy, ivory, muted gold, blue-gray).
- Standardize primary interface typography to Tahoma.
- Retain the right-side module navigation, with a vertical scrolling canvas.
- Add icons to the module navigation labels.
- Add a horizontally scrollable workspace module strip, synchronized with the selected module.
- Highlight the selected module in both navigation surfaces.
- Preserve existing module frame identities, setup mixins, services, callbacks, and database workflows.

## Compatibility
This phase modifies the UI shell in `legacy/audit_app.py`; it does not migrate or alter the database schema.

## Verification
- Python compileall passed.
- Unit test suite: 218 tests passed.
- A live desktop GUI smoke test was not performed in this Linux/headless build environment.
