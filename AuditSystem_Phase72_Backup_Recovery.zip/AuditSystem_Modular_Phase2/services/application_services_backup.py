
from repositories.project_repository import ProjectRepository
from repositories.risk_repository import RiskRepository
from repositories.workpaper_repository import WorkpaperRepository
from repositories.finding_repository import FindingRepository
from repositories.trial_balance_repository import TrialBalanceRepository
from repositories.team_repository import TeamRepository
from repositories.audit_test_repository import AuditTestRepository

from services import (
    benford_service,
    beneish_service,
    sampling_service,
    trial_balance_service
)

from services.audit_test_service import AuditTestService


class ApplicationServices:

    def __init__(self):
        self.projects = ProjectRepository()
        self.risks = RiskRepository()
        self.workpapers = WorkpaperRepository()
        self.findings = FindingRepository()
        self.trial_balance = TrialBalanceRepository()
        self.team = TeamRepository()

        self.audit_tests = AuditTestService(AuditTestRepository())

        self.benford = benford_service
        self.beneish = beneish_service
        self.sampling = sampling_service
        self.trial_balance_tools = trial_balance_service
