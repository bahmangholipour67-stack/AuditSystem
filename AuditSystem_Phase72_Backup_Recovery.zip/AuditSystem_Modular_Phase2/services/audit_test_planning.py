"""Build a risk-aware execution guide from reusable audit-test templates.

The guide is a planning aid only. It does not select a sample size, determine
materiality, establish assurance, or replace engagement-specific judgment.
"""

from copy import deepcopy

from services.audit_test_catalog import get_template


_TYPE_CHECKS = {
    "کنترلی": [
        "طراحی کنترل، مسئول اجرا، تناوب و شواهد اجرای کنترل را مستند کنید.",
        "انحراف‌ها را از خطاهای مستندسازی و موارد فاقد قابلیت اتکا تفکیک کنید.",
        "علت انحراف و آثار آن بر ارزیابی ریسک و رویکرد رسیدگی را بررسی کنید.",
    ],
    "ماهوی": [
        "مانده یا گردش مبنا را با دفتر کل و صورت‌های مالی تطبیق دهید.",
        "برای هر مغایرت، مبلغ تحریف و اثر آن بر ادعاهای مرتبط را جداگانه ثبت کنید.",
        "نتایج را با اهمیت عملکردی و سایر تحریف‌های تجمیع‌شده مقایسه کنید.",
    ],
    "تحلیلی": [
        "انتظار مستقل و منبع داده‌های مورد استفاده را مستند کنید.",
        "قابلیت اتکای داده‌ها و سطح تفکیک تحلیل را ارزیابی کنید.",
        "آستانه بررسی را پیش از نتیجه‌گیری تعیین و اختلاف‌های بااهمیت را پیگیری کنید.",
    ],
}

_ASSERTION_FOCUS = {
    "وجود": "ردیابی از سوابق به اسناد یا مشاهده مستقیم برای پشتیبانی از وجود.",
    "کامل بودن": "ردیابی از اسناد مبدأ یا منابع مستقل به سوابق حسابداری برای بررسی کامل بودن.",
    "دقت": "بازمحاسبه، تطبیق نرخ و مقدار و کنترل صحت انتقال اطلاعات.",
    "ارزش‌گذاری": "بررسی مفروضات، برآوردها، کاهش ارزش و شواهد مؤید ارزش ثبت‌شده.",
    "برش زمانی": "آزمون معاملات قبل و بعد از تاریخ گزارشگری و ارزیابی ثبت در دوره صحیح.",
    "وقوع": "ردیابی اقلام ثبت‌شده به اسناد معتبر و شواهد وقوع معامله.",
    "حقوق و تعهدات": "بررسی مالکیت، تعهدات، وثایق، محدودیت‌ها و شرایط قرارداد.",
    "ارائه و افشا": "ارزیابی طبقه‌بندی، تجمیع و کفایت افشا در صورت‌های مالی.",
    "طبقه‌بندی": "بررسی ثبت در سرفصل و طبقه مناسب و ثبات رویه.",
    "مجوز": "تطبیق با حدود اختیار و شواهد تصویب توسط مقام مجاز.",
    "وضعیت": "بررسی وضعیت فیزیکی، قابلیت استفاده، آسیب‌دیدگی یا کهنگی.",
}


class AuditTestPlanningService:
    """Create structured, risk-aware execution guidance for a catalog template."""

    def build_execution_plan(self, template_id, *, risk_score=None):
        template = get_template(template_id)
        if template is None:
            raise ValueError("الگوی آزمون موردنظر در کتابخانه وجود ندارد.")

        if risk_score in (None, ""):
            risk_level = "تعیین‌نشده"
            risk_focus = "سطح ریسک پرونده را پیش از نهایی‌سازی دامنه و حجم رسیدگی تعیین کنید."
        else:
            if isinstance(risk_score, bool):
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            try:
                score = int(risk_score)
            except (TypeError, ValueError):
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            if str(score) != str(risk_score).strip() or not 1 <= score <= 25:
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            if score >= 16:
                risk_level = "بالا"
                risk_focus = "دامنه و عمق رسیدگی را با توجه به ریسک بالا افزایش دهید؛ شواهد مستقل‌تر و آزمون‌های تکمیلی را بررسی کنید."
            elif score >= 9:
                risk_level = "متوسط"
                risk_focus = "دامنه رسیدگی را متناسب با عوامل ریسک و نتایج آزمون‌های اولیه تنظیم کنید."
            else:
                risk_level = "پایین"
                risk_focus = "کفایت شواهد و توجیه هرگونه اتکای کمتر را مستند کنید؛ ریسک پایین به‌تنهایی حذف رسیدگی را توجیه نمی‌کند."

        steps = [line.strip() for line in template["procedure"].splitlines() if line.strip()]
        evidence = [item.strip(" .،؛") for item in template["evidence"].replace(" و ", "،").split("،") if item.strip(" .،؛")]
        assertion_focus = [
            {"assertion": assertion, "focus": _ASSERTION_FOCUS.get(assertion, "روش رسیدگی متناسب با این ادعا را در برنامه پرونده مشخص کنید.")}
            for assertion in template["assertions"]
        ]

        completion_checks = [
            "جامعه آماری، منبع استخراج و تطبیق آن با سوابق حسابداری مستند شده است.",
            "روش انتخاب اقلام و توجیه حجم نمونه با توجه به ریسک و اهمیت مستند شده است.",
            "برای تمام اقلام منتخب نتیجه رسیدگی و ارجاع به شواهد ثبت شده است.",
            "مغایرت‌ها، علت، مبلغ، آثار و نحوه تعیین تکلیف آن‌ها مستند شده است.",
            "نتیجه‌گیری با ادعاهای مرتبط، ریسک و سایر شواهد پرونده سازگار است.",
        ]
        escalation = [
            "مغایرت بااهمیت یا الگوی تکرارشونده مشاهده شود.",
            "شواهد کافی و مناسب به دست نیاید یا قابلیت اتکای داده‌ها محل تردید باشد.",
            "نشانه تقلب، دور زدن کنترل‌ها یا دخالت مدیریت مشاهده شود.",
            "نتیجه آزمون با ارزیابی ریسک یا سایر شواهد پرونده ناسازگار باشد.",
        ]

        return {
            "template": deepcopy(template),
            "risk_level": risk_level,
            "risk_focus": risk_focus,
            "procedure_steps": steps,
            "assertion_focus": assertion_focus,
            "evidence_checklist": evidence,
            "type_specific_checks": list(_TYPE_CHECKS[template["test_type"]]),
            "completion_checks": completion_checks,
            "escalation_triggers": escalation,
            "limitations": [
                "این راهنما جایگزین ارزیابی ریسک و قضاوت حرفه‌ای حسابرس نیست.",
                "حجم نمونه، اهمیت و آستانه‌های قابل قبول باید برای هر پرونده جداگانه تعیین شوند.",
                "نتیجه نمونه بدون مبنای مناسب، به کل جامعه آماری تعمیم داده نمی‌شود.",
            ],
        }
