import csv, io, os, re
from collections import Counter
from services.number_utils import parse_amount

def normalize_header(value):
    text=str(value or "").strip().lower().translate(str.maketrans({"ي":"ی","ك":"ک"}))
    return re.sub(r"[\s\u200c_\-./()]+", "", text)

def find_columns(header):
    aliases={"name":{"نامحساب","شرححساب","سرفصل","accountname","account","name"},
    "code":{"کد","کدحساب","accountcode","code"},
    "debit":{"بدهکار","ماندهبدهکار","ماندهبدهکارپایاندوره","debit","debitbalance","closingdebitbalance"},
    "credit":{"بستانکار","ماندهبستانکار","ماندهبستانکارپایاندوره","credit","creditbalance","closingcreditbalance"}}
    found={}
    for i,value in enumerate(header):
        n=normalize_header(value)
        for key,opts in aliases.items():
            if key not in found and n in opts: found[key]=i
    return found

def percentile(sorted_values,fraction):
    position=(len(sorted_values)-1)*fraction; lower=int(position); upper=min(lower+1,len(sorted_values)-1); weight=position-lower
    return sorted_values[lower]*(1-weight)+sorted_values[upper]*weight

def add_flags(records):
    code_counts=Counter(r['code'] for r in records if r['code'])
    balances=sorted(abs(r['net']) for r in records if abs(r['net'])>0); limit=None
    if len(balances)>=10:
        q1=percentile(balances,.25); q3=percentile(balances,.75)
        if q3>q1: limit=q3+1.5*(q3-q1)
    for r in records:
        f=[]
        if r['debit']<0:f.append('بدهکار منفی')
        if r['credit']<0:f.append('بستانکار منفی')
        if r['debit']>0 and r['credit']>0:f.append('مانده در هر دو ستون')
        if r['code'] and code_counts[r['code']]>1:f.append('کد تکراری')
        if limit is not None and abs(r['net'])>limit:f.append('مانده بزرگ نسبت به جامعه')
        r['flags']='؛ '.join(f)
    return records

def read_file(path):
    ext=os.path.splitext(path)[1].lower()
    if ext=='.csv':
        content=None
        for enc in ('utf-8-sig','utf-8','cp1256','cp1252'):
            try:
                with open(path,'r',encoding=enc,newline='') as f: content=f.read()
                break
            except UnicodeDecodeError: pass
        if content is None: raise ValueError('خواندن متن فایل CSV ممکن نشد.')
        try: delimiter=csv.Sniffer().sniff(content[:8192],delimiters=',;\t|').delimiter
        except csv.Error: delimiter=','
        rows=list(csv.reader(io.StringIO(content),delimiter=delimiter))
    elif ext in ('.xlsx','.xlsm'):
        try: from openpyxl import load_workbook
        except ImportError as exc: raise RuntimeError('openpyxl نصب نیست. فایل Excel را به CSV تبدیل کنید یا openpyxl را نصب کنید.') from exc
        wb=load_workbook(path,read_only=True,data_only=True)
        try: rows=list(wb.active.iter_rows(values_only=True))
        finally: wb.close()
    else: raise ValueError('فقط CSV، XLSX و XLSM پشتیبانی می‌شود.')
    if not rows: raise ValueError('فایل خالی است.')
    cols=None; hidx=None
    for i,row in enumerate(rows[:25]):
        c=find_columns(row)
        if all(k in c for k in ('name','debit','credit')): cols=c; hidx=i; break
    if cols is None: raise ValueError('عنوان ستون‌های «نام حساب»، «مانده بدهکار» و «مانده بستانکار» پیدا نشد.')
    records=[]; totals={'جمع','جمعکل','مجموع','مجموعکل','total','grandtotal'}
    for excel_row,row in enumerate(rows[hidx+1:],start=hidx+2):
        if not row or all(v is None or str(v).strip()=='' for v in row): continue
        def cell(k):
            i=cols.get(k); return row[i] if i is not None and i<len(row) else None
        name=str(cell('name') or '').strip()
        if normalize_header(name) in totals: continue
        if not name: raise ValueError(f'ردیف {excel_row}: نام حساب خالی است.')
        cv=cell('code'); code=str(int(cv)) if isinstance(cv,float) and cv.is_integer() else str(cv or '').strip()
        try: debit=parse_amount(cell('debit')); credit=parse_amount(cell('credit'))
        except ValueError as exc: raise ValueError(f'ردیف {excel_row}: {exc}') from exc
        records.append({'code':code,'name':name,'debit':debit,'credit':credit,'net':debit-credit,'flags':''})
    if not records: raise ValueError('هیچ حسابی برای ورود پیدا نشد.')
    return add_flags(records)
