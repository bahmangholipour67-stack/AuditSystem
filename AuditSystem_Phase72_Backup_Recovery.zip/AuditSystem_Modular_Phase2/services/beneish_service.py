import math
from services.number_utils import parse_amount
THRESHOLD=-1.78
REQUIRED=("recv_t","sales_t","recv_p","sales_p","cogs_p","cogs_t","ca_t","ppe_t","ta_t","ca_p","ppe_p","ta_p","dep_p","dep_t","ppe_p","ppe_t","sga_t","sga_p","cl_t","ltd_t","cl_p","ltd_p","ni_t","cfo_t")

def calculate(raw_values):
    v={k:parse_amount(raw_values[k]) for k in REQUIRED}
    def div(a,b,label):
        if abs(b)<1e-12: raise ValueError(f"محاسبه «{label}» به علت مخرج صفر ممکن نیست.")
        return a/b
    dsri=div(div(v['recv_t'],v['sales_t'],'DSRI'),div(v['recv_p'],v['sales_p'],'DSRI'),'DSRI')
    gmi=div(div(v['sales_p']-v['cogs_p'],v['sales_p'],'GMI'),div(v['sales_t']-v['cogs_t'],v['sales_t'],'GMI'),'GMI')
    aqi=div(1-div(v['ca_t']+v['ppe_t'],v['ta_t'],'AQI'),1-div(v['ca_p']+v['ppe_p'],v['ta_p'],'AQI'),'AQI')
    sgi=div(v['sales_t'],v['sales_p'],'SGI')
    depi=div(div(v['dep_p'],v['dep_p']+v['ppe_p'],'DEPI'),div(v['dep_t'],v['dep_t']+v['ppe_t'],'DEPI'),'DEPI')
    sgai=div(div(v['sga_t'],v['sales_t'],'SGAI'),div(v['sga_p'],v['sales_p'],'SGAI'),'SGAI')
    lvgi=div(div(v['cl_t']+v['ltd_t'],v['ta_t'],'LVGI'),div(v['cl_p']+v['ltd_p'],v['ta_p'],'LVGI'),'LVGI')
    tata=div(v['ni_t']-v['cfo_t'],v['ta_t'],'TATA')
    score=(-4.840+0.920*dsri+0.528*gmi+0.404*aqi+0.892*sgi+0.115*depi-0.172*sgai+4.679*tata-0.327*lvgi)
    if not math.isfinite(score): raise ValueError("نتیجه عددی معتبر نیست.")
    return {"score":score,"threshold":THRESHOLD,"screening_flag":score>THRESHOLD,
            "indices":{"DSRI":dsri,"GMI":gmi,"AQI":aqi,"SGI":sgi,"DEPI":depi,"SGAI":sgai,"LVGI":lvgi,"TATA":tata},
            "note":"TATA مطابق نسخه فعلی برنامه و به‌صورت تقریبی محاسبه شده است؛ تعریف دقیق مقاله اصلی نیست."}
