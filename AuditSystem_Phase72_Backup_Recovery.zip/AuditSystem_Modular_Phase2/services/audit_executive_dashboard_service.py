"""Phase 39: deterministic executive dashboard KPIs.

Pure aggregation over caller-supplied database rows; no database writes occur here.
"""


class AuditExecutiveDashboardService:
    CLOSED = {
        "بسته", "مختومه", "تکمیل شده", "تکمیل‌شده", "نهایی و تأیید",
        "completed", "closed", "done",
    }
    OPEN = {"باز", "در جریان", "فعال", "open", "in progress", "pending"}
    HIGH_RISK = {"زیاد", "بالا", "critical", "high", "اساسی", "بااهمیت"}
    REVIEW_PENDING = {"آماده بررسی سرپرست", "در انتظار بررسی", "pending review", "awaiting review"}

    @staticmethod
    def normalize(value):
        return (str(value or "").strip().replace("ي", "ی").replace("ك", "ک")
                .replace("\u200c", " ").lower())

    @classmethod
    def is_closed(cls, status):
        return cls.normalize(status) in {cls.normalize(item) for item in cls.CLOSED}



    @classmethod
    def snapshot(cls, *, projects=(), risks=(), workpapers=(), findings=(), tests=()):
        """Build KPI snapshot.

        Row formats: projects=(id,name,status); risks=(title,score); workpapers=(id,title,status);
        findings=(id,title,severity,status); tests=(id,title,status).
        """
        project_rows = list(projects)
        risk_rows = list(risks)
        workpaper_rows = list(workpapers)
        finding_rows = list(findings)
        test_rows = list(tests)

        active_projects = sum(1 for row in project_rows if not cls.is_closed(row[2]))
        high_risks = []
        for row in risk_rows:
            try:
                score = int(row[1])
            except (TypeError, ValueError, IndexError):
                continue
            if score >= 15:
                high_risks.append((row[0], score))

        completed_workpapers = sum(1 for row in workpaper_rows if cls.is_closed(row[2]))
        open_findings = sum(1 for row in finding_rows if not cls.is_closed(row[3]))
        critical_findings = sum(
            1 for row in finding_rows
            if not cls.is_closed(row[3]) and cls.normalize(row[2]) in {cls.normalize(x) for x in cls.HIGH_RISK}
        )
        pending_reviews = sum(
            1 for row in test_rows if cls.normalize(row[2]) in {cls.normalize(x) for x in cls.REVIEW_PENDING}
        )
        workpaper_total = len(workpaper_rows)
        return {
            "project_count": len(project_rows),
            "active_project_count": active_projects,
            "risk_count": len(risk_rows),
            "high_risk_count": len(high_risks),
            "high_risks": high_risks,
            "workpaper_count": workpaper_total,
            "completed_workpaper_count": completed_workpapers,
            "workpaper_completion_percent": round(completed_workpapers * 100 / workpaper_total) if workpaper_total else 0,
            "finding_count": len(finding_rows),
            "open_finding_count": open_findings,
            "critical_open_finding_count": critical_findings,
            "audit_test_count": len(test_rows),
            "pending_review_count": pending_reviews,
        }
