"""Deterministic evaluation engine for audit-test sample results.

This module is intentionally pure: it does not read or write the database.
It summarizes recorded sample outcomes and applies thresholds supplied by
an auditor. It never extrapolates sample errors to the population.
"""

from collections import Counter
from math import isfinite


RESULT_UNTESTED = "رسیدگی‌نشده"
RESULT_PASS = "تأیید"
RESULT_EXCEPTION = "مغایرت"
RESULT_NONCOMPLIANCE = "عدم انطباق"
RESULT_REVIEW = "نیازمند بررسی"

VALID_RESULTS = {
    RESULT_UNTESTED,
    RESULT_PASS,
    RESULT_EXCEPTION,
    RESULT_NONCOMPLIANCE,
    RESULT_REVIEW,
}
EXCEPTION_RESULTS = {RESULT_EXCEPTION, RESULT_NONCOMPLIANCE}


class AuditTestEvaluationService:
    """Summarize sample outcomes and produce a transparent assessment."""

    @staticmethod
    def _number(value, field_name, *, minimum=None, maximum=None):
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"مقدار {field_name} باید عددی باشد.")
        if not isfinite(number):
            raise ValueError(f"مقدار {field_name} معتبر نیست.")
        if minimum is not None and number < minimum:
            raise ValueError(f"مقدار {field_name} نمی‌تواند کمتر از {minimum} باشد.")
        if maximum is not None and number > maximum:
            raise ValueError(f"مقدار {field_name} نمی‌تواند بیشتر از {maximum} باشد.")
        return number

    def evaluate(self, samples, *, allowed_exception_rate=0.0, require_complete=True):
        """Return counts, rates, amounts and a threshold-based assessment.

        ``allowed_exception_rate`` is a percentage from 0 to 100. The rate is
        calculated over tested samples only. Unresolved samples are kept
        separate and, by default, prevent a final assessment.
        """
        if samples is None:
            raise ValueError("فهرست نمونه‌ها باید مشخص باشد.")
        samples = list(samples)
        if not samples:
            raise ValueError("برای ارزیابی، حداقل یک نمونه لازم است.")

        threshold = self._number(
            allowed_exception_rate, "حد مجاز مغایرت", minimum=0, maximum=100
        )

        counts = Counter()
        exception_amount = 0.0
        amount_known_count = 0
        exception_amount_known_count = 0
        invalid_results = []

        for index, sample in enumerate(samples, start=1):
            if not isinstance(sample, dict):
                raise ValueError(f"ساختار نمونه شماره {index} معتبر نیست.")
            result = str(sample.get("result") or RESULT_UNTESTED).strip()
            if result not in VALID_RESULTS:
                invalid_results.append({"sample_no": sample.get("sample_no", index), "result": result})
                continue
            counts[result] += 1

            amount = sample.get("amount")
            if amount not in (None, ""):
                amount_value = self._number(amount, f"مبلغ نمونه {sample.get('sample_no', index)}")
                amount_known_count += 1
                if result in EXCEPTION_RESULTS:
                    exception_amount += abs(amount_value)
                    exception_amount_known_count += 1

        if invalid_results:
            raise ValueError(f"نتیجه نامعتبر برای نمونه‌ها ثبت شده است: {invalid_results}")

        total = len(samples)
        tested = total - counts[RESULT_UNTESTED]
        unresolved = counts[RESULT_UNTESTED] + counts[RESULT_REVIEW]
        exceptions = sum(counts[item] for item in EXCEPTION_RESULTS)
        rate = (exceptions / tested * 100.0) if tested else 0.0
        complete = unresolved == 0

        if tested == 0:
            assessment = "فاقد نتیجه"
            rationale = "هنوز هیچ نمونه‌ای رسیدگی نشده است."
        elif require_complete and not complete:
            assessment = "نیازمند تکمیل رسیدگی"
            rationale = "نمونه رسیدگی‌نشده یا نیازمند بررسی وجود دارد؛ نتیجه نهایی صادر نمی‌شود."
        elif rate > threshold:
            assessment = "عدم احراز معیار"
            rationale = "نرخ مغایرت از حد مجاز تعیین‌شده بیشتر است."
        else:
            assessment = "احراز معیار"
            rationale = "نرخ مغایرت از حد مجاز تعیین‌شده تجاوز نمی‌کند."

        return {
            "total_samples": total,
            "tested_samples": tested,
            "untested_samples": counts[RESULT_UNTESTED],
            "review_required_samples": counts[RESULT_REVIEW],
            "exception_samples": exceptions,
            "accepted_samples": counts[RESULT_PASS],
            "completion_percent": round(tested / total * 100.0, 2),
            "exception_rate_percent": round(rate, 4),
            "allowed_exception_rate_percent": threshold,
            "exception_amount": round(exception_amount, 2),
            "samples_with_amount": amount_known_count,
            "exception_samples_with_amount": exception_amount_known_count,
            "is_complete": complete,
            "assessment": assessment,
            "rationale": rationale,
            "result_counts": {key: counts[key] for key in sorted(VALID_RESULTS)},
            "limitations": [
                "این ارزیابی فقط خلاصه نمونه‌های ثبت‌شده است و به جامعه آماری تعمیم داده نمی‌شود.",
                "مبلغ مغایرت فقط از نمونه‌های دارای مبلغ ثبت‌شده محاسبه شده است.",
            ],
        }
