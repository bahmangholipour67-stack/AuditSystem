"""Read-only traceability analysis across audit risks, work and evidence.

The service identifies missing or inconsistent links. It never creates findings,
changes risk scores, alters approvals, or concludes on the audit opinion.
"""

import json


class AuditTraceabilityService:
    PRIORITY_ORDER = {"فوری": 0, "بالا": 1, "متوسط": 2, "عادی": 3}
    EXCEPTION_RESULTS = {"مغایرت", "عدم انطباق", "نیازمند بررسی"}

    @staticmethod
    def _int(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _assertions(raw):
        if isinstance(raw, (list, tuple)):
            values = raw
        else:
            try:
                values = json.loads(raw or "[]")
            except (TypeError, ValueError):
                values = []
        if not isinstance(values, (list, tuple)):
            return []
        return list(dict.fromkeys(str(value).strip() for value in values if str(value).strip()))

    @staticmethod
    def _has_path(value):
        return bool(str(value or "").strip())

    def build_report(self, data, *, high_risk_threshold=16):
        if not isinstance(data, dict):
            raise ValueError("اطلاعات ردیابی حسابرسی معتبر نیست.")
        try:
            threshold = int(high_risk_threshold)
        except (TypeError, ValueError):
            raise ValueError("آستانه ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
        if not 1 <= threshold <= 25:
            raise ValueError("آستانه ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")

        risks = list(data.get("risks", ()))
        programs = list(data.get("programs", ()))
        tests = list(data.get("tests", ()))
        samples = list(data.get("samples", ()))
        findings = list(data.get("findings", ()))
        finding_evidence = list(data.get("finding_evidence", ()))

        programs_by_id = {row.get("id"): row for row in programs}
        tests_by_program = {}
        tests_by_id = {row.get("id"): row for row in tests}
        samples_by_test = {}
        evidence_by_finding = {}
        for row in tests:
            tests_by_program.setdefault(row.get("program_id"), []).append(row)
        for row in samples:
            samples_by_test.setdefault(row.get("test_id"), []).append(row)
        for row in finding_evidence:
            evidence_by_finding.setdefault(row.get("finding_id"), []).append(row)

        issues = []

        def issue(priority, entity_type, entity_id, title, problem, recommendation):
            issues.append({
                "priority": priority,
                "entity_type": entity_type,
                "entity_id": entity_id,
                "title": str(title or "بدون عنوان"),
                "problem": problem,
                "recommendation": recommendation,
            })

        # Risk-to-program coverage and program-to-test coverage.
        risk_ids_with_programs = set()
        risk_ids_with_tests = set()
        for program in programs:
            risk_id = program.get("risk_id")
            if risk_id:
                risk_ids_with_programs.add(risk_id)
            attached = tests_by_program.get(program.get("id"), [])
            if not attached:
                issue("متوسط", "برنامه", program.get("id"), program.get("title"),
                      "برای برنامه حسابرسی هنوز آزمونی ثبت نشده است.",
                      "آزمون‌های لازم را بر اساس هدف برنامه و ریسک مرتبط طراحی و ثبت کنید.")
            if not risk_id:
                issue("متوسط", "برنامه", program.get("id"), program.get("title"),
                      "برنامه حسابرسی به ریسک پرونده متصل نیست.",
                      "ارتباط برنامه با ریسک مرتبط را بررسی و در صورت وجود مبنای مستند ثبت کنید.")
            for test in attached:
                effective_risk = risk_id or test.get("program_risk_id")
                if effective_risk:
                    risk_ids_with_tests.add(effective_risk)

        for risk in risks:
            rid = risk.get("id")
            score = self._int(risk.get("score"))
            if rid not in risk_ids_with_programs:
                priority = "بالا" if score >= threshold else "متوسط"
                issue(priority, "ریسک", rid, risk.get("title"),
                      "برای این ریسک برنامه حسابرسی مرتبط ثبت نشده است.",
                      "پاسخ حسابرسی و برنامه رسیدگی متناسب با سطح ریسک را مستند کنید.")
            elif rid not in risk_ids_with_tests:
                issue("بالا" if score >= threshold else "متوسط", "ریسک", rid, risk.get("title"),
                      "برنامه به ریسک متصل است، اما آزمون مرتبط قابل ردیابی نیست.",
                      "اطمینان حاصل کنید برنامه دارای آزمون‌های کافی برای پاسخ به ریسک است.")

        for test in tests:
            tid = test.get("id")
            title = test.get("title")
            program = programs_by_id.get(test.get("program_id"))
            if program is None:
                issue("بالا", "آزمون", tid, title,
                      "برنامه مادر آزمون در پرونده پیدا نشد.",
                      "ارتباط آزمون با برنامه معتبر همان پرونده را بررسی کنید.")
            if not test.get("workpaper_id"):
                issue("متوسط", "آزمون", tid, title,
                      "آزمون به کاربرگ مستندکننده متصل نیست.",
                      "کاربرگ اجرای آزمون را ایجاد یا به آزمون متصل کنید.")
            elif test.get("workpaper_risk_id") and test.get("program_risk_id") and test["workpaper_risk_id"] != test["program_risk_id"]:
                issue("بالا", "آزمون", tid, title,
                      "ریسک کاربرگ با ریسک برنامه آزمون یکسان نیست.",
                      "ارتباط ریسک‌ها را بررسی کنید؛ تفاوت فقط با توجیه و مستندسازی روشن قابل قبول است.")

            assertions = self._assertions(test.get("template_assertions"))
            if not assertions:
                issue("متوسط", "آزمون", tid, title,
                      "ادعاهای صورت‌های مالی برای آزمون ثبت نشده‌اند.",
                      "ادعاهای مرتبط را متناسب با هدف آزمون تعیین و مستند کنید.")

            test_samples = samples_by_test.get(tid, [])
            has_sample_evidence = any(self._has_path(s.get("evidence_path")) for s in test_samples)
            expects_evidence = self._has_path(test.get("expected_evidence"))
            if expects_evidence and test_samples and not has_sample_evidence:
                issue("بالا", "شواهد آزمون", tid, title,
                      "برای نمونه‌های آزمون، مسیر شواهد ثبت نشده است.",
                      "شواهد قابل اتکا را نگهداری و مسیر یا ارجاع آن را برای نمونه‌ها ثبت کنید.")
            if test_samples and any(str(s.get("result") or "") in self.EXCEPTION_RESULTS for s in test_samples):
                sample_has_finding = any(s.get("finding_id") for s in test_samples)
                if not test.get("finding_id") and not sample_has_finding:
                    issue("بالا", "آزمون", tid, title,
                          "در نمونه‌ها مورد استثنا ثبت شده، اما آزمون یا نمونه به یافته‌ای متصل نیست.",
                          "مورد را از نظر معیارهای ثبت یافته ارزیابی کنید؛ در صورت لزوم یافته را به آزمون یا نمونه مرتبط کنید.")
            if str(test.get("status") or "") in {"تأیید نهایی مدیر", "نهایی و تأیید"} and not str(test.get("conclusion") or "").strip():
                issue("بالا", "آزمون", tid, title,
                      "آزمون در وضعیت تأیید نهایی است، اما نتیجه‌گیری آن خالی است.",
                      "پیش از نهایی‌سازی، نتیجه‌گیری مستند و سازگار با شواهد ثبت شود.")

        for finding in findings:
            fid = finding.get("id")
            title = finding.get("title")
            if not finding.get("risk_id") and not finding.get("workpaper_risk_id"):
                issue("متوسط", "یافته", fid, title,
                      "یافته به ریسک مشخصی متصل نیست.",
                      "ریسک مرتبط را از طریق کاربرگ یا ارتباط مستقیم یافته تعیین کنید.")
            if not finding.get("workpaper_id"):
                issue("متوسط", "یافته", fid, title,
                      "یافته به کاربرگ پشتیبان متصل نیست.",
                      "کاربرگ حاوی شواهد و مبنای یافته را متصل کنید.")
            if not evidence_by_finding.get(fid):
                issue("بالا", "شواهد یافته", fid, title,
                      "برای یافته هیچ مستند پشتیبانی در مخزن شواهد ثبت نشده است.",
                      "شواهد مؤید وضعیت، معیار، علت و آثار یافته را ثبت و ارجاع دهید.")

        issues.sort(key=lambda item: (
            self.PRIORITY_ORDER.get(item["priority"], 9),
            item["entity_type"], item["entity_id"] or 0,
        ))
        risk_matrix = []
        for risk in risks:
            rid = risk.get("id")
            related_programs = [p for p in programs if p.get("risk_id") == rid]
            related_tests = [t for t in tests if t.get("program_risk_id") == rid]
            assertion_values = []
            for test in related_tests:
                assertion_values.extend(self._assertions(test.get("template_assertions")))
            risk_matrix.append({
                "risk_id": rid,
                "risk_title": risk.get("title"),
                "risk_score": risk.get("score"),
                "program_count": len(related_programs),
                "test_count": len(related_tests),
                "assertions": list(dict.fromkeys(assertion_values)),
                "covered": bool(related_tests),
            })

        complete_risks = len(risk_ids_with_tests)
        total_risks = len(risks)
        return {
            "project_id": data.get("project_id"),
            "summary": {
                "risk_count": total_risks,
                "program_count": len(programs),
                "test_count": len(tests),
                "finding_count": len(findings),
                "issue_count": len(issues),
                "high_priority_count": sum(i["priority"] in {"فوری", "بالا"} for i in issues),
                "risks_with_test_count": complete_risks,
                "risk_test_coverage_percent": round(complete_risks / total_risks * 100, 1) if total_risks else 100.0,
                "distinct_assertion_count": len({a for row in risk_matrix for a in row["assertions"]}),
                "tests_without_assertions": sum(not self._assertions(t.get("template_assertions")) for t in tests),
            },
            "risk_matrix": risk_matrix,
            "issues": issues,
            "limitations": [
                "این گزارش فقط پیوندهای ثبت‌شده و خلأهای قابل تشخیص از داده‌های موجود را نشان می‌دهد.",
                "وجود پیوند یا مسیر فایل به‌تنهایی کفایت، اصالت یا قابلیت اتکای شواهد را اثبات نمی‌کند.",
                "پیشنهادها هیچ ریسک، یافته، نتیجه آزمون یا تصمیم تأییدی را خودکار تغییر نمی‌دهند.",
            ],
        }

    def for_project(self, project_id, repository=None, *, high_risk_threshold=16):
        from repositories.audit_traceability_repository import AuditTraceabilityRepository
        repo = repository or AuditTraceabilityRepository()
        return self.build_report(repo.for_project(project_id), high_risk_threshold=high_risk_threshold)
