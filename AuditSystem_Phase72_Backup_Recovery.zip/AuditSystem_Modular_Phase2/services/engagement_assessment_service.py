"""Read-only, evidence-linked engagement assessment engine.

This engine produces review signals, not an automated audit opinion.
All queries are scoped to one engagement and no audit records are changed.
"""
from decimal import Decimal, InvalidOperation
import sqlite3

from database.connection import connect


class EngagementAssessmentService:
    FINAL_WORKPAPER_STATUSES = {"نهایی و تأیید"}
    FINAL_TEST_STATUSES = {"تأیید نهایی مدیر"}
    UNCERTAIN_MISSTATEMENT_STATUSES = {"اصلاح‌نشده", "مورد اختلاف"}
    OPEN_REQUEST_STATUSES = {"جدید", "ارسال‌شده", "دریافت‌شده", "در حال بررسی"}

    def __init__(self, db_path=None):
        self.db_path = db_path

    @staticmethod
    def _decimal(value):
        try:
            return Decimal(str(value or 0))
        except (InvalidOperation, TypeError, ValueError):
            return Decimal("0")

    @staticmethod
    def _table_exists(conn, name):
        return bool(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
        ).fetchone())

    def build(self, project_id):
        if not project_id:
            raise ValueError("شناسه پرونده برای ارزیابی الزامی است.")
        with connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            project = conn.execute(
                "SELECT id,name,period,status FROM projects WHERE id=?", (project_id,)
            ).fetchone()
            if not project:
                raise ValueError("پرونده حسابرسی پیدا نشد.")

            def rows(sql, params=(project_id,)):
                return [dict(r) for r in conn.execute(sql, params).fetchall()]

            risks = rows("SELECT id,title,score FROM risks WHERE project_id=? ORDER BY id") if self._table_exists(conn,"risks") else []
            workpapers = rows("SELECT id,title,risk_id,status FROM workpapers WHERE project_id=? ORDER BY id") if self._table_exists(conn,"workpapers") else []
            findings = rows("SELECT id,title,severity,status,risk_id,workpaper_id FROM findings WHERE project_id=? ORDER BY id") if self._table_exists(conn,"findings") else []
            tests = rows("SELECT id,title,status,workpaper_id,finding_id FROM audit_tests WHERE project_id=? ORDER BY id") if self._table_exists(conn,"audit_tests") else []
            samples = rows("SELECT id,test_id,sample_no,result,misstatement_amount,exception_description,evidence_path FROM audit_test_samples WHERE project_id=? ORDER BY id") if self._table_exists(conn,"audit_test_samples") else []
            misstatements = rows("SELECT id,title,misstatement_type,amount,status,account_name FROM audit_misstatements WHERE project_id=? AND archived_at IS NULL ORDER BY id") if self._table_exists(conn,"audit_misstatements") else []
            requests = rows("SELECT id,title,status,due_date,priority FROM document_requests WHERE project_id=? AND archived_at IS NULL ORDER BY id") if self._table_exists(conn,"document_requests") else []
            materiality_row = conn.execute("SELECT * FROM project_materiality WHERE project_id=?",(project_id,)).fetchone() if self._table_exists(conn,"project_materiality") else None

        materiality = dict(materiality_row) if materiality_row else None
        uncorrected = [m for m in misstatements if m["status"] in self.UNCERTAIN_MISSTATEMENT_STATUSES]
        corrected = [m for m in misstatements if m["status"] == "اصلاح‌شده"]
        gross_total = sum((self._decimal(m["amount"]) for m in uncorrected), Decimal("0"))
        total_text = format(gross_total.quantize(Decimal("0.01")), "f")
        issues = []

        def issue(code, severity, title, detail, refs=None):
            issues.append({"code":code,"severity":severity,"title":title,"detail":detail,"references":refs or []})

        if not materiality:
            issue("MATERIALITY_NOT_SET","بحرانی","سطوح اهمیت تعیین نشده است","تا زمان ثبت اهمیت کلی، عملکردی و حد آستانه اقلام ناچیز، ارزیابی کمی تحریفات ناقص است.")
        else:
            overall = self._decimal(materiality["overall_materiality"])
            performance = self._decimal(materiality["performance_materiality"])
            trivial = self._decimal(materiality["clearly_trivial"])
            if gross_total >= overall:
                issue("MISSTATEMENTS_OVERALL_MATERIALITY","بحرانی","مجموع تحریفات به اهمیت کلی رسیده یا از آن عبور کرده است",f"جمع ناخالص تحریفات اصلاح‌نشده و مورد اختلاف {total_text} و اهمیت کلی {overall} است.",[m["id"] for m in uncorrected])
            elif gross_total >= performance:
                issue("MISSTATEMENTS_OVER_PERFORMANCE","زیاد","مجموع تحریفات به اهمیت عملکردی رسیده یا از آن عبور کرده است",f"جمع ناخالص {total_text} در برابر اهمیت عملکردی {performance} است.",[m["id"] for m in uncorrected])
            elif gross_total > 0:
                issue("UNCORRECTED_MISSTATEMENTS","متوسط","تحریفات اصلاح‌نشده یا مورد اختلاف وجود دارد",f"جمع ناخالص تحریفات {total_text} است؛ ماهیت، شرایط و آثار کیفی نیز باید ارزیابی شوند.",[m["id"] for m in uncorrected])
            trivial_items = [m for m in uncorrected if self._decimal(m["amount"]) >= trivial]
            if trivial_items:
                issue("TRIVIAL_THRESHOLD_ITEMS","متوسط","اقلام مشمول بررسی حد آستانه ناچیز وجود دارد",f"تعداد {len(trivial_items)} قلم به حد آستانه ثبت‌شده رسیده یا از آن عبور کرده است.",[m["id"] for m in trivial_items])

        risk_ids_with_workpapers = {w["risk_id"] for w in workpapers if w["risk_id"] is not None}
        uncovered_risks = [r for r in risks if r["id"] not in risk_ids_with_workpapers]
        if uncovered_risks:
            issue("RISKS_WITHOUT_WORKPAPERS","زیاد","ریسک‌هایی بدون کاربرگ مرتبط شناسایی شدند",f"تعداد {len(uncovered_risks)} ریسک فاقد کاربرگ مرتبط است.",[r["id"] for r in uncovered_risks])

        unfinished_workpapers = [w for w in workpapers if w["status"] not in self.FINAL_WORKPAPER_STATUSES]
        if unfinished_workpapers:
            issue("WORKPAPERS_NOT_FINAL","متوسط","کاربرگ‌های نهایی‌نشده وجود دارد",f"تعداد {len(unfinished_workpapers)} کاربرگ هنوز وضعیت نهایی و تأیید ندارد.",[w["id"] for w in unfinished_workpapers])
        unfinished_tests = [t for t in tests if t["status"] not in self.FINAL_TEST_STATUSES]
        if unfinished_tests:
            issue("TESTS_NOT_FINAL","زیاد","آزمون‌های حسابرسی نهایی‌نشده وجود دارد",f"تعداد {len(unfinished_tests)} آزمون هنوز تأیید نهایی مدیر دریافت نکرده است.",[t["id"] for t in unfinished_tests])

        open_findings = [f for f in findings if f["status"] not in ("رفع‌شده","بسته‌شده","مختومه")]
        if open_findings:
            issue("OPEN_FINDINGS","متوسط","یافته‌های باز وجود دارد",f"تعداد {len(open_findings)} یافته هنوز باز یا تعیین‌تکلیف‌نشده است.",[f["id"] for f in open_findings])

        samples_with_exceptions = [s for s in samples if s["result"] in ("مغایرت","دارای استثنا","رد") or s["exception_description"]]
        exceptions_without_evidence = [s for s in samples_with_exceptions if not s["evidence_path"]]
        if exceptions_without_evidence:
            issue("SAMPLE_EXCEPTIONS_WITHOUT_EVIDENCE","زیاد","استثناهای نمونه فاقد مسیر مدرک هستند",f"تعداد {len(exceptions_without_evidence)} نمونه دارای استثنا، مسیر مدرک ثبت‌شده ندارند.",[s["id"] for s in exceptions_without_evidence])

        open_requests = [r for r in requests if r["status"] in self.OPEN_REQUEST_STATUSES]
        if open_requests:
            issue("OPEN_DOCUMENT_REQUESTS","متوسط","درخواست‌های مدارک باز وجود دارد",f"تعداد {len(open_requests)} درخواست مدرک هنوز تکمیل یا لغو نشده است.",[r["id"] for r in open_requests])

        severity_order = {"بحرانی":0,"زیاد":1,"متوسط":2,"کم":3}
        issues.sort(key=lambda x:(severity_order.get(x["severity"],9),x["code"]))
        critical = sum(1 for x in issues if x["severity"] == "بحرانی")
        high = sum(1 for x in issues if x["severity"] == "زیاد")
        readiness = "نیازمند رسیدگی فوری" if critical else ("نیازمند تکمیل رسیدگی" if high else ("دارای موارد قابل پیگیری" if issues else "بدون هشدار شناسایی‌شده"))
        return {
            "project":dict(project),
            "readiness":readiness,
            "issues":issues,
            "counts":{
                "risks":len(risks),"workpapers":len(workpapers),"workpapers_not_final":len(unfinished_workpapers),
                "tests":len(tests),"tests_not_final":len(unfinished_tests),"findings":len(findings),
                "open_findings":len(open_findings),"samples":len(samples),"sample_exceptions":len(samples_with_exceptions),
                "exceptions_without_evidence":len(exceptions_without_evidence),"misstatements":len(misstatements),
                "uncorrected_misstatements":len(uncorrected),"corrected_misstatements":len(corrected),
                "document_requests_open":len(open_requests),"critical_issues":critical,"high_issues":high,
            },
            "misstatement_summary":{"uncorrected_gross_total":total_text,"materiality":materiality,
                "uncorrected_ids":[m["id"] for m in uncorrected],"corrected_ids":[m["id"] for m in corrected]},
            "limitations":[
                "این خروجی ابزار پشتیبان تصمیم‌گیری است و اظهارنظر حسابرس را تعیین نمی‌کند.",
                "وجود یا فقدان هشدار به‌تنهایی کفایت و مناسبت شواهد حسابرسی را اثبات نمی‌کند.",
                "جمع تحریفات به‌صورت ناخالص و بدون تهاتر محاسبه شده؛ آثار مالیاتی و آثار کیفی جداگانه نیازمند بررسی هستند.",
                "وضعیت آمادگی صرفاً بر اساس قواعد کنترلی تعریف‌شده در سامانه است و جایگزین قضاوت حرفه‌ای نیست.",
            ],
        }
