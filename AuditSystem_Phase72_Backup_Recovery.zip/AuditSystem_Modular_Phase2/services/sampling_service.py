import random

def select_sample(population, sample_size, seed=None):
    population=int(population); sample_size=int(sample_size)
    if population<1 or not 1<=sample_size<=population:
        raise ValueError("N و n باید اعداد صحیح مثبت باشند و n از N بزرگ‌تر نباشد.")
    if seed is None: seed=random.SystemRandom().getrandbits(64)
    selected=sorted(random.Random(seed).sample(range(1,population+1),sample_size))
    return {"seed":seed,"selected":selected}
