"""Phase 46 evidence metadata validation and traceability helpers.

This service is deliberately database/UI independent so the evidence rules can be
reused by repositories, views, imports, and tests.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Iterable


STATUSES = ("دریافت‌شده", "در حال بررسی", "تأییدشده", "ردشده", "بایگانی‌شده")
_ALLOWED_TRANSITIONS = {
    "دریافت‌شده": {"در حال بررسی", "بایگانی‌شده"},
    "در حال بررسی": {"تأییدشده", "ردشده", "دریافت‌شده", "بایگانی‌شده"},
    "تأییدشده": {"بایگانی‌شده"},
    "ردشده": {"دریافت‌شده", "بایگانی‌شده"},
    "بایگانی‌شده": set(),
}

_REQUIRED_FIELDS = ("title", "source", "received_by", "received_date")



class EvidenceManagementService:
    """Pure helpers for evidence validation, status transitions, links and hashing."""



    @staticmethod
    def validate_metadata(record: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(record, dict):
            raise ValueError("اطلاعات مدرک باید به شکل یک رکورد باشد.")
        missing = [field for field in _REQUIRED_FIELDS if not str(record.get(field) or "").strip()]
        if missing:
            raise ValueError("فیلدهای ضروری مدرک تکمیل نشده‌اند: " + ", ".join(missing))
        status = record.get("status", "دریافت‌شده")
        if status not in STATUSES:
            raise ValueError("وضعیت مدرک معتبر نیست.")
        return {**record, "status": status}



    @staticmethod
    def transition_status(current: str, target: str) -> str:
        if current not in _ALLOWED_TRANSITIONS:
            raise ValueError("وضعیت فعلی مدرک معتبر نیست.")
        if target not in STATUSES:
            raise ValueError("وضعیت مقصد معتبر نیست.")
        if target == current:
            return current
        if target not in _ALLOWED_TRANSITIONS[current]:
            raise ValueError(f"تغییر وضعیت از «{current}» به «{target}» مجاز نیست.")
        return target



    @staticmethod
    def validate_links(links: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
        """Validate link types and IDs; duplicates are removed while preserving order."""
        allowed_types = {"engagement", "risk", "account", "assertion", "procedure", "test", "sample", "workpaper", "finding"}
        result, seen = [], set()
        for item in links or []:
            if not isinstance(item, dict):
                raise ValueError("ارتباط مدرک باید رکورد معتبر باشد.")
            kind, entity_id = str(item.get("entity_type") or "").strip(), str(item.get("entity_id") or "").strip()
            if kind not in allowed_types:
                raise ValueError(f"نوع ارتباط مدرک معتبر نیست: {kind}")
            if not entity_id:
                raise ValueError("شناسه موجودیت مرتبط خالی است.")
            key = (kind, entity_id)
            if key not in seen:
                seen.add(key)
                result.append({"entity_type": kind, "entity_id": entity_id})
        return result



    @staticmethod
    def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
        """Return SHA-256 for file integrity/duplicate checks; raises on missing files."""
        file_path = Path(path)
        if not file_path.is_file():
            raise FileNotFoundError(str(file_path))
        if chunk_size <= 0:
            raise ValueError("اندازه بخش خواندن باید مثبت باشد.")
        digest = hashlib.sha256()
        with file_path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(chunk_size), b""):
                digest.update(chunk)
        return digest.hexdigest()



    @staticmethod
    def find_duplicate_hash(records: Iterable[dict[str, Any]], file_hash: str) -> list[dict[str, Any]]:
        """Find metadata rows with the same non-empty SHA-256 hash."""
        if not file_hash:
            return []
        return [record for record in records if str(record.get("sha256") or "").lower() == file_hash.lower()]
