"""Management dashboard metrics and actionable review queue.

This module is deliberately read-only: it summarizes recorded audit data and
never changes risks, tests, workpapers, findings, or approval decisions.
"""


class ManagementDashboardService:
    CLOSED_STATUSES = {
        "بسته", "مختومه", "رفع شده", "تکمیل شده", "انجام شده",
        "نهایی و تأیید", "تأیید نهایی مدیر", "completed", "closed", "done",
    }
    HIGH_SEVERITIES = {"بااهمیت", "اساسی", "زیاد", "critical", "high"}

    @staticmethod
    def normalize(value):
        return (str(value or "").strip().replace("ي", "ی")
                .replace("ك", "ک").replace("\u200c", " ").lower())

    @classmethod
    def is_closed(cls, value):
        return cls.normalize(value) in cls.CLOSED_STATUSES

    @classmethod
    def build_snapshot(cls, *, risk_rows=(), workpaper_rows=(),
                       finding_rows=(), test_rows=(),
                       findings_without_evidence=(),
                       unlinked_workpapers=(), unlinked_findings=(),
                       unlinked_tests=(), unlinked_programs=(),
                       risk_threshold=15):
        """Return deterministic KPIs and management actions from DB rows.

        Row formats: risks=(title, score); workpapers=(id,title,status);
        findings=(id,title,severity,status,owner); tests=(id,title,status).
        """
        try:
            threshold = int(risk_threshold)
        except (TypeError, ValueError):
            raise ValueError("آستانه ریسک باید عدد صحیح باشد.")
        if not 1 <= threshold <= 25:
            raise ValueError("آستانه ریسک باید بین ۱ تا ۲۵ باشد.")

        actions = []
        high_risks = []
        for row in risk_rows:
            title, score = row[0], row[1]
            try:
                numeric_score = int(score)
            except (TypeError, ValueError):
                continue
            if numeric_score >= threshold:
                high_risks.append((title, numeric_score))
                actions.append({
                    "priority": "بالا", "category": "ریسک",
                    "subject": str(title),
                    "action": "بازبینی پاسخ به ریسک و کفایت روش‌های رسیدگی",
                    "reference": "ریسک ثبت‌شده؛ نیازمند قضاوت حسابرس",
                })

        pending_tests = returned_tests = approved_tests = 0
        for row in test_rows:
            test_id, title, status = row[:3]
            normalized = cls.normalize(status)
            if normalized == cls.normalize("آماده بررسی سرپرست"):
                pending_tests += 1
                actions.append({
                    "priority": "بالا", "category": "آزمون",
                    "subject": str(title),
                    "action": "بررسی و تعیین تکلیف توسط سرپرست",
                    "reference": f"شناسه آزمون: {test_id}",
                })
            elif normalized == cls.normalize("نیازمند اصلاح"):
                returned_tests += 1
                actions.append({
                    "priority": "بالا", "category": "آزمون",
                    "subject": str(title),
                    "action": "پیگیری اصلاحات و ارسال مجدد برای بررسی",
                    "reference": f"شناسه آزمون: {test_id}",
                })
            elif normalized == cls.normalize("تأیید نهایی مدیر"):
                approved_tests += 1

        open_findings = critical_open_findings = 0
        for row in finding_rows:
            finding_id, title, severity, status, *rest = row
            if cls.is_closed(status):
                continue
            open_findings += 1
            if cls.normalize(severity) in {cls.normalize(x) for x in cls.HIGH_SEVERITIES}:
                critical_open_findings += 1
                owner = rest[0] if rest else ""
                actions.append({
                    "priority": "بالا", "category": "یافته",
                    "subject": str(title),
                    "action": "پیگیری اقدام اصلاحی و ارزیابی اثر بر گزارش",
                    "reference": f"شناسه یافته: {finding_id}" + (f" | مسئول: {owner}" if owner else ""),
                })

        for row in findings_without_evidence:
            finding_id, title = row[0], row[1]
            actions.append({
                "priority": "فوری", "category": "شواهد",
                "subject": str(title),
                "action": "بررسی کفایت و ثبت مستند پشتیبان",
                "reference": f"شناسه یافته: {finding_id}",
            })

        for label, rows, action in (
            ("کاربرگ", unlinked_workpapers, "بررسی و اتصال کاربرگ به ریسک مرتبط"),
            ("یافته", unlinked_findings, "بررسی و اتصال یافته به کاربرگ مرتبط"),
            ("آزمون", unlinked_tests, "بررسی ارتباط آزمون با کاربرگ"),
            ("برنامه", unlinked_programs, "بررسی ارتباط برنامه حسابرسی با ریسک"),
        ):
            for row in rows:
                actions.append({
                    "priority": "متوسط", "category": label,
                    "subject": str(row[1]), "action": action,
                    "reference": f"شناسه: {row[0]}",
                })

        priority_order = {"فوری": 0, "بالا": 1, "متوسط": 2, "عادی": 3}
        actions.sort(key=lambda item: (priority_order[item["priority"]],
                                      item["category"], item["subject"]))
        completed_workpapers = sum(1 for row in workpaper_rows if cls.is_closed(row[2]))
        return {
            "high_risk_count": len(high_risks),
            "pending_test_reviews": pending_tests,
            "returned_tests": returned_tests,
            "manager_approved_tests": approved_tests,
            "open_findings": open_findings,
            "critical_open_findings": critical_open_findings,
            "completed_workpapers": completed_workpapers,
            "total_workpapers": len(workpaper_rows),
            "workpaper_completion_percent": round(completed_workpapers * 100 / len(workpaper_rows)) if workpaper_rows else 0,
            "action_count": len(actions),
            "actions": actions,
        }
