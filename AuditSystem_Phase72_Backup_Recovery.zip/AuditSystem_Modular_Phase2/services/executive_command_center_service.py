"""Phase 32: read-only executive command center snapshot.


The service is schema-tolerant and only queries existing data. It does not
perform migrations, update statuses, or write audit records.
"""
from datetime import datetime



class ExecutiveCommandCenterService:
    TABLES = {
        "projects": ("projects", "پرونده‌ها"),
        "risks": ("risks", "ریسک‌ها"),
        "workpapers": ("workpapers", "کاربرگ‌ها"),
        "findings": ("findings", "یافته‌ها"),
        "audit_tests": ("audit_tests", "آزمون‌ها"),
        "documents": ("engagement_documents", "اسناد"),
        "document_requests": ("document_requests", "درخواست مدارک"),
        "internal_controls": ("internal_controls", "کنترل‌های داخلی"),
        "misstatements": ("audit_misstatements", "تحریفات"),
    }
    CLOSED = {"بسته", "مختومه", "رفع شده", "تکمیل شده", "انجام شده", "closed", "done", "completed"}
    OPEN = {"باز", "در جریان", "فعال", "open", "pending", "in progress"}



    @staticmethod
    def tables(conn):
        return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}



    @staticmethod
    def columns(conn, table):
        return {r[1] for r in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}



    @staticmethod
    def normalize(value):
        return str(value or "").strip().replace("ي", "ی").replace("ك", "ک").replace("\u200c", " ").lower()



    @classmethod
    def snapshot(cls, conn, project_id=None):
        """Return executive KPIs, status breakdowns and quality notices.


        Counts are scoped to project_id where the table supports that column.
        Optional/missing tables or columns are skipped rather than fatal.
        """
        present = cls.tables(conn)
        counts, statuses, notices = {}, {}, []
        for key, (table, label) in cls.TABLES.items():
            if table not in present:
                counts[key] = 0
                statuses[key] = {"open": 0, "closed": 0, "other": 0}
                continue
            cols = cls.columns(conn, table)
            scope_sql, params = (" WHERE project_id=?", (project_id,)) if project_id is not None and "project_id" in cols else ("", ())
            count = conn.execute(f'SELECT COUNT(*) FROM "{table}"{scope_sql}', params).fetchone()[0]
            counts[key] = count
            status_col = next((c for c in ("status", "state", "workflow_status") if c in cols), None)
            bucket = {"open": 0, "closed": 0, "other": 0}
            if status_col:
                query = f'SELECT "{status_col}" FROM "{table}"{scope_sql}'
                for (raw,) in conn.execute(query, params).fetchall():
                    normalized = cls.normalize(raw)
                    if normalized in {cls.normalize(x) for x in cls.CLOSED}:
                        bucket["closed"] += 1
                    elif normalized in {cls.normalize(x) for x in cls.OPEN}:
                        bucket["open"] += 1
                    else:
                        bucket["other"] += 1
            statuses[key] = bucket
        if project_id is not None:
            notices.append("نمایش داده‌ها به پرونده فعال محدود شده است.")
        else:
            notices.append("نمایش تجمیعی؛ برای تحلیل پرونده‌ای، یک پرونده فعال انتخاب کنید.")
        return {"scope_project_id": project_id, "counts": counts, "statuses": statuses,
                "total_records": sum(counts.values()), "notices": notices,
                "generated_at": datetime.now().isoformat(timespec="seconds")}
