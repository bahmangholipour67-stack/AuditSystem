import sqlite3
"""Professional, evidence-aware COSO assessment reporting.

The report is a read-only snapshot of records already entered for one project.
It deliberately does not infer control effectiveness from checklist answers.
"""
from datetime import datetime
from database.connection import open_connection


ANSWERS = ("بله", "خیر", "تاحدی", "قابل‌اعمال نیست", "پاسخ‌داده‌نشده")


class CosoAssessmentReportService:
    def __init__(self, db_path):
        self.db_path = str(db_path)

    def build(self, project_id):
        try:
            project_id = int(project_id)
        except (TypeError, ValueError):
            raise ValueError("شناسه پرونده حسابرسی معتبر نیست.")
        if project_id <= 0:
            raise ValueError("شناسه پرونده حسابرسی باید مثبت باشد.")

        conn = open_connection(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            project_row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
            if project_row is None:
                raise ValueError("پرونده انتخاب‌شده در پایگاه داده وجود ندارد.")
            project = dict(project_row)

            question_rows = conn.execute("""
                SELECT q.id question_id,q.principle_code,q.question_no,q.question_text,
                       q.guidance,q.expected_evidence,
                       COALESCE(r.answer,'پاسخ‌داده‌نشده') answer,
                       COALESCE(r.explanation,'') explanation,
                       COALESCE(r.evidence_ref,'') evidence_ref,
                       COALESCE(r.weakness,'') weakness,
                       COALESCE(r.corrective_action,'') corrective_action,
                       COALESCE(r.owner,'') owner,COALESCE(r.due_date,'') due_date,
                       COALESCE(r.assessor,'') assessor,r.updated_at
                FROM coso_checklist_questions q
                LEFT JOIN coso_checklist_responses r
                  ON r.question_id=q.id AND r.project_id=?
                ORDER BY q.principle_code,q.question_no
            """, (project_id,)).fetchall()
            questions = [dict(r) for r in question_rows]

            principle_rows = conn.execute("""
                SELECT p.code,p.component_no,p.component,p.principle_no,p.title,
                       a.rating,a.evidence assessment_evidence,a.conclusion assessment_conclusion,
                       a.assessor assessment_assessor,a.assessed_at,
                       (SELECT COUNT(*) FROM coso_control_mappings m
                         WHERE m.project_id=? AND m.principle_code=p.code) mapped_controls,
                       (SELECT COUNT(DISTINCT m.control_id) FROM coso_control_mappings m
                         JOIN control_tests t ON t.project_id=m.project_id AND t.control_id=m.control_id
                         WHERE m.project_id=? AND m.principle_code=p.code) tested_controls,
                       (SELECT COUNT(DISTINCT f.id) FROM findings f
                         JOIN coso_control_mappings m ON m.project_id=f.project_id
                           AND m.control_id=f.control_id AND m.principle_code=p.code
                         WHERE f.project_id=? AND f.finding_type='کنترل داخلی') linked_findings
                FROM coso_principles p
                LEFT JOIN coso_principle_assessments a
                  ON a.project_id=? AND a.principle_code=p.code
                ORDER BY p.component_no,p.principle_no
            """, (project_id, project_id, project_id, project_id)).fetchall()
            principles = [dict(r) for r in principle_rows]

            answer_counts = {a: sum(q["answer"] == a for q in questions) for a in ANSWERS}
            answered = len(questions) - answer_counts["پاسخ‌داده‌نشده"]
            weaknesses = [q for q in questions if q["answer"] in ("خیر", "تاحدی")]
            # An explanation is narrative; it is not a separately identifiable evidence reference.
            evidence_gaps = [q for q in questions
                             if q["answer"] not in ("پاسخ‌داده‌نشده", "قابل‌اعمال نیست")
                             and not q["evidence_ref"].strip()]
            na_without_rationale = [q for q in questions
                                    if q["answer"] == "قابل‌اعمال نیست"
                                    and not (q["explanation"].strip() or q["evidence_ref"].strip())]
            unanswered = [q for q in questions if q["answer"] == "پاسخ‌داده‌نشده"]

            component_map = {}
            for p in principles:
                comp = component_map.setdefault(p["component_no"], {
                    "component_no": p["component_no"], "component": p["component"],
                    "principle_count": 0, "question_count": 0, "answered_count": 0,
                    "yes_count": 0, "no_count": 0, "partial_count": 0,
                    "not_applicable_count": 0, "unanswered_count": 0,
                    "evidence_gap_count": 0, "mapped_control_count": 0,
                    "tested_control_count": 0, "linked_finding_count": 0,
                })
                comp["principle_count"] += 1
                comp["mapped_control_count"] += int(p["mapped_controls"] or 0)
                comp["tested_control_count"] += int(p["tested_controls"] or 0)
                comp["linked_finding_count"] += int(p["linked_findings"] or 0)
            for q in questions:
                p = next((x for x in principles if x["code"] == q["principle_code"]), None)
                if p is None:
                    continue
                comp = component_map[p["component_no"]]
                comp["question_count"] += 1
                key = {"بله": "yes_count", "خیر": "no_count", "تاحدی": "partial_count",
                       "قابل‌اعمال نیست": "not_applicable_count", "پاسخ‌داده‌نشده": "unanswered_count"}[q["answer"]]
                comp[key] += 1
                if q["answer"] != "پاسخ‌داده‌نشده":
                    comp["answered_count"] += 1
                if q in evidence_gaps:
                    comp["evidence_gap_count"] += 1
            components = sorted(component_map.values(), key=lambda x: x["component_no"])
            for comp in components:
                comp["completion_percent"] = round(comp["answered_count"] * 100 / comp["question_count"], 1) if comp["question_count"] else 0
                comp["assessment_status"] = self._component_status(comp)

            for p in principles:
                qs = [q for q in questions if q["principle_code"] == p["code"]]
                p["question_count"] = len(qs)
                p["answered_count"] = sum(q["answer"] != "پاسخ‌داده‌نشده" for q in qs)
                p["completion_percent"] = round(p["answered_count"] * 100 / len(qs), 1) if qs else 0
                p["yes_count"] = sum(q["answer"] == "بله" for q in qs)
                p["no_count"] = sum(q["answer"] == "خیر" for q in qs)
                p["partial_count"] = sum(q["answer"] == "تاحدی" for q in qs)
                p["not_applicable_count"] = sum(q["answer"] == "قابل‌اعمال نیست" for q in qs)
                p["unanswered_count"] = sum(q["answer"] == "پاسخ‌داده‌نشده" for q in qs)
                p["evidence_gap_count"] = sum(q in evidence_gaps for q in qs)
                p["assessment_status"] = self._principle_status(p)
                p["questions"] = qs

            actions = []
            for q in questions:
                if q["corrective_action"].strip() or q["weakness"].strip():
                    actions.append({
                        "principle_code": q["principle_code"], "question_no": q["question_no"],
                        "question_text": q["question_text"], "answer": q["answer"],
                        "weakness": q["weakness"], "action": q["corrective_action"],
                        "owner": q["owner"], "due_date": q["due_date"],
                        "followup_status": "وضعیت پیگیری در چک‌لیست ثبت نمی‌شود؛ نیازمند بررسی در ماژول اقدامات اصلاحی است.",
                    })

            if unanswered:
                overall_status = "ارزیابی ناقص؛ پرسش‌های بی‌پاسخ وجود دارد"
            elif weaknesses or evidence_gaps or na_without_rationale:
                overall_status = "نیازمند بررسی و پیگیری موارد شناسایی‌شده"
            else:
                overall_status = "پاسخ‌گویی تکمیل شده؛ نتیجه اثربخشی نیازمند آزمون و قضاوت مستقل است"

            summary = {
                "principle_count": len(principles), "component_count": len(components),
                "question_count": len(questions), "answered_count": answered,
                "completion_percent": round(answered * 100 / len(questions), 1) if questions else 0,
                "yes_count": answer_counts["بله"], "no_count": answer_counts["خیر"],
                "partial_count": answer_counts["تاحدی"],
                "not_applicable_count": answer_counts["قابل‌اعمال نیست"],
                "unanswered_count": answer_counts["پاسخ‌داده‌نشده"],
                "weakness_count": len(weaknesses), "evidence_gap_count": len(evidence_gaps),
                "na_without_rationale_count": len(na_without_rationale),
                "principles_with_recorded_rating": sum(p["rating"] is not None for p in principles),
                "principles_without_mapped_control": sum(int(p["mapped_controls"] or 0) == 0 for p in principles),
                "principles_with_no_control_test": sum(int(p["tested_controls"] or 0) == 0 for p in principles),
                "principles_linked_to_findings": sum(int(p["linked_findings"] or 0) > 0 for p in principles),
                "action_register_count": len(actions), "overall_status": overall_status,
            }
            return {
                "report_title": "گزارش حرفه‌ای ارزیابی چارچوب کنترل داخلی COSO",
                "project": project, "project_id": project_id,
                "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "summary": summary, "components": components, "principles": principles,
                "weaknesses": weaknesses, "evidence_gaps": evidence_gaps,
                "unanswered_questions": unanswered, "na_without_rationale": na_without_rationale,
                "action_register": actions,
                "methodology": [
                    "این گزارش بر اساس پاسخ‌ها و مستندات ثبت‌شده در پرونده انتخاب‌شده تهیه شده است.",
                    "پاسخ‌های پرسش‌نامه به‌تنهایی اثبات‌کننده طراحی مناسب یا اثربخشی عملیاتی کنترل‌ها نیستند.",
                    "پاسخ «خیر» یا «تاحدی» نشانه نیاز به بررسی است و بدون ارزیابی معیار، علت، اثر، اهمیت و شواهد، یافته قطعی تلقی نمی‌شود.",
                    "پاسخ «بله» نیز بدون بررسی شواهد و آزمون، اثبات اجرای مؤثر کنترل نیست.",
                    "پرسش‌های فاقد ارجاع مستقل شواهد به‌عنوان خلأ مستندسازی علامت‌گذاری شده‌اند؛ شرح پاسخ به‌تنهایی جای ارجاع مدرک را نمی‌گیرد.",
                    "موارد قابل‌اعمال‌نبودن باید دارای توجیه مستند و تأیید ارزیاب باشند.",
                    "امتیازهای ثبت‌شده برای اصول، جدا از نتایج پرسش‌نامه نمایش داده می‌شوند و میانگین یا نتیجه اثربخشی از پاسخ‌ها استنتاج نمی‌شود.",
                    "این گزارش گواهی انطباق با COSO نیست و جایگزین قضاوت حرفه‌ای حسابرس یا ارزیابی مستقل نمی‌شود.",
                ],
            }
        finally:
            conn.close()

    @staticmethod
    def _principle_status(p):
        if p["unanswered_count"]:
            return "ناقص"
        if p["no_count"] or p["partial_count"] or p["evidence_gap_count"]:
            return "نیازمند بررسی"
        return "پاسخ‌گویی تکمیل‌شده؛ اثربخشی احراز نشده"

    @staticmethod
    def _component_status(c):
        if c["unanswered_count"]:
            return "ناقص"
        if c["no_count"] or c["partial_count"] or c["evidence_gap_count"]:
            return "نیازمند بررسی"
        return "پاسخ‌گویی تکمیل‌شده؛ اثربخشی احراز نشده"

    def export_excel(self, report, path):
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
        wb = Workbook(); ws = wb.active; ws.title = "خلاصه مدیریتی"
        ws.append([report["report_title"]]); ws.append(["پرونده", report["project"].get("name", "")])
        ws.append(["دوره", report["project"].get("period", "")]); ws.append(["تاریخ تهیه", report["generated_at"]])
        ws.append([]); ws.append(["شاخص", "مقدار"])
        labels = {"overall_status":"وضعیت ارزیابی", "completion_percent":"درصد تکمیل", "question_count":"تعداد پرسش‌ها", "answered_count":"پاسخ‌داده‌شده", "yes_count":"بله", "no_count":"خیر", "partial_count":"تاحدی", "not_applicable_count":"قابل‌اعمال نیست", "unanswered_count":"بی‌پاسخ", "weakness_count":"موارد نیازمند بررسی", "evidence_gap_count":"فاقد ارجاع مستقل شواهد", "principles_with_recorded_rating":"اصول دارای امتیاز مستقل", "principles_without_mapped_control":"اصول فاقد کنترل نگاشت‌شده", "principles_with_no_control_test":"اصول فاقد آزمون کنترل"}
        for k, label in labels.items(): ws.append([label, report["summary"].get(k, "")])
        components = wb.create_sheet("مؤلفه‌ها"); components.append(["شماره", "مؤلفه", "اصول", "پرسش‌ها", "پاسخ‌داده‌شده", "درصد تکمیل", "خیر", "تاحدی", "بی‌پاسخ", "خلأ شواهد", "وضعیت"])
        for c in report["components"]: components.append([c["component_no"],c["component"],c["principle_count"],c["question_count"],c["answered_count"],c["completion_percent"],c["no_count"],c["partial_count"],c["unanswered_count"],c["evidence_gap_count"],c["assessment_status"]])
        principles = wb.create_sheet("اصول ۱۷گانه"); principles.append(["کد", "مؤلفه", "اصل", "عنوان", "پاسخ‌داده‌شده", "کل پرسش", "بله", "خیر", "تاحدی", "بی‌پاسخ", "کنترل نگاشت‌شده", "کنترل آزمون‌شده", "یافته مرتبط", "امتیاز مستقل", "وضعیت"])
        for p in report["principles"]: principles.append([p["code"],p["component"],p["principle_no"],p["title"],p["answered_count"],p["question_count"],p["yes_count"],p["no_count"],p["partial_count"],p["unanswered_count"],p["mapped_controls"],p["tested_controls"],p["linked_findings"],p["rating"],p["assessment_status"]])
        qsheet = wb.create_sheet("جزئیات پرسش‌ها"); qsheet.append(["کد اصل", "شماره", "پرسش", "پاسخ", "توضیحات", "ارجاع شواهد", "ضعف", "اقدام اصلاحی", "مسئول", "سررسید", "ارزیاب"])
        for p in report["principles"]:
            for q in p["questions"]: qsheet.append([q["principle_code"],q["question_no"],q["question_text"],q["answer"],q["explanation"],q["evidence_ref"],q["weakness"],q["corrective_action"],q["owner"],q["due_date"],q["assessor"]])
        for name, rows, headers in (("موارد نیازمند بررسی", report["weaknesses"], ["اصل","شماره","پرسش","پاسخ","ضعف","شواهد"]), ("خلأ شواهد",report["evidence_gaps"],["اصل","شماره","پرسش","پاسخ","توضیحات","ارجاع شواهد"])):
            sh=wb.create_sheet(name); sh.append(headers)
            for q in rows: sh.append([q["principle_code"],q["question_no"],q["question_text"],q["answer"],q.get("weakness") or q.get("explanation"),q["evidence_ref"]])
        acts=wb.create_sheet("اقدامات اصلاحی"); acts.append(["اصل","شماره پرسش","ضعف","اقدام","مسئول","سررسید","یادداشت پیگیری"])
        for a in report["action_register"]: acts.append([a["principle_code"],a["question_no"],a["weakness"],a["action"],a["owner"],a["due_date"],a["followup_status"]])
        for sh in wb.worksheets:
            sh.sheet_view.rightToLeft=True; sh.freeze_panes="A2"
            for row in sh.iter_rows():
                for cell in row: cell.alignment=Alignment(horizontal="right",vertical="top",wrap_text=True)
            for cell in sh[1]: cell.font=Font(bold=True,color="FFFFFF"); cell.fill=PatternFill("solid",fgColor="1F4E78")
            for col in sh.columns:
                letter=get_column_letter(col[0].column); width=max((len(str(x.value or "")) for x in col),default=12)
                sh.column_dimensions[letter].width=min(max(width+2,14),60)
        wb.save(path); return str(path)

    def export_word(self, report, path):
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Cm, Pt
        doc=Document(); sec=doc.sections[0]; sec.top_margin=Cm(1.8); sec.bottom_margin=Cm(1.8)
        title=doc.add_heading(report["report_title"],0); title.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        p=doc.add_paragraph(f"پرونده: {report['project'].get('name','')} | دوره: {report['project'].get('period','')} | تاریخ تهیه: {report['generated_at']}"); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        doc.add_heading("۱. خلاصه مدیریتی",level=1)
        s=report["summary"]
        for label,key in (("وضعیت ارزیابی","overall_status"),("درصد تکمیل","completion_percent"),("پرسش‌های پاسخ‌داده‌شده","answered_count"),("کل پرسش‌ها","question_count"),("پاسخ خیر","no_count"),("پاسخ تاحدی","partial_count"),("پرسش‌های بی‌پاسخ","unanswered_count"),("موارد نیازمند بررسی","weakness_count"),("خلأ ارجاع شواهد","evidence_gap_count")):
            p=doc.add_paragraph(f"{label}: {s[key]}"); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        doc.add_heading("۲. نتایج پنج مؤلفه",level=1)
        table=doc.add_table(rows=1,cols=6); table.style="Table Grid"
        for cell,label in zip(table.rows[0].cells,("مؤلفه","پرسش","تکمیل","خیر","تاحدی","وضعیت")): cell.text=label
        for c in report["components"]:
            cells=table.add_row().cells
            for cell,value in zip(cells,(c["component"],c["question_count"],f"{c['completion_percent']}%",c["no_count"],c["partial_count"],c["assessment_status"])): cell.text=str(value)
        doc.add_heading("۳. تحلیل ۱۷ اصل",level=1)
        for pitem in report["principles"]:
            p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
            run=p.add_run(f"{pitem['code']} ـ اصل {pitem['principle_no']}: {pitem['title']}"); run.bold=True
            detail=f"پیشرفت: {pitem['answered_count']}/{pitem['question_count']} ({pitem['completion_percent']}%) | بله: {pitem['yes_count']} | خیر: {pitem['no_count']} | تاحدی: {pitem['partial_count']} | بی‌پاسخ: {pitem['unanswered_count']} | کنترل نگاشت‌شده: {pitem['mapped_controls']} | کنترل آزمون‌شده: {pitem['tested_controls']} | امتیاز مستقل ثبت‌شده: {pitem['rating'] if pitem['rating'] is not None else 'ثبت نشده'} | وضعیت: {pitem['assessment_status']}"
            pp=doc.add_paragraph(detail); pp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
            for q in pitem["questions"]:
                if q["answer"] in ("خیر","تاحدی","پاسخ‌داده‌نشده") or not q["evidence_ref"]:
                    d=doc.add_paragraph(f"پرسش {q['question_no']} ـ {q['question_text']} | پاسخ: {q['answer']} | ضعف: {q['weakness']} | شواهد: {q['evidence_ref'] or 'ارجاع ثبت نشده'}")
                    d.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        doc.add_heading("۴. فهرست اقدامات اصلاحی ثبت‌شده",level=1)
        if report["action_register"]:
            table=doc.add_table(rows=1,cols=5); table.style="Table Grid"
            for cell,label in zip(table.rows[0].cells,("اصل/پرسش","ضعف","اقدام","مسئول","سررسید")): cell.text=label
            for a in report["action_register"]:
                cells=table.add_row().cells
                for cell,value in zip(cells,(f"{a['principle_code']} / {a['question_no']}",a["weakness"],a["action"],a["owner"],a["due_date"])): cell.text=str(value)
        else:
            doc.add_paragraph("اقدام اصلاحی در چک‌لیست ثبت نشده است.")
        doc.add_heading("۵. روش‌شناسی و محدودیت‌ها",level=1)
        for note in report["methodology"]:
            p=doc.add_paragraph(note); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        for paragraph in doc.paragraphs: paragraph.paragraph_format.space_after=Pt(5)
        doc.save(path); return str(path)
