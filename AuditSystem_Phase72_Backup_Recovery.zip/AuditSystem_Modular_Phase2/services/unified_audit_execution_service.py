"""Shared, read-only execution-coverage engine for financial and internal audits.

The service normalizes common audit execution stages while preserving the
method-specific requirements of financial-statement and internal audits.
It reports documentation gaps; it does not determine audit opinions or
replace professional judgment.
"""

from repositories.audit_traceability_repository import AuditTraceabilityRepository


class UnifiedAuditExecutionService:
    MODES = {"financial": "حسابرسی صورت‌های مالی", "internal": "حسابرسی داخلی", "combined": "حسابرسی تلفیقی"}
    PRIORITY = {"فوری": 0, "بالا": 1, "متوسط": 2, "عادی": 3}
    EXCEPTIONS = {"مغایرت", "عدم انطباق", "نیازمند بررسی"}

    def __init__(self, repository=None):
        self.repository = repository or AuditTraceabilityRepository()

    @staticmethod
    def _text(value):
        return str(value or "").strip()

    @staticmethod
    def _list(value):
        if isinstance(value, (list, tuple)):
            return [str(x).strip() for x in value if str(x).strip()]
        import json
        try:
            parsed = json.loads(value or "[]")
        except (TypeError, ValueError):
            return []
        return [str(x).strip() for x in parsed if str(x).strip()] if isinstance(parsed, list) else []

    def build_report(self, data, mode="combined"):
        if mode not in self.MODES:
            raise ValueError("نوع حسابرسی باید financial، internal یا combined باشد.")
        if not isinstance(data, dict) or not data.get("project_id"):
            raise ValueError("اطلاعات پرونده حسابرسی معتبر نیست.")

        risks = list(data.get("risks", []))
        programs = list(data.get("programs", []))
        tests = list(data.get("tests", []))
        samples = list(data.get("samples", []))
        findings = list(data.get("findings", []))
        evidence = list(data.get("finding_evidence", []))
        programs_by_id = {x.get("id"): x for x in programs}
        tests_by_program, samples_by_test, evidence_by_finding = {}, {}, {}
        for row in tests:
            tests_by_program.setdefault(row.get("program_id"), []).append(row)
        for row in samples:
            samples_by_test.setdefault(row.get("test_id"), []).append(row)
        for row in evidence:
            evidence_by_finding.setdefault(row.get("finding_id"), []).append(row)

        gaps = []
        def add(priority, kind, row_id, title, issue, action):
            gaps.append({"priority": priority, "entity_type": kind, "entity_id": row_id,
                         "title": self._text(title) or "بدون عنوان", "issue": issue, "action": action})

        risk_programs, risk_tests = set(), set()
        for program in programs:
            rid = program.get("risk_id")
            if rid is not None:
                risk_programs.add(rid)
            attached = tests_by_program.get(program.get("id"), [])
            if not attached:
                add("متوسط", "برنامه", program.get("id"), program.get("title"),
                    "برای برنامه حسابرسی آزمونی ثبت نشده است.", "آزمون متناسب با هدف برنامه طراحی و مستند شود.")
            if rid is None:
                add("متوسط", "برنامه", program.get("id"), program.get("title"),
                    "برنامه به ریسک مشخصی متصل نیست.", "ارتباط برنامه با ریسک یا توجیه عدم ارتباط ثبت شود.")
            for test in attached:
                effective = rid if rid is not None else test.get("program_risk_id")
                if effective is not None:
                    risk_tests.add(effective)

        for risk in risks:
            rid = risk.get("id")
            if rid not in risk_programs:
                add("بالا" if int(risk.get("score") or 0) >= 16 else "متوسط", "ریسک", rid,
                    risk.get("title"), "برای ریسک برنامه رسیدگی ثبت نشده است.",
                    "پاسخ حسابرسی متناسب با سطح ریسک طراحی شود.")
            elif rid not in risk_tests:
                add("بالا" if int(risk.get("score") or 0) >= 16 else "متوسط", "ریسک", rid,
                    risk.get("title"), "ریسک به برنامه متصل است اما آزمون قابل ردیابی ندارد.",
                    "حداقل یک آزمون مرتبط با این ریسک ثبت شود.")

        for test in tests:
            tid, title = test.get("id"), test.get("title")
            if test.get("program_id") not in programs_by_id:
                add("بالا", "آزمون", tid, title, "برنامه مادر آزمون در همین پرونده یافت نشد.",
                    "ارتباط آزمون با برنامه معتبر همین پرونده اصلاح شود.")
            if not test.get("workpaper_id"):
                add("متوسط", "آزمون", tid, title, "آزمون کاربرگ پشتیبان ندارد.",
                    "کاربرگ اجرای آزمون به آن متصل شود.")
            assertions = self._list(test.get("template_assertions"))
            objective = self._text(test.get("template_objective"))
            if mode in ("financial", "combined") and not assertions:
                add("متوسط", "آزمون", tid, title, "ادعاهای مرتبط صورت‌های مالی ثبت نشده‌اند.",
                    "ادعاهای مرتبط مانند وقوع، کامل بودن، دقت یا ارزشیابی تعیین شوند.")
            if mode in ("internal", "combined") and not objective:
                add("متوسط", "آزمون", tid, title, "هدف یا معیار کنترلی آزمون ثبت نشده است.",
                    "هدف کنترل، معیار ارزیابی یا مبنای سنجش آزمون داخلی مستند شود.")
            test_samples = samples_by_test.get(tid, [])
            if not test_samples:
                add("متوسط", "آزمون", tid, title, "برای آزمون نمونه یا نتیجه اجرای مستند ثبت نشده است.",
                    "جامعه و نمونه‌ها یا مبنای عدم نمونه‌گیری ثبت شود.")
            unresolved = [s for s in test_samples if not self._text(s.get("result"))]
            if unresolved:
                add("متوسط", "نمونه", tid, title, f"{len(unresolved)} نمونه نتیجه رسیدگی ندارد.",
                    "نتیجه هر نمونه یا وضعیت عدم امکان رسیدگی ثبت شود.")
            if any(self._text(s.get("result")) in self.EXCEPTIONS for s in test_samples):
                linked = bool(test.get("finding_id")) or any(s.get("finding_id") for s in test_samples)
                if not linked:
                    add("بالا", "آزمون", tid, title, "استثنا ثبت شده اما به یافته‌ای مرتبط نیست.",
                        "استثنا ارزیابی و در صورت لزوم به یافته متصل شود.")
            if not self._text(test.get("conclusion")):
                add("متوسط", "آزمون", tid, title, "نتیجه‌گیری آزمون ثبت نشده است.",
                    "نتیجه‌گیری متناسب با هدف، روش، نمونه و شواهد مستند شود.")
            if test_samples and not any(self._text(s.get("evidence_path")) for s in test_samples):
                add("بالا", "شواهد", tid, title, "برای نمونه‌ها مسیر شواهد ثبت نشده است.",
                    "ارجاع به شواهد قابل اتکا برای نمونه‌ها ثبت شود.")

        for finding in findings:
            fid, title = finding.get("id"), finding.get("title")
            if not finding.get("risk_id") and not finding.get("workpaper_risk_id"):
                add("متوسط", "یافته", fid, title, "یافته به ریسک مشخصی متصل نیست.",
                    "ریسک مرتبط یا توجیه عدم ارتباط ثبت شود.")
            if not finding.get("workpaper_id"):
                add("متوسط", "یافته", fid, title, "یافته کاربرگ پشتیبان ندارد.",
                    "کاربرگ حاوی شواهد و مبنای یافته متصل شود.")
            if not evidence_by_finding.get(fid):
                add("بالا", "یافته", fid, title, "برای یافته مدرک پشتیبان ثبت نشده است.",
                    "شواهد مؤید وضعیت، معیار، علت و اثر یافته ثبت شود.")

        gaps.sort(key=lambda x: (self.PRIORITY.get(x["priority"], 9), x["entity_type"], x["entity_id"] or 0))
        total_risks = len(risks)
        covered = len(risk_tests)
        stage_counts = {
            "risks": total_risks, "programs": len(programs), "tests": len(tests),
            "samples": len(samples), "findings": len(findings), "evidence_links": len(evidence),
            "tests_without_conclusion": sum(not self._text(t.get("conclusion")) for t in tests),
            "open_gaps": len(gaps), "high_priority_gaps": sum(g["priority"] in ("فوری", "بالا") for g in gaps),
        }
        return {
            "project_id": data["project_id"], "mode": mode, "mode_label": self.MODES[mode],
            "summary": stage_counts,
            "risk_coverage_percent": round(covered / total_risks * 100, 1) if total_risks else 100.0,
            "gaps": gaps,
            "limitations": [
                "این گزارش ابزار کنترل تکمیل و ردیابی مستندات است و کفایت یا قابلیت اتکای شواهد را اثبات نمی‌کند.",
                "درصد پوشش ریسک صرفاً وجود ارتباط ثبت‌شده با آزمون را نشان می‌دهد، نه کفایت پاسخ حسابرسی.",
                "این موتور اظهارنظر حسابرس، ارزیابی نهایی کنترل یا نتیجه حسابرسی را تعیین نمی‌کند.",
                "در حالت تلفیقی، هر دو مجموعه الزامات ادعاهای صورت‌های مالی و اهداف/معیارهای کنترلی بررسی می‌شوند.",
            ],
        }

    def for_project(self, project_id, mode="combined"):
        if not project_id:
            raise ValueError("پرونده حسابرسی مشخص نشده است.")
        return self.build_report(self.repository.for_project(project_id), mode=mode)
