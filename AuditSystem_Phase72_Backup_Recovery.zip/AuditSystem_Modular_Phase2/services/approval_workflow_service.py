"""Version-bound, project-scoped multi-stage approval workflow."""
import hashlib
import json
from database.connection import connect


class ApprovalWorkflowService:
    ENTITY_TABLES = {
        "workpaper": ("workpapers", "id, project_id, title, procedure, result, status, risk_id"),
        "audit_test": ("audit_tests", "id, project_id, title, procedure, conclusion, status, program_id, workpaper_id"),
    }
    STAGES = {
        "supervisor": ("سرپرست حسابرسی", "supervisor_member_id", "manager"),
        "manager": ("مدیر حسابرسی", "manager_member_id", "quality"),
        "quality": ("مسئول کنترل کیفیت", "quality_member_id", "complete"),
    }

    @staticmethod
    def _dict(cursor, row):
        return dict(zip([c[0] for c in cursor.description], row)) if row else None

    def _snapshot(self, conn, project_id, entity_type, entity_id):
        if entity_type not in self.ENTITY_TABLES:
            raise ValueError("نوع مدرک برای گردش تأیید پشتیبانی نمی‌شود.")
        table, columns = self.ENTITY_TABLES[entity_type]
        cur = conn.execute(f"SELECT {columns} FROM {table} WHERE id=? AND project_id=?", (entity_id, project_id))
        row = self._dict(cur, cur.fetchone())
        if not row:
            raise ValueError("مدرک در این پرونده پیدا نشد.")
        encoded = json.dumps(row, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(encoded.encode("utf-8")).hexdigest()

    @staticmethod
    def _member(conn, project_id, member_id):
        cur = conn.execute("SELECT id, full_name, role, is_active FROM team_members WHERE id=? AND project_id=?", (member_id, project_id))
        row = cur.fetchone()
        if not row or not row[3]:
            raise ValueError("عضو فعال در این پرونده یافت نشد.")
        return {"id": row[0], "full_name": row[1], "role": row[2]}

    def submit(self, project_id, entity_type, entity_id, submitter_id, supervisor_id, manager_id, quality_id):
        if not all((project_id, entity_id, submitter_id, supervisor_id, manager_id, quality_id)):
            raise ValueError("پرونده، مدرک و تمام اعضای گردش تأیید الزامی هستند.")
        with connect() as conn:
            snapshot = self._snapshot(conn, project_id, entity_type, entity_id)
            submitter = self._member(conn, project_id, submitter_id)
            assignments = [
                (supervisor_id, "سرپرست حسابرسی"),
                (manager_id, "مدیر حسابرسی"),
                (quality_id, "مسئول کنترل کیفیت"),
            ]
            reviewers = [self._member(conn, project_id, mid) for mid, _ in assignments]
            for member, (_, role) in zip(reviewers, assignments):
                if member["role"] != role:
                    raise ValueError(f"نقش عضو {member['full_name']} باید {role} باشد.")
                if member["id"] == submitter_id:
                    raise ValueError("ارسال‌کننده نمی‌تواند هیچ‌یک از تأییدکنندگان باشد.")
            if len({submitter_id, supervisor_id, manager_id, quality_id}) != 4:
                raise ValueError("ارسال‌کننده و سه تأییدکننده باید چهار شخص متفاوت باشند.")
            existing = conn.execute("SELECT id, status FROM approval_requests WHERE project_id=? AND entity_type=? AND entity_id=?", (project_id, entity_type, entity_id)).fetchone()
            if existing and existing[1] not in ("returned",):
                raise ValueError("برای این مدرک درخواست فعال یا نهایی‌شده وجود دارد.")
            if existing:
                raise ValueError("برای ارسال مجدد از متد resubmit استفاده کنید تا تاریخچه حفظ شود.")
            cur = conn.execute("""INSERT INTO approval_requests
                (project_id, entity_type, entity_id, snapshot_hash, submitted_by_member_id,
                 supervisor_member_id, manager_member_id, quality_member_id, current_stage, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'supervisor', 'pending_supervisor')""",
                (project_id, entity_type, entity_id, snapshot, submitter_id, supervisor_id, manager_id, quality_id))
            request_id = cur.lastrowid
            conn.execute("""INSERT INTO approval_history
                (project_id, request_id, event_type, stage, actor_member_id, actor_role, comment, snapshot_hash)
                VALUES (?, ?, 'submitted', 'supervisor', ?, ?, '', ?)""", (project_id, request_id, submitter_id, submitter["role"], snapshot))
            return request_id

    def decide(self, project_id, request_id, actor_id, decision, comment=""):
        if decision not in ("approve", "return"):
            raise ValueError("تصمیم باید approve یا return باشد.")
        with connect() as conn:
            cur = conn.execute("SELECT * FROM approval_requests WHERE id=? AND project_id=? AND archived_at IS NULL", (request_id, project_id))
            req = self._dict(cur, cur.fetchone())
            if not req:
                raise ValueError("درخواست تأیید در این پرونده یافت نشد.")
            if req["status"] not in ("pending_supervisor", "pending_manager", "pending_quality"):
                raise ValueError("این درخواست در وضعیت قابل تصمیم‌گیری نیست.")
            current_hash = self._snapshot(conn, project_id, req["entity_type"], req["entity_id"])
            if current_hash != req["snapshot_hash"]:
                raise ValueError("نسخه مدرک پس از ارسال تغییر کرده است؛ تصمیم‌گیری روی نسخه قدیمی ممنوع است.")
            actor = self._member(conn, project_id, actor_id)
            role, member_field, next_stage = self.STAGES[req["current_stage"]]
            if actor["role"] != role or req[member_field] != actor_id:
                raise ValueError("این عضو، تأییدکننده مجاز مرحله جاری نیست.")
            if actor_id == req["submitted_by_member_id"]:
                raise ValueError("خودتأییدی مجاز نیست.")
            comment = str(comment or "").strip()
            if decision == "return" and not comment:
                raise ValueError("برای برگشت جهت اصلاح، درج توضیحات الزامی است.")
            if decision == "return":
                conn.execute("UPDATE approval_requests SET status='returned' WHERE id=? AND project_id=?", (request_id, project_id))
                event = "returned"
            elif next_stage == "complete":
                conn.execute("UPDATE approval_requests SET status='approved', current_stage='complete', completed_at=CURRENT_TIMESTAMP WHERE id=? AND project_id=?", (request_id, project_id))
                event = "approved_final"
            else:
                conn.execute("UPDATE approval_requests SET current_stage=?, status=? WHERE id=? AND project_id=?", (next_stage, f"pending_{next_stage}", request_id, project_id))
                event = "stage_approved"
            conn.execute("""INSERT INTO approval_history
                (project_id, request_id, event_type, stage, actor_member_id, actor_role, comment, snapshot_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", (project_id, request_id, event, req["current_stage"], actor_id, actor["role"], comment, current_hash))
            return True

    def resubmit(self, project_id, request_id, submitter_id):
        with connect() as conn:
            cur = conn.execute("SELECT * FROM approval_requests WHERE id=? AND project_id=? AND archived_at IS NULL", (request_id, project_id))
            req = self._dict(cur, cur.fetchone())
            if not req or req["status"] != "returned":
                raise ValueError("فقط درخواست برگشت‌خورده قابل ارسال مجدد است.")
            if req["submitted_by_member_id"] != submitter_id:
                raise ValueError("فقط ارسال‌کننده اولیه می‌تواند نسخه اصلاح‌شده را ارسال کند.")
            submitter = self._member(conn, project_id, submitter_id)
            snapshot = self._snapshot(conn, project_id, req["entity_type"], req["entity_id"])
            conn.execute("""UPDATE approval_requests SET snapshot_hash=?, current_stage='supervisor',
                status='pending_supervisor', submitted_at=CURRENT_TIMESTAMP, completed_at=NULL
                WHERE id=? AND project_id=?""", (snapshot, request_id, project_id))
            conn.execute("""INSERT INTO approval_history
                (project_id, request_id, event_type, stage, actor_member_id, actor_role, comment, snapshot_hash)
                VALUES (?, ?, 'resubmitted', 'supervisor', ?, ?, '', ?)""", (project_id, request_id, submitter_id, submitter["role"], snapshot))
            return True

    def history(self, project_id, request_id):
        with connect() as conn:
            return conn.execute("""SELECT h.id, h.event_type, h.stage, h.actor_member_id,
                m.full_name, h.actor_role, h.comment, h.snapshot_hash, h.created_at
                FROM approval_history h LEFT JOIN team_members m
                ON m.id=h.actor_member_id AND m.project_id=h.project_id
                WHERE h.project_id=? AND h.request_id=? ORDER BY h.id""", (project_id, request_id)).fetchall()

    def inbox(self, project_id, member_id):
        """Return only pending approvals assigned to the active member."""
        if not project_id or not member_id:
            return []
        with connect() as conn:
            member = self._member(conn, project_id, member_id)
            stage_assignment = {
                "supervisor": ("supervisor_member_id", "pending_supervisor"),
                "manager": ("manager_member_id", "pending_manager"),
                "quality": ("quality_member_id", "pending_quality"),
            }
            stage = next((key for key, (field, _) in stage_assignment.items()
                          if member["role"] == self.STAGES[key][0]), None)
            if stage is None:
                return []
            field, status = stage_assignment[stage]
            rows = conn.execute(f"""SELECT a.id, a.entity_type, a.entity_id, a.status,
                a.current_stage, a.submitted_at, a.submitted_by_member_id,
                CASE a.entity_type
                    WHEN 'workpaper' THEN (SELECT w.title FROM workpapers w
                        WHERE w.id=a.entity_id AND w.project_id=a.project_id)
                    WHEN 'audit_test' THEN (SELECT t.title FROM audit_tests t
                        WHERE t.id=a.entity_id AND t.project_id=a.project_id)
                    ELSE '' END AS entity_title
                FROM approval_requests a
                WHERE a.project_id=? AND a.archived_at IS NULL
                  AND a.status=? AND a.current_stage=? AND a.{field}=?
                ORDER BY a.submitted_at, a.id""",
                (project_id, status, stage, member_id)).fetchall()
            return rows

    def for_project(self, project_id):
        with connect() as conn:
            return conn.execute("""SELECT id, entity_type, entity_id, status, current_stage,
                submitted_by_member_id, submitted_at, completed_at FROM approval_requests
                WHERE project_id=? AND archived_at IS NULL ORDER BY id DESC""", (project_id,)).fetchall()
