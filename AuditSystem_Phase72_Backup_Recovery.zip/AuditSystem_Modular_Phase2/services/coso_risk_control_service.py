"""Project-scoped COSO Internal Control Framework mapping and assessment.

The service supports structured documentation against the five COSO components
and 17 principles. It does not certify compliance or replace professional judgment.
"""
from database.connection import connect
from database.migrations import ensure_schema
from config.settings import DATABASE_PATH


class CosoRiskControlService:
    RATINGS = {1: "ضعیف", 2: "نیازمند بهبود", 3: "قابل قبول", 4: "خوب", 5: "قوی"}

    def __init__(self, db_path=None):
        self.db_path = str(db_path or DATABASE_PATH)
        ensure_schema(self.db_path)

    def _project(self, c, project_id):
        if not project_id or not c.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
            raise ValueError("پرونده حسابرسی معتبر نیست.")

    def principles(self):
        with connect(self.db_path) as c:
            cur = c.execute("SELECT * FROM coso_principles ORDER BY component_no, principle_no")
            names = [d[0] for d in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    def map_control(self, project_id, control_id, principle_code, risk_id=None, rationale=""):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            if not c.execute("SELECT 1 FROM internal_controls WHERE id=? AND project_id=?", (control_id, project_id)).fetchone():
                raise ValueError("کنترل انتخاب‌شده متعلق به این پرونده نیست.")
            if not c.execute("SELECT 1 FROM coso_principles WHERE code=?", (principle_code,)).fetchone():
                raise ValueError("اصل COSO معتبر نیست.")
            if risk_id is not None and not c.execute("SELECT 1 FROM risks WHERE id=? AND project_id=?", (risk_id, project_id)).fetchone():
                raise ValueError("ریسک انتخاب‌شده متعلق به این پرونده نیست.")
            cur = c.execute("""INSERT INTO coso_control_mappings
                (project_id,control_id,principle_code,risk_id,rationale)
                VALUES(?,?,?,?,?) ON CONFLICT(project_id,control_id,principle_code)
                DO UPDATE SET risk_id=excluded.risk_id,rationale=excluded.rationale,
                updated_at=CURRENT_TIMESTAMP""", (project_id, control_id, principle_code, risk_id, str(rationale or "").strip()))
            row = c.execute("SELECT id FROM coso_control_mappings WHERE project_id=? AND control_id=? AND principle_code=?", (project_id, control_id, principle_code)).fetchone()
            self._history(c, project_id, "mapping", row[0], "UPSERT", principle_code)
            return row[0]

    def assess_principle(self, project_id, principle_code, rating, evidence, conclusion="", assessor=""):
        try: rating = int(rating)
        except (TypeError, ValueError): raise ValueError("امتیاز باید عددی بین ۱ تا ۵ باشد.")
        if rating not in self.RATINGS: raise ValueError("امتیاز باید بین ۱ تا ۵ باشد.")
        if not str(evidence or "").strip(): raise ValueError("ارجاع یا شرح شواهد الزامی است.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            if not c.execute("SELECT 1 FROM coso_principles WHERE code=?", (principle_code,)).fetchone():
                raise ValueError("اصل COSO معتبر نیست.")
            c.execute("""INSERT INTO coso_principle_assessments
                (project_id,principle_code,rating,evidence,conclusion,assessor)
                VALUES(?,?,?,?,?,?) ON CONFLICT(project_id,principle_code)
                DO UPDATE SET rating=excluded.rating,evidence=excluded.evidence,
                conclusion=excluded.conclusion,assessor=excluded.assessor,
                assessed_at=CURRENT_TIMESTAMP""", (project_id, principle_code, rating, str(evidence).strip(), str(conclusion or "").strip(), str(assessor or "").strip()))
            row = c.execute("SELECT id FROM coso_principle_assessments WHERE project_id=? AND principle_code=?", (project_id, principle_code)).fetchone()
            self._history(c, project_id, "assessment", row[0], "ASSESSED", f"{principle_code}: {rating}")
            return row[0]

    def build_report(self, project_id):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            principles = c.execute("""SELECT p.*, a.rating,a.evidence,a.conclusion,a.assessor,a.assessed_at,
                (SELECT COUNT(*) FROM coso_control_mappings m WHERE m.project_id=? AND m.principle_code=p.code) mapping_count
                FROM coso_principles p LEFT JOIN coso_principle_assessments a
                ON a.project_id=? AND a.principle_code=p.code
                ORDER BY p.component_no,p.principle_no""", (project_id, project_id)).fetchall()
            names = [x[0] for x in c.execute("SELECT p.* FROM coso_principles p LIMIT 0").description]
            rows = [dict(zip(names + ["rating", "evidence", "conclusion", "assessor", "assessed_at", "mapping_count"], r)) for r in principles]
            gaps = []
            for p in rows:
                if not p["mapping_count"]:
                    gaps.append({"code":p["code"],"issue":"کنترل مرتبط نگاشت نشده است.","priority":"بالا"})
                if p["rating"] is None:
                    gaps.append({"code":p["code"],"issue":"ارزیابی این اصل ثبت نشده است.","priority":"بالا"})
                elif int(p["rating"]) <= 2:
                    gaps.append({"code":p["code"],"issue":"امتیاز ارزیابی پایین است و نیازمند بررسی و برنامه بهبود است.","priority":"بالا"})
            assessed = sum(p["rating"] is not None for p in rows)
            mapped = sum(p["mapping_count"] > 0 for p in rows)
            avg = round(sum(int(p["rating"]) for p in rows if p["rating"] is not None) / assessed, 2) if assessed else None
            return {"project_id":project_id,"summary":{"principle_count":len(rows),"assessed_count":assessed,"mapped_count":mapped,"gap_count":len(gaps),"average_rating":avg},"principles":rows,"gaps":gaps}

    def _history(self, c, project_id, entity_type, entity_id, event, detail):
        c.execute("INSERT INTO coso_history(project_id,entity_type,entity_id,event_type,detail) VALUES(?,?,?,?,?)", (project_id,entity_type,entity_id,event,str(detail or "")))

    ANSWERS = {"بله", "خیر", "تاحدی", "قابل‌اعمال نیست", "پاسخ‌داده‌نشده"}

    def checklist(self, project_id, principle_code=None):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            sql = """SELECT q.id question_id,q.principle_code,q.question_no,q.question_text,
                q.guidance,q.expected_evidence,r.id response_id,COALESCE(r.answer,'پاسخ‌داده‌نشده') answer,r.explanation,
                r.evidence_ref,r.weakness,r.corrective_action,r.owner,r.due_date,r.assessor,r.updated_at
                FROM coso_checklist_questions q LEFT JOIN coso_checklist_responses r
                ON r.question_id=q.id AND r.project_id=?"""
            params=[project_id]
            if principle_code:
                if not c.execute("SELECT 1 FROM coso_principles WHERE code=?",(principle_code,)).fetchone():
                    raise ValueError("اصل COSO معتبر نیست.")
                sql += " WHERE q.principle_code=?"; params.append(principle_code)
            sql += " ORDER BY q.principle_code,q.question_no"
            cur=c.execute(sql,params); names=[d[0] for d in cur.description]
            return [dict(zip(names,row)) for row in cur.fetchall()]

    def save_checklist_response(self, project_id, question_id, answer, explanation="", evidence_ref="", weakness="", corrective_action="", owner="", due_date="", assessor=""):
        answer=str(answer or "پاسخ‌داده‌نشده").strip()
        if answer not in self.ANSWERS: raise ValueError("گزینه پاسخ معتبر نیست.")
        with connect(self.db_path) as c:
            self._project(c,project_id)
            q=c.execute("SELECT id,principle_code,question_no FROM coso_checklist_questions WHERE id=?",(question_id,)).fetchone()
            if not q: raise ValueError("پرسش چک‌لیست پیدا نشد.")
            if answer != "پاسخ‌داده‌نشده" and not (str(explanation or "").strip() or str(evidence_ref or "").strip()):
                raise ValueError("برای هر پاسخ، از جمله قابل‌اعمال‌نبودن، توضیح یا ارجاع شواهد الزامی است.")
            c.execute("""INSERT INTO coso_checklist_responses
                (project_id,question_id,answer,explanation,evidence_ref,weakness,corrective_action,owner,due_date,assessor)
                VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(project_id,question_id) DO UPDATE SET
                answer=excluded.answer,explanation=excluded.explanation,evidence_ref=excluded.evidence_ref,
                weakness=excluded.weakness,corrective_action=excluded.corrective_action,owner=excluded.owner,
                due_date=excluded.due_date,assessor=excluded.assessor,updated_at=CURRENT_TIMESTAMP""",
                (project_id,question_id,answer,str(explanation or "").strip(),str(evidence_ref or "").strip(),
                 str(weakness or "").strip(),str(corrective_action or "").strip(),str(owner or "").strip(),
                 str(due_date or "").strip(),str(assessor or "").strip()))
            response_id=c.execute("SELECT id FROM coso_checklist_responses WHERE project_id=? AND question_id=?",(project_id,question_id)).fetchone()[0]
            c.execute("INSERT INTO coso_checklist_history(project_id,question_id,response_id,event_type,detail) VALUES(?,?,?,?,?)",
                (project_id,question_id,response_id,"SAVED",f"{q[1]} پرسش {q[2]}: {answer}"))
            return response_id

    def checklist_report(self, project_id):
        rows=self.checklist(project_id)
        counts={a:sum(r["answer"]==a for r in rows) for a in self.ANSWERS}
        answered=len(rows)-counts["پاسخ‌داده‌نشده"]
        gaps=[r for r in rows if r["answer"] in ("خیر","تاحدی")]
        no_evidence=[r for r in rows if r["answer"] in ("بله","خیر","تاحدی") and not (r["evidence_ref"] or r["explanation"])]
        principles={}
        for r in rows:
            item=principles.setdefault(r["principle_code"],{"total":0,"answered":0,"yes":0,"no":0,"partial":0,"na":0})
            item["total"]+=1
            if r["answer"]!="پاسخ‌داده‌نشده": item["answered"]+=1
            if r["answer"]=="بله": item["yes"]+=1
            elif r["answer"]=="خیر": item["no"]+=1
            elif r["answer"]=="تاحدی": item["partial"]+=1
            elif r["answer"]=="قابل‌اعمال نیست": item["na"]+=1
        return {"project_id":project_id,"summary":{"question_count":len(rows),"answered_count":answered,"completion_percent":round(answered*100/len(rows),1) if rows else 0,"yes_count":counts["بله"],"no_count":counts["خیر"],"partial_count":counts["تاحدی"],"not_applicable_count":counts["قابل‌اعمال نیست"],"unanswered_count":counts["پاسخ‌داده‌نشده"],"weakness_count":len(gaps),"evidence_gap_count":len(no_evidence)},"principles":principles,"weaknesses":gaps,"questions":rows}

