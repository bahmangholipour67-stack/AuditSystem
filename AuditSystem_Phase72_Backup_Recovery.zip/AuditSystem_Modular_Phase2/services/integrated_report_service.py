import sqlite3
"""Read-only, project-scoped integrated engagement reporting."""

from database.connection import open_connection
from datetime import datetime
from services.coso_assessment_report_service import CosoAssessmentReportService


class IntegratedReportService:
    """Build a consolidated snapshot from the single AuditSystem database.

    The service never creates, updates, or deletes audit records. Optional
    tables are detected at runtime so older database files remain readable.
    """

    TABLES = {
        "risks": ("ریسک‌ها", "SELECT id, title, score, control_desc FROM risks WHERE project_id=? ORDER BY id"),
        "workpapers": ("کاربرگ‌ها", "SELECT id, risk_id, title, procedure, result, status FROM workpapers WHERE project_id=? ORDER BY id"),
        "findings": ("یافته‌ها", "SELECT id, risk_id, workpaper_id, title, severity, action_text, owner, status, finding_type, condition_text, criteria_text, cause_text, effect_text, likelihood, impact, control_id FROM findings WHERE project_id=? ORDER BY id"),
        "audit_programs": ("برنامه‌های حسابرسی", "SELECT id, title, audit_area, objective, risk_id, workpaper_id, assigned_member_id, status, due_date FROM audit_programs WHERE project_id=? ORDER BY id"),
        "audit_tests": ("آزمون‌های حسابرسی", "SELECT id, program_id, workpaper_id, finding_id, title, test_type, status, conclusion FROM audit_tests WHERE project_id=? ORDER BY id"),
        "audit_test_samples": ("نمونه‌های آزمون", "SELECT id, test_id, sample_no, document_ref, description, amount, result, misstatement_amount, exception_description, evidence_path FROM audit_test_samples WHERE project_id=? ORDER BY test_id, sample_no"),
        "finding_evidence": ("مستندات یافته‌ها", "SELECT id, finding_id, file_path, description, added_by_member_id, created_at FROM finding_evidence WHERE project_id=? ORDER BY id"),
        "engagement_documents": ("مخزن اسناد پرونده", "SELECT id, title, category, file_path, file_name, size_bytes, sha256, description, created_at, archived_at FROM engagement_documents WHERE project_id=? ORDER BY id"),
        "document_links": ("ارتباط اسناد", "SELECT id, document_id, relation_type, relation_id, created_at FROM document_links WHERE project_id=? ORDER BY id"),
        "document_requests": ("درخواست‌های مدارک", "SELECT id, title, description, requested_from, assigned_member_id, due_date, priority, status, created_at, completed_at, archived_at FROM document_requests WHERE project_id=? ORDER BY id"),
        "project_materiality": ("سطوح اهمیت پرونده", "SELECT project_id, overall_materiality, performance_materiality, clearly_trivial, basis, updated_at FROM project_materiality WHERE project_id=?"),
        "project_materiality_history": ("سوابق تغییر سطوح اهمیت", "SELECT id, event_type, previous_values, new_values, actor_member_id, created_at FROM project_materiality_history WHERE project_id=? ORDER BY id"),
        "audit_misstatements": ("تحریفات حسابرسی", "SELECT id, title, misstatement_type, account_name, description, source, amount, status, finding_id, workpaper_id, audit_test_id, tax_effect, created_at, archived_at FROM audit_misstatements WHERE project_id=? ORDER BY id"),
        "misstatement_history": ("سوابق تحریفات", "SELECT id, misstatement_id, event_type, old_status, new_status, details, actor_member_id, created_at FROM misstatement_history WHERE project_id=? ORDER BY id"),
        "internal_controls": ("کنترل‌های داخلی", "SELECT id,title,objective,risk_id,owner,frequency,control_type,method,criteria,archived_at FROM internal_controls WHERE project_id=? ORDER BY id"),
        "control_tests": ("آزمون‌های کنترل", "SELECT id,control_id,test_stage,result,sample_size,exceptions,evidence,tester,notes,created_at FROM control_tests WHERE project_id=? ORDER BY id"),
        "internal_control_findings": ("یافته‌های کنترل داخلی", "SELECT id,title,severity,status,risk_id,control_id,condition_text,criteria_text,cause_text,effect_text,likelihood,impact,owner FROM findings WHERE project_id=? AND finding_type='کنترل داخلی' ORDER BY id"),
        "corrective_actions": ("اقدامات اصلاحی", "SELECT id,finding_id,title,owner,due_date,milestones,status,progress_note,closure_evidence,followup_result,updated_at FROM corrective_actions WHERE project_id=? ORDER BY id"),
        "internal_control_history": ("سوابق کنترل داخلی", "SELECT id,entity_type,entity_id,event_type,detail,created_at FROM internal_control_history WHERE project_id=? ORDER BY id"),
        "coso_control_mappings": ("نگاشت کنترل‌ها به اصول COSO", "SELECT id,control_id,principle_code,risk_id,rationale,updated_at FROM coso_control_mappings WHERE project_id=? ORDER BY principle_code,id"),
        "coso_principle_assessments": ("ارزیابی اصول COSO", "SELECT id,principle_code,rating,evidence,conclusion,assessor,assessed_at FROM coso_principle_assessments WHERE project_id=? ORDER BY principle_code"),
        "coso_checklist_responses": ("پاسخ‌های چک‌لیست COSO", "SELECT q.principle_code,q.question_no,q.question_text,COALESCE(r.answer,'پاسخ‌داده‌نشده') answer,r.explanation,r.evidence_ref,r.weakness,r.corrective_action,r.owner,r.due_date,r.assessor,r.updated_at FROM coso_checklist_questions q LEFT JOIN coso_checklist_responses r ON r.question_id=q.id AND r.project_id=? ORDER BY q.principle_code,q.question_no"),
        "trial_balance": ("تراز آزمایشی", "SELECT id, account_code, account_name, debit, credit, net, flags, imported_at FROM trial_balance WHERE project_id=? ORDER BY account_code, id"),
    }

    def __init__(self, db_path):
        self.db_path = str(db_path)

    @staticmethod
    def _table_exists(conn, table):
        return conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name=?", (table,)
        ).fetchone() is not None

    @staticmethod
    def _rows(conn, sql, project_id):
        cursor = conn.execute(sql, (project_id,))
        names = [item[0] for item in cursor.description]
        return [dict(zip(names, row)) for row in cursor.fetchall()]

    @staticmethod
    def _status_counts(rows):
        counts = {}
        for row in rows:
            status = str(row.get("status") or "نامشخص").strip() or "نامشخص"
            counts[status] = counts.get(status, 0) + 1
        return dict(sorted(counts.items(), key=lambda item: item[0]))

    def build(self, project_id):
        if project_id in (None, ""):
            raise ValueError("شناسه پرونده حسابرسی الزامی است.")
        try:
            project_id = int(project_id)
        except (TypeError, ValueError):
            raise ValueError("شناسه پرونده حسابرسی معتبر نیست.")
        if project_id <= 0:
            raise ValueError("شناسه پرونده حسابرسی باید مثبت باشد.")

        conn = open_connection(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            project_row = conn.execute(
                "SELECT * FROM projects WHERE id=?", (project_id,)
            ).fetchone()
            if project_row is None:
                raise ValueError("پرونده انتخاب‌شده در پایگاه داده وجود ندارد.")
            project = dict(project_row)
            sections = {}
            unavailable = []
            for key, (label, query) in self.TABLES.items():
                if self._table_exists(conn, key):
                    sections[key] = self._rows(conn, query, project_id)
                else:
                    sections[key] = []
                    unavailable.append(label)

            risks = sections["risks"]
            workpapers = sections["workpapers"]
            findings = sections["findings"]
            programs = sections["audit_programs"]
            tests = sections["audit_tests"]
            samples = sections["audit_test_samples"]
            evidence = sections["finding_evidence"]
            trial_balance = sections["trial_balance"]
            documents = sections["engagement_documents"]
            document_links = sections["document_links"]
            document_requests = sections["document_requests"]
            misstatements = [r for r in sections["audit_misstatements"] if not r.get("archived_at")]
            uncorrected_misstatements = [r for r in misstatements if r.get("status") in ("اصلاح‌نشده", "مورد اختلاف")]

            debit_total = sum(float(row.get("debit") or 0) for row in trial_balance)
            credit_total = sum(float(row.get("credit") or 0) for row in trial_balance)
            misstatement_values = [row.get("misstatement_amount") for row in samples
                                   if row.get("misstatement_amount") is not None]
            coso_assessment_report = None
            if self._table_exists(conn, "coso_checklist_questions") and self._table_exists(conn, "coso_principles"):
                coso_assessment_report = CosoAssessmentReportService(self.db_path).build(project_id)
            summary = {
                "risk_count": len(risks),
                "high_risk_count": sum(1 for row in risks if self._is_high_risk(row.get("score"))),
                "workpaper_count": len(workpapers),
                "workpaper_status": self._status_counts(workpapers),
                "program_count": len(programs),
                "program_status": self._status_counts(programs),
                "test_count": len(tests),
                "test_status": self._status_counts(tests),
                "sample_count": len(samples),
                "sample_exception_count": sum(1 for row in samples if self._is_exception(row.get("result"))),
                "finding_count": len(findings),
                "open_finding_count": sum(1 for row in findings if not self._is_closed(row.get("status"))),
                "evidence_count": len(evidence),
                "document_count": sum(1 for row in documents if not row.get("archived_at")),
                "document_link_count": len(document_links),
                "document_request_count": sum(1 for row in document_requests if not row.get("archived_at")),
                "open_document_request_count": sum(1 for row in document_requests if not row.get("archived_at") and row.get("status") not in ("تکمیل‌شده", "لغوشده")),
                "misstatement_count": len(misstatements),
                "uncorrected_misstatement_count": len(uncorrected_misstatements),
                "uncorrected_misstatement_total": round(sum(float(r.get("amount") or 0) for r in uncorrected_misstatements), 2),
                "trial_balance_account_count": len(trial_balance),
                "trial_balance_debit_total": round(debit_total, 2),
                "trial_balance_credit_total": round(credit_total, 2),
                "trial_balance_difference": round(debit_total - credit_total, 2),
                "recorded_misstatement_total": round(sum(float(x) for x in misstatement_values), 2),
                "samples_with_recorded_misstatement": len(misstatement_values),
                "internal_control_count": len(sections.get("internal_controls", [])),
                "control_test_count": len(sections.get("control_tests", [])),
                "internal_control_finding_count": len(sections.get("internal_control_findings", [])),
                "open_corrective_action_count": sum(1 for x in sections.get("corrective_actions", []) if x.get("status") not in ("تأییدشده", "لغوشده")),
                "coso_principle_assessment_count": len(sections.get("coso_principle_assessments", [])),
                "coso_control_mapping_count": len(sections.get("coso_control_mappings", [])),
                "coso_checklist_question_count": len(sections.get("coso_checklist_responses", [])),
                "coso_checklist_answered_count": sum(1 for r in sections.get("coso_checklist_responses", []) if r.get("answer") != "پاسخ‌داده‌نشده"),
                "coso_checklist_weakness_count": sum(1 for r in sections.get("coso_checklist_responses", []) if r.get("answer") in ("خیر", "تاحدی")),
                "coso_assessment_completion_percent": coso_assessment_report["summary"]["completion_percent"] if coso_assessment_report else 0,
                "coso_assessment_evidence_gap_count": coso_assessment_report["summary"]["evidence_gap_count"] if coso_assessment_report else 0,
                "coso_assessment_unanswered_count": coso_assessment_report["summary"]["unanswered_count"] if coso_assessment_report else 0,
            }
            return {
                "project": project,
                "project_id": project_id,
                "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "summary": summary,
                "sections": sections,
                "coso_assessment_report": coso_assessment_report,
                "unavailable_sections": unavailable,
                "limitations": [
                    "این گزارش خلاصه و تجمیع اطلاعات ثبت‌شده در پرونده انتخاب‌شده است.",
                    "مبلغ تحریف فقط از فیلدهای مبلغ تحریف ثبت‌شده در نمونه‌های آزمون جمع شده است؛ این رقم به‌تنهایی تحریف نهایی یا تعدیل پیشنهادی نیست.",
                    "تراز بودن جمع بدهکار و بستانکار، صحت یا کامل بودن مانده حساب‌ها را اثبات نمی‌کند.",
                    "این گزارش جایگزین قضاوت حرفه‌ای حسابرس، بررسی کفایت شواهد یا گزارش رسمی حسابرس نیست.",
                    "جمع تحریفات ثبت‌شده در بخش تحریفات صرفاً اقلام فعال با وضعیت اصلاح‌نشده یا مورد اختلاف را به‌صورت ناخالص جمع می‌کند؛ تهاتر بین حساب‌ها انجام نمی‌شود و این جمع به‌تنهایی مبنای اظهارنظر نیست.",
                    "نتیجه آزمون کنترل و وضعیت اقدام اصلاحی، اطلاعات ثبت‌شده در سامانه است و به‌تنهایی اثربخشی کلی نظام کنترل داخلی را اثبات نمی‌کند.",
                    "نگاشت‌ها، پاسخ‌های چک‌لیست و امتیازهای COSO ابزار مستندسازی ارزیابی‌اند و به‌تنهایی گواهی انطباق با چارچوب COSO محسوب نمی‌شوند.",
                ],
            }
        finally:
            conn.close()

    @staticmethod
    def _is_high_risk(value):
        try:
            return float(value) >= 16
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _norm(value):
        return str(value or "").strip().replace("ي", "ی").replace("ك", "ک").replace("\u200c", " ").lower()

    @classmethod
    def _is_closed(cls, value):
        return cls._norm(value) in {
            "بسته", "مختومه", "رفع شده", "رفع شده است", "تکمیل شده",
            "انجام شده", "نهایی و تأیید", "تأیید نهایی مدیر", "completed", "closed", "done",
        }

    @classmethod
    def _is_exception(cls, value):
        normalized = cls._norm(value)
        return any(token in normalized for token in ("مغایرت", "استثنا", "رد", "عدم انطباق", "exception", "deviation"))
