"""Specialized, transparent audit-test calculations.

The engine is deliberately deterministic and database-independent. It provides
sample selection and descriptive evaluations; it does not replace the auditor's
judgment, establish statistical assurance, or project sample errors to a population.
"""

from __future__ import annotations

import math
import random
from collections.abc import Mapping, Sequence


class AuditTestEngine:
    """Selection and evaluation helpers for control, substantive and analytical tests."""

    @staticmethod
    def _positive_int(value, field_name):
        try:
            number = int(value)
        except (TypeError, ValueError):
            raise ValueError(f"{field_name} باید عدد صحیح باشد.")
        if isinstance(value, bool) or str(number) != str(value).strip():
            # Accept integral numeric values such as 10.0, but reject 10.5.
            try:
                if float(value) != number:
                    raise ValueError
            except (TypeError, ValueError):
                raise ValueError(f"{field_name} باید عدد صحیح باشد.")
        if number < 1:
            raise ValueError(f"{field_name} باید حداقل یک باشد.")
        return number

    @staticmethod
    def _seed_value(seed):
        if seed is None:
            return random.SystemRandom().getrandbits(63)
        try:
            normalized = int(seed)
        except (TypeError, ValueError):
            raise ValueError("بذر نمونه‌گیری باید عدد صحیح باشد.")
        if isinstance(seed, bool) or normalized != seed or not 0 <= normalized <= (2**63 - 1):
            raise ValueError("بذر نمونه‌گیری باید عدد صحیح غیرمنفی و قابل ذخیره باشد.")
        return normalized

    @staticmethod
    def _item_token(value):
        if isinstance(value, Mapping):
            if "id" in value:
                return ("mapping-id", repr(value["id"]))
            return ("mapping", tuple(sorted((str(key), repr(item)) for key, item in value.items())))
        if isinstance(value, (list, tuple)):
            return (type(value).__name__, tuple(AuditTestEngine._item_token(item) for item in value))
        try:
            hash(value)
            return (type(value).__name__, value)
        except TypeError:
            return (type(value).__name__, repr(value))

    @staticmethod
    def _finite_number(value, field_name, *, minimum=None):
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{field_name} باید عددی باشد.")
        if not math.isfinite(number):
            raise ValueError(f"{field_name} معتبر نیست.")
        if minimum is not None and number < minimum:
            raise ValueError(f"{field_name} نمی‌تواند کمتر از {minimum} باشد.")
        return number

    def select_random(self, population, sample_size, seed=None):
        """Select a simple random sample from an ordered population of unique items."""
        items = list(population) if population is not None else []
        if not items:
            raise ValueError("جامعه آماری خالی است.")
        tokens = [self._item_token(item) for item in items]
        if len(set(tokens)) != len(tokens):
            raise ValueError("اقلام جامعه آماری نباید تکراری باشند.")
        size = self._positive_int(sample_size, "حجم نمونه")
        if size > len(items):
            raise ValueError("حجم نمونه نمی‌تواند از حجم جامعه بیشتر باشد.")
        seed = self._seed_value(seed)
        selected = random.Random(seed).sample(items, size)
        return {"seed": seed, "selected": selected, "method": "تصادفی ساده"}

    def select_systematic(self, population, sample_size, seed=None, start=None):
        """Select a systematic sample from a population already in audit order.

        ``start`` is a zero-based offset within the sampling interval. If omitted,
        a reproducible random offset is generated from ``seed``.
        """
        items = list(population) if population is not None else []
        if not items:
            raise ValueError("جامعه آماری خالی است.")
        size = self._positive_int(sample_size, "حجم نمونه")
        total = len(items)
        if size > total:
            raise ValueError("حجم نمونه نمی‌تواند از حجم جامعه بیشتر باشد.")
        seed = self._seed_value(seed)
        interval = total / size
        if start is None:
            offset = random.Random(seed).uniform(0, interval)
        else:
            offset = self._finite_number(start, "نقطه شروع", minimum=0)
            if offset >= interval:
                raise ValueError("نقطه شروع باید از فاصله نمونه‌گیری کمتر باشد.")
        positions = [min(total - 1, int(offset + index * interval)) for index in range(size)]
        if len(set(positions)) != size:
            raise ValueError("با این نقطه شروع، انتخاب نمونه یکتا امکان‌پذیر نیست.")
        return {
            "seed": seed,
            "start": round(offset, 8),
            "interval": round(interval, 8),
            "positions": [position + 1 for position in positions],
            "selected": [items[position] for position in positions],
            "method": "سیستماتیک",
        }

    def select_stratified(self, strata, sample_size, seed=None):
        """Proportionally allocate a sample across strata using largest remainders."""
        if not isinstance(strata, Mapping) or not strata:
            raise ValueError("طبقات جامعه آماری باید مشخص باشند.")
        normalized = {str(key): list(values) for key, values in strata.items()}
        if any(not values for values in normalized.values()):
            raise ValueError("هیچ‌یک از طبقات نباید خالی باشد.")
        flattened = [item for values in normalized.values() for item in values]
        tokens = [self._item_token(item) for item in flattened]
        if len(set(tokens)) != len(tokens):
            raise ValueError("هر قلم جامعه باید فقط در یک طبقه قرار گیرد.")
        size = self._positive_int(sample_size, "حجم نمونه")
        total = len(flattened)
        if size > total:
            raise ValueError("حجم نمونه نمی‌تواند از حجم جامعه بیشتر باشد.")
        seed = self._seed_value(seed)

        keys = sorted(normalized)
        exact = {key: size * len(normalized[key]) / total for key in keys}
        allocation = {key: min(len(normalized[key]), int(exact[key])) for key in keys}
        remaining = size - sum(allocation.values())
        order = sorted(keys, key=lambda key: (exact[key] - int(exact[key]), key), reverse=True)
        while remaining:
            progressed = False
            for key in order:
                if allocation[key] < len(normalized[key]):
                    allocation[key] += 1
                    remaining -= 1
                    progressed = True
                    if remaining == 0:
                        break
            if not progressed:
                raise ValueError("تخصیص حجم نمونه بین طبقات امکان‌پذیر نیست.")

        rng = random.Random(seed)
        selected = {
            key: rng.sample(normalized[key], allocation[key])
            for key in keys
        }
        return {
            "seed": seed,
            "allocation": allocation,
            "selected": selected,
            "selected_total": sum(len(values) for values in selected.values()),
            "method": "طبقه‌ای متناسب",
        }

    def evaluate_control_test(self, sample_outcomes, tolerable_deviation_rate, require_complete=True):
        """Compare observed control deviations with a user-defined tolerable rate.

        Each outcome is a mapping with ``deviation`` set to True/False/None.
        None means unresolved. This is a descriptive observed rate only; no upper
        deviation limit or statistical conclusion is inferred.
        """
        rows = list(sample_outcomes or [])
        if not rows:
            raise ValueError("برای ارزیابی آزمون کنترل حداقل یک نمونه لازم است.")
        tolerance = self._finite_number(tolerable_deviation_rate, "حد قابل تحمل انحراف", minimum=0)
        if tolerance > 100:
            raise ValueError("حد قابل تحمل انحراف نمی‌تواند بیش از ۱۰۰ درصد باشد.")
        deviations = 0
        tested = 0
        unresolved = 0
        for index, row in enumerate(rows, 1):
            if not isinstance(row, Mapping):
                raise ValueError(f"ساختار نتیجه نمونه شماره {index} معتبر نیست.")
            value = row.get("deviation")
            if value is None:
                unresolved += 1
            elif isinstance(value, bool):
                tested += 1
                deviations += int(value)
            else:
                raise ValueError(f"وضعیت انحراف نمونه شماره {index} باید درست، نادرست یا خالی باشد.")
        rate = deviations / tested * 100 if tested else 0.0
        complete = unresolved == 0
        if not tested:
            assessment = "فاقد نتیجه"
        elif require_complete and not complete:
            assessment = "نیازمند تکمیل رسیدگی"
        elif rate > tolerance:
            assessment = "نرخ انحراف مشاهده‌شده بیش از حد قابل تحمل است"
        else:
            assessment = "نرخ انحراف مشاهده‌شده از حد قابل تحمل تجاوز نمی‌کند"
        return {
            "total_samples": len(rows),
            "tested_samples": tested,
            "deviation_samples": deviations,
            "unresolved_samples": unresolved,
            "observed_deviation_rate_percent": round(rate, 4),
            "tolerable_deviation_rate_percent": tolerance,
            "is_complete": complete,
            "assessment": assessment,
            "limitations": [
                "نرخ گزارش‌شده، نرخ انحراف مشاهده‌شده در نمونه است.",
                "ریسک نمونه‌گیری و حد بالای انحراف به‌صورت آماری محاسبه نشده است.",
                "نتیجه به‌تنهایی مبنای اتکای نهایی به کنترل نیست و قضاوت حسابرس لازم است.",
            ],
        }

    def evaluate_substantive_test(self, sample_items, performance_materiality, require_complete=True):
        """Summarize identified sample misstatements without population projection.

        Each item has ``misstatement`` as an absolute amount, or None if unresolved.
        """
        rows = list(sample_items or [])
        if not rows:
            raise ValueError("برای ارزیابی آزمون ماهوی حداقل یک نمونه لازم است.")
        materiality = self._finite_number(performance_materiality, "اهمیت عملکردی", minimum=0)
        if materiality <= 0:
            raise ValueError("اهمیت عملکردی باید بزرگ‌تر از صفر باشد.")
        tested = 0
        unresolved = 0
        identified = 0.0
        nonzero_count = 0
        for index, row in enumerate(rows, 1):
            if not isinstance(row, Mapping):
                raise ValueError(f"ساختار قلم شماره {index} معتبر نیست.")
            value = row.get("misstatement")
            if value in (None, ""):
                unresolved += 1
                continue
            amount = self._finite_number(value, f"مبلغ مغایرت قلم {index}", minimum=0)
            tested += 1
            identified += amount
            nonzero_count += int(amount > 0)
        complete = unresolved == 0
        if not tested:
            assessment = "فاقد نتیجه"
        elif require_complete and not complete:
            assessment = "نیازمند تکمیل رسیدگی"
        elif identified > materiality:
            assessment = "مبلغ مغایرت شناسایی‌شده بیش از اهمیت عملکردی است"
        else:
            assessment = "مبلغ مغایرت شناسایی‌شده از اهمیت عملکردی تجاوز نمی‌کند"
        return {
            "total_samples": len(rows),
            "tested_samples": tested,
            "unresolved_samples": unresolved,
            "identified_misstatement": round(identified, 2),
            "items_with_misstatement": nonzero_count,
            "performance_materiality": materiality,
            "is_complete": complete,
            "assessment": assessment,
            "limitations": [
                "مبلغ صرفاً جمع مغایرت‌های شناسایی‌شده در اقلام ارائه‌شده است.",
                "هیچ‌گونه تعمیم یا برآورد مغایرت جامعه آماری انجام نشده است.",
                "ارزیابی کیفی، آثار کیفی و تجمیع با سایر مغایرت‌ها باید جداگانه بررسی شود.",
            ],
        }

    def evaluate_analytical_procedure(
        self,
        actual,
        expected,
        *,
        tolerable_difference_amount=None,
        tolerable_difference_percent=None,
    ):
        """Compare actual and expected values against one explicit threshold."""
        actual_value = self._finite_number(actual, "مبلغ واقعی")
        expected_value = self._finite_number(expected, "مبلغ مورد انتظار")
        if (tolerable_difference_amount is None) == (tolerable_difference_percent is None):
            raise ValueError("دقیقاً یکی از آستانه مبلغی یا درصدی باید تعیین شود.")
        variance = actual_value - expected_value
        absolute_variance = abs(variance)
        percent = None if expected_value == 0 else absolute_variance / abs(expected_value) * 100
        if tolerable_difference_amount is not None:
            threshold = self._finite_number(tolerable_difference_amount, "آستانه اختلاف مبلغی", minimum=0)
            exceeded = absolute_variance > threshold
            threshold_type = "مبلغی"
        else:
            threshold = self._finite_number(tolerable_difference_percent, "آستانه اختلاف درصدی", minimum=0)
            if threshold > 100000:
                raise ValueError("آستانه اختلاف درصدی غیرواقعی است.")
            if expected_value == 0:
                raise ValueError("برای محاسبه آستانه درصدی، مبلغ مورد انتظار نباید صفر باشد.")
            exceeded = percent > threshold
            threshold_type = "درصدی"
        return {
            "actual": actual_value,
            "expected": expected_value,
            "variance": round(variance, 2),
            "absolute_variance": round(absolute_variance, 2),
            "variance_percent": None if percent is None else round(percent, 4),
            "threshold_type": threshold_type,
            "tolerable_difference": threshold,
            "threshold_exceeded": exceeded,
            "assessment": "اختلاف بیش از آستانه است؛ بررسی بیشتر لازم است" if exceeded else "اختلاف از آستانه تعیین‌شده تجاوز نمی‌کند",
            "limitations": [
                "نتیجه به کیفیت و قابلیت اتکای داده‌های مورد انتظار وابسته است.",
                "تحلیل رابطه و عوامل توضیح‌دهنده اختلاف همچنان باید توسط حسابرس انجام شود.",
                "عدم تجاوز از آستانه به‌تنهایی اثبات‌کننده نبود تحریف بااهمیت نیست.",
            ],
        }
