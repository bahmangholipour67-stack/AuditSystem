"""Read-only quality-management analytics over the existing approval workflow."""
from datetime import datetime


class QualityDashboardService:
    PENDING = {"pending_supervisor", "pending_manager", "pending_quality"}

    @staticmethod
    def _date(value):
        if not value:
            return None
        try:
            return datetime.fromisoformat(str(value).replace("Z", "+00:00")).replace(tzinfo=None)
        except (TypeError, ValueError):
            return None

    @classmethod
    def build_snapshot(cls, requests=(), history=(), *, now=None, overdue_days=7):
        """Rows: requests(id,status,stage,submitted_at,completed_at,supervisor_id).
        History rows: (actor_id, actor_name, stage, event_type, created_at).
        """
        now = now or datetime.now()
        try:
            overdue_days = max(0, int(overdue_days))
        except (TypeError, ValueError):
            raise ValueError("آستانه تأخیر باید عدد صحیح باشد.")
        pending = returned = approved = overdue = 0
        durations = []
        by_supervisor = {}
        for row in requests:
            _rid, status, _stage, submitted_at, completed_at, supervisor_id = row[:6]
            status = str(status or "")
            if status in cls.PENDING:
                pending += 1
                submitted = cls._date(submitted_at)
                if submitted and (now - submitted).total_seconds() >= overdue_days * 86400:
                    overdue += 1
            elif status == "returned":
                returned += 1
            elif status == "approved":
                approved += 1
            start, end = cls._date(submitted_at), cls._date(completed_at)
            if start and end and end >= start:
                durations.append((end - start).total_seconds() / 86400)
        for row in history:
            actor_id, actor_name, stage, event_type, _created_at = row[:5]
            if stage != "supervisor":
                continue
            item = by_supervisor.setdefault(actor_id, {"reviewed": 0, "returned": 0, "approved": 0, "name": actor_name})
            item.setdefault("name", actor_name)
            if event_type in ("stage_approved", "returned"):
                item["reviewed"] += 1
                if event_type == "returned":
                    item["returned"] += 1
        return {
            "total_requests": len(requests), "pending_requests": pending,
            "overdue_requests": overdue, "returned_requests": returned,
            "approved_requests": approved,
            "average_review_days": round(sum(durations) / len(durations), 2) if durations else None,
            "supervisors": by_supervisor,
            "completion_percent": round(approved * 100 / len(requests)) if requests else 0,
        }
