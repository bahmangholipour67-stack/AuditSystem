"""Phase 45: convert risk-planning recommendations into structured audit procedures.

Advisory and deterministic; does not write to the engagement database.
"""
from copy import deepcopy

from services.audit_test_catalog import list_templates
from services.audit_planning_service import AuditPlanningService


CATEGORY_CYCLE_HINTS = {
    "نقد و بانک": ("وجوه نقد", "بانک"),
    "موجودی کالا": ("موجودی", "انبار"),
    "درآمد و فروش": ("فروش", "درآمد"),
    "حساب‌های دریافتنی": ("دریافتنی", "فروش"),
    "حساب‌های پرداختنی": ("پرداختنی", "خرید"),
    "دارایی‌های ثابت": ("دارایی ثابت",),
    "حقوق و دستمزد": ("حقوق", "دستمزد"),
    "ریسک تقلب": ("تقلب",),
    "سیستم‌ها و فناوری اطلاعات": ("فناوری", "سیستم"),
}



class AuditProceduresEngine:
    """Build reviewable procedure candidates from a risk and existing catalog."""



    @staticmethod
    def _risk_identity(risk):
        identity = str(risk.get("id") or risk.get("risk_id") or risk.get("title") or "").strip()
        if not identity:
            raise ValueError("ریسک باید شناسه یا عنوان داشته باشد.")
        return identity



    @classmethod
    def build_for_risk(cls, risk, *, max_templates=5):
        if not isinstance(risk, dict):
            raise ValueError("اطلاعات ریسک باید دیکشنری باشد.")
        if isinstance(max_templates, bool) or not isinstance(max_templates, int) or not 1 <= max_templates <= 25:
            raise ValueError("تعداد الگوها باید عدد صحیح بین ۱ تا ۲۵ باشد.")
        planning = AuditPlanningService.plan_for_risk(risk)
        category = planning["category"]
        hints = CATEGORY_CYCLE_HINTS.get(category, ())
        catalog = list_templates()
        assertion_set = set(planning["relevant_assertions"])
        scored = []
        for template in catalog:
            cycle = str(template.get("cycle", ""))
            title = str(template.get("title", ""))
            assertions = set(template.get("assertions", []))
            cycle_match = sum(1 for hint in hints if hint.casefold() in cycle.casefold())
            assertion_match = len(assertion_set.intersection(assertions))
            title_match = sum(1 for hint in hints if hint.casefold() in title.casefold())
            score = (cycle_match * 5 + title_match * 2 + assertion_match) if hints else 0
            if score > 0:
                scored.append((score, template))
        scored.sort(key=lambda pair: (-pair[0], pair[1].get("title", "")))
        risk_identity = cls._risk_identity(risk)
        procedures = []
        seen = set()
        for relevance, template in scored[:max_templates]:
            template_id = template["id"]
            if template_id in seen:
                continue
            seen.add(template_id)
            procedures.append({
                "procedure_key": f"{risk_identity}::{template_id}",
                "risk_identity": risk_identity,
                "template_id": template_id,
                "title": template["title"],
                "cycle": template.get("cycle", ""),
                "test_type": template.get("test_type", ""),
                "assertions": list(template.get("assertions", [])),
                "objective": template.get("objective", ""),
                "relevance_score": relevance,
                "status": "پیشنهادی",
                "source": "کتابخانه الگوهای آزمون AuditSystem",
            })
        return {
            "risk": deepcopy(risk),
            "risk_plan": planning,
            "procedure_candidates": procedures,
            "count": len(procedures),
            "advisory": "الگوها صرفاً پیشنهاد هستند؛ حسابرس باید تناسب، دامنه، زمان‌بندی و روش اجرا را برای پرونده تأیید یا اصلاح کند.",
        }



    @classmethod
    def build_for_risks(cls, risks, *, max_templates=5):
        results = [cls.build_for_risk(risk, max_templates=max_templates) for risk in (risks or [])]
        return sorted(results, key=lambda item: (-item["risk_plan"]["risk_score"], item["risk_plan"]["risk_title"]))
