"""Read-only, rule-based in-app audit notifications derived from existing tasks."""
from datetime import date, datetime


class NotificationCenterService:
    """Create deterministic notifications without writing to the database."""

    ACTION_CATEGORIES = {"تأییدیه", "کاربرگ"}
    CLOSED_STATUSES = {
        "بسته", "مختومه", "رفع شده", "تکمیل شده", "انجام شده",
        "completed", "closed", "done", "تأیید نهایی مدیر", "نهایی و تأیید"
    }

    @staticmethod
    def _days_until(value, today):
        if not value:
            return None
        try:
            due = datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
            return (due - today).days
        except (TypeError, ValueError):
            return None

    @classmethod
    def build(cls, task_snapshot, today=None, days_ahead=3):
        today = today or date.today()
        if isinstance(today, str):
            today = datetime.strptime(today[:10], "%Y-%m-%d").date()
        days_ahead = max(0, min(int(days_ahead), 90))
        notifications = []

        for task in task_snapshot.get("tasks", []):
            days = cls._days_until(task.get("due_date"), today)
            status = (str(task.get("status") or "").strip()
                      .replace("ي", "ی").replace("ك", "ک").replace("‌", " ").lower())
            if status in cls.CLOSED_STATUSES:
                continue
            overdue = bool(task.get("overdue")) or (days is not None and days < 0)
            if overdue:
                severity, label = "critical", "مهلت گذشته"
                message = "مهلت این مورد سپری شده و هنوز بسته نشده است"
            elif days is not None and days <= days_ahead:
                severity, label = "warning", "مهلت نزدیک"
                message = "برای انجام این مورد در مهلت مقرر اقدام کنید"
            elif task.get("category") in cls.ACTION_CATEGORIES:
                severity, label = "action", "نیازمند پیگیری"
                message = "این مورد در انتظار بررسی یا اقدام است"
            else:
                continue

            notifications.append({
                "severity": severity,
                "label": label,
                "category": task.get("category", ""),
                "title": task.get("title", "بدون عنوان"),
                "message": message,
                "owner": task.get("owner", "تعیین نشده"),
                "due_date": task.get("due_date", ""),
                "days_until": days,
                "task_id": task.get("id"),
            })

        order = {"critical": 0, "warning": 1, "action": 2}
        notifications.sort(key=lambda n: (
            order[n["severity"]],
            n["days_until"] if n["days_until"] is not None else 99999,
            n["category"], n["title"]
        ))
        return {
            "notifications": notifications,
            "total": len(notifications),
            "overdue": sum(n["severity"] == "critical" for n in notifications),
            "due_soon": sum(n["severity"] == "warning" for n in notifications),
            "action_required": sum(n["severity"] == "action" for n in notifications),
            "days_ahead": days_ahead,
        }
