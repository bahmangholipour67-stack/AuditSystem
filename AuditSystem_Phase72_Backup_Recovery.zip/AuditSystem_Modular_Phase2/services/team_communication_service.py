"""Append-only team communication and workpaper routing service."""
from database.connection import connect


class TeamCommunicationService:
    """Project-scoped comments, review requests and auditable routing events."""

    EVENT_COMMENT = "نظر"
    EVENT_REVIEW_REQUEST = "درخواست بررسی"
    EVENT_ASSIGNMENT = "ارجاع کار"

    @staticmethod
    def _member(conn, member_id, project_id):
        row = conn.execute(
            "SELECT id, full_name, role, is_active FROM team_members WHERE id=? AND project_id=?",
            (member_id, project_id),
        ).fetchone()
        if not row or not row[3]:
            raise ValueError("عضو انتخاب‌شده فعال نیست یا به این پرونده تعلق ندارد.")
        return {"id": row[0], "name": row[1], "role": row[2]}

    @classmethod
    def _validate_workpaper(cls, conn, project_id, workpaper_id):
        row = conn.execute(
            "SELECT id, title FROM workpapers WHERE id=? AND project_id=?",
            (workpaper_id, project_id),
        ).fetchone()
        if not row:
            raise ValueError("کاربرگ در پرونده انتخاب‌شده پیدا نشد.")
        return row

    @classmethod
    def add_comment(cls, project_id, workpaper_id, author_member_id, body, recipient_member_id=None):
        body = str(body or "").strip()
        if not body:
            raise ValueError("متن پیام یا نظر الزامی است.")
        with connect() as conn:
            cls._validate_workpaper(conn, project_id, workpaper_id)
            cls._member(conn, author_member_id, project_id)
            if recipient_member_id is not None:
                cls._member(conn, recipient_member_id, project_id)
            cur = conn.execute("""
                INSERT INTO team_communications
                    (project_id, workpaper_id, event_type, author_member_id,
                     recipient_member_id, body)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (project_id, workpaper_id, cls.EVENT_COMMENT,
                  author_member_id, recipient_member_id, body))
            return cur.lastrowid

    @classmethod
    def request_review(cls, project_id, workpaper_id, author_member_id, reviewer_member_id, body=""):
        with connect() as conn:
            cls._validate_workpaper(conn, project_id, workpaper_id)
            author = cls._member(conn, author_member_id, project_id)
            reviewer = cls._member(conn, reviewer_member_id, project_id)
            if reviewer["role"] != "سرپرست حسابرسی":
                raise ValueError("درخواست بررسی باید به سرپرست حسابرسی ارجاع شود.")
            if author["id"] == reviewer["id"]:
                raise ValueError("درخواست‌دهنده و بررسی‌کننده باید متفاوت باشند.")
            cur = conn.execute("""
                INSERT INTO team_communications
                    (project_id, workpaper_id, event_type, author_member_id,
                     recipient_member_id, body)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (project_id, workpaper_id, cls.EVENT_REVIEW_REQUEST,
                  author_member_id, reviewer_member_id, str(body or "").strip()))
            return cur.lastrowid

    @classmethod
    def route_workpaper(cls, project_id, workpaper_id, actor_member_id,
                        assignee_member_id, reviewer_member_id, note=""):
        """Use existing workflow rules; append an immutable routing record."""
        from repositories.workpaper_repository import WorkpaperRepository
        with connect() as conn:
            cls._validate_workpaper(conn, project_id, workpaper_id)
            cls._member(conn, actor_member_id, project_id)
            cls._member(conn, assignee_member_id, project_id)
            cls._member(conn, reviewer_member_id, project_id)
        WorkpaperRepository().update_assignment(
            project_id, workpaper_id, assignee_member_id, reviewer_member_id
        )
        with connect() as conn:
            cur = conn.execute("""
                INSERT INTO team_communications
                    (project_id, workpaper_id, event_type, author_member_id,
                     recipient_member_id, body)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (project_id, workpaper_id, cls.EVENT_ASSIGNMENT,
                  actor_member_id, assignee_member_id,
                  str(note or "ارجاع کاربرگ به مسئول تعیین‌شده").strip()))
            return cur.lastrowid

    @staticmethod
    def thread(project_id, workpaper_id):
        with connect() as conn:
            rows = conn.execute("""
                SELECT c.id, c.event_type, c.body, c.created_at,
                       a.full_name, r.full_name, c.author_member_id, c.recipient_member_id
                FROM team_communications c
                LEFT JOIN team_members a ON a.id=c.author_member_id
                LEFT JOIN team_members r ON r.id=c.recipient_member_id
                WHERE c.project_id=? AND c.workpaper_id=?
                ORDER BY c.id ASC
            """, (project_id, workpaper_id)).fetchall()
        keys = ("id", "event_type", "body", "created_at", "author", "recipient", "author_id", "recipient_id")
        return [dict(zip(keys, row)) for row in rows]

    @staticmethod
    def inbox(project_id, member_id):
        with connect() as conn:
            TeamCommunicationService._member(conn, member_id, project_id)
            rows = conn.execute("""
                SELECT c.id, c.workpaper_id, w.title, c.event_type, c.body,
                       c.created_at, m.full_name
                FROM team_communications c
                JOIN workpapers w ON w.id=c.workpaper_id AND w.project_id=c.project_id
                LEFT JOIN team_members m ON m.id=c.author_member_id
                WHERE c.project_id=? AND c.recipient_member_id=?
                ORDER BY c.id DESC
            """, (project_id, member_id)).fetchall()
        keys = ("id", "workpaper_id", "workpaper_title", "event_type", "body", "created_at", "author")
        return [dict(zip(keys, row)) for row in rows]
