"""Read-only smart workspace queries for Phase 31.

The service discovers optional tables/columns at runtime so it remains
compatible with older project databases and never performs schema changes.
"""


class Phase31WorkspaceService:
    SEARCH_TARGETS = (
        ("projects", "name", "period", "مدیریت پرونده‌ها"),
        ("risks", "title", "control_desc", "ریسک‌ها"),
        ("workpapers", "title", "procedure", "کاربرگ‌ها"),
        ("findings", "title", "action_text", "یافته‌ها و اقدامات اصلاحی"),
        ("audit_tests", "title", "conclusion", "برنامه‌ها و آزمون‌های حسابرسی"),
        ("audit_programs", "title", "objective", "برنامه‌ها و آزمون‌های حسابرسی"),
        ("engagement_documents", "title", "description", "اسناد و درخواست مدارک"),
        ("document_requests", "title", "details", "اسناد و درخواست مدارک"),
        ("internal_controls", "title", "objective", "کنترل‌های داخلی"),
        ("audit_misstatements", "title", "description", "تحریفات و اهمیت"),
        ("team_members", "full_name", "role", "اعضای تیم"),
    )
    FILTER_COLUMNS = {
        "status": ("status", "state", "review_status", "approval_status", "workflow_status"),
        "responsible": ("assigned_to", "responsible", "owner", "auditor", "assignee", "full_name"),
        "period": ("period", "fiscal_year", "financial_period", "reporting_period"),
    }
    HISTORY_TABLES = (
        ("approval_history", "event_type", "comment", "تأییدها"),
        ("workpaper_history", "action", "notes", "کاربرگ"),
        ("audit_test_history", "action", "details", "آزمون حسابرسی"),
        ("document_history", "event_type", "details", "اسناد"),
        ("document_request_history", "event_type", "details", "درخواست مدرک"),
        ("internal_control_history", "event_type", "detail", "کنترل داخلی"),
        ("coso_history", "event_type", "detail", "COSO"),
        ("coso_checklist_history", "event_type", "detail", "چک‌لیست COSO"),
        ("misstatement_history", "event_type", "details", "تحریفات"),
        ("project_archive_history", "event_type", "reason", "بایگانی پرونده"),
    )

    @staticmethod
    def _tables(conn):
        return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}

    @staticmethod
    def _columns(conn, table):
        return {r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')}

    @staticmethod
    def _scope_sql(columns, project_id):
        if project_id is not None and "project_id" in columns:
            return " AND project_id=?", (project_id,)
        return "", ()

    @classmethod
    def project_options(cls, conn):
        """List available engagements for an explicit cross-project search scope."""
        if "projects" not in cls._tables(conn):
            return []
        cols = cls._columns(conn, "projects")
        if "id" not in cols or "name" not in cols:
            return []
        rows = conn.execute('SELECT id, CAST(name AS TEXT) FROM projects ORDER BY name').fetchall()
        return [{"id": row[0], "name": row[1] or f"پرونده {row[0]}"} for row in rows]

    @classmethod
    def filter_options(cls, conn, project_id=None):
        """Return distinct, safe filter values from tables that expose them."""
        tables = cls._tables(conn)
        result = {"status": set(), "responsible": set(), "period": set()}
        for table, *_ in cls.SEARCH_TARGETS:
            if table not in tables:
                continue
            cols = cls._columns(conn, table)
            scope, params = cls._scope_sql(cols, project_id)
            for key, candidates in cls.FILTER_COLUMNS.items():
                column = next((name for name in candidates if name in cols), None)
                if not column:
                    continue
                sql = (f'SELECT DISTINCT CAST("{column}" AS TEXT) FROM "{table}" '
                       f"WHERE \"{column}\" IS NOT NULL AND TRIM(CAST(\"{column}\" AS TEXT)) <> ''{scope} "
                       f'ORDER BY 1 LIMIT 100')
                for row in conn.execute(sql, params).fetchall():
                    value = str(row[0] or "").strip()
                    if value:
                        result[key].add(value)
        return {key: sorted(values, key=str.casefold) for key, values in result.items()}

    def search(self, conn, query, project_id=None, limit=40, filters=None):
        query = str(query or "").strip()
        if len(query) < 2:
            return []
        tables = self._tables(conn)
        found = []
        pattern = f"%{query}%"
        filters = filters or {}
        selected_module = str(filters.get("module") or "همه").strip()
        for table, primary, secondary, module in self.SEARCH_TARGETS:
            if selected_module not in ("", "همه") and selected_module != module:
                continue
            if table not in tables:
                continue
            cols = self._columns(conn, table)
            if project_id is not None and "project_id" not in cols:
                continue
            searchable = [c for c in (primary, secondary) if c in cols]
            if not searchable:
                continue
            scope, params = self._scope_sql(cols, project_id)
            extra_clauses = []
            extra_params = []
            for filter_key in ("status", "responsible", "period"):
                selected = str(filters.get(filter_key) or "همه").strip()
                if selected in ("", "همه"):
                    continue
                column = next((name for name in self.FILTER_COLUMNS[filter_key] if name in cols), None)
                if column is None:
                    # A selected metadata filter only applies to tables that expose it.
                    searchable = []
                    break
                extra_clauses.append(f'CAST("{column}" AS TEXT)=?')
                extra_params.append(selected)
            if not searchable:
                continue
            clauses = " OR ".join(f'CAST("{c}" AS TEXT) LIKE ?' for c in searchable)
            title_col = primary if primary in cols else searchable[0]
            select_cols = [f'CAST("{title_col}" AS TEXT)']
            context_col = secondary if secondary in cols else None
            select_cols.append(f'CAST("{context_col}" AS TEXT)' if context_col else "''")
            id_col = 'id' if 'id' in cols else 'rowid'
            extra_sql = "".join(f" AND ({clause})" for clause in extra_clauses)
            sql = (f'SELECT {id_col}, {", ".join(select_cols)} FROM "{table}" '
                   f'WHERE ({clauses}){scope}{extra_sql} ORDER BY {id_col} DESC LIMIT ?')
            rows = conn.execute(sql, tuple(pattern for _ in searchable) + params + tuple(extra_params) + (limit,)).fetchall()
            for row in rows:
                found.append({"id": row[0], "title": row[1] or "(بدون عنوان)",
                              "context": row[2] or "", "module": module,
                              "table": table, "project_id": project_id})
                if len(found) >= limit:
                    return found
        return found

    def recent_activity(self, conn, project_id=None, limit=25):
        tables = self._tables(conn)
        events = []
        for table, event_col, detail_col, label in self.HISTORY_TABLES:
            if table not in tables:
                continue
            cols = self._columns(conn, table)
            if "created_at" not in cols:
                continue
            event_expr = f'CAST("{event_col}" AS TEXT)' if event_col in cols else "'به‌روزرسانی'"
            detail_expr = f'CAST("{detail_col}" AS TEXT)' if detail_col in cols else "''"
            scope, params = self._scope_sql(cols, project_id)
            sql = (f'SELECT created_at, {event_expr}, {detail_expr} FROM "{table}" '
                   f'WHERE 1=1{scope} ORDER BY created_at DESC LIMIT ?')
            for row in conn.execute(sql, params + (limit,)).fetchall():
                events.append({"date": row[0] or "", "type": label,
                               "event": row[1] or "", "detail": row[2] or ""})
        if not events:
            # Graceful fallback for databases without history tables.
            for table, title_col, _, label in self.SEARCH_TARGETS:
                if table not in tables:
                    continue
                cols = self._columns(conn, table)
                if project_id is not None and "project_id" not in cols:
                    continue
                date_col = "updated_at" if "updated_at" in cols else "created_at"
                if date_col not in cols:
                    continue
                scope, params = self._scope_sql(cols, project_id)
                sql = (f'SELECT "{date_col}", CAST("{title_col}" AS TEXT) FROM "{table}" '
                       f'WHERE 1=1{scope} ORDER BY "{date_col}" DESC LIMIT ?')
                for row in conn.execute(sql, params + (limit,)).fetchall():
                    events.append({"date": row[0] or "", "type": label,
                                   "event": "ثبت یا ویرایش", "detail": row[1] or ""})
        events.sort(key=lambda x: x["date"], reverse=True)
        return events[:limit]
