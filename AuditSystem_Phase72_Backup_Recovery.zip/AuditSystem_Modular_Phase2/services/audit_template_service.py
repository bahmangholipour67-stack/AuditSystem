"""Business rules for editing global and engagement-specific audit templates."""
from copy import deepcopy
from services.audit_test_catalog import list_templates, get_template
from repositories.audit_template_repository import AuditTemplateRepository

EDITABLE_FIELDS = (
    "title", "cycle", "test_type", "assertions", "objective",
    "population_description", "procedure", "evidence",
)


class AuditTemplateService:
    def __init__(self, repository=None):
        self.repository = repository or AuditTemplateRepository()

    @staticmethod
    def validate(template):
        if not isinstance(template, dict):
            raise ValueError("اطلاعات الگو معتبر نیست.")
        result = {key: deepcopy(template.get(key)) for key in EDITABLE_FIELDS}
        for key in ("title", "cycle", "objective", "population_description", "procedure", "evidence"):
            result[key] = str(result.get(key) or "").strip()
            if not result[key]:
                raise ValueError(f"تکمیل فیلد «{key}» الزامی است.")
        result["test_type"] = str(result.get("test_type") or "").strip()
        if result["test_type"] not in {"کنترلی", "ماهوی", "تحلیلی"}:
            raise ValueError("نوع آزمون باید کنترلی، ماهوی یا تحلیلی باشد.")
        assertions = result.get("assertions") or []
        if isinstance(assertions, str):
            assertions = assertions.replace("،", ",").split(",")
        result["assertions"] = list(dict.fromkeys(str(x).strip() for x in assertions if str(x).strip()))
        if not result["assertions"]:
            raise ValueError("حداقل یک ادعای صورت مالی باید انتخاب یا وارد شود.")
        return result

    def get_template(self, template_id, project_id=None):
        base = get_template(template_id)
        if not base:
            return None
        global_override = self.repository.get_library_override(template_id)
        if global_override:
            base.update(global_override)
        project_override = self.repository.get_project_override(project_id, template_id)
        if project_override:
            base.update(project_override)
        return base

    def list_templates(self, project_id=None):
        rows = list_templates()
        for row in rows:
            effective = self.get_template(row["id"], project_id)
            if effective:
                row.update(effective)
        return rows

    def save_to_library(self, template_id, content, actor_member_id=None):
        if not get_template(template_id):
            raise ValueError("الگوی پایه پیدا نشد.")
        return self.repository.save_library_override(template_id, self.validate(content), actor_member_id)

    def save_to_project(self, project_id, template_id, content, actor_member_id=None):
        if not get_template(template_id):
            raise ValueError("الگوی پایه پیدا نشد.")
        return self.repository.save_project_override(project_id, template_id, self.validate(content), actor_member_id)

    def history(self, template_id, project_id=None):
        return self.repository.list_history(template_id, project_id)

    def restore_history(self, history_id, actor_member_id=None):
        return self.repository.restore_history(history_id, actor_member_id)
