"""Project-scoped internal-control assessment and corrective-action lifecycle.

This service records evidence and workflow; it does not issue an audit opinion
or automatically conclude that a control is effective.
"""
import sqlite3
from pathlib import Path
from database.connection import connect
from database.migrations import ensure_schema
from config.settings import DATABASE_PATH


class InternalControlService:
    CONTROL_TYPES = {"پیشگیرانه", "کاشفانه", "اصلاحی"}
    CONTROL_METHODS = {"دستی", "خودکار", "ترکیبی"}
    EFFECTIVENESS = {"موثر", "دارای نقص", "ناموثر", "آزمون‌نشده"}
    ACTION_STATUSES = {"باز", "در حال اجرا", "آماده پیگیری", "تأییدشده", "معوق", "لغوشده"}

    def __init__(self, db_path=None):
        self.db_path = str(db_path or DATABASE_PATH)
        ensure_schema(self.db_path)

    def _project(self, conn, project_id):
        if not project_id or not conn.execute("SELECT 1 FROM projects WHERE id=?", (project_id,)).fetchone():
            raise ValueError("پرونده حسابرسی معتبر نیست.")

    def create_control(self, project_id, title, objective="", risk_id=None,
                       owner="", frequency="", control_type="پیشگیرانه",
                       method="دستی", criteria=""):
        title = str(title or "").strip()
        if not title: raise ValueError("عنوان کنترل الزامی است.")
        if control_type not in self.CONTROL_TYPES: raise ValueError("نوع کنترل معتبر نیست.")
        if method not in self.CONTROL_METHODS: raise ValueError("روش اجرای کنترل معتبر نیست.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            if risk_id is not None and not c.execute("SELECT 1 FROM risks WHERE id=? AND project_id=?", (risk_id, project_id)).fetchone():
                raise ValueError("ریسک انتخاب‌شده متعلق به این پرونده نیست.")
            cur = c.execute("""INSERT INTO internal_controls
                (project_id,title,objective,risk_id,owner,frequency,control_type,method,criteria)
                VALUES(?,?,?,?,?,?,?,?,?)""", (project_id,title,str(objective or ""),risk_id,str(owner or ""),str(frequency or ""),control_type,method,str(criteria or "")))
            self._history(c, project_id, "control", cur.lastrowid, "CREATED", "ثبت کنترل")
            return cur.lastrowid

    def list_controls(self, project_id, include_archived=False):
        sql = "SELECT * FROM internal_controls WHERE project_id=?"
        if not include_archived: sql += " AND archived_at IS NULL"
        sql += " ORDER BY id DESC"
        with connect(self.db_path) as c:
            cur = c.execute(sql, (project_id,))
            names = [x[0] for x in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    def record_control_test(self, project_id, control_id, test_stage, result,
                            sample_size=0, exceptions=0, evidence="", tester="", notes=""):
        if test_stage not in {"طراحی", "پیاده‌سازی", "اثربخشی عملیاتی"}: raise ValueError("مرحله آزمون معتبر نیست.")
        if result not in self.EFFECTIVENESS: raise ValueError("نتیجه آزمون معتبر نیست.")
        if int(sample_size) < 0 or int(exceptions) < 0 or int(exceptions) > int(sample_size): raise ValueError("تعداد نمونه یا استثنا معتبر نیست.")
        if test_stage == "اثربخشی عملیاتی" and int(sample_size) == 0: raise ValueError("برای آزمون اثربخشی عملیاتی، حجم نمونه الزامی است.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            if not c.execute("SELECT 1 FROM internal_controls WHERE id=? AND project_id=? AND archived_at IS NULL", (control_id,project_id)).fetchone(): raise ValueError("کنترل در این پرونده یافت نشد.")
            cur = c.execute("""INSERT INTO control_tests(project_id,control_id,test_stage,result,sample_size,exceptions,evidence,tester,notes)
                VALUES(?,?,?,?,?,?,?,?,?)""", (project_id,control_id,test_stage,result,int(sample_size),int(exceptions),str(evidence or "").strip(),str(tester or "").strip(),str(notes or "")))
            self._history(c, project_id, "control_test", cur.lastrowid, "TEST_RECORDED", f"{test_stage}: {result}")
            return cur.lastrowid

    def archive_control(self, project_id, control_id, reason=""):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            row = c.execute("SELECT id,archived_at FROM internal_controls WHERE id=? AND project_id=?", (control_id,project_id)).fetchone()
            if not row: raise ValueError("کنترل در این پرونده یافت نشد.")
            if row[1]: return False
            c.execute("UPDATE internal_controls SET archived_at=CURRENT_TIMESTAMP WHERE id=? AND project_id=?", (control_id,project_id))
            self._history(c, project_id, "control", control_id, "ARCHIVED", reason)
            return True

    def restore_control(self, project_id, control_id, reason=""):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            row = c.execute("SELECT id,archived_at FROM internal_controls WHERE id=? AND project_id=?", (control_id,project_id)).fetchone()
            if not row: raise ValueError("کنترل در این پرونده یافت نشد.")
            if not row[1]: return False
            c.execute("UPDATE internal_controls SET archived_at=NULL WHERE id=? AND project_id=?", (control_id,project_id))
            self._history(c, project_id, "control", control_id, "RESTORED", reason)
            return True

    def create_control_finding(self, project_id, control_id, title, condition, criteria,
                               cause="", effect="", severity="متوسط", likelihood=3, impact=3, owner=""):
        title = str(title or "").strip()
        if not title or not str(condition or "").strip() or not str(criteria or "").strip():
            raise ValueError("عنوان، وضعیت مشاهده‌شده و معیار یافته الزامی است.")
        if not 1 <= int(likelihood) <= 5 or not 1 <= int(impact) <= 5: raise ValueError("احتمال و اثر باید بین ۱ تا ۵ باشند.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            control = c.execute("SELECT risk_id FROM internal_controls WHERE id=? AND project_id=? AND archived_at IS NULL", (control_id,project_id)).fetchone()
            if not control: raise ValueError("کنترل در این پرونده یافت نشد.")
            cur = c.execute("""INSERT INTO findings(project_id,title,severity,action_text,owner,status,risk_id,finding_type,condition_text,criteria_text,cause_text,effect_text,likelihood,impact,control_id)
                VALUES(?,?,?,?,?,'باز',?,'کنترل داخلی',?,?,?,?,?,?,?)""", (project_id,title,severity,str(effect or ""),str(owner or ""),control[0],str(condition),str(criteria),str(cause or ""),str(effect or ""),int(likelihood),int(impact),control_id))
            self._history(c, project_id, "finding", cur.lastrowid, "CREATED", "یافته کنترل داخلی")
            return cur.lastrowid

    def create_action(self, project_id, finding_id, title, owner, due_date, milestones=""):
        if not str(title or "").strip() or not str(owner or "").strip() or not str(due_date or "").strip(): raise ValueError("عنوان اقدام، مسئول و سررسید الزامی است.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            if not c.execute("SELECT 1 FROM findings WHERE id=? AND project_id=? AND finding_type='کنترل داخلی'", (finding_id,project_id)).fetchone(): raise ValueError("یافته کنترل داخلی در این پرونده یافت نشد.")
            cur = c.execute("INSERT INTO corrective_actions(project_id,finding_id,title,owner,due_date,milestones) VALUES(?,?,?,?,?,?)", (project_id,finding_id,title.strip(),owner.strip(),due_date.strip(),str(milestones or "")))
            self._history(c, project_id, "action", cur.lastrowid, "CREATED", "ثبت برنامه اقدام اصلاحی")
            return cur.lastrowid

    def update_action(self, project_id, action_id, status, progress_note="", evidence="", followup_result=""):
        if status not in self.ACTION_STATUSES: raise ValueError("وضعیت اقدام اصلاحی معتبر نیست.")
        with connect(self.db_path) as c:
            self._project(c, project_id)
            row = c.execute("SELECT id,finding_id FROM corrective_actions WHERE id=? AND project_id=?", (action_id,project_id)).fetchone()
            if not row: raise ValueError("اقدام اصلاحی در این پرونده یافت نشد.")
            if status == "تأییدشده":
                if not str(evidence or "").strip() or not str(followup_result or "").strip(): raise ValueError("تأیید اقدام نیازمند مستند رفع و نتیجه آزمون پیگیری است.")
                if followup_result not in {"موفق", "ناموفق"}: raise ValueError("نتیجه پیگیری باید موفق یا ناموفق باشد.")
                if followup_result != "موفق": raise ValueError("اقدام اصلاحی با نتیجه پیگیری ناموفق قابل تأیید نیست.")
            c.execute("UPDATE corrective_actions SET status=?,progress_note=?,closure_evidence=?,followup_result=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND project_id=?", (status,str(progress_note or ""),str(evidence or "").strip(),str(followup_result or ""),action_id,project_id))
            self._history(c, project_id, "action", action_id, "STATUS_CHANGED", f"{status}: {progress_note}")
            return True

    def close_finding(self, project_id, finding_id, reviewer="", comment=""):
        with connect(self.db_path) as c:
            self._project(c, project_id)
            finding = c.execute("SELECT status,finding_type FROM findings WHERE id=? AND project_id=?", (finding_id,project_id)).fetchone()
            if not finding: raise ValueError("یافته در این پرونده یافت نشد.")
            if finding[1] != "کنترل داخلی": raise ValueError("این مسیر فقط برای یافته‌های کنترل داخلی است.")
            actions = c.execute("SELECT status,closure_evidence,followup_result FROM corrective_actions WHERE finding_id=? AND project_id=?", (finding_id,project_id)).fetchall()
            if not actions or any(a[0] != "تأییدشده" or not a[1] or a[2] != "موفق" for a in actions):
                raise ValueError("بستن یافته مستلزم وجود اقدام اصلاحی و تأیید همه اقدامات با مستند رفع و آزمون پیگیری موفق است.")
            c.execute("UPDATE findings SET status='رفع‌شده' WHERE id=? AND project_id=?", (finding_id,project_id))
            self._history(c, project_id, "finding", finding_id, "CLOSED", f"بازبین: {reviewer}; {comment}")
            return True

    def list_actions(self, project_id, finding_id=None):
        sql = "SELECT * FROM corrective_actions WHERE project_id=?"
        params = [project_id]
        if finding_id is not None:
            sql += " AND finding_id=?"; params.append(finding_id)
        sql += " ORDER BY id DESC"
        with connect(self.db_path) as c:
            cur = c.execute(sql, params)
            names = [x[0] for x in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    def list_findings(self, project_id):
        with connect(self.db_path) as c:
            cur = c.execute("SELECT * FROM findings WHERE project_id=? AND finding_type='کنترل داخلی' ORDER BY id DESC", (project_id,))
            names = [x[0] for x in cur.description]
            return [dict(zip(names, row)) for row in cur.fetchall()]

    def _history(self, conn, project_id, entity_type, entity_id, event, detail):
        conn.execute("INSERT INTO internal_control_history(project_id,entity_type,entity_id,event_type,detail) VALUES(?,?,?,?,?)", (project_id,entity_type,entity_id,event,str(detail or "")))
