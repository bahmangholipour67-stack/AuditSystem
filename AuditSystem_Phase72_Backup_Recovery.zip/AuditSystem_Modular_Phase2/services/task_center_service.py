"""Read-only task and follow-up center assembled from existing audit records."""
from datetime import date


class TaskCenterService:
    """Build a unified, non-mutating queue from supported existing tables."""

    @staticmethod
    def _tables(conn):
        return {row[0] for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}

    @staticmethod
    def _columns(conn, table):
        return {row[1] for row in conn.execute(f'PRAGMA table_info("{table}")').fetchall()}

    @classmethod
    def snapshot(cls, conn, project_id=None, today=None):
        today = today or date.today().isoformat()
        tables = cls._tables(conn)
        tasks = []

        def add(category, entity_id, title, status, owner="", due_date="", project=""):
            status_text = str(status or "نامشخص").strip()
            due = str(due_date or "").strip()
            closed = status_text.replace("ي", "ی").replace("ك", "ک").lower() in {
                "بسته", "مختومه", "رفع شده", "تکمیل شده", "انجام شده", "completed", "closed", "done",
                "تأیید نهایی مدیر", "نهایی و تأیید"
            }
            overdue = bool(due and due[:10] < today and not closed)
            tasks.append({
                "category": category, "id": entity_id, "title": str(title or "بدون عنوان"),
                "status": status_text, "owner": str(owner or "تعیین نشده"),
                "due_date": due, "project": str(project or ""),
                "overdue": overdue, "priority": "متأخر" if overdue else "عادی",
            })

        def scoped_rows(table, select_sql, project_col="project_id"):
            cols = cls._columns(conn, table)
            if project_id is not None and project_col in cols:
                return conn.execute(select_sql + f' WHERE "{project_col}"=?', (project_id,)).fetchall()
            if project_id is not None:
                return []
            return conn.execute(select_sql).fetchall()

        if "corrective_actions" in tables:
            c = cls._columns(conn, "corrective_actions")
            if {"id", "title", "status", "due_date"}.issubset(c):
                owner = "owner" if "owner" in c else "''"
                rows = scoped_rows("corrective_actions", f"SELECT id,title,status,{owner},due_date FROM corrective_actions")
                for r in rows:
                    add("اقدام اصلاحی", r[0], r[1], r[2], r[3], r[4])

        if "document_requests" in tables:
            c = cls._columns(conn, "document_requests")
            if {"id", "title", "status", "due_date"}.issubset(c):
                owner = "requested_from" if "requested_from" in c else "''"
                rows = scoped_rows("document_requests", f"SELECT id,title,status,{owner},due_date FROM document_requests")
                for r in rows:
                    add("درخواست مدرک", r[0], r[1], r[2], r[3], r[4])

        if "approval_requests" in tables:
            c = cls._columns(conn, "approval_requests")
            if {"id", "entity_type", "entity_id", "status", "current_stage"}.issubset(c):
                rows = scoped_rows("approval_requests", "SELECT id,entity_type,entity_id,status,current_stage FROM approval_requests")
                for r in rows:
                    if str(r[3]).lower() not in {"complete", "completed", "approved", "returned_final", "archived"}:
                        add("تأییدیه", r[0], f"{r[1]} #{r[2]}", f"{r[3]} / {r[4]}")

        if "workpapers" in tables:
            c = cls._columns(conn, "workpapers")
            if {"id", "title", "status"}.issubset(c):
                owner = "assigned_member_id" if "assigned_member_id" in c else "''"
                rows = scoped_rows("workpapers", f"SELECT id,title,status,{owner} FROM workpapers")
                pending = {"پیش نویس", "در انتظار بررسی مدیر", "آماده بررسی سرپرست", "نیازمند اصلاح", "در انتظار بررسی"}
                for r in rows:
                    normalized = str(r[2] or "").replace("ي", "ی").replace("‌", " ").strip()
                    if normalized in pending:
                        add("کاربرگ", r[0], r[1], r[2], r[3])

        priority = {"متأخر": 0, "عادی": 1}
        tasks.sort(key=lambda t: (priority[t["priority"]], t["due_date"] or "9999-99-99", t["category"], t["title"]))
        return {
            "tasks": tasks,
            "total": len(tasks),
            "overdue": sum(1 for t in tasks if t["overdue"]),
            "by_category": {name: sum(1 for t in tasks if t["category"] == name)
                            for name in sorted({t["category"] for t in tasks})},
        }
