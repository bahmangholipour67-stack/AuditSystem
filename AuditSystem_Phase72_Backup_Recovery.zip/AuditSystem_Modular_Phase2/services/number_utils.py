import math, re

def parse_amount(value):
    """Same Persian/Arabic/English number parsing rules as the original app."""
    if value is None or str(value).strip() == "": return 0.0
    if isinstance(value, (int, float)): number = float(value)
    else:
        text = str(value).strip().translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
        text = (text.replace("ریال", "").replace("تومان", "").replace("٬", "")
                .replace(",", "").replace("٫", ".").replace("−", "-").replace("\u00a0", ""))
        text = re.sub(r"\s+", "", text)
        negative_parentheses = text.startswith("(") and text.endswith(")")
        if negative_parentheses: text = text[1:-1]
        if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", text):
            raise ValueError(f"عدد نامعتبر: {value}")
        number = float(text)
        if negative_parentheses: number = -abs(number)
    if not math.isfinite(number): raise ValueError(f"عدد نامعتبر یا بیش از حد بزرگ: {value}")
    return number

def safe_csv_text(value):
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + value
    return value
