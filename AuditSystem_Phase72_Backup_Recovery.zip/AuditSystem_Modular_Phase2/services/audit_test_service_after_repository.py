
import random

from repositories.audit_test_repository import AuditTestRepository


class AuditTestService:
    """Business logic for audit program and test execution."""

    def __init__(self, repository=None):
        self.repository = repository or AuditTestRepository()

    # -----------------------------------------------------
    # Validation
    # -----------------------------------------------------

    @staticmethod
    def validate_population(population_size, sample_size):
        try:
            population_size = int(population_size)
            sample_size = int(sample_size)
        except (TypeError, ValueError):
            raise ValueError("حجم جامعه و نمونه باید عدد صحیح باشند.")

        if population_size < 1:
            raise ValueError("حجم جامعه باید حداقل یک باشد.")

        if sample_size < 1:
            raise ValueError("حجم نمونه باید حداقل یک باشد.")

        if sample_size > population_size:
            raise ValueError("حجم نمونه نمی‌تواند از حجم جامعه بیشتر باشد.")

        return population_size, sample_size

    # -----------------------------------------------------
    # Programs
    # -----------------------------------------------------

    def create_program(self, project_id, title, **kwargs):
        if not project_id:
            raise ValueError("پروژه حسابرسی مشخص نشده است.")

        if not str(title).strip():
            raise ValueError("عنوان برنامه حسابرسی الزامی است.")

        return self.repository.create_program(
            project_id=project_id,
            title=str(title).strip(),
            **kwargs
        )

    def list_programs(self, project_id):
        return self.repository.for_project(project_id)

    # -----------------------------------------------------
    # Tests
    # -----------------------------------------------------

    def create_test(
        self,
        project_id,
        program_id,
        title,
        population_size,
        sample_size,
        **kwargs
    ):
        if not project_id:
            raise ValueError("پروژه حسابرسی مشخص نشده است.")

        if not program_id:
            raise ValueError("برنامه حسابرسی مشخص نشده است.")

        if not str(title).strip():
            raise ValueError("عنوان آزمون الزامی است.")

        population_size, sample_size = self.validate_population(
            population_size,
            sample_size
        )

        return self.repository.create_test(
            project_id=project_id,
            program_id=program_id,
            title=str(title).strip(),
            population_size=population_size,
            sample_size=sample_size,
            **kwargs
        )

    def list_tests(self, program_id):
        return self.repository.tests_for_program(program_id)

    # -----------------------------------------------------
    # Sampling
    # -----------------------------------------------------

    def generate_samples(self, project_id, test_id, seed=None):
        test = self.repository.get_test(test_id)

        if not test:
            raise ValueError("آزمون موردنظر پیدا نشد.")

        if test["project_id"] != project_id:
            raise ValueError("آزمون متعلق به این پروژه نیست.")

        population_size, sample_size = self.validate_population(
            test["population_size"],
            test["sample_size"]
        )

        if seed is None:
            seed = random.SystemRandom().getrandbits(64)

        selected = sorted(
            random.Random(seed).sample(
                range(1, population_size + 1),
                sample_size
            )
        )

        count = self.repository.create_samples(
            project_id,
            test_id,
            selected
        )

        return {
            "seed": seed,
            "selected": selected,
            "count": count
        }

    # -----------------------------------------------------
    # Sample results
    # -----------------------------------------------------

    def record_sample_result(
        self,
        sample_id,
        result,
        **kwargs
    ):
        return self.repository.update_sample_result(
            sample_id=sample_id,
            result=result,
            **kwargs
        )

    def list_samples(self, test_id):
        return self.repository.samples_for_test(test_id)

    # -----------------------------------------------------
    # Reports
    # -----------------------------------------------------

    def progress(self, test_id):
        return self.repository.test_progress(test_id)

    def exceptions(self, test_id):
        return self.repository.exceptions_for_test(test_id)

    def history(self, test_id):
        return self.repository.history_for_test(test_id)

    def untested_samples(self, test_id):
        return [
            sample
            for sample in self.list_samples(test_id)
            if sample["result"] == "رسیدگی‌نشده"
        ]

    # -----------------------------------------------------
    # Workpaper and finding links
    # -----------------------------------------------------

    def link_workpaper(self, project_id, test_id, workpaper_id):
        if not project_id or not test_id:
            raise ValueError("پروژه و آزمون باید مشخص باشند.")

        return self.repository.link_test_workpaper(
            project_id, test_id, workpaper_id
        )

    def link_finding(self, project_id, test_id, finding_id):
        if not project_id or not test_id:
            raise ValueError("پروژه و آزمون باید مشخص باشند.")

        return self.repository.link_test_finding(
            project_id, test_id, finding_id
        )

    def link_sample_finding(
        self, project_id, test_id, sample_id, finding_id
    ):
        if not all((project_id, test_id, sample_id, finding_id)):
            raise ValueError("پروژه، آزمون، نمونه و یافته الزامی هستند.")

        return self.repository.link_sample_finding(
            project_id, test_id, sample_id, finding_id
        )

    def unlink_sample_finding(
        self, project_id, test_id, sample_id, finding_id
    ):
        return self.repository.unlink_sample_finding(
            project_id, test_id, sample_id, finding_id
        )

    def test_links(self, project_id, test_id):
        return self.repository.test_links(project_id, test_id)

    def sample_findings(self, project_id, sample_id):
        return self.repository.findings_for_sample(
            project_id, sample_id
        )

    def available_workpapers(self, project_id):
        return self.repository.available_workpapers(project_id)

    def available_findings(self, project_id):
        return self.repository.available_findings(project_id)
