"""Risk-aware follow-up recommendations for evaluated audit tests.

This module is deliberately database-independent. It organizes auditor follow-up
work without creating findings, changing risk ratings, or issuing audit conclusions.
"""

from math import isfinite


class AuditTestFollowUpService:
    """Translate recorded test outcomes into transparent next-step suggestions."""

    @staticmethod
    def _optional_number(value, field_name, *, minimum=0):
        if value in (None, ""):
            return None
        try:
            number = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{field_name} باید عددی باشد.")
        if not isfinite(number) or number < minimum:
            raise ValueError(f"{field_name} معتبر نیست.")
        return number

    def build_follow_up(
        self, evaluation, *, risk_score=None, materiality=None,
        evidence_sufficient=True, contradictory_evidence=False,
    ):
        if not isinstance(evaluation, dict):
            raise ValueError("نتیجه ارزیابی آزمون باید به‌صورت ساختاریافته ارائه شود.")
        if risk_score in (None, ""):
            normalized_risk = None
            risk_level = "تعیین‌نشده"
        else:
            if isinstance(risk_score, bool):
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            try:
                normalized_risk = int(risk_score)
            except (TypeError, ValueError):
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            if str(normalized_risk) != str(risk_score).strip() or not 1 <= normalized_risk <= 25:
                raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
            risk_level = "بالا" if normalized_risk >= 16 else "متوسط" if normalized_risk >= 9 else "پایین"

        if not isinstance(evidence_sufficient, bool) or not isinstance(contradictory_evidence, bool):
            raise ValueError("وضعیت کفایت و تعارض شواهد باید درست یا نادرست باشد.")
        threshold = self._optional_number(materiality, "اهمیت")
        exception_amount = self._optional_number(
            evaluation.get("exception_amount", evaluation.get("identified_misstatement")),
            "مبلغ مغایرت"
        )
        assessment = str(evaluation.get("assessment") or "فاقد نتیجه")
        complete = evaluation.get("is_complete")
        actions = []

        if complete is False or assessment in {"نیازمند تکمیل رسیدگی", "فاقد نتیجه"}:
            actions.append({"priority": "فوری", "code": "COMPLETE_TEST", "action": "نمونه‌های رسیدگی‌نشده و موارد نیازمند بررسی را تعیین تکلیف و نتیجه هر قلم را مستند کنید."})
        if not evidence_sufficient:
            actions.append({"priority": "فوری", "code": "OBTAIN_EVIDENCE", "action": "شواهد کافی و مناسب بیشتری تحصیل کنید یا محدودیت دسترسی به شواهد را مستند و به سرپرست ارجاع دهید."})
        if contradictory_evidence:
            actions.append({"priority": "فوری", "code": "RESOLVE_CONFLICT", "action": "شواهد متعارض را بررسی، علت اختلاف را تعیین و نتیجه‌گیری را تا رفع تعارض متوقف کنید."})
        if assessment in {"عدم احراز معیار", "نرخ انحراف مشاهده‌شده بیش از حد قابل تحمل است"}:
            actions.append({"priority": "بالا", "code": "INVESTIGATE_EXCEPTIONS", "action": "علت و ماهیت مغایرت‌ها را بررسی، آثار آن‌ها بر ادعاهای مرتبط را ارزیابی و نیاز به آزمون‌های تکمیلی را تعیین کنید."})
        if normalized_risk is not None and normalized_risk >= 16:
            actions.append({"priority": "بالا", "code": "REASSESS_HIGH_RISK", "action": "سازگاری نتیجه آزمون با ریسک بالا را ارزیابی و در صورت لزوم دامنه رسیدگی، نوع شواهد و آزمون‌های تکمیلی را بازنگری کنید."})
        elif normalized_risk is not None and normalized_risk >= 9:
            actions.append({"priority": "متوسط", "code": "REVIEW_RISK", "action": "نتیجه آزمون را با عوامل ریسک متوسط و سایر شواهد پرونده تطبیق دهید."})
        if threshold is not None and exception_amount is not None and exception_amount > threshold:
            actions.append({"priority": "بالا", "code": "MATERIALITY_REVIEW", "action": "مبلغ مغایرت مشاهده‌شده از آستانه اهمیت ارائه‌شده بیشتر است؛ آثار، تجمیع با سایر تحریف‌ها و نیاز به ارجاع را بررسی کنید."})

        if not actions:
            actions.append({"priority": "عادی", "code": "DOCUMENT_CONCLUSION", "action": "مبنای نتیجه‌گیری، کفایت شواهد و سازگاری نتیجه با ریسک و ادعاهای مرتبط را در کاربرگ مستند کنید."})

        priority_order = {"فوری": 0, "بالا": 1, "متوسط": 2, "عادی": 3}
        actions.sort(key=lambda item: priority_order[item["priority"]])
        finding_review = bool(
            evaluation.get("exception_samples", 0)
            or evaluation.get("deviation_samples", 0)
            or evaluation.get("identified_misstatement", 0)
            or contradictory_evidence
        )
        return {
            "risk_level": risk_level,
            "assessment": assessment,
            "follow_up_priority": actions[0]["priority"],
            "actions": actions,
            "finding_review_recommended": finding_review,
            "finding_review_note": (
                "موضوع برای ارزیابی حسابرس از نظر معیارهای ثبت یافته، علت، آثار و اهمیت بررسی شود؛ ایجاد یافته خودکار انجام نمی‌شود."
                if finding_review else "بر اساس داده‌های ارائه‌شده محرک مستقیمی برای بررسی ثبت یافته شناسایی نشد؛ قضاوت حسابرس همچنان لازم است."
            ),
            "limitations": [
                "پیشنهادها صرفاً راهنمای پیگیری هستند و یافته، تحریف یا نتیجه حسابرسی را به‌صورت خودکار ثبت یا قطعی نمی‌کنند.",
                "مبلغ مغایرت مشاهده‌شده بدون مبنای مناسب به کل جامعه آماری تعمیم داده نمی‌شود.",
                "آستانه اهمیت باید توسط حسابرس و متناسب با پرونده تعیین و تفسیر شود.",
            ],
        }
