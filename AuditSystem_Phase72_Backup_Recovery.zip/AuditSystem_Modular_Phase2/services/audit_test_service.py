﻿

from repositories.audit_test_repository import AuditTestRepository
from services.audit_test_evaluation_service import AuditTestEvaluationService
from services.audit_test_engine import AuditTestEngine
from services.audit_test_followup import AuditTestFollowUpService


class AuditTestService:
    """Business logic for audit program and test execution."""

    def __init__(self, repository=None, evaluation_service=None, engine=None, followup_service=None):
        self.repository = repository or AuditTestRepository()
        self.evaluation_service = evaluation_service or AuditTestEvaluationService()
        self.engine = engine or AuditTestEngine()
        self.followup_service = followup_service or AuditTestFollowUpService()

    # -----------------------------------------------------
    # Validation
    # -----------------------------------------------------

    @staticmethod
    def validate_population(population_size, sample_size):
        try:
            population_size = int(population_size)
            sample_size = int(sample_size)
        except (TypeError, ValueError):
            raise ValueError(
                "حجم جامعه و نمونه باید عدد صحیح باشند."
            )

        if population_size < 1:
            raise ValueError("حجم جامعه باید حداقل یک باشد.")

        if sample_size < 1:
            raise ValueError("حجم نمونه باید حداقل یک باشد.")

        if sample_size > population_size:
            raise ValueError(
                "حجم نمونه نمی‌تواند از حجم جامعه بیشتر باشد."
            )

        return population_size, sample_size

    # -----------------------------------------------------
    # Specialized audit-test engine
    # -----------------------------------------------------

    def select_random_sample(self, population, sample_size, seed=None):
        return self.engine.select_random(population, sample_size, seed=seed)

    def select_systematic_sample(self, population, sample_size, seed=None, start=None):
        return self.engine.select_systematic(
            population, sample_size, seed=seed, start=start
        )

    def select_stratified_sample(self, strata, sample_size, seed=None):
        return self.engine.select_stratified(strata, sample_size, seed=seed)

    def evaluate_control_test(self, sample_outcomes, tolerable_deviation_rate, require_complete=True):
        return self.engine.evaluate_control_test(
            sample_outcomes,
            tolerable_deviation_rate,
            require_complete=require_complete,
        )

    def evaluate_substantive_test(self, sample_items, performance_materiality, require_complete=True):
        return self.engine.evaluate_substantive_test(
            sample_items,
            performance_materiality,
            require_complete=require_complete,
        )

    def evaluate_analytical_procedure(
        self, actual, expected, *,
        tolerable_difference_amount=None,
        tolerable_difference_percent=None,
    ):
        return self.engine.evaluate_analytical_procedure(
            actual,
            expected,
            tolerable_difference_amount=tolerable_difference_amount,
            tolerable_difference_percent=tolerable_difference_percent,
        )

    def build_follow_up_recommendations(
        self, evaluation, *, risk_score=None, materiality=None,
        evidence_sufficient=True, contradictory_evidence=False,
    ):
        """Expose transparent follow-up guidance for a previously evaluated test."""
        return self.followup_service.build_follow_up(
            evaluation, risk_score=risk_score, materiality=materiality,
            evidence_sufficient=evidence_sufficient,
            contradictory_evidence=contradictory_evidence,
        )

    # -----------------------------------------------------
    # Programs
    # -----------------------------------------------------

    def create_program(self, project_id, title, **kwargs):
        if not project_id:
            raise ValueError("پروژه حسابرسی مشخص نشده است.")

        if not str(title).strip():
            raise ValueError(
                "عنوان برنامه حسابرسی الزامی است."
            )

        return self.repository.create_program(
            project_id=project_id,
            title=str(title).strip(),
            **kwargs
        )

    def list_programs(self, project_id):
        return self.repository.for_project(project_id)

    # -----------------------------------------------------
    # Tests
    # -----------------------------------------------------

    def create_test(
        self,
        project_id,
        program_id,
        title,
        population_size,
        sample_size,
        **kwargs
    ):
        if not project_id:
            raise ValueError("پروژه حسابرسی مشخص نشده است.")

        if not program_id:
            raise ValueError(
                "برنامه حسابرسی مشخص نشده است."
            )

        if not str(title).strip():
            raise ValueError("عنوان آزمون الزامی است.")

        test_type = str(kwargs.get("test_type", "ماهوی") or "ماهوی").strip()
        if test_type not in {"کنترلی", "ماهوی", "تحلیلی"}:
            raise ValueError("نوع آزمون باید کنترلی، ماهوی یا تحلیلی باشد.")
        kwargs["test_type"] = test_type

        population_size, sample_size = self.validate_population(
            population_size,
            sample_size
        )

        return self.repository.create_test(
            project_id=project_id,
            program_id=program_id,
            title=str(title).strip(),
            population_size=population_size,
            sample_size=sample_size,
            **kwargs
        )

    def list_tests(self, program_id):
        return self.repository.tests_for_program(program_id)

    # -----------------------------------------------------
    # Sampling
    # -----------------------------------------------------

    def generate_samples(self, project_id, test_id, seed=None, method="تصادفی ساده"):
        test = self.repository.get_test(test_id)

        if not test:
            raise ValueError("آزمون موردنظر پیدا نشد.")

        if test["project_id"] != project_id:
            raise ValueError("آزمون متعلق به این پروژه نیست.")

        population_size, sample_size = self.validate_population(
            test["population_size"],
            test["sample_size"]
        )

        if method == "تصادفی ساده":
            selection = self.engine.select_random(
                range(1, population_size + 1), sample_size, seed=seed
            )
        elif method == "سیستماتیک":
            selection = self.engine.select_systematic(
                range(1, population_size + 1), sample_size, seed=seed
            )
        else:
            raise ValueError("روش نمونه‌گیری انتخاب‌شده پشتیبانی نمی‌شود.")

        seed = selection["seed"]
        selected = sorted(selection["selected"])

        count = self.repository.create_samples(
            project_id,
            test_id,
            selected,
            sampling_method=method,
            random_seed=seed,
        )

        return {
            "seed": seed,
            "selected": selected,
            "count": count,
            "method": method,
        }

    # -----------------------------------------------------
    # Sample results
    # -----------------------------------------------------

    def record_sample_result(
        self,
        sample_id,
        result,
        **kwargs
    ):
        return self.repository.update_sample_result(
            sample_id=sample_id,
            result=result,
            **kwargs
        )

    def list_samples(self, test_id):
        return self.repository.samples_for_test(test_id)

    def save_conclusion(self, project_id, test_id, actor_member_id, conclusion):
        if not project_id or not test_id or not actor_member_id:
            raise ValueError("پروژه، آزمون و عضو ثبت‌کننده باید مشخص باشند.")
        if not str(conclusion or "").strip():
            raise ValueError("نتیجه‌گیری حسابرسی الزامی است.")
        return self.repository.save_conclusion(
            project_id, test_id, actor_member_id, str(conclusion).strip()
        )

    # -----------------------------------------------------
    # Approval workflow
    # -----------------------------------------------------

    def submit_test(
        self,
        project_id,
        test_id,
        actor_member_id,
        supervisor_member_id
    ):
        """
        Submit an audit test for supervisor review.

        actor_member_id:
            Active auditor or senior auditor.

        supervisor_member_id:
            Explicitly selected active supervisor
            belonging to the same project.
        """

        if not all((
            project_id,
            test_id,
            actor_member_id,
            supervisor_member_id
        )):
            raise ValueError(
                "پروژه، آزمون، حسابرس و سرپرست باید مشخص باشند."
            )

        return self.repository.submit_test(
            project_id=project_id,
            test_id=test_id,
            actor_member_id=actor_member_id,
            supervisor_member_id=supervisor_member_id
        )

    def supervisor_review(
        self,
        project_id,
        test_id,
        supervisor_member_id,
        decision,
        comment=""
    ):
        """
        Supervisor decision.

        decision:
            approve = approve supervisor review
            return  = return to auditor for correction
        """

        if not all((
            project_id,
            test_id,
            supervisor_member_id
        )):
            raise ValueError(
                "پروژه، آزمون و سرپرست باید مشخص باشند."
            )

        if decision not in ("approve", "return"):
            raise ValueError(
                "تصمیم سرپرست معتبر نیست."
            )

        if decision == "return" and not str(comment).strip():
            raise ValueError(
                "برای برگشت آزمون، توضیح اصلاحات الزامی است."
            )

        return self.repository.supervisor_review(
            project_id=project_id,
            test_id=test_id,
            supervisor_member_id=supervisor_member_id,
            decision=decision,
            comment=str(comment).strip()
        )

    def manager_approve(
        self,
        project_id,
        test_id,
        manager_member_id,
        comment=""
    ):
        """
        Final approval by an active audit manager.
        """

        if not all((
            project_id,
            test_id,
            manager_member_id
        )):
            raise ValueError(
                "پروژه، آزمون و مدیر حسابرسی باید مشخص باشند."
            )

        return self.repository.manager_approve(
            project_id=project_id,
            test_id=test_id,
            manager_member_id=manager_member_id,
            comment=str(comment).strip()
        )

    # -----------------------------------------------------
    # Reports
    # -----------------------------------------------------

    def progress(self, test_id):
        return self.repository.test_progress(test_id)

    def exceptions(self, test_id):
        return self.repository.exceptions_for_test(test_id)

    def history(self, test_id):
        return self.repository.history_for_test(test_id)

    def untested_samples(self, test_id):
        return [
            sample
            for sample in self.list_samples(test_id)
            if sample["result"] == "رسیدگی‌نشده"
        ]

    def evaluate_test(self, test_id, *, allowed_exception_rate=0.0, require_complete=True):
        """Evaluate the currently recorded sample outcomes without changing data."""
        samples = self.list_samples(test_id)
        return self.evaluation_service.evaluate(
            samples,
            allowed_exception_rate=allowed_exception_rate,
            require_complete=require_complete,
        )

    def evaluate_test_for_conclusion(self, test_id, **parameters):
        """Evaluate a test according to its type using recorded sample data.

        The result is a draft assessment only. It is never saved as the auditor's
        conclusion and does not extrapolate sample results to the population.
        """
        test = self.repository.get_test(test_id)
        if not test:
            raise ValueError("آزمون موردنظر پیدا نشد.")
        test_type = str(test.get("test_type") or "ماهوی").strip()
        samples = self.list_samples(test_id) if test_type in {"کنترلی", "ماهوی"} else []

        if test_type in {"کنترلی", "ماهوی"} and not samples:
            raise ValueError("برای ارزیابی ابتدا نمونه‌های آزمون را ایجاد کنید.")

        if test_type == "کنترلی":
            tolerance = parameters.get("tolerable_deviation_rate")
            if tolerance in (None, ""):
                raise ValueError("حد قابل تحمل انحراف را وارد کنید.")
            outcomes = []
            for sample in samples:
                result = sample.get("result") or "رسیدگی‌نشده"
                if result == "تأیید":
                    deviation = False
                elif result in ("مغایرت", "عدم انطباق"):
                    deviation = True
                else:
                    deviation = None
                outcomes.append({"deviation": deviation})
            return self.engine.evaluate_control_test(
                outcomes, tolerance, require_complete=True
            )

        if test_type == "ماهوی":
            materiality = parameters.get("performance_materiality")
            if materiality in (None, ""):
                raise ValueError("اهمیت عملکردی را وارد کنید.")
            items = []
            for sample in samples:
                result = sample.get("result") or "رسیدگی‌نشده"
                if result in ("رسیدگی‌نشده", "نیازمند بررسی"):
                    amount = None
                elif result == "تأیید":
                    amount = 0
                else:
                    amount = sample.get("misstatement_amount")
                items.append({"misstatement": amount})
            return self.engine.evaluate_substantive_test(
                items, materiality, require_complete=True
            )

        if test_type == "تحلیلی":
            return self.engine.evaluate_analytical_procedure(
                parameters.get("actual"),
                parameters.get("expected"),
                tolerable_difference_amount=parameters.get("tolerable_difference_amount"),
                tolerable_difference_percent=parameters.get("tolerable_difference_percent"),
            )

        raise ValueError("نوع آزمون برای ارزیابی پشتیبانی نمی‌شود.")

    # -----------------------------------------------------
    # Workpaper and finding links
    # -----------------------------------------------------

    def link_workpaper(
        self,
        project_id,
        test_id,
        workpaper_id
    ):
        if not project_id or not test_id:
            raise ValueError(
                "پروژه و آزمون باید مشخص باشند."
            )

        return self.repository.link_test_workpaper(
            project_id,
            test_id,
            workpaper_id
        )

    def link_finding(
        self,
        project_id,
        test_id,
        finding_id
    ):
        if not project_id or not test_id:
            raise ValueError(
                "پروژه و آزمون باید مشخص باشند."
            )

        return self.repository.link_test_finding(
            project_id,
            test_id,
            finding_id
        )

    def link_sample_finding(
        self,
        project_id,
        test_id,
        sample_id,
        finding_id
    ):
        if not all((
            project_id,
            test_id,
            sample_id,
            finding_id
        )):
            raise ValueError(
                "پروژه، آزمون، نمونه و یافته الزامی هستند."
            )

        return self.repository.link_sample_finding(
            project_id,
            test_id,
            sample_id,
            finding_id
        )

    def unlink_sample_finding(
        self,
        project_id,
        test_id,
        sample_id,
        finding_id
    ):
        return self.repository.unlink_sample_finding(
            project_id,
            test_id,
            sample_id,
            finding_id
        )

    def test_links(self, project_id, test_id):
        return self.repository.test_links(
            project_id,
            test_id
        )

    def sample_findings(self, project_id, sample_id):
        return self.repository.findings_for_sample(
            project_id,
            sample_id
        )

    def available_workpapers(self, project_id):
        return self.repository.available_workpapers(
            project_id
        )

    def available_findings(self, project_id):
        return self.repository.available_findings(
            project_id
        )
