"""Phase 41 risk intelligence: deterministic, read-only classification and alerts."""


class RiskIntelligenceService:
    LOW = 1
    MEDIUM = 5
    HIGH = 10
    CRITICAL = 16
    HIGH_SEVERITY = {"بااهمیت", "اساسی", "زیاد", "بالا", "critical", "high"}
    CLOSED = {"بسته", "مختومه", "رفع شده", "تکمیل شده", "تکمیل‌شده", "completed", "closed", "done"}
    PENDING_REVIEW = {"آماده بررسی سرپرست", "در انتظار بررسی", "pending review", "awaiting review"}



    @staticmethod
    def normalize(value):
        return (str(value or "").strip().replace("ي", "ی").replace("ك", "ک")
                .replace("\u200c", " ").lower())

    @classmethod
    def risk_level(cls, score):
        try:
            value = int(score)
        except (TypeError, ValueError):
            raise ValueError("امتیاز ریسک باید عدد صحیح بین ۱ تا ۲۵ باشد.")
        if not 1 <= value <= 25:
            raise ValueError("امتیاز ریسک باید بین ۱ تا ۲۵ باشد.")
        if value >= cls.CRITICAL:
            return "بحرانی"
        if value >= cls.HIGH:
            return "زیاد"
        if value >= cls.MEDIUM:
            return "متوسط"
        return "کم"

    @classmethod
    def classify_risks(cls, risks):
        classified = []
        for row in risks or ():
            if len(row) < 2:
                continue
            title, score = row[0], row[1]
            try:
                numeric = int(score)
                level = cls.risk_level(numeric)
            except (TypeError, ValueError):
                continue
            classified.append({"title": str(title), "score": numeric, "level": level})
        return sorted(classified, key=lambda item: (-item["score"], item["title"]))



    @classmethod
    def build_alerts(cls, *, risks=(), findings=(), findings_without_evidence=(),
                     pending_tests=(), unlinked_workpapers=(), unlinked_findings=(),
                     unlinked_tests=(), unlinked_programs=()):
        """Build actionable alerts from existing rows. Does not write to the database.

        Rows: risks=(title, score); findings=(id,title,severity,status[,owner]);
        evidence rows=(finding_id,title); pending tests=(id,title,status).
        """
        alerts = []
        for risk in cls.classify_risks(risks):
            if risk["level"] in {"زیاد", "بحرانی"}:
                alerts.append({
                    "priority": "P1" if risk["level"] == "بحرانی" else "P2",
                    "category": "ریسک", "subject": risk["title"],
                    "message": f"ریسک {risk['level']} با امتیاز {risk['score']}; پاسخ و روش رسیدگی بازبینی شود.",
                    "score": risk["score"],
                })

        closed = {cls.normalize(item) for item in cls.CLOSED}
        high = {cls.normalize(item) for item in cls.HIGH_SEVERITY}
        for row in findings or ():
            if len(row) < 4:
                continue
            finding_id, title, severity, status = row[:4]
            if cls.normalize(status) in closed:
                continue
            if cls.normalize(severity) in high:
                alerts.append({
                    "priority": "P1", "category": "یافته", "subject": str(title),
                    "message": f"یافته بااهمیت باز (شناسه {finding_id})؛ اقدام اصلاحی و اثر بر گزارش ارزیابی شود.",
                })

        for row in findings_without_evidence or ():
            if len(row) >= 2:
                alerts.append({"priority": "P1", "category": "شواهد", "subject": str(row[1]),
                              "message": f"یافته (شناسه {row[0]}) فاقد شواهد مرتبط است؛ کفایت مستندات بررسی شود."})
        for row in pending_tests or ():
            if len(row) >= 3 and cls.normalize(row[2]) in {cls.normalize(x) for x in cls.PENDING_REVIEW}:
                alerts.append({"priority": "P2", "category": "بازبینی", "subject": str(row[1]),
                              "message": f"آزمون (شناسه {row[0]}) در انتظار بازبینی سرپرست است."})
        for category, rows, message in (
            ("کاربرگ", unlinked_workpapers, "به ریسک مرتبط متصل نشده است."),
            ("یافته", unlinked_findings, "به کاربرگ مرتبط متصل نشده است."),
            ("آزمون", unlinked_tests, "به کاربرگ مرتبط متصل نشده است."),
            ("برنامه", unlinked_programs, "به ریسک مرتبط متصل نشده است."),
        ):
            for row in rows or ():
                if len(row) >= 2:
                    alerts.append({"priority": "P3", "category": category, "subject": str(row[1]),
                                  "message": message})
        priority = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}
        alerts.sort(key=lambda item: (priority.get(item["priority"], 9), item["category"], item["subject"]))
        return alerts
