import sqlite3
"""Audit-file completeness and quality checks for a single audit project."""

from pathlib import Path
from database.connection import open_connection


class AuditFileQualityService:
    """Read-only quality review of audit records; never changes source data."""

    CLOSED_STATUSES = {
        "بسته", "مختومه", "رفع شده", "رفع شده است", "تکمیل شده",
        "انجام شده", "completed", "closed", "done",
    }
    APPROVED_STATUSES = {
        "تایید نهایی", "تأیید نهایی", "تایید نهایی مدیر",
        "تأیید نهایی مدیر", "نهایی و تایید", "نهایی و تأیید",
        "approved", "final approved",
    }

    def __init__(self, db_path):
        self.db_path = str(db_path)

    @staticmethod
    def _norm(value):
        return (str(value or "").strip().replace("ي", "ی")
                .replace("ك", "ک").replace("\u200c", " ").lower())

    @classmethod
    def _is_approved(cls, value):
        value = cls._norm(value)
        compact = value.replace(" ", "")
        return value in cls.APPROVED_STATUSES or compact in {
            "تاییدنهایی", "تأییدنهایی", "تاییدنهاییمدیر", "تأییدنهاییمدیر",
            "نهاییوتایید", "نهاییوتأیید", "approved", "finalapproved",
        }

    @staticmethod
    def _rows(conn, sql, params=()):
        cur = conn.execute(sql, params)
        names = [item[0] for item in cur.description]
        return [dict(zip(names, row)) for row in cur.fetchall()]

    @staticmethod
    def _table_exists(conn, name):
        return conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
        ).fetchone() is not None

    @staticmethod
    def _columns(conn, table):
        if not AuditFileQualityService._table_exists(conn, table):
            return set()
        return {row[1] for row in conn.execute(f'PRAGMA table_info("{table}")')}

    @staticmethod
    def _count(conn, table, project_id):
        if not AuditFileQualityService._table_exists(conn, table):
            return 0
        columns = AuditFileQualityService._columns(conn, table)
        if "project_id" in columns:
            return conn.execute(
                f'SELECT COUNT(*) FROM "{table}" WHERE project_id=?',
                (project_id,),
            ).fetchone()[0]
        return conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]

    @staticmethod
    def _check(code, title, severity, items, recommendation):
        return {
            "code": code,
            "title": title,
            "severity": severity,
            "count": len(items),
            "items": items,
            "recommendation": recommendation,
        }

    def run(self, project_id):
        if not project_id:
            raise ValueError("برای کنترل کیفیت، ابتدا یک پرونده حسابرسی انتخاب کنید.")

        conn = open_connection(self.db_path)
        try:
            conn.row_factory = sqlite3.Row
            project_row = conn.execute(
                "SELECT * FROM projects WHERE id=?", (project_id,)
            ).fetchone()
            if project_row is None:
                raise ValueError("پرونده انتخاب‌شده در پایگاه داده وجود ندارد.")
            project = dict(project_row)

            wp_cols = self._columns(conn, "workpapers")
            finding_cols = self._columns(conn, "findings")
            test_cols = self._columns(conn, "audit_tests")
            program_cols = self._columns(conn, "audit_programs")
            evidence_cols = self._columns(conn, "finding_evidence")

            workpapers = self._rows(
                conn, "SELECT * FROM workpapers WHERE project_id=? ORDER BY id", (project_id,)
            ) if wp_cols else []
            findings = self._rows(
                conn, "SELECT * FROM findings WHERE project_id=? ORDER BY id", (project_id,)
            ) if finding_cols else []
            risks = self._rows(
                conn, "SELECT * FROM risks WHERE project_id=? ORDER BY id", (project_id,)
            ) if self._table_exists(conn, "risks") else []
            programs = self._rows(
                conn, "SELECT * FROM audit_programs WHERE project_id=? ORDER BY id", (project_id,)
            ) if program_cols else []
            tests = self._rows(
                conn, "SELECT * FROM audit_tests WHERE project_id=? ORDER BY id", (project_id,)
            ) if test_cols else []
            evidence = self._rows(
                conn, "SELECT * FROM finding_evidence WHERE project_id=? ORDER BY id", (project_id,)
            ) if evidence_cols else []
            samples = self._rows(
                conn, "SELECT * FROM audit_test_samples WHERE project_id=? ORDER BY test_id, sample_no", (project_id,)
            ) if self._table_exists(conn, "audit_test_samples") else []

            trial_balance = self._rows(
                conn, "SELECT * FROM trial_balance WHERE project_id=? ORDER BY account_code, account_name", (project_id,)
            ) if self._table_exists(conn, "trial_balance") else []

            evidence_by_finding = {}
            for item in evidence:
                evidence_by_finding.setdefault(item.get("finding_id"), []).append(item)
            samples_by_test = {}
            for item in samples:
                samples_by_test.setdefault(item.get("test_id"), []).append(item)

            checks = []
            unlinked_wp = [w for w in workpapers if "risk_id" in wp_cols and not w.get("risk_id")]
            checks.append(self._check(
                "WP_NO_RISK", "کاربرگ بدون ارتباط با ریسک", "متوسط",
                [{"id": w.get("id"), "title": w.get("title"), "detail": "ریسک مرتبط تعیین نشده است"} for w in unlinked_wp],
                "ریسک مرتبط با هر کاربرگ را تعیین و ارتباط آن را بازبینی کنید.",
            ))

            covered_risk_ids = {w.get("risk_id") for w in workpapers if w.get("risk_id")}
            risks_without_workpapers = [r for r in risks if r.get("id") not in covered_risk_ids]
            checks.append(self._check(
                "RISK_NO_WORKPAPER", "ریسک فاقد کاربرگ رسیدگی", "متوسط",
                [{"id": r.get("id"), "title": r.get("title"), "detail": f"امتیاز ریسک: {r.get('score')}"} for r in risks_without_workpapers],
                "برای هر ریسک، پاسخ حسابرسی و کاربرگ متناسب تعریف کنید یا دلیل عدم رسیدگی را مستند سازید.",
            ))

            unassigned_wp = [w for w in workpapers if "assigned_member_id" in wp_cols and not w.get("assigned_member_id")]
            checks.append(self._check(
                "WP_UNASSIGNED", "کاربرگ بدون مسئول", "متوسط",
                [{"id": w.get("id"), "title": w.get("title"), "detail": "عضو مسئول تعیین نشده است"} for w in unassigned_wp],
                "برای هر کاربرگ، حسابرس مسئول تعیین کنید.",
            ))

            pending_wp = [w for w in workpapers if not self._is_approved(w.get("status")) and self._norm(w.get("status")) not in self.CLOSED_STATUSES]
            checks.append(self._check(
                "WP_PENDING_APPROVAL", "کاربرگ‌های فاقد تأیید نهایی", "بالا",
                [{"id": w.get("id"), "title": w.get("title"), "detail": f"وضعیت: {w.get('status') or 'نامشخص'}"} for w in pending_wp],
                "کاربرگ‌های ناتمام را تکمیل و برای بررسی و تأیید ارسال کنید.",
            ))

            unlinked_findings = [f for f in findings if "workpaper_id" in finding_cols and not f.get("workpaper_id")]
            checks.append(self._check(
                "FINDING_NO_WP", "یافته بدون کاربرگ پشتیبان", "بالا",
                [{"id": f.get("id"), "title": f.get("title"), "detail": "کاربرگ مرتبط ثبت نشده است"} for f in unlinked_findings],
                "یافته را به کاربرگ مربوط متصل کنید یا علت نبود کاربرگ را مستند کنید.",
            ))

            no_evidence = [f for f in findings if not evidence_by_finding.get(f.get("id"))]
            checks.append(self._check(
                "FINDING_NO_EVIDENCE", "یافته فاقد مستند پشتیبان", "بالا",
                [{"id": f.get("id"), "title": f.get("title"), "detail": f"اهمیت: {f.get('severity') or 'نامشخص'} | وضعیت: {f.get('status') or 'نامشخص'}"} for f in no_evidence],
                "برای هر یافته، مستندات کافی ثبت کنید؛ در صورت عدم امکان، محدودیت را در پرونده توضیح دهید.",
            ))

            missing_files = []
            for ev in evidence:
                raw_path = str(ev.get("file_path") or "").strip()
                try:
                    file_exists = bool(raw_path) and Path(raw_path).exists()
                except (OSError, ValueError):
                    file_exists = False
                if not file_exists:
                    missing_files.append({
                        "id": ev.get("id"),
                        "title": f"مستند یافته شماره {ev.get('finding_id')}",
                        "detail": f"مسیر نامعتبر یا فایل در دسترس نیست: {raw_path or 'ثبت نشده'}",
                    })
            checks.append(self._check(
                "EVIDENCE_FILE_MISSING", "فایل مستندات در مسیر ثبت‌شده موجود نیست", "بالا",
                missing_files,
                "مسیر فایل را اصلاح کنید یا نسخه معتبر مستند را دوباره ثبت کنید.",
            ))

            invalid_risks = []
            for risk in risks:
                try:
                    numeric_score = float(risk.get("score"))
                    valid_score = numeric_score.is_integer() and 1 <= numeric_score <= 25
                except (TypeError, ValueError):
                    valid_score = False
                if not valid_score:
                    invalid_risks.append(risk)
            checks.append(self._check(
                "RISK_SCORE_INVALID", "امتیاز ریسک خارج از دامنه مجاز", "بالا",
                [{"id": r.get("id"), "title": r.get("title"), "detail": f"امتیاز ثبت‌شده: {r.get('score')}"} for r in invalid_risks],
                "امتیاز ریسک را بر اساس روش ارزیابی مصوب در دامنه ۱ تا ۲۵ اصلاح کنید.",
            ))

            unlinked_programs = [p for p in programs if "risk_id" in program_cols and not p.get("risk_id")]
            checks.append(self._check(
                "PROGRAM_NO_RISK", "برنامه حسابرسی بدون ریسک مرتبط", "متوسط",
                [{"id": p.get("id"), "title": p.get("title"), "detail": "ریسک مرتبط تعیین نشده است"} for p in unlinked_programs],
                "برنامه حسابرسی را به ریسک مربوط متصل کنید.",
            ))

            unlinked_program_workpapers = [
                p for p in programs
                if "workpaper_id" in program_cols and not p.get("workpaper_id")
            ]
            checks.append(self._check(
                "PROGRAM_NO_WORKPAPER", "برنامه حسابرسی بدون کاربرگ مرتبط", "متوسط",
                [{"id": p.get("id"), "title": p.get("title"), "detail": "کاربرگ مرتبط ثبت نشده است"} for p in unlinked_program_workpapers],
                "برای برنامه‌های حسابرسی، کاربرگ متناظر را ایجاد یا متصل کنید.",
            ))

            no_sample_tests = [t for t in tests if not samples_by_test.get(t.get("id"))]
            tests_without_workpapers = [
                t for t in tests
                if "workpaper_id" in test_cols and not t.get("workpaper_id")
            ]
            checks.append(self._check(
                "TEST_NO_WORKPAPER", "آزمون حسابرسی بدون کاربرگ مرتبط", "متوسط",
                [{"id": t.get("id"), "title": t.get("title"), "detail": "کاربرگ پشتیبان آزمون ثبت نشده است"} for t in tests_without_workpapers],
                "آزمون را به کاربرگ مربوط متصل کنید تا مستندات و نتیجه رسیدگی در پرونده قابل ردیابی باشد.",
            ))

            checks.append(self._check(
                "TEST_NO_SAMPLES", "آزمون حسابرسی فاقد نمونه", "بالا",
                [{"id": t.get("id"), "title": t.get("title"), "detail": f"تعداد نمونه برنامه‌ریزی‌شده: {t.get('sample_size', 0)}"} for t in no_sample_tests],
                "جامعه و حجم نمونه را مشخص و نمونه‌ها را ایجاد کنید؛ اگر آزمون بدون نمونه است، مبنای آن را مستند کنید.",
            ))

            incomplete_tests = []
            untested_samples = []
            for test in tests:
                test_samples = samples_by_test.get(test.get("id"), [])
                pending_samples = [s for s in test_samples if self._norm(s.get("result")) in {"", "رسیدگی نشده", "رسیدگی نشده است"}]
                untested_samples.extend([
                    {"id": s.get("id"), "title": f"آزمون {test.get('title')} - نمونه {s.get('sample_no')}", "detail": "نتیجه رسیدگی ثبت نشده است"}
                    for s in pending_samples
                ])
                expected = int(test.get("sample_size") or 0)
                if not test_samples or pending_samples or (expected and len(test_samples) < expected):
                    incomplete_tests.append({
                        "id": test.get("id"), "title": test.get("title"),
                        "detail": f"نمونه ایجادشده: {len(test_samples)} از {expected} | رسیدگی‌نشده: {len(pending_samples)}",
                    })
            checks.append(self._check(
                "TEST_INCOMPLETE", "آزمون‌های حسابرسی ناتمام", "بالا",
                incomplete_tests,
                "نمونه‌های برنامه‌ریزی‌شده را ایجاد کنید و نتیجه رسیدگی هر نمونه را ثبت کنید.",
            ))
            checks.append(self._check(
                "SAMPLE_UNTESTED", "نمونه‌های فاقد نتیجه رسیدگی", "بالا",
                untested_samples,
                "برای هر نمونه نتیجه، شرح استثنا و در صورت لزوم مستند پشتیبان ثبت کنید.",
            ))

            pending_tests = [t for t in tests if not self._is_approved(t.get("status"))]
            checks.append(self._check(
                "TEST_PENDING_APPROVAL", "آزمون‌های فاقد تأیید نهایی", "بالا",
                [{"id": t.get("id"), "title": t.get("title"), "detail": f"وضعیت: {t.get('status') or 'نامشخص'}"} for t in pending_tests],
                "نتیجه‌گیری آزمون را تکمیل و گردش تأیید سرپرست و مدیر را طی کنید.",
            ))

            high_risk_without_workpaper = []
            wp_risk_ids = {w.get("risk_id") for w in workpapers if w.get("risk_id")}
            for risk in risks:
                try:
                    score = int(risk.get("score") or 0)
                except (TypeError, ValueError):
                    score = 0
                if score >= 15 and risk.get("id") not in wp_risk_ids:
                    high_risk_without_workpaper.append({
                        "id": risk.get("id"), "title": risk.get("title"),
                        "detail": f"امتیاز ریسک: {score} | کاربرگ مرتبط ندارد",
                    })
            checks.append(self._check(
                "HIGH_RISK_NO_WP", "ریسک بااهمیت فاقد کاربرگ رسیدگی", "بحرانی",
                high_risk_without_workpaper,
                "برای ریسک‌های با امتیاز ۱۵ و بیشتر، پاسخ حسابرسی و کاربرگ پشتیبان تعریف کنید.",
            ))

            flagged_accounts = [
                row for row in trial_balance if str(row.get("flags") or "").strip()
            ]
            checks.append(self._check(
                "TRIAL_BALANCE_FLAGS", "حساب‌های دارای پرچم یا هشدار در تراز آزمایشی", "بالا",
                [{"id": row.get("id"), "title": row.get("account_name"), "detail": str(row.get("flags") or "")} for row in flagged_accounts],
                "موارد پرچم‌گذاری‌شده را بررسی و نتیجه رسیدگی را در کاربرگ مربوط مستند کنید.",
            ))

            def safe_amount(value):
                try:
                    return float(value or 0)
                except (TypeError, ValueError):
                    return 0.0

            total_debit = sum(safe_amount(row.get("debit")) for row in trial_balance)
            total_credit = sum(safe_amount(row.get("credit")) for row in trial_balance)
            tb_difference = total_debit - total_credit
            tb_imbalance_items = []
            if trial_balance and abs(tb_difference) > 0.01:
                tb_imbalance_items.append({
                    "id": "-", "title": "اختلاف جمع بدهکار و بستانکار",
                    "detail": f"جمع بدهکار: {total_debit:,.2f} | جمع بستانکار: {total_credit:,.2f} | اختلاف: {tb_difference:,.2f}",
                })
            checks.append(self._check(
                "TRIAL_BALANCE_UNBALANCED", "تراز آزمایشی نامتوازن", "بحرانی",
                tb_imbalance_items,
                "علت اختلاف جمع بدهکار و بستانکار را بررسی و تراز اصلاح‌شده را مجدداً وارد کنید.",
            ))

            metrics = {
                "projects": 1,
                "risks": len(risks),
                "audit_programs": len(programs),
                "workpapers": len(workpapers),
                "findings": len(findings),
                "audit_tests": len(tests),
                "samples": len(samples),
                "evidence": len(evidence),
                "accounts": len(trial_balance),
                "trial_balance_flagged_accounts": len(flagged_accounts),
                "trial_balance_difference": round(tb_difference, 2),
                "workpapers_approved": sum(1 for w in workpapers if self._is_approved(w.get("status"))),
                "tests_approved": sum(1 for t in tests if self._is_approved(t.get("status"))),
                "open_findings": sum(1 for f in findings if self._norm(f.get("status")) not in self.CLOSED_STATUSES),
            }

        finally:
            conn.close()

        issue_count = sum(c["count"] for c in checks)
        critical_count = sum(c["count"] for c in checks if c["severity"] == "بحرانی")
        high_count = sum(c["count"] for c in checks if c["severity"] == "بالا")
        medium_count = sum(c["count"] for c in checks if c["severity"] == "متوسط")
        return {
            "project": project,
            "project_id": project_id,
            "generated_at": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "metrics": metrics,
            "checks": checks,
            "summary": {
                "issue_count": issue_count,
                "critical_count": critical_count,
                "high_count": high_count,
                "medium_count": medium_count,
                "passed_checks": sum(1 for c in checks if c["count"] == 0),
                "total_checks": len(checks),
            },
        }
