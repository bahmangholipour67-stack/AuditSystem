import math
from collections import Counter
from services.number_utils import parse_amount

def analyze(values):
    digits=[]
    for line_number, entry in enumerate(values, start=1):
        if str(entry).strip()=="": continue
        try: number=parse_amount(entry)
        except ValueError as exc: raise ValueError(f"خط {line_number}: {exc}") from exc
        if number==0: continue
        digits.append(int(str(abs(number)).lstrip("0.")[0]))
    if len(digits)<20:
        raise ValueError("حداقل ۲۰ مبلغ غیرصفر لازم است؛ برای تفسیر قابل‌اتکاتر، جامعه بزرگ‌تر و مناسب بنفورد انتخاب کنید.")
    counts=Counter(digits); total=len(digits); rows=[]; deviations=[]
    for digit in range(1,10):
        actual=counts[digit]/total*100
        expected=math.log10(1+1/digit)*100
        difference=actual-expected; deviations.append(abs(difference))
        rows.append({"digit":digit,"count":counts[digit],"actual":actual,"expected":expected,"difference":difference})
    return {"count":total,"mad":sum(deviations)/9,"rows":rows,
            "warning":"این خروجی اثبات تقلب نیست؛ ابتدا تناسب جامعه با قانون بنفورد بررسی شود."}
