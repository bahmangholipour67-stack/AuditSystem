"""Phase 42: read-only risk heatmap and inherent/residual risk analytics."""

class RiskHeatmapService:
    """Build 5x5 risk matrices from supplied records; never writes data.

    Each record is a mapping with title, likelihood, impact and optional inherent_
    likelihood/inherent_impact, residual_likelihood/residual_impact. Scores are
    products of likelihood and impact. Missing residual values are not inferred.
    """
    LEVELS = ("کم", "متوسط", "زیاد", "بحرانی")

    @staticmethod
    def _rating(value, field):
        try:
            n = int(value)
        except (TypeError, ValueError):
            raise ValueError(f"{field} باید عدد صحیح بین ۱ تا ۵ باشد.")
        if not 1 <= n <= 5:
            raise ValueError(f"{field} باید بین ۱ تا ۵ باشد.")
        return n

    @classmethod
    def score(cls, likelihood, impact):
        return cls._rating(likelihood, "احتمال") * cls._rating(impact, "اثر")

    @staticmethod
    def level(score):
        score = int(score)
        if score >= 16:
            return "بحرانی"
        if score >= 10:
            return "زیاد"
        if score >= 5:
            return "متوسط"
        return "کم"

    @classmethod
    def matrix(cls, records, *, likelihood_key="likelihood", impact_key="impact"):
        """Return counts for all 25 cells and ignore invalid records safely."""
        cells = {(l, i): 0 for l in range(1, 6) for i in range(1, 6)}
        accepted = []
        for record in records or ():
            if not isinstance(record, dict):
                continue
            try:
                likelihood = cls._rating(record.get(likelihood_key), "احتمال")
                impact = cls._rating(record.get(impact_key), "اثر")
            except ValueError:
                continue
            score = likelihood * impact
            item = dict(record)
            item.update({"likelihood": likelihood, "impact": impact, "score": score, "level": cls.level(score)})
            cells[(likelihood, impact)] += 1
            accepted.append(item)
        return {"cells": cells, "risks": accepted, "total": len(accepted)}

    @classmethod
    def compare_inherent_residual(cls, records):
        """Compare only explicit inherent/residual ratings; do not infer controls."""
        result = []
        for record in records or ():
            if not isinstance(record, dict):
                continue
            try:
                il = cls._rating(record.get("inherent_likelihood"), "احتمال ذاتی")
                ii = cls._rating(record.get("inherent_impact"), "اثر ذاتی")
                rl = cls._rating(record.get("residual_likelihood"), "احتمال باقیمانده")
                ri = cls._rating(record.get("residual_impact"), "اثر باقیمانده")
            except ValueError:
                continue
            inherent = il * ii
            residual = rl * ri
            result.append({"title": str(record.get("title", "")),
                          "inherent_score": inherent, "inherent_level": cls.level(inherent),
                          "residual_score": residual, "residual_level": cls.level(residual),
                          "score_difference": inherent - residual})
        return sorted(result, key=lambda row: (-row["residual_score"], row["title"]))

    @classmethod
    def filter_cell(cls, records, likelihood, impact, *, likelihood_key="likelihood", impact_key="impact"):
        likelihood = cls._rating(likelihood, "احتمال")
        impact = cls._rating(impact, "اثر")
        matches = []
        for record in records or ():
            if not isinstance(record, dict):
                continue
            try:
                l = cls._rating(record.get(likelihood_key), "احتمال")
                i = cls._rating(record.get(impact_key), "اثر")
            except ValueError:
                continue
            if (l, i) == (likelihood, impact):
                item = dict(record)
                item["score"] = l * i
                item["level"] = cls.level(l * i)
                matches.append(item)
        return matches
