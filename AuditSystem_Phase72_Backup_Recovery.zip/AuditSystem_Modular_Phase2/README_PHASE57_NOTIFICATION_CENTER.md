# Phase 57 – Audit Notification & Reminder Center

## Scope
Adds a read-only, rule-based in-app notification center to the management dashboard. Notifications are derived from the existing Phase 56 task snapshot and include overdue items, items approaching their due date (configurable 0–90 day window), and pending approval/workpaper actions.

## Behavior and safeguards
- Uses existing task records only; no database schema, tables, migrations, or notification history are added.
- Does not change task statuses, approvals, workpapers, findings, or evidence.
- Project scoping follows the existing TaskCenterService behavior.
- Notifications are recalculated on dashboard refresh or when the user refreshes the notification panel.
- No OS-level popups or automatic background polling are enabled; this avoids intrusive alerts and hidden database activity.

## Validation
- Python compileall: passed.
- Full test suite: see TEST_REPORT_PHASE57.md.
- ZIP integrity: verified after packaging.
- Windows GUI visual verification: not performed in this environment.

## Files added/changed
- `services/notification_center_service.py` (new)
- `ui/views/dashboard_view.py` (notification center integration)
- `tests/test_phase57_notification_center.py` (new regression tests)
